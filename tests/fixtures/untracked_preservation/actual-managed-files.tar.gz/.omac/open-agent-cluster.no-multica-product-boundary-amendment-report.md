# Remove Multica concepts from the OAC product amendment

## Trigger

- Manifest: `.omac/open-agent-cluster.yaml`
- Rejected human-confirmation issue: `07e54f21-a799-4725-8404-3b81b9986a8a` (`AITEAM-844`)
- Rejected amendment: `amend-572ed84390dc`
- Blocked delivery node: `contracts-platform-resource`
- Existing implementation: OAC PR #8 at `66efa82f66bdd763e25355d7bef9da95841b5bb1`

The reviewed amendment is not acceptable at the human gate because it lets the
development-control platform leak into the Open Agent Cluster product repository.
Multica and OMAC may orchestrate OAC development, but they are not OAC product
concepts, runtime dependencies, public contracts, persisted facts, or source-code
authorities.

## Hard product boundary

The replacement amendment must not add any OAC repository artifact whose product
meaning or execution depends on Multica or OMAC, including:

- Multica Issue, Comment, Attachment, Project Lead, workspace, project, repository
  resource, Agent Run, selector, uploader, or task identities;
- Multica-specific approval request/envelope schemas;
- scripts that query, select, replay, or verify Multica comments or attachments;
- OMAC plan, manifest, work-item, review-ledger, or confirmation metadata as an OAC
  product contract;
- a second approval state machine implemented inside OAC merely to reproduce the
  human confirmation already owned by OMAC.

OMAC and Multica evidence may remain in the amendment audit trail. It must not be
materialized into OAC product source paths, product schemas, APIs, runtime behavior,
or authoritative design terminology.

## Required replacement

Preserve the valid acyclic Platform Resource decomposition, PR #8 migration map,
acceptance matrix, stable final conformance node, downstream gating, and minimum
runtime recovery set from AITEAM-844. Replace only the authority/approval portion.

Use the current amendment human-confirmation gate as the single explicit product
approval for Kernel Contract Schema v1:

1. The amendment itself must state the complete proposed platform-neutral Kernel
   Contract Schema v1 profile, including every exact limit value, relation key,
   canonicalization rule, digest domain, version rule, and unknown-field behavior.
2. Bind that complete profile to a stable content digest in the amendment. Human
   acceptance of the amendment is approval of that exact profile and digest.
3. Add at most one platform-neutral `contracts-kernel-schema-v1` delivery node. It
   may write only the final approved machine-readable schema, the owning Reference
   document, and the smallest validators/compatibility tests required by the
   product contract.
4. Do not add a separate project-lead approval protocol node or any approval
   request/envelope/selection/replay implementation to OAC.
5. The schema node and every dependent Platform Resource or Kernel node must refer
   only to OAC domain terminology and authoritative OAC docs.
6. If the complete exact profile cannot be determined and presented for this
   human-confirmation gate, stop for a product decision instead of inventing values
   or adding another workflow.

## Kernel Contract Schema v1 product profile decision

The project owner delegated selection of practical v1 bounds on 2026-08-02. Use
the following exact positive integer values. They are product contract values,
not environment settings, Solution parameters, Runtime-provider settings, or
Multica/OMAC configuration:

| key | exact value |
| --- | ---: |
| `max_canonical_request_bytes` | 65536 |
| `max_objective_bytes` | 2048 |
| `max_display_name_bytes` | 128 |
| `max_display_description_bytes` | 1024 |
| `max_inputs` | 16 |
| `max_input_display_name_bytes` | 128 |
| `max_input_display_description_bytes` | 512 |
| `max_computational_guides` | 8 |
| `max_inferential_guides` | 8 |
| `max_prior_conclusions` | 8 |
| `max_feedback` | 16 |
| `max_allowed_actions` | 32 |

These values reflect the actual OAC storage and execution boundary:

- an `InvocationRequest` is one Run's control envelope, not the whole Plan or DAG;
- multiple active Runs retain their complete bounded requests concurrently in the
  Workflow CR, so the per-Run hard limit is 64 KiB rather than 128/256 KiB;
- objective and display text remain short control-plane descriptions;
- input bodies, large Contract/Schema content, Guide bodies, Review evidence,
  logs, code and binaries remain in their existing immutable stores and are read
  through typed resource identity plus digest;
- work needing more than sixteen independent inputs, eight guides of either kind,
  or thirty-two admitted actions is too broad for one independently reviewable
  WorkUnit and must aggregate content behind an owned typed resource or be
  replanned, not receive a larger ad-hoc limit;
- the final RFC 8785 JCS UTF-8 byte count is an independent hard gate even when
  every individual field/count limit passes.

The replacement amendment must embed these exact values together with the seven
already identified relation keys, RFC 8785 JCS UTF-8 canonicalization, SHA-256
digest rules, exact `oac.kernel-contract/v1` version behavior, unknown-field
rejection and unknown-version rejection. It must show the complete canonical
profile and its digest before human confirmation. Orchestrator and delivery Agents
must not tune, infer, increase, or make these values configurable.

## Reviewer requirements

Reviewer must explicitly verify that:

1. no changed OAC product path, description, command, schema, or source reference
   contains Multica/OMAC development-platform semantics;
2. there is no duplicate approval state machine in OAC;
3. the complete Kernel Schema v1 profile and digest are visible in the amendment
   before human confirmation, not deferred to a future Agent task;
4. the final schema publication node is platform-neutral and minimal;
5. the acyclic independently buildable Platform Resource split and exact PR #8
   migration remain valid;
6. no existing product boundary, acceptance responsibility, completed runtime fact,
   or unrelated node is weakened or reset.

## Non-goals

- Do not implement product code in this amendment.
- Do not edit the live manifest directly.
- Do not add generic OAC approval infrastructure.
- Do not relax the missing-authority blocker by choosing undocumented values without
  presenting them for explicit human confirmation.
