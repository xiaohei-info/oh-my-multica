# Convergence rework recovery request

Coordinator request under existing user authorization to advance original DAG tasks and restore exhausted budgets after cause addressed. Do not use plan create. Do not change product contract or accept rejected work.

Node contracts-platform-resource-convergence, issue01a0e28c-0705-7851-940d-c12b4eebad50, PR85. Fresh work show has worker20/review1/merge0 and four required_closures below. Prior worker repeatedly reused an old session and treated an old submission as completion instead of implementing these closures. No OMAC regression was established. Request independent OMAC amendment planning/review of minimal recovery with an alternative configured worker, explicit fresh work-show/current reject handoff, preservation of PR/workspace/evidence and absolute counters; do not hand-write baselines or raise limits. Verify full current ledger and supported recovery semantics; do not treat previous_review=null after exhaustion as proof the original feedback was absent. Derive exact authorized baseline from actual counters only through normal accept, if recovery needs it. This is ordinary rework, not permission to redesign product. Existing user allows budget restoration after root cause addressed, not repeated same-session empty retries.

Fresh required closures (verbatim from work show):

[
  {
    "blocker_id": "BLK-5011ae2f1248",
    "obligation_id": "dimension:structure",
    "root_cause_key": "child-workflow-outcome-not-bound-to-invoked-child",
    "summary": "Any WorkflowOutcome Observation for any named Workflow can complete a successful child-workflow WorkUnit.",
    "required_fix": "Bind the confirmed output to the exact dispatched child Workflow identity and validated terminal WorkflowOutcome (and expected terminal state) via the existing child-link/immutable evidence boundary; test wrong child, wrong outcome and absent link."
  },
  {
    "blocker_id": "BLK-734ff9f8c480",
    "obligation_id": "dimension:evidence",
    "root_cause_key": "activation-evidence-not-reconciled-to-immutable-facts",
    "summary": "An activated WorkUnit can use an embedded Decision or GateResult different from the supplied immutable fact.",
    "required_fix": "At aggregate validation, reconcile each activated unit's embedded Decision or GateResult with the exact supplied immutable fact (including identity, digest, outcome and relevant owner), rejecting missing, mismatched or ambiguous matches; cover both kinds with cross-fact tests."
  },
  {
    "blocker_id": "BLK-a51307449a39",
    "obligation_id": "dimension:execution",
    "root_cause_key": "failed-terminal-primary-execution-unproved",
    "summary": "Terminal failed/abandoned WorkUnits skip primary execution closure altogether.",
    "required_fix": "For terminal activated WorkUnits that actually began execution, require their primary execution's exact terminal report and the applicable immutable failure/decision evidence, while retaining legitimate never-dispatched cancellation/obsolete cases; add failed-path tests."
  },
  {
    "blocker_id": "BLK-b0041f40e6e5",
    "obligation_id": "dimension:execution",
    "root_cause_key": "primary-run-conclusion-not-attributed-to-current-run",
    "summary": "Successful full primary Runs accept a run-conclusion Observation without evidence that this Run produced or referenced it.",
    "required_fix": "For full Runs, require a typed immutable report/submission or history link to the exact conclusion ID/digest for that Run, just as compressed result references are linked; cover stale same-subject conclusions."
  }
]

Current Harness stop-policy amendment is active. This report is queued preparation only; do not launch concurrently. Preserve all56 done nodes.
