# Harness SDK contract consistency amendment request

Observed after OMAC 3f1eeaa repaired delivery collection. PR73 entered review and received five current blockers. This request is NOT a budget-only amendment.

Current objective/non-goals forbid SDK-owned or test-only Host authority issuance and require SDK-boundary negative-only Host/Gate evidence, leaving genuine positive Host-installed evidence to harness-host. However the same current contract still requires valid_service_mode_invocation_accept_count=2, positive Host producer test names and positive Trigger/EventHandler fixtures without a defined non-authoritative fixture boundary. The Worker repeatedly stopped on this contradiction. Inspect the entire current contract and owning design before deciding which exact assertions conflict; preserve ordinary non-authority positive operation tests where legitimate.

Requested minimal correction: align every verification command, integration gate, exact metric and evidence scope with the already approved SDK consumer versus Host producer boundary. Do not weaken real response/schema, unknown-outcome, full identity, provenance, receipt or replay checks. Keep genuine Host positive conformance downstream and explicitly identify its owning artifact/dependency. Do not introduce SDK-local authority bridges or make unavailable upstream evidence look passed. No new architecture or scope expansion. If design authority does not support a correction, report the decision instead of silently changing boundaries. Keep done nodes unchanged. Require authoring recovery for this rejected SDK delivery; compute only necessary started downstream recovery through normal OMAC machinery.

Current review required closures:

[
  {
    "blocker_id": "BLK-00834908b018",
    "obligation_id": "dimension:regression",
    "root_cause_key": "typed-extension-invalid-response-accepted-receipt",
    "summary": "Typed Guide/Sensor/Trigger/EventHandler receipt is accepted before response and schema validation.",
    "required_fix": "Complete response and output-schema validation before issuing an accepted receipt; issue a rejected/failed measured receipt on invalid results and preserve a separate business failure outcome for valid error envelopes. Add conformance assertions that erroneous responses cannot yield accepted receipts."
  },
  {
    "blocker_id": "BLK-0ad5e6d07e71",
    "obligation_id": "dimension:evidence",
    "root_cause_key": "sdk-owned-test-host-authority-bridge",
    "summary": "SDK-local fixtures mint trusted Host scopes and report them as measured Host authority.",
    "required_fix": "Delete SDK-owned/same-package Host authority issuance bridges. Keep SDK fixtures limited to fail-closed consumer assertions with measured rejection; source positive authenticated handoffs only from the downstream Host-owned producer when that evidence becomes available, without claiming them in SDK-local metrics."
  },
  {
    "blocker_id": "BLK-64e3bc19728b",
    "obligation_id": "integration:harness-sdk-gate",
    "root_cause_key": "gate-host-ingress-unimplementable",
    "summary": "Gate consumer API is an unconditional rejecting stub with no usable Host-facing handoff ingress.",
    "required_fix": "Define a package-neutral opaque Host ingress contract that a separately owned producer can satisfy, binding exact release, policy, operation, request scope and evaluator identity without letting an ExtensionPackage mint a binding. Preserve negative-only SDK-local verification; the genuine positive test stays downstream."
  },
  {
    "blocker_id": "BLK-a162a5643d17",
    "obligation_id": "dimension:execution",
    "root_cause_key": "optional-unknown-failure-skipped",
    "summary": "Optional failure policy skips an error even when external outcome is not known.",
    "required_fix": "Require a known failure outcome before classifying an optional side-effecting binding as skipped; preserve Unknown and demand observation/recovery otherwise. Cover unknown and unstructured error paths with measured tests."
  },
  {
    "blocker_id": "BLK-ddc68ddec4ac",
    "obligation_id": "dimension:authority",
    "root_cause_key": "caller-selectable-service-host-ingress",
    "summary": "Public service verifier is supplied by the caller, so matching descriptive fields are treated as Host authentication.",
    "required_fix": "Remove the caller-selectable authentication provider from the public authority path. Define a Host-owned, non-extension-constructible provenance/ingress handoff with verification and replay handled by harness-host, then consume that opaque result and test rejection of caller-supplied but internally consistent handoffs."
  }
]

Current complete contract snapshot (for evidence, manifest remains authority):

{
  "objective": "Deliver the complete protocol-neutral public harness.oac.dev/v1 SDK boundary with typed Describe, execute, observe, cancel, result, and error unions; preserve exact Package/entrypoint, Extension/binding, operation, owner, subject, scope, request digest, and service payload digest through every public binding path. Remove every public authority constructor that lets a caller choose both Host signing and trust verification inputs, and expose only the package-neutral consumer/verification side of opaque service and Gate handoffs. The SDK must define a usable Host-facing ingress contract without implementing the Host producer: arbitrary callers and ExtensionPackages must be unable to mint an authoritative RequestScope, GateEvaluatorBinding, receipt, or evaluator invocation. Replace the obsolete missing-symbol regression with a structurally valid attempt against the current public API and prove zero binding, receipt, and evaluator calls. Remove all SDK-owned or same-package test-only Host authority bridges. Every SDK-local fixture must emit source-revision-bound measured evidence for its exact scoped assertion; the Gate consumer row may pass only by proving the negative boundary, must report registered_gate_positive_path_count=0 and authoritative_gate_positive_claim_count=0, and must identify its scope as sdk-boundary rather than representing full Host-backed Gate conformance. Produce harness-sdk-boundary-evidence for the downstream harness-host producer. Preserve typed operation-schema validation, successful Trigger/EventHandler, bounded offline schema resolution, Required/Optional behavior, Unknown recovery, safe retry/cancel, coverage, race, vet, and deterministic sdk/harness packaging. The mandatory genuine Host-installed positive path and final combined semantic verdict remain downstream responsibilities of harness-host and contracts-extension.",
  "non_goals": [
    "Do not implement production Harness Host provisioning, signer/trust-root selection, installer-owned Package records, Platform Core repositories, Workflow persistence, Kubernetes workloads, persisted recovery records, or EventHandler lineage in this SDK; harness-host owns the actual producer and genuine positive path.",
    "Do not retain NewHostScopeIssuer/NewHostTrustStore-style public authority composition that treats a caller-selected signer, key resolver, replay guard, provider, callable, literal marker, or same-package test fixture as Host provenance.",
    "Do not construct a Host service or Gate handoff through sdk/harness/internal or a test-only bridge, and do not claim a negative-only SDK row as the real registered Host positive path.",
    "Do not expose a standalone caller-supplied Gate evaluator, accept extension-created handoffs, or treat repeated equal return values as sufficient purity or Host-origin evidence.",
    "Do not add a caller-supplied secret or key-material path, or expose attestation material without exact Package/entrypoint, Extension/binding, operation, owner, subject, scope, request digest, service payload digest, expiry, rotation, and replay binding.",
    "Do not create a second executor, lifecycle controller, persistence store, generic plugin runtime, universal invoke(any) path, authorization or admission engine, Package authority, state-write path, or Gate bypass.",
    "Do not let an ExtensionPackage omit, select, replace, weaken, or self-report mandatory SDK boundary fixtures; test-name presence, compile failure against a removed symbol, expected counters, helper-only predicates, or literal status values are not evidence.",
    "Do not resolve Describe-provided schemas through arbitrary file or network references, perform host-side I/O during schema validation, accept unbounded schema/payload size or depth, or convert an unknown external outcome into failure or retry permission.",
    "Do not change adjacent domain ownership, redefine contracts-extension-wire, move Harness decisions into Package Governance, Workflow, or a delivery adapter, or bypass Authorization, Execution Admission, CAS, idempotency, review, or evidence gates."
  ],
  "verification_commands": [
    "mkdir -p artifacts/harness-sdk && go test -covermode=atomic -coverprofile=artifacts/harness-sdk/coverage.out ./sdk/harness/...",
    "python3 -c \"from pathlib import Path; import re,subprocess; p=Path('artifacts/harness-sdk/coverage.out'); assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True); m=re.search(r'^total:\\s+[(]statements[)]\\s+([0-9.]+)%$',out,re.M); assert m and float(m.group(1)) >= 90\"",
    "mkdir -p artifacts/harness-sdk && go test -json ./sdk/harness/... -run '^(TestHarnessSDKDescribeAndTypedInvocationConformance|TestHarnessSDKObserveBeforeRetryAndCancelConformance|TestHarnessSDKPermissionAndFailureConformance|TestHarnessSDKRejectsSelfAttestedHostEvidence|TestHarnessSDKServiceModeInvocationEnvelopeConformance|TestHarnessSDKServiceModeRejectsMissingAttestation|TestHarnessSDKServiceModeRejectsAlteredAttestation|TestHarnessSDKServiceModeRejectsExpiredAttestation|TestHarnessSDKServiceModeRejectsReplayedAttestation|TestHarnessSDKServiceModeRejectsMismatchedScope|TestHarnessSDKServiceModeRejectsMismatchedDigest|TestHarnessSDKServiceModeRejectsMismatchedInvocationIdentity|TestHarnessSDKServiceModeKeyRotationConformance|TestHarnessSDKComputationalGuideMonotonicConformance|TestHarnessSDKInferentialGuideAppendOnlyConformance|TestHarnessSDKExecutorSideEffectLifecycleConformance|TestHarnessSDKComputationalSensorAppendOnlyConformance|TestHarnessSDKInferentialSensorAppendOnlyConformance|TestHarnessSDKTriggerConformance|TestHarnessSDKEventHandlerSideEffectLifecycleConformance|TestHarnessSDKRequiredOptionalFailureObservationConformance|TestHarnessSDKTargetBindingConformance|TestHarnessSDKRegisteredGateEvaluatorPurityFailClosedConformance|TestHarnessSDKTypeSpecificDescribeSchemaConformance|TestHarnessSDKTypedOperationAndPayloadBindingConformance|TestHarnessSDKGateEvaluatorRegistryProvenanceConformance|TestPublicExternalHostIssuesTransportsAndBindsTypedServiceInvocation|TestPublicHostReplayGuardSpansReceiversAndRestart|TestPublicHostTrustStoreRejectsIncompleteConfiguration)$' -count=1 > artifacts/harness-sdk/conformance-tests.json",
    "python3 -c \"import json; required=set('TestHarnessSDKDescribeAndTypedInvocationConformance TestHarnessSDKObserveBeforeRetryAndCancelConformance TestHarnessSDKPermissionAndFailureConformance TestHarnessSDKRejectsSelfAttestedHostEvidence TestHarnessSDKServiceModeInvocationEnvelopeConformance TestHarnessSDKServiceModeRejectsMissingAttestation TestHarnessSDKServiceModeRejectsAlteredAttestation TestHarnessSDKServiceModeRejectsExpiredAttestation TestHarnessSDKServiceModeRejectsReplayedAttestation TestHarnessSDKServiceModeRejectsMismatchedScope TestHarnessSDKServiceModeRejectsMismatchedDigest TestHarnessSDKServiceModeRejectsMismatchedInvocationIdentity TestHarnessSDKServiceModeKeyRotationConformance TestHarnessSDKComputationalGuideMonotonicConformance TestHarnessSDKInferentialGuideAppendOnlyConformance TestHarnessSDKExecutorSideEffectLifecycleConformance TestHarnessSDKComputationalSensorAppendOnlyConformance TestHarnessSDKInferentialSensorAppendOnlyConformance TestHarnessSDKTriggerConformance TestHarnessSDKEventHandlerSideEffectLifecycleConformance TestHarnessSDKRequiredOptionalFailureObservationConformance TestHarnessSDKTargetBindingConformance TestHarnessSDKRegisteredGateEvaluatorPurityFailClosedConformance TestHarnessSDKTypeSpecificDescribeSchemaConformance TestHarnessSDKTypedOperationAndPayloadBindingConformance TestHarnessSDKGateEvaluatorRegistryProvenanceConformance TestPublicExternalHostIssuesTransportsAndBindsTypedServiceInvocation TestPublicHostReplayGuardSpansReceiversAndRestart TestPublicHostTrustStoreRejectsIncompleteConfiguration'.split()); rows=[json.loads(x) for x in open('artifacts/harness-sdk/conformance-tests.json') if x.strip()]; passed={x.get('Test') for x in rows if x.get('Action')=='pass' and x.get('Test') in required}; assert passed==required, f'missing required passing tests: {sorted(required-passed)}'\"",
    "go test -json ./sdk/harness/... -run '^(TestHarnessSDKRetryProofBindsCompleteObserveScopeAndServicePayload|TestHarnessSDKTargetBindingIdentityMismatchesRejectWithoutImplementationCalls|TestPublicHostIssuerOutputCannotBindWithoutReceiverVerification|TestPublicGateEvaluatorRegistryRejectsCallerForgedHostCapability|TestHarnessSDKGateCapabilityBoundaryFailures|TestPublicVerifiedServiceGenericBindingRejectsAlternatePayload|TestHarnessSDKObserveSchemaRejectsInvalidPayloadWithoutImplementationCall|TestHarnessSDKCancelSchemaRejectsInvalidPayloadWithoutImplementationCall|TestHarnessSDKTriggerAndEventHandlerPositiveFixturesRejectErrorOnlyImplementations|TestHarnessSDKRejectsExternalSchemaReferencesWithoutIO|TestHarnessSDKBoundsSchemaPayloadSizeAndDepth|TestPublicGateEvaluationRejectsCallerSuppliedEvaluator|TestExternalPackageCannotForgeCurrentHostGateHandoff|TestHarnessSDKSemanticLedgerPreservesChildExecutionEvidence|TestHarnessSDKSemanticLedgerRejectsHelperOnlyOrLiteralPassRows)$' -count=1 >> artifacts/harness-sdk/conformance-tests.json",
    "python3 -c \"import json; required=set('TestHarnessSDKRetryProofBindsCompleteObserveScopeAndServicePayload TestHarnessSDKTargetBindingIdentityMismatchesRejectWithoutImplementationCalls TestPublicHostIssuerOutputCannotBindWithoutReceiverVerification TestPublicGateEvaluatorRegistryRejectsCallerForgedHostCapability TestHarnessSDKGateCapabilityBoundaryFailures TestPublicVerifiedServiceGenericBindingRejectsAlternatePayload TestHarnessSDKObserveSchemaRejectsInvalidPayloadWithoutImplementationCall TestHarnessSDKCancelSchemaRejectsInvalidPayloadWithoutImplementationCall TestHarnessSDKTriggerAndEventHandlerPositiveFixturesRejectErrorOnlyImplementations TestHarnessSDKRejectsExternalSchemaReferencesWithoutIO TestHarnessSDKBoundsSchemaPayloadSizeAndDepth TestPublicGateEvaluationRejectsCallerSuppliedEvaluator TestExternalPackageCannotForgeCurrentHostGateHandoff TestHarnessSDKSemanticLedgerPreservesChildExecutionEvidence TestHarnessSDKSemanticLedgerRejectsHelperOnlyOrLiteralPassRows'.split()); rows=[json.loads(x) for x in open('artifacts/harness-sdk/conformance-tests.json') if x.strip()]; passed={x.get('Test') for x in rows if x.get('Action')=='pass' and x.get('Test') in required}; assert passed==required, f'missing residual semantic regressions: {sorted(required-passed)}'\"",
    "HARNESS_SDK_SEMANTIC_EVIDENCE=\"$PWD/artifacts/harness-sdk/semantic-evidence.json\" go test -json ./sdk/harness/... -run '^TestHarnessSDKSemanticEvidenceConformance$' -count=1 >> artifacts/harness-sdk/conformance-tests.json",
    "python3 -c \"from pathlib import Path; import json,subprocess; p=Path('artifacts/harness-sdk/semantic-evidence.json'); assert p.is_file() and p.stat().st_size>0; d=json.loads(p.read_text()); assert d['schema']=='oac.harness-sdk-semantic-evidence/v1'; rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); assert d['source_revision']==rev; required={'typed-point-describe-contracts','service-host-authority','service-verified-generic-bind-payload','observe-input-schema','cancel-input-schema','trigger-positive-success','event-handler-positive-lifecycle','external-schema-reference-isolation','schema-size-depth-bounds','required-optional-failure-policy','unknown-recovery-retry-cancel','target-binding-identity','gate-evaluator-consumer-boundary'}; rows={x['fixture_id']:x for x in d['fixtures']}; assert required==set(rows); assert all(rows[k]['status']=='pass' and rows[k].get('execution_count')==1 and rows[k].get('accepted_count',0)+rows[k].get('rejected_count',0)>0 and rows[k].get('forbidden_accept_count')==0 and rows[k].get('forbidden_implementation_call_count')==0 and isinstance(rows[k].get('identity_evidence'),list) and any(str(x).startswith('target=') for x in rows[k]['identity_evidence']) and any(str(x).startswith('operation=') for x in rows[k]['identity_evidence']) and any(str(x).startswith('provenance=') for x in rows[k]['identity_evidence']) and rows[k].get('assertions') and rows[k].get('evidence_refs') for k in required); m=d['metrics']; assert m['required_current_amendment_semantic_fixture_count']==7; assert m['required_delivery_goal_semantic_fixture_count']==13; exact={'required_extension_point_fixture_count':7,'required_service_mode_fixture_count':15,'valid_service_mode_invocation_accept_count':2,'invalid_service_mode_invocation_accept_count':0,'malformed_type_specific_schema_accept_count':0,'missing_target_binding_accept_count':0,'missing_registered_gate_evaluator_accept_count':0,'required_optional_failure_observation_gap_count':0,'operation_mismatch_rejection_count':3,'altered_payload_rejection_count':7,'external_host_direct_bind_rejection_count':2,'event_handler_lifecycle_schema_negative_count':2,'gate_evaluator_provenance_fixture_count':7,'gate_evaluator_service_mode_rejection_count':2,'gate_evaluator_mismatched_release_rejection_count':1,'gate_evaluator_purity_rejection_count':1,'retry_scope_mismatch_rejection_count':4,'target_binding_identity_mismatch_fixture_count':56,'target_binding_package_id_mismatch_rejection_count':7,'target_binding_package_version_mismatch_rejection_count':7,'target_binding_entrypoint_mismatch_rejection_count':7,'target_binding_artifact_mismatch_rejection_count':7,'cross_receiver_replay_rejection_count':2}; assert all(m[k]==v for k,v in exact.items()); assert m['service_verified_generic_bind_alternate_payload_accept_count']==0; assert m['observe_schema_invalid_implementation_call_count']==0; assert m['cancel_schema_invalid_implementation_call_count']==0; assert m['trigger_error_only_positive_accept_count']==0; assert m['event_handler_error_only_positive_accept_count']==0; assert m['external_schema_reference_rejection_count']>=2; assert m['external_schema_resolution_io_attempt_count']==0; assert m['schema_size_limit_bypass_accept_count']==0; assert m['payload_size_limit_bypass_accept_count']==0; assert m['schema_depth_limit_bypass_accept_count']==0; assert m['payload_depth_limit_bypass_accept_count']==0; assert m['trigger_successful_response_count']>=1; assert m['event_handler_successful_lifecycle_operation_count']>=3; assert m['required_measured_semantic_row_count']==13; assert m['unregistered_gate_execution_accept_count']==0; assert m['sdk_owned_host_handoff_construction_count']==0; assert m['helper_only_semantic_fixture_accept_count']==0; assert m['literal_semantic_status_accept_count']==0; assert m['dropped_child_execution_evidence_count']==0\"",
    "mkdir -p artifacts/harness-sdk && go test -json ./sdk/harness/... -run '^(TestPublicHostAuthorityCannotBeSelectedByCaller|TestCurrentPublicGateForgeryRejectsWithoutBindingReceiptOrEvaluatorCall)$' -count=1 >> artifacts/harness-sdk/conformance-tests.json",
    "python3 -c \"import json; required={'TestPublicHostAuthorityCannotBeSelectedByCaller','TestCurrentPublicGateForgeryRejectsWithoutBindingReceiptOrEvaluatorCall'}; rows=[json.loads(x) for x in open('artifacts/harness-sdk/conformance-tests.json') if x.strip()]; passed={x.get('Test') for x in rows if x.get('Action')=='pass' and x.get('Test') in required}; assert passed==required, f'missing current-boundary regressions: {sorted(required-passed)}'\"",
    "python3 -c \"from pathlib import Path; import json; d=json.loads(Path('artifacts/harness-sdk/semantic-evidence.json').read_text()); m=d['metrics']; assert m['registered_gate_positive_path_count']==0; assert m['authoritative_gate_positive_claim_count']==0; assert d['evidence_scope']=='sdk-boundary'; rows={x['fixture_id']:x for x in d['fixtures']}; r=rows['gate-evaluator-consumer-boundary']; assert r['status']=='pass' and r.get('accepted_count',0)==0 and r.get('rejected_count',0)>0; assert r.get('forbidden_accept_count')==0 and r.get('forbidden_implementation_call_count')==0\"",
    "go vet ./sdk/harness/...",
    "CGO_ENABLED=1 go test -race ./sdk/harness/...",
    "python3 scripts/release/package_component.py --component harness-sdk --kind public-extension-sdk --input sdk/harness --bundle artifacts/harness-sdk/source-bundle.tar.zst --component-manifest artifacts/harness-sdk/component-manifest.json --digest-output artifacts/harness-sdk/bundle-digest.txt --ownership-baseline contracts/release/source-ownership-baseline.yaml --owner harness-sdk --require-all-owner-sources-accounted",
    "python3 -c \"from pathlib import Path; import hashlib,json,subprocess; b=Path('artifacts/harness-sdk/source-bundle.tar.zst'); m=json.loads(Path('artifacts/harness-sdk/component-manifest.json').read_text()); digest=Path('artifacts/harness-sdk/bundle-digest.txt').read_text().strip(); actual=hashlib.sha256(b.read_bytes()).hexdigest(); rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); assert m['component_id']=='harness-sdk' and m['source_revision']==rev; assert actual==digest==m['bundle']['sha256']; assert {x['path'] for x in m['files']} and all(x['path'].startswith('sdk/harness/') for x in m['files'])\""
  ],
  "integration_gates": [
    {
      "name": "harness-sdk-gate",
      "layer": "L1",
      "source_of_truth": [
        "git:ff6c81d568c57d871c58e713c99c018c4e8fd95e:harness-sdk-fourth-amendment-decision.md#sha256=5560469099217e132394a970dde8568bf83b1878f682462116f79fd1694d8c06",
        "git:a3bead45c067b5107b949a0752b7f545bf639aaf:harness-sdk-current-amendment-decision.md#sha256=e52509ad4cb3f444680ce6992263190d102ce886e796e6af878c48bdb5395211",
        "harness-sdk-amendment-decision.md:L1-L29",
        "docs/design/open-agent-cluster-overview-design.md:L335-L355",
        "docs/design/open-agent-cluster-overview-design.md:L469-L485",
        "docs/design/detailed/08-component-and-extension-detailed-design.md:L259-L325",
        "docs/design/detailed/08-component-and-extension-detailed-design.md:L327-L412",
        "docs/design/detailed/08-component-and-extension-detailed-design.md:L461-L480",
        "docs/design/detailed/09-governance-and-security-detailed-design.md:L27-L46",
        "docs/design/detailed/09-governance-and-security-detailed-design.md:L312-L406",
        "docs/references/extension/plugin-contracts.md:L7-L176",
        "docs/references/extension/component-governance.md:L1-L281",
        "docs/references/governance/security-and-enterprise.md:L7-L20",
        "docs/references/governance/security-and-enterprise.md:L263-L299",
        "docs/delivery/acceptance-and-validation.md:L170-L185",
        "git:e1e48af331c0d568257e0eb2cbb88c1f19c97cb0:b-class-structural-decomposition-decisions.md#sha256=bee2866be23e0d5fe6f77a245f7f3177522308d5bd3ebbd14fb2baf0d9e37f19"
      ],
      "delivery_goal": "Deliver the complete protocol-neutral public harness.oac.dev/v1 SDK boundary with typed Describe, execute, observe, cancel, result, and error unions; preserve exact Package/entrypoint, Extension/binding, operation, owner, subject, scope, request digest, and service payload digest through every public binding path. Remove every public authority constructor that lets a caller choose both Host signing and trust verification inputs, and expose only the package-neutral consumer/verification side of opaque service and Gate handoffs. The SDK must define a usable Host-facing ingress contract without implementing the Host producer: arbitrary callers and ExtensionPackages must be unable to mint an authoritative RequestScope, GateEvaluatorBinding, receipt, or evaluator invocation. Replace the obsolete missing-symbol regression with a structurally valid attempt against the current public API and prove zero binding, receipt, and evaluator calls. Remove all SDK-owned or same-package test-only Host authority bridges. Every SDK-local fixture must emit source-revision-bound measured evidence for its exact scoped assertion; the Gate consumer row may pass only by proving the negative boundary, must report registered_gate_positive_path_count=0 and authoritative_gate_positive_claim_count=0, and must identify its scope as sdk-boundary rather than representing full Host-backed Gate conformance. Produce harness-sdk-boundary-evidence for the downstream harness-host producer. Preserve typed operation-schema validation, successful Trigger/EventHandler, bounded offline schema resolution, Required/Optional behavior, Unknown recovery, safe retry/cancel, coverage, race, vet, and deterministic sdk/harness packaging. The mandatory genuine Host-installed positive path and final combined semantic verdict remain downstream responsibilities of harness-host and contracts-extension.",
      "covers": [
        "harness-sdk"
      ],
      "acceptance_refs": [
        "UJ-EXTENSION-PACKAGE-001"
      ],
      "commands": [
        "mkdir -p artifacts/harness-sdk && go test -covermode=atomic -coverprofile=artifacts/harness-sdk/coverage.out ./sdk/harness/...",
        "python3 -c \"from pathlib import Path; import re,subprocess; p=Path('artifacts/harness-sdk/coverage.out'); assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True); m=re.search(r'^total:\\s+[(]statements[)]\\s+([0-9.]+)%$',out,re.M); assert m and float(m.group(1)) >= 90\"",
        "mkdir -p artifacts/harness-sdk && go test -json ./sdk/harness/... -run '^(TestHarnessSDKDescribeAndTypedInvocationConformance|TestHarnessSDKObserveBeforeRetryAndCancelConformance|TestHarnessSDKPermissionAndFailureConformance|TestHarnessSDKRejectsSelfAttestedHostEvidence|TestHarnessSDKServiceModeInvocationEnvelopeConformance|TestHarnessSDKServiceModeRejectsMissingAttestation|TestHarnessSDKServiceModeRejectsAlteredAttestation|TestHarnessSDKServiceModeRejectsExpiredAttestation|TestHarnessSDKServiceModeRejectsReplayedAttestation|TestHarnessSDKServiceModeRejectsMismatchedScope|TestHarnessSDKServiceModeRejectsMismatchedDigest|TestHarnessSDKServiceModeRejectsMismatchedInvocationIdentity|TestHarnessSDKServiceModeKeyRotationConformance|TestHarnessSDKComputationalGuideMonotonicConformance|TestHarnessSDKInferentialGuideAppendOnlyConformance|TestHarnessSDKExecutorSideEffectLifecycleConformance|TestHarnessSDKComputationalSensorAppendOnlyConformance|TestHarnessSDKInferentialSensorAppendOnlyConformance|TestHarnessSDKTriggerConformance|TestHarnessSDKEventHandlerSideEffectLifecycleConformance|TestHarnessSDKRequiredOptionalFailureObservationConformance|TestHarnessSDKTargetBindingConformance|TestHarnessSDKRegisteredGateEvaluatorPurityFailClosedConformance|TestHarnessSDKTypeSpecificDescribeSchemaConformance|TestHarnessSDKTypedOperationAndPayloadBindingConformance|TestHarnessSDKGateEvaluatorRegistryProvenanceConformance|TestPublicExternalHostIssuesTransportsAndBindsTypedServiceInvocation|TestPublicHostReplayGuardSpansReceiversAndRestart|TestPublicHostTrustStoreRejectsIncompleteConfiguration)$' -count=1 > artifacts/harness-sdk/conformance-tests.json",
        "python3 -c \"import json; required=set('TestHarnessSDKDescribeAndTypedInvocationConformance TestHarnessSDKObserveBeforeRetryAndCancelConformance TestHarnessSDKPermissionAndFailureConformance TestHarnessSDKRejectsSelfAttestedHostEvidence TestHarnessSDKServiceModeInvocationEnvelopeConformance TestHarnessSDKServiceModeRejectsMissingAttestation TestHarnessSDKServiceModeRejectsAlteredAttestation TestHarnessSDKServiceModeRejectsExpiredAttestation TestHarnessSDKServiceModeRejectsReplayedAttestation TestHarnessSDKServiceModeRejectsMismatchedScope TestHarnessSDKServiceModeRejectsMismatchedDigest TestHarnessSDKServiceModeRejectsMismatchedInvocationIdentity TestHarnessSDKServiceModeKeyRotationConformance TestHarnessSDKComputationalGuideMonotonicConformance TestHarnessSDKInferentialGuideAppendOnlyConformance TestHarnessSDKExecutorSideEffectLifecycleConformance TestHarnessSDKComputationalSensorAppendOnlyConformance TestHarnessSDKInferentialSensorAppendOnlyConformance TestHarnessSDKTriggerConformance TestHarnessSDKEventHandlerSideEffectLifecycleConformance TestHarnessSDKRequiredOptionalFailureObservationConformance TestHarnessSDKTargetBindingConformance TestHarnessSDKRegisteredGateEvaluatorPurityFailClosedConformance TestHarnessSDKTypeSpecificDescribeSchemaConformance TestHarnessSDKTypedOperationAndPayloadBindingConformance TestHarnessSDKGateEvaluatorRegistryProvenanceConformance TestPublicExternalHostIssuesTransportsAndBindsTypedServiceInvocation TestPublicHostReplayGuardSpansReceiversAndRestart TestPublicHostTrustStoreRejectsIncompleteConfiguration'.split()); rows=[json.loads(x) for x in open('artifacts/harness-sdk/conformance-tests.json') if x.strip()]; passed={x.get('Test') for x in rows if x.get('Action')=='pass' and x.get('Test') in required}; assert passed==required, f'missing required passing tests: {sorted(required-passed)}'\"",
        "go test -json ./sdk/harness/... -run '^(TestHarnessSDKRetryProofBindsCompleteObserveScopeAndServicePayload|TestHarnessSDKTargetBindingIdentityMismatchesRejectWithoutImplementationCalls|TestPublicHostIssuerOutputCannotBindWithoutReceiverVerification|TestPublicGateEvaluatorRegistryRejectsCallerForgedHostCapability|TestHarnessSDKGateCapabilityBoundaryFailures|TestPublicVerifiedServiceGenericBindingRejectsAlternatePayload|TestHarnessSDKObserveSchemaRejectsInvalidPayloadWithoutImplementationCall|TestHarnessSDKCancelSchemaRejectsInvalidPayloadWithoutImplementationCall|TestHarnessSDKTriggerAndEventHandlerPositiveFixturesRejectErrorOnlyImplementations|TestHarnessSDKRejectsExternalSchemaReferencesWithoutIO|TestHarnessSDKBoundsSchemaPayloadSizeAndDepth|TestPublicGateEvaluationRejectsCallerSuppliedEvaluator|TestExternalPackageCannotForgeCurrentHostGateHandoff|TestHarnessSDKSemanticLedgerPreservesChildExecutionEvidence|TestHarnessSDKSemanticLedgerRejectsHelperOnlyOrLiteralPassRows)$' -count=1 >> artifacts/harness-sdk/conformance-tests.json",
        "python3 -c \"import json; required=set('TestHarnessSDKRetryProofBindsCompleteObserveScopeAndServicePayload TestHarnessSDKTargetBindingIdentityMismatchesRejectWithoutImplementationCalls TestPublicHostIssuerOutputCannotBindWithoutReceiverVerification TestPublicGateEvaluatorRegistryRejectsCallerForgedHostCapability TestHarnessSDKGateCapabilityBoundaryFailures TestPublicVerifiedServiceGenericBindingRejectsAlternatePayload TestHarnessSDKObserveSchemaRejectsInvalidPayloadWithoutImplementationCall TestHarnessSDKCancelSchemaRejectsInvalidPayloadWithoutImplementationCall TestHarnessSDKTriggerAndEventHandlerPositiveFixturesRejectErrorOnlyImplementations TestHarnessSDKRejectsExternalSchemaReferencesWithoutIO TestHarnessSDKBoundsSchemaPayloadSizeAndDepth TestPublicGateEvaluationRejectsCallerSuppliedEvaluator TestExternalPackageCannotForgeCurrentHostGateHandoff TestHarnessSDKSemanticLedgerPreservesChildExecutionEvidence TestHarnessSDKSemanticLedgerRejectsHelperOnlyOrLiteralPassRows'.split()); rows=[json.loads(x) for x in open('artifacts/harness-sdk/conformance-tests.json') if x.strip()]; passed={x.get('Test') for x in rows if x.get('Action')=='pass' and x.get('Test') in required}; assert passed==required, f'missing residual semantic regressions: {sorted(required-passed)}'\"",
        "HARNESS_SDK_SEMANTIC_EVIDENCE=\"$PWD/artifacts/harness-sdk/semantic-evidence.json\" go test -json ./sdk/harness/... -run '^TestHarnessSDKSemanticEvidenceConformance$' -count=1 >> artifacts/harness-sdk/conformance-tests.json",
        "python3 -c \"from pathlib import Path; import json,subprocess; p=Path('artifacts/harness-sdk/semantic-evidence.json'); assert p.is_file() and p.stat().st_size>0; d=json.loads(p.read_text()); assert d['schema']=='oac.harness-sdk-semantic-evidence/v1'; rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); assert d['source_revision']==rev; required={'typed-point-describe-contracts','service-host-authority','service-verified-generic-bind-payload','observe-input-schema','cancel-input-schema','trigger-positive-success','event-handler-positive-lifecycle','external-schema-reference-isolation','schema-size-depth-bounds','required-optional-failure-policy','unknown-recovery-retry-cancel','target-binding-identity','gate-evaluator-consumer-boundary'}; rows={x['fixture_id']:x for x in d['fixtures']}; assert required==set(rows); assert all(rows[k]['status']=='pass' and rows[k].get('execution_count')==1 and rows[k].get('accepted_count',0)+rows[k].get('rejected_count',0)>0 and rows[k].get('forbidden_accept_count')==0 and rows[k].get('forbidden_implementation_call_count')==0 and isinstance(rows[k].get('identity_evidence'),list) and any(str(x).startswith('target=') for x in rows[k]['identity_evidence']) and any(str(x).startswith('operation=') for x in rows[k]['identity_evidence']) and any(str(x).startswith('provenance=') for x in rows[k]['identity_evidence']) and rows[k].get('assertions') and rows[k].get('evidence_refs') for k in required); m=d['metrics']; assert m['required_current_amendment_semantic_fixture_count']==7; assert m['required_delivery_goal_semantic_fixture_count']==13; exact={'required_extension_point_fixture_count':7,'required_service_mode_fixture_count':15,'valid_service_mode_invocation_accept_count':2,'invalid_service_mode_invocation_accept_count':0,'malformed_type_specific_schema_accept_count':0,'missing_target_binding_accept_count':0,'missing_registered_gate_evaluator_accept_count':0,'required_optional_failure_observation_gap_count':0,'operation_mismatch_rejection_count':3,'altered_payload_rejection_count':7,'external_host_direct_bind_rejection_count':2,'event_handler_lifecycle_schema_negative_count':2,'gate_evaluator_provenance_fixture_count':7,'gate_evaluator_service_mode_rejection_count':2,'gate_evaluator_mismatched_release_rejection_count':1,'gate_evaluator_purity_rejection_count':1,'retry_scope_mismatch_rejection_count':4,'target_binding_identity_mismatch_fixture_count':56,'target_binding_package_id_mismatch_rejection_count':7,'target_binding_package_version_mismatch_rejection_count':7,'target_binding_entrypoint_mismatch_rejection_count':7,'target_binding_artifact_mismatch_rejection_count':7,'cross_receiver_replay_rejection_count':2}; assert all(m[k]==v for k,v in exact.items()); assert m['service_verified_generic_bind_alternate_payload_accept_count']==0; assert m['observe_schema_invalid_implementation_call_count']==0; assert m['cancel_schema_invalid_implementation_call_count']==0; assert m['trigger_error_only_positive_accept_count']==0; assert m['event_handler_error_only_positive_accept_count']==0; assert m['external_schema_reference_rejection_count']>=2; assert m['external_schema_resolution_io_attempt_count']==0; assert m['schema_size_limit_bypass_accept_count']==0; assert m['payload_size_limit_bypass_accept_count']==0; assert m['schema_depth_limit_bypass_accept_count']==0; assert m['payload_depth_limit_bypass_accept_count']==0; assert m['trigger_successful_response_count']>=1; assert m['event_handler_successful_lifecycle_operation_count']>=3; assert m['required_measured_semantic_row_count']==13; assert m['unregistered_gate_execution_accept_count']==0; assert m['sdk_owned_host_handoff_construction_count']==0; assert m['helper_only_semantic_fixture_accept_count']==0; assert m['literal_semantic_status_accept_count']==0; assert m['dropped_child_execution_evidence_count']==0\"",
        "mkdir -p artifacts/harness-sdk && go test -json ./sdk/harness/... -run '^(TestPublicHostAuthorityCannotBeSelectedByCaller|TestCurrentPublicGateForgeryRejectsWithoutBindingReceiptOrEvaluatorCall)$' -count=1 >> artifacts/harness-sdk/conformance-tests.json",
        "python3 -c \"import json; required={'TestPublicHostAuthorityCannotBeSelectedByCaller','TestCurrentPublicGateForgeryRejectsWithoutBindingReceiptOrEvaluatorCall'}; rows=[json.loads(x) for x in open('artifacts/harness-sdk/conformance-tests.json') if x.strip()]; passed={x.get('Test') for x in rows if x.get('Action')=='pass' and x.get('Test') in required}; assert passed==required, f'missing current-boundary regressions: {sorted(required-passed)}'\"",
        "python3 -c \"from pathlib import Path; import json; d=json.loads(Path('artifacts/harness-sdk/semantic-evidence.json').read_text()); m=d['metrics']; assert m['registered_gate_positive_path_count']==0; assert m['authoritative_gate_positive_claim_count']==0; assert d['evidence_scope']=='sdk-boundary'; rows={x['fixture_id']:x for x in d['fixtures']}; r=rows['gate-evaluator-consumer-boundary']; assert r['status']=='pass' and r.get('accepted_count',0)==0 and r.get('rejected_count',0)>0; assert r.get('forbidden_accept_count')==0 and r.get('forbidden_implementation_call_count')==0\"",
        "go vet ./sdk/harness/...",
        "CGO_ENABLED=1 go test -race ./sdk/harness/...",
        "python3 scripts/release/package_component.py --component harness-sdk --kind public-extension-sdk --input sdk/harness --bundle artifacts/harness-sdk/source-bundle.tar.zst --component-manifest artifacts/harness-sdk/component-manifest.json --digest-output artifacts/harness-sdk/bundle-digest.txt --ownership-baseline contracts/release/source-ownership-baseline.yaml --owner harness-sdk --require-all-owner-sources-accounted",
        "python3 -c \"from pathlib import Path; import hashlib,json,subprocess; b=Path('artifacts/harness-sdk/source-bundle.tar.zst'); m=json.loads(Path('artifacts/harness-sdk/component-manifest.json').read_text()); digest=Path('artifacts/harness-sdk/bundle-digest.txt').read_text().strip(); actual=hashlib.sha256(b.read_bytes()).hexdigest(); rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); assert m['component_id']=='harness-sdk' and m['source_revision']==rev; assert actual==digest==m['bundle']['sha256']; assert {x['path'] for x in m['files']} and all(x['path'].startswith('sdk/harness/') for x in m['files'])\""
      ],
      "required_metrics": {
        "statement_coverage_percent": 90,
        "required_harness_conformance_test_count": 47,
        "required_extension_point_fixture_count": 7,
        "required_service_mode_fixture_count": 15,
        "valid_service_mode_invocation_accept_count": 2,
        "invalid_service_mode_invocation_accept_count": 0,
        "malformed_type_specific_schema_accept_count": 0,
        "missing_target_binding_accept_count": 0,
        "missing_registered_gate_evaluator_accept_count": 0,
        "required_optional_failure_observation_gap_count": 0,
        "operation_mismatch_rejection_count": 3,
        "altered_payload_rejection_count": 7,
        "external_host_direct_bind_rejection_count": 2,
        "event_handler_lifecycle_schema_negative_count": 2,
        "gate_evaluator_provenance_fixture_count": 7,
        "gate_evaluator_service_mode_rejection_count": 2,
        "gate_evaluator_mismatched_release_rejection_count": 1,
        "gate_evaluator_purity_rejection_count": 1,
        "retry_scope_mismatch_rejection_count": 4,
        "target_binding_identity_mismatch_fixture_count": 56,
        "target_binding_package_id_mismatch_rejection_count": 7,
        "target_binding_package_version_mismatch_rejection_count": 7,
        "target_binding_entrypoint_mismatch_rejection_count": 7,
        "target_binding_artifact_mismatch_rejection_count": 7,
        "cross_receiver_replay_rejection_count": 2,
        "required_current_amendment_semantic_fixture_count": 7,
        "required_delivery_goal_semantic_fixture_count": 13,
        "service_verified_generic_bind_alternate_payload_accept_count": 0,
        "observe_schema_invalid_implementation_call_count": 0,
        "cancel_schema_invalid_implementation_call_count": 0,
        "trigger_error_only_positive_accept_count": 0,
        "event_handler_error_only_positive_accept_count": 0,
        "external_schema_reference_rejection_count": 2,
        "external_schema_resolution_io_attempt_count": 0,
        "schema_size_limit_bypass_accept_count": 0,
        "payload_size_limit_bypass_accept_count": 0,
        "schema_depth_limit_bypass_accept_count": 0,
        "payload_depth_limit_bypass_accept_count": 0,
        "trigger_successful_response_count": 1,
        "event_handler_successful_lifecycle_operation_count": 3,
        "semantic_evidence_source_revision_match_count": 1,
        "required_measured_semantic_row_count": 13,
        "unregistered_gate_execution_accept_count": 0,
        "sdk_owned_host_handoff_construction_count": 0,
        "helper_only_semantic_fixture_accept_count": 0,
        "literal_semantic_status_accept_count": 0,
        "dropped_child_execution_evidence_count": 0,
        "registered_gate_positive_path_count": 0,
        "authoritative_gate_positive_claim_count": 0,
        "caller_selected_host_authority_accept_count": 0,
        "current_public_handoff_forgery_accept_count": 0,
        "gate_consumer_boundary_fixture_count": 1
      },
      "artifacts": [
        "artifacts/harness-sdk/coverage.out",
        "artifacts/harness-sdk/conformance-tests.json",
        "artifacts/harness-sdk/semantic-evidence.json",
        "artifacts/harness-sdk/source-bundle.tar.zst",
        "artifacts/harness-sdk/bundle-digest.txt",
        "artifacts/harness-sdk/component-manifest.json"
      ]
    }
  ],
  "pr_base": "main",
  "acceptance_refs": [
    "UJ-EXTENSION-PACKAGE-001"
  ],
  "source_of_truth": [
    "git:ff6c81d568c57d871c58e713c99c018c4e8fd95e:harness-sdk-fourth-amendment-decision.md#sha256=5560469099217e132394a970dde8568bf83b1878f682462116f79fd1694d8c06",
    "git:a3bead45c067b5107b949a0752b7f545bf639aaf:harness-sdk-current-amendment-decision.md#sha256=e52509ad4cb3f444680ce6992263190d102ce886e796e6af878c48bdb5395211",
    "harness-sdk-amendment-decision.md:L1-L29",
    "docs/design/open-agent-cluster-overview-design.md:L335-L355",
    "docs/design/open-agent-cluster-overview-design.md:L469-L485",
    "docs/design/detailed/08-component-and-extension-detailed-design.md:L259-L325",
    "docs/design/detailed/08-component-and-extension-detailed-design.md:L327-L412",
    "docs/design/detailed/08-component-and-extension-detailed-design.md:L461-L480",
    "docs/design/detailed/09-governance-and-security-detailed-design.md:L27-L46",
    "docs/design/detailed/09-governance-and-security-detailed-design.md:L312-L406",
    "docs/references/extension/plugin-contracts.md:L7-L176",
    "docs/references/extension/component-governance.md:L1-L281",
    "docs/references/governance/security-and-enterprise.md:L7-L20",
    "docs/references/governance/security-and-enterprise.md:L263-L299",
    "docs/delivery/acceptance-and-validation.md:L170-L185",
    "git:e1e48af331c0d568257e0eb2cbb88c1f19c97cb0:b-class-structural-decomposition-decisions.md#sha256=bee2866be23e0d5fe6f77a245f7f3177522308d5bd3ebbd14fb2baf0d9e37f19"
  ],
  "required_contracts": [
    "harness-sdk-amendment-decision.md",
    "docs/references/extension/plugin-contracts.md",
    "docs/references/extension/component-governance.md",
    "docs/references/governance/security-and-enterprise.md",
    "docs/delivery/acceptance-and-validation.md"
  ],
  "scope_paths": [
    "sdk/harness/**"
  ],
  "evidence_mode": "artifact",
  "produces": [
    {
      "artifact_id": "harness-sdk-boundary-evidence"
    }
  ],
  "consumes": [
    {
      "artifact_id": "contracts-extension-wire-evidence",
      "producer": "contracts-extension-wire",
      "evidence_mode": "artifact"
    }
  ]
}