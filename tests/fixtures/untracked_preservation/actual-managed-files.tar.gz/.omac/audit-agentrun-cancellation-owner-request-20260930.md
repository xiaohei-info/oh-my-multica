# Source-bound Audit / AgentRun cancellation prerequisite amendment request

Coordinator evidence handoff; not a product design or technical feasibility verdict.

Current node `contracts-audit-usage`, issue `7b568083-2a29-47d5-a56e-3509b79ebb6c`, PR78 HEAD `7fa6e08311f1680967ff20273b56421b698b0219`. The independent Reviewer requests the responsible Runtime/AgentRun owner to diagnose the observed failure. Existing Audit scope excludes that owner implementation.

## Requested Planner and independent Reviewer delivery

Inspect current authoritative DAG, owner contracts and exact immutable evidence below. Produce a concrete minimal amendment assigning only the necessary owner diagnosis/remedy and Audit prerequisite/recovery, if needed. Identify whether source/fixture correction or evidenced environment remedy is necessary through the appropriate OAC owner Agent; the coordinator does not decide it. Preserve all quality/security boundaries, uncached repository verification, original reject/ledger, all 61 done nodes and absolute counters; do not claim unchanged-tree reruns diagnose or solve the failure. No plan workflow, generic assessment, empty operations, unchanged resume, threshold relaxation, unrelated recovery or historical-source importer. Existing completed owners may only be resumed if justified by precise source-bound responsibilities and recovery. The proposal must explain actual restoration effects and expose real new product tradeoffs only if unavoidable.

## Exact current structured blocker

```json
{
  "schema": "omac.decision-required/v1",
  "reason_code": "worker-decision-required",
  "kind": "develop",
  "phase": "authoring",
  "gate": "worker",
  "resume_issue_id": "7b568083-2a29-47d5-a56e-3509b79ebb6c",
  "review_context_binding": {
    "generation": "amendment-683b48abd7c2958436b1033e",
    "contract_sha256": "f1a4804c619a456d3a094834357544d2db368ecb50e50b918ee2f451f3d654e6"
  },
  "blocker": {
    "schema": "omac.worker-blocker/v2",
    "reason_code": "owner-decision-required",
    "issue_id": "7b568083-2a29-47d5-a56e-3509b79ebb6c",
    "review_context_binding": {
      "generation": "amendment-683b48abd7c2958436b1033e",
      "contract_sha256": "f1a4804c619a456d3a094834357544d2db368ecb50e50b918ee2f451f3d654e6"
    },
    "handoff_generation": "handoff-9b1f1790f4a08982",
    "worker": "pi-ubuntu-newapi",
    "run_id": "01a0f327-a574-7ad6-9d72-a9e34df75b63",
    "summary": "The required uncached repository test intermittently failed in the Runtime/AgentRun cancellation boundary; cause is undiagnosed and outside this node's scope.",
    "decision_needed": "Runtime/AgentRun owner: determine whether the child remaining detectable after cancel is a source/fixture defect or environment/observation issue, and provide a separate-owner repair or verified cause/remedy. Do not weaken the test or change this Audit PR.",
    "contract_ref": "verification_commands",
    "evidence": [
      {
        "ref": "review report attachment 01a0f325-c5a2-7bd0-ae43-624c6d61e485; PR #78 head 7fa6e08311f1680967ff20273b56421b698b0219",
        "observation": "First uncached go test exited 1 at cmd/agentrun-job/main_test.go:218, TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure: child remained detectable after cancel. The helper polls 10 seconds (adapters_test.go:638-649). Unchanged-tree reruns passed, showing intermittency but no diagnosed repair.",
        "command": "go test -count=1 ./...",
        "exit_code": 1
      },
      {
        "ref": "open-agent-cluster local checkout",
        "observation": "cwd /home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-820-f3eb3e577f5b/workdir/open-agent-cluster; clean branch agent/pi-ubuntu-newapi/2229f093fb30 at 7fa6e08311f1680967ff20273b56421b698b0219, equal to origin. No partial diff or Runtime/AgentRun files changed."
      }
    ]
  },
  "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> contracts-audit-usage"
}
```

## Exact prior independent review context

```json
{
  "verdict": "reject",
  "report_ref": {
    "comment_id": "01a0f325-c625-7846-b4bd-1d6bf5116b1c",
    "attachment_id": "01a0f325-c5a2-7bd0-ae43-624c6d61e485",
    "sha256": "e15cd8e27bbf52e970b31e16453e885f99178b4576adc1f23f66f5c49040fd39",
    "bytes": 28831,
    "filename": "omac-review-report-e15cd8e27bbf.yaml"
  },
  "ledger_ref": {
    "comment_id": "01a0f325-c98a-7289-bc9c-7cde59689d58",
    "attachment_id": "01a0f325-c91c-7abf-b69f-346fe0f95b39",
    "sha256": "35afd7e34ac1d0c0ed9af931fd2584e628d0d82ab4dea9f5b9957dd1b9620c4c",
    "bytes": 21173,
    "filename": "omac-review-ledger-35afd7e34ac1.yaml"
  },
  "blockers": [
    {
      "root_cause_key": "required-agentrun-cancellation-verification-intermittent-failure",
      "summary": "Declared repository-wide verification intermittently fails the existing built AgentRun cancellation/reaping boundary; no cause or repair is established.",
      "required_fix": "Obtain the Runtime/AgentRun prerequisite owner decision and evidence explaining the intermittent cancellation/process-observation failure. If code or fixture repair is needed, deliver it under that owner separately; if it is environmental, document and ver"
    }
  ]
}
```

Authoritative work show: `/tmp/oac-audit-decision-show-20260930-1722.json`. Original Run queries: `/tmp/oac-audit-failed-runs-1722-20260930.json`. Both failed Run histories remain intact; no node retry, clearing, coding, test edit or budget reset has been performed.

## Supported proposal-admission recovery

First propose at17:26UTC exited5 before creating an issue or waking a Planner, because the existing worker-decision-required marker forbade amendment admission. Following its exact supported next action, authoring retry at17:28UTC exited0 with no Worker dispatched; Runner remains stopped. Fresh work show `/tmp/oac-audit-owner-admission-after-show-20260930.json` confirms TODO/AUTHORING, absolute20/3/0 unchanged and original report SHAe15cd8/ledgerSHA35afd7 in previous_review unchanged. This unlocks planning admission only; the cancellation failure is unresolved and the original v2 blocker above remains the authoritative evidence for this proposal. Do not dispatch the unchanged Audit work before the actual owner prerequisite is resolved. No budget grant or threshold change.
