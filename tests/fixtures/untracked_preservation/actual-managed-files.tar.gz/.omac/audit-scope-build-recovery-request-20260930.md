# Resolve the concrete Audit/Usage scope-build conflict

User directs advancing OAC via existing DAG or minimal independently reviewed amend, no plan create. User authorizes coordinator to accept acceptable B amendments after independent review. This is an OAC product responsibility/contract problem, not an OMAC infrastructure repair.

Node contracts-audit-usage / issue7b568083-2a29-47d5-a56e-3509b79ebb6c / PR78. Fresh control BLOCKED, scope-build-conflict operator prerequisite, absoluteworker20/review0/merge0. Prior worker repeatedly waited for scope direction. PR78 remainsOPEN/headb3bf8ab0820a7bd365bb65dc3a026dd289dcb7fd. Its files include Audit/Usage owners plus internal/agents/definitions, internal/softwaredelivery/artifacts/plan.go, internal/softwaredelivery/preview files, runtime-sdk/sdk.go, and owning docs. The latest worker says RuntimeSDK/software-delivery changes conflict with AITEAM820 allowedscope and repositorychecks. This proves a reported ownership/build issue; coordinator has not judged which support edits are required or correct. Do not authorize all PR extras just because they are present.

Current DAG runtime-sdk, software-artifacts, release-artifact-tooling and agent-definition are done. Preserve all57done. Required upstream owner methods and current source must be inspected through exact work show PR/verification/source, not text work read on develop outputs. Read current complete Audit contract, real latest rejected ledger/report/verification and PR diff. Determine concrete still-required support changes versus old/extraneous/unnecessary patches using current merged main. Produce minimum executable amendment restoring legitimate Audit development: preferably narrow worker handoff if it can satisfy current contract; otherwise explicit smallest responsibility/dependency recovery or compensating owner delivery, each with exact source evidence, owning design/API impact and validations. Do not silently let Audit edit other owners, duplicate production validators, reopen done tasks or remove guards. No generic architecture assessment and no unconditional fullscope widening.

Preserve Audit authority, redaction/canonicalexport, Usage unknown semantics, CAS/idempotency, current coverage/review requirements, Workspace deferral, and current healthy Convergence/Harness work. No fake source-verification or blanket acceptance of PR78. Do not bypass genuine prerequisites. If node admission must be released by operator first, report supported exact no-dispatch recovery; do not clear decisions manually. Any new budget generation must derive actual20/0/0 via approvednormalapply, no limit increase or absolutecounter reset, not repeated same-session waits. Scope plan requires independent reviewer execution/ownership checks.

Recent worker result, verbatim:
{
  "id": "01a0dde0-b96c-7c05-a76b-e2bfc4573ac1",
  "status": "completed",
  "result": {
    "output": "OMAC still reports `in_progress/authoring` at worker bounce 20; the comment scan found no owner scope decision. The Runtime SDK/software-delivery changes still conflict with AITEAM-820’s scope and repository checks, so I made no changes, push, or submission. An owner must authorize those support changes or have the owning fixes land before this PR can be narrowed.",
    "pr_url": "",
    "session_id": "/home/ubuntu/.multica/pi-sessions/20260926T033229.755795708.jsonl",
    "work_dir": "/home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-820-f3eb3e577f5b/workdir"
  }
}

Admission correction: initialpropose exited5 before creatingissue because olddecision only haddecision_class/reason_code/observed_at and is malformed under current protocol. Coordinator followedrequiredfreshworkshow then supportednode retry authoring exit0 solely for planning admission, no Worker dispatched, absolute20/0/0 remains. Old scope-conflict report remains this request's source. No silent productresolution or budgetreset. Do not dispatch exhaustedoldWorker without independentlyreviewed recovery and explicit owner solution.
