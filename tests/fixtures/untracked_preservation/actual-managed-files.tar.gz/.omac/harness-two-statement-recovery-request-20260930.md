# Concrete Harness residual gap: minimal independent developer recovery

Existing user authorization: advance OAC through original DAG or minimal reviewed amend; coordinator may accept a reviewed B amendment if acceptable. No plan create/resume/confirm. Do not infer lowering quality or changing security from this request.

Original Harness developer Run01a0eda7 completed after substantive corrections. It reported source1f836db8ac6ef4df4d4fbc7eea6270f12f0acd25, raw1913/2252=84.9467%, minimum1915, with vet/race/four tree regressions/fixed semantic selectors/packaging passing. These are Worker claims, not independent reproduction. It blocked owner-decision-required with a specific reachability argument. Coordinator does not judge that argument correct or impossible; independent developer must reconstruct exact source and profile and inspect remaining lawful in-contract opportunities. A new concrete independent execution is appropriate; do not create another broad architecture assessment or repeat original session without changes.

Prefer minimum amendment transferring only harness-sdk worker to configured codex-macmini-newapi and a source-bound concrete handoff, preserving complete existing contract85/wholeSDK90/Host90, current stop policy, dependencies, approved design, all57done, originalissue/PR/workspaces/absolutebudget history. Previous Codex attempts predating this actual committed tree do not establish that current gap cannot be solved. Planner must verify current control admission/recovery and precise affected set; if policy requires no-dispatch operator recovery first, report exact supported action, no hand-edited decisions or budget. New worker must read current full contract/work show, inherit source1f836db and retained evidence, independently assess legal coverage and implement real remaining corrections under existing contract. Reject padding/filtering/Host-proof fixtures/deleting required guards or moving ownership to game coverage. Ordinary failure requires substantive in-contract development; a genuine impossibility claim requires exact source/attempted corrections/unavailable next action, not a percentage alone. Do not guarantee attainability or ask coordinator to design tests. Keep independent hermes-reviewer.

Exact retained package on Mac: /tmp/oac-harness-two-statement-handoff-20260930/manifest.json, source.bundle (two local commits beyond621ba1f), artifacts.tar with original profile/evidence, working.patch includes post-commit artifacts. Hashes are in manifest.json. Original tree remains untouched. New worker has local filesystem access; rebuild an isolated checkout from exact bundle rather than stale remote PR. Original location is /Users/chiangguantik/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-949-e10c0298b131/workdir/open-agent-cluster. Preserve it. If source unavailable, report accurately, never claim reproduced.

If the independent Planner/Reviewer establishes a true product-contract conflict rather than an implementation gap, provide a separate precise executable amendment with necessity/evidence; do not silently change gates in this recovery. No implementation or acceptance in proposal. Keep Executor already done and Convergence recovery isolated.

Verbatim current Worker technical report follows:

# Receipt-tree verification — owner decision required; not delivery evidence

This report binds the approved recursive measurement-tree repair to the current committed source, records the complete SDK verification, and explains why it cannot be submitted as a successful delivery. It does not claim downstream Host conformance or change PR #73.

## Source and evidence binding

- Repository branch: `agent/codex-ubuntu-newapi/4dfc8fb68cdb`; PR base remains `main`.
- Current source revision: `1f836db8ac6ef4df4d4fbc7eea6270f12f0acd25` (two local commits beyond retained PR base `621ba1f7a2a45c9cf6072a3cc0c25cb27c727fb8`; remote branch remains at the PR base; no push or PR update).
- OMAC contract: `9ac9bbe8d65089fd48cc26921953564e711d4ea1605238593a755e744b04f5ec`; current worker review binding `amendment-ff7c33e981bc93c8f55494b2` / `b9525a949380d9695cfe741aa70d19c2420151b67aaba7fe4efd30e1bfc50dfe`.
- Toolchain: `go1.26.5 darwin/arm64`.
- Atomic raw SDK profile: `artifacts/harness-sdk/coverage.out`, SHA-256 `d9e0e499c2e6c9e8d4b6f42db6dcc34174288ee70614e603e3939c0d85408ebc`.
- Four-design-regression JSON log: `artifacts/harness-sdk/receipt-tree-tests.json`, SHA-256 `5d4a1a8ec61eb5b75fcbbd9a161a35db804bc61339735c110a9583c3eb801612`.
- Fixed-selector/semantic JSON log: `artifacts/harness-sdk/conformance-tests.json`, SHA-256 `ea9c684a9a26d390f8455bc742b3068de05a54ce70439220f28cefdb7b6b51fc`.
- Final semantic evidence: `artifacts/harness-sdk/semantic-evidence.json`, SHA-256 `d899c3b1305168bf8dc19fd37ab9d4229f54c1099463a08538684ffb6fb60e39`; `source_revision` equals the current source revision.
- Deterministic package: `artifacts/harness-sdk/source-bundle.tar.zst`, SHA-256 `3e42f69174e914b7fcea3d5860e81d476ca9ffc80f6cd5b4ac074bc19a2319d4`; component manifest SHA-256 `e20c959c9d0890a312ea62f13f1afecd151fa2efe5a21cb9d6105f9496c91281`; digest-file SHA-256 `54ca9f9b33d13cfcd50fca7cd0f0f3bf0b1a7cf561101efc64c4559fcfe5a7bf`. The manifest source revision and bundle digest checks passed.

## Required gate result

- `go test -covermode=atomic -coverprofile=artifacts/harness-sdk/coverage.out ./sdk/harness/...` — exit 0; Go summary `84.9%`.
- The exact raw SDK-only assertion — exit 1: **1,913/2,252 = 84.9467%**. Required minimum is **1,915**, leaving a **two-statement** gap. Profile is unfiltered, atomic, and contains only `sdk/harness/**` source. No counter, denominator, source filter, or Host proof was manufactured.
- `go vet ./sdk/harness/...` — exit 0.
- `CGO_ENABLED=1 go test -race ./sdk/harness/...` — exit 0.
- All four additional design regressions passed separately: `TestHarnessSDKMeasuredTreeUsesProductionLineage`, `TestHarnessSDKMeasuredTreeCopyAndParentBinding`, `TestHarnessSDKMeasuredTreeCannotAuthorizeReceipt`, and `TestHarnessSDKReceiptProjectionCompatibility`.
- All fixed conformance selectors and the once-generated final semantic evidence passed their exact source-bound validators. The log has no test failures/skips; required 50-test set, 13 measured semantic rows, seven current-amendment rows, 16 typed rejection cases, eight valid business-error envelopes, exact service cases/counters, and SDK-boundary scope checks passed.
- Package generation and source-revision/hash validation passed. The unchanged 85% gate is the sole failed gate. No whole-SDK 90% or Host 90% result is claimed; Host work is downstream and not-run.

## Implemented changes and invariant mapping

- `sdk/harness/execution_measurement_tree.go`: one immutable data-only tree is now used by runner measurements and sealed receipt adapters. It validates complete node data/lineage, preserves ordered child digests and canonical historical projections, deep-copies mutable data, rejects different-parent reuse, and compares every parent/child projection recursively. The new fixed runner tests exercise every retained tree function (100% per-function coverage in this profile); they verify real Guide/Sensor/Executor/Trigger/EventHandler measurements, lineage, copy isolation, and that unsealed data cannot produce a receipt or Host ingress.
- `sdk/harness/conformance.go` and `semantic_measurements_test.go`: typed and Executor records are populated from the actual fixed production operation runners and their real lifecycle calls; recursive identity/source/child data is projected from those measurements. No extra implementation or evaluator calls were added to inflate counts.
- `sdk/harness/execution_receipt.go`: public receipt fields, JSON tags, canonical digest compatibility, and production-only per-node seals remain. Validation still rejects unsealed JSON/data and compares the complete public projection to the sealed tree. Data validity never creates a seal.
- `sdk/harness/schema.go`: schema validation now compiles a bounded, reference-checked schema once and reuses that compiled value for payload validation. This removes duplicate parsing, not a schema limit or error check.
- `sdk/harness/harness.go` / `conformance.go`: removed only validations already implied by earlier shared validators or by construction of their input (AgentInvoke's shared Extension.Validate rule; the exact binding ref after `binding.Validate` and ID/version comparisons; duplicate schema/required-optional checks; a lookup of an ID drawn from the same validated description). The source tests still exercise the authoritative shared/public validations. No security boundary or user-visible acceptance was removed.
- Owning overview, detailed design 08, plugin-contracts and component-governance docs preserve the data/seal distinction, per-node seal requirement, no-authority tree boundary, copy/reparent rules, and downstream Host ownership.
- Coverage evolution is source-visible, not a denominator maneuver: the prior repaired tree profile was 1,853/2,211 (83.8082%); current committed implementation is 1,913/2,252 (84.9467%). Added denominator is the real shared tree and integration code. Subsequent reductions are the documented duplicate compilation/projection and redundant validation refactors above; the raw total still grew, and the final uncovered gap remains two.

## Concrete residual reachability conflict

The approved SDK contract requires both (a) raw SDK-only coverage `>=85%`, and (b) no Host issuer/proof construction, no private-proof test bridge, and no moving SDK production code into another owner. The verified source/profile leave a two-statement shortfall after the substantive tree integration and ordinary SDK error-path corrections. The remaining obvious paths cannot be safely executed as passing SDK evidence:

- `sdk/harness/schema.go:59-61` is the error return from compiled-schema validation of a payload. The same entry point first validates payload JSON/size/depth and compiles the reference-free schema. Triggering this error requires a library failure after those preconditions, not a valid negative schema/payload fixture; do not remove error handling or claim an impossible test.
- `sdk/harness/conformance.go:1194-1196` is the verifier failure if the SDK's own `RecoveryFor` does not map an actual `Unknown` response to Observe/no retry. The fixed recovery tests pass that invariant; executing this guard as a passing test would require a contract violation or injectable fake not present in the production path.
- Receipt success/attachment/rebinding blocks after private seal checks (`execution_receipt.go:190-220`, `281-306`, `378-399`), trusted retry proof (`harness.go:923-944`), authenticated service ingress (`service.go:18-46`), and registered Gate positive paths (`extension_points.go:342-499`) require Host-issued private authority. They are expressly downstream, not legal SDK fixtures. The fixed SDK rows correctly prove rejection and keep Host-positive counters at zero.
- Other residual `Verify*` return blocks in `conformance.go` are fail-if-an-invariant-is-broken assertions (for example acceptance of an undeclared permission or caller-authored Host claim); allowing them to execute means the fixed verification fails. No wrapper, fixture, Host proof, or false result was introduced to count them.

The contract provides no lawful SDK test path to execute these residual defensive/Host-owned branches. Do not close the two-statement gap by deleting required validation, weakening the failure assertions, building same-package Host proof, changing raw coverage scope, or moving production ownership.

## Decision required

Request the owner/coordinator to identify an explicitly authorized, source-reachable SDK-only coverage path that preserves the unchanged security and ownership boundaries, or to issue a separately reviewed amendment resolving this specific gate-vs-testability conflict. Until that decision, retain the work and evidence, keep PR #73 unpushed/unsubmitted, and do not claim the quality gate or downstream Host conformance passed. This is not a request to relax the 85/90/90 gates unilaterally.

Coordinator admission recovery completed2026-09-30: current Store expectedTODO/AUTHORING with decision cleared only to admit minimal independent reassignment; node retry exited0, no Runner exists, originalWorker not dispatched. Old report preserved in Storecomment and exact localarchive. Prior authorizedbaseline88/1/0 remains, do not repeat retry. Convergence already dispatchedRun01a0efa6 and can keep working; do not cancel or mutate that healthy run during planning.
