# Source-bound bounded cancellation / owning Wait contract conflict

Coordinator evidence handoff, not a feasibility or design verdict. Current compensation issue01a0f396-a507-7db4-b0f2-39dc38aa6dce completed WorkerRun01a0f4ca-dbb9-7e0f-973e-a4ab594c65ee has reported a precise conflict after real implementation and before/after production-path regression. Inspect current authoritative documents, full contract, actual PR88 source and immutable review report87173b88083b360d812880bf9695b7b9da38a2df93757d70194f8b84f9cdbfa1/ledger5fc6e07bdb43088ab02117a99d4d6b247ed8763b7ae24675f470634fd451c5aa. Determine whether the already-approved boundary permits a concrete causal repair satisfying bounded cleanup and child exit+owning Wait before Job returns; do not treat Worker impossibility claim as proven. If a real approved contract/ownership conflict exists, produce the minimum concrete amendment with exact old/new behavior and safety/Unknown/restart/reaping impacts, responsibility and evidence. Do not use generic assessment, plan, empty operations or unchanged resume. Do not silently authorize unknown early return, unbounded waiting, a new supervisor, privilege/cluster changes, weakened security/coverage/verification or historical-cause waiver. Any unavoidable new product/safety boundary tradeoff must be explicitly disclosed for user decision before implementation. Preserve175nodes/61done, original failure histories, all absolute counters, current source/ignored evidence and scoped work. No operator retry/tick/dispatch or live manifest editing by Planner. No independent implementation pass is claimed by current Worker evidence.

Structured blocker:
```json
{
  "schema": "omac.decision-required/v1",
  "reason_code": "worker-decision-required",
  "kind": "develop",
  "phase": "authoring",
  "gate": "worker",
  "resume_issue_id": "01a0f396-a507-7db4-b0f2-39dc38aa6dce",
  "review_context_binding": {
    "generation": "amendment-aa036ac9b90e1e11db233d6c",
    "contract_sha256": "57b856045397a1a6a34b61d97a7a956b64ad33774da4ac606a4466714c68c578"
  },
  "blocker": {
    "schema": "omac.worker-blocker/v2",
    "reason_code": "owner-decision-required",
    "issue_id": "01a0f396-a507-7db4-b0f2-39dc38aa6dce",
    "review_context_binding": {
      "generation": "amendment-aa036ac9b90e1e11db233d6c",
      "contract_sha256": "57b856045397a1a6a34b61d97a7a956b64ad33774da4ac606a4466714c68c578"
    },
    "handoff_generation": "handoff-698f4a0126b3259a",
    "worker": "codex-ubuntu-newapi",
    "run_id": "01a0f4ca-dbb9-7e0f-973e-a4ab594c65ee",
    "summary": "Production race reproduced and fixed; a no-Wait finite-bound conflict remains.",
    "decision_needed": "Choose: allow unknown Job return before proven Wait, allow unbounded wait, or authorize a process supervisor outside this boundary. Contract requires bounded termination and Wait-before-return, but forbids a new supervisor.",
    "contract_ref": "non_goals",
    "evidence": [
      {
        "ref": "artifacts/agentrun-cancellation-prerequisite/built-production-before-final.json",
        "observation": "Exit 1 at pre-fix commit 072c3b5be69d7461c381d699b01df4e291748ff9/tree 7647332b03939efac82d782fce0b5a61df4db425: built Job returned while configured Runtime was live before Wait. SHA-256 d88f227f1a2f03dc393d3232f8f7ba8bd634c08d4bd4782b122af1bc289bf785."
      },
      {
        "ref": "artifacts/agentrun-cancellation-prerequisite/built-production-after-final.json",
        "observation": "Exit 0 at PR HEAD 67d1011fcec19bf28df0135d7a495361a0d9941c/tree 346bbfe405b30b62bbd0a3efb41beb4f3b9b78ea; same test waits through Runtime and driver Wait. SHA-256 028249fdae3466517626db5a883f0a36940277dfaa02b0f77eaa3fcaf92ce2ed."
      },
      {
        "ref": "PR #88 source; current OMAC review",
        "observation": "After TERM/SIGKILL windows, settleVendor still waits for owning Wait; finite return may leave a live child. Review requires bounded cleanup and Wait-before-return. Historical AITEAM-820 process state remains unproven."
      }
    ]
  },
  "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> agentrun-cancellation-prerequisite"
}
```

Original Worker result:
```json
{
  "output": "Updated [PR #88](https://github.com/xiaohei-info/open-agent-cluster/pull/88) with a production-path cancellation regression that fails on the pre-fix snapshot and passes after the repair. The full scoped tests, vet, build, and pinned `linux/arm64` package checks passed; coverage is 90.0%.\n\nOMAC accepted an owner-decision blocker. If `exec.Cmd.Wait` never completes after SIGKILL, a finite Job return could violate the required Wait-before-return guarantee; waiting preserves that guarantee but has no finite bound. The owner must choose how to resolve this conflict. The historical AITEAM-820 process state remains unproven.",
  "pr_url": "",
  "session_id": "01a0f397-381f-79b2-abf6-e67977eab03c",
  "work_dir": "/home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-1031-e671ab7c802a/workdir"
}
```

Supported planning admission only: initial propose exit5 before issue/dispatch; exact CLI normal authoring retry once exit0, freshTODO/noactiveAgent, Runner remains stopped. Original structured blocker above remains unresolved; do not dispatch unchanged Worker or infer decision approval. Evidence /tmp/oac-bounded-wait-admission-after-20261001.json.
