# Source-bound AgentRun release module owner amendment request

Coordinator evidence handoff only. Inspect current authoritative DAG, owning contracts and source. Produce the minimum concrete amendment routing the root go.mod duplicate-indirect-requirement prerequisite to its proper owner or narrowly authorizing the existing compensation node if independently justified. Do not predetermine which route is correct. Preserve completed nodes, the existing cancellation/diagnosis obligations, exact pinned release gates, ten-second deadline, 90% coverage, all historical failed evidence and absolute counters. No plan, generic assessment, unchanged resume, threshold change or broad module tidy/refactor. Any ownership transfer must be explicit and independently reviewed. Existing scoped unsubmitted work must be preserved and handed off; do not claim it independently verified. The historical cancellation cause remains unproven and must not be waived merely because current tests pass.

Current compensation issue 01a0f396-a507-7db4-b0f2-39dc38aa6dce; formal completed WorkerRun01a0f397-2199-7347-9a8c-e671ab7c802a. No PR or package verification submission. Existing scope cmd/agentrun-job/**. Runner exited20 at19:56:18UTC, no active Agent; no retry or control recovery yet. Current DAG175/61. Source workdir /home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-1031-e671ab7c802a/workdir.

Original structured blocker:
```json
{
  "schema": "omac.decision-required/v1",
  "reason_code": "worker-decision-required",
  "kind": "develop",
  "phase": "authoring",
  "gate": "worker",
  "resume_issue_id": "01a0f396-a507-7db4-b0f2-39dc38aa6dce",
  "review_context_binding": {
    "generation": null,
    "contract_sha256": "4168e85e4ec5f7ed6d536ea908d5e964b804ca5660b1d2d8b509f67fbdecddeb"
  },
  "blocker": {
    "schema": "omac.worker-blocker/v2",
    "reason_code": "owner-decision-required",
    "issue_id": "01a0f396-a507-7db4-b0f2-39dc38aa6dce",
    "review_context_binding": {
      "generation": null,
      "contract_sha256": "4168e85e4ec5f7ed6d536ea908d5e964b804ca5660b1d2d8b509f67fbdecddeb"
    },
    "handoff_generation": "handoff-746c933d625b4a43",
    "worker": "codex-ubuntu-newapi",
    "run_id": "01a0f397-2199-7347-9a8c-e671ab7c802a",
    "summary": "The cancellation repair tests pass; the pinned release build fails because Go must update root go.mod on the read-only source mount.",
    "decision_needed": "Route the duplicate indirect requirement in root go.mod to its owner or authorize this node to correct it, then rerun the pinned package gates.",
    "contract_ref": "scope_paths",
    "evidence": [
      {
        "ref": "artifacts/agentrun-cancellation-prerequisite/release-build-initial-failure.txt",
        "observation": "Contract build exited 1 at go mod download: `/src/go.mod` is read-only."
      },
      {
        "ref": "artifacts/agentrun-cancellation-prerequisite/modulecheck/go.mod-update.diff",
        "observation": "Writable copy succeeds after Go removes duplicate indirect `gopkg.in/yaml.v3 v3.0.1`; go.sum is unchanged. Root go.mod is outside scope."
      },
      {
        "ref": "artifacts/agentrun-cancellation-prerequisite/cancellation-test.json",
        "observation": "Exact cancellation regression passed; JSON validates one run/pass and no skip/failure."
      }
    ]
  },
  "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> agentrun-cancellation-prerequisite"
}
```

Original Worker result (claim, not independent pass):
```json
{
  "output": "The cancellation tests now track the Runtime process, its parent chain, start time, and process state. Live child, zombie, PID reuse, and probe-error controls pass; the 10-second deadline is unchanged. The historical failed process state wasn’t recorded, so its exact cause remains unproven.\n\nAll scoped tests, vet, build, and protocol checks passed; coverage is 90.3%. The release build is blocked because Go tries to remove a duplicate indirect requirement from root `go.mod`, which is outside this task’s authorized scope. I recorded the evidence and submitted an OMAC owner-decision blocker. No PR or package verification was submitted.",
  "pr_url": "",
  "session_id": "01a0f397-381f-79b2-abf6-e67977eab03c",
  "work_dir": "/home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-1031-e671ab7c802a/workdir"
}
```

Admission recovery: first propose20:25:56UTC exit5 before creating issue/Run; exact CLI next_action normal authoring retry once exit0. Fresh StoreTODO, no active Worker, Runner remains stopped. This unlocks planning only; module release blocker and original evidence above are unresolved. Never dispatch unchanged scope before amendment. See /tmp/oac-agentrun-module-admission-after-20260930.json; no budget reset.
