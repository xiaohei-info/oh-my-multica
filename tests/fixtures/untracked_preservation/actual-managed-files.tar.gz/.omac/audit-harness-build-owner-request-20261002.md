# Audit build prerequisite: source-bound Harness owner routing

## Requested OMAC product Planner + independent Reviewer outcome
Audit contracts-audit-usage has a real v2 owner-decision blocker after the independently reviewed and merged PR88 owner prerequisite. Verify the exact retained source and failed production build, then propose the smallest executable responsibility/dependency correction through the existing DAG amendment channel. Do not assume the worker diagnosis is already independently proven.

The suspected source belongs to sdk/harness, whose harness-sdk node is already done. Do not reopen or rewrite a completed node, waive its history, or let Audit silently edit another owner's production code. Determine the supported minimal owner remedy/prerequisite and Audit recovery/dependency mapping needed to restore the existing full build. Keep all current SDK85/wholeSDK90/Host90, Artifact, security, H/S and original Audit full uncached verification requirements. No new architecture/API/product behavior or quality tradeoff is authorized. This is concrete owner routing for a reported compile failure, not generic assessment or an unchanged resume.

## Retained facts and authority
- Manifest .omac/open-agent-cluster.yaml: 175 nodes, 62 done IDs must remain done. No resets of absolute counters or accepted amendment baselines.
- Audit issue 7b568083-2a29-47d5-a56e-3509b79ebb6c, PR78 remote head 7fa6e08311f1680967ff20273b56421b698b0219. Fresh completed Worker Run 01a0facd-0e42-7b5b-bf3f-fc81ed02fc92. Real v2 block terminal exit20/next_action stop.
- Audit local clean unpushed rebase 59c51dd399b7b48ef4c3c0cca89a13edab83ebda onto origin/main a1837b81e115104b235bd3ed2665af6b3ec157f5 is retained in the original Worker work directory; do not discard or fabricate a new source delivery.
- PR88 merged b612e4febc46ef2ed742868a080d3a555b0cd35c; all 19 owner indexed records were checked by the Worker, not a replacement Audit independent review.
- Reported build failure sdk/harness/conformance.go:1402:77 operationPointer is defined only in conformance_test.go:469; Worker attributes unchanged main code to PR73 merge52285b83b608f86ce10847c9cf36b9b989736c23. Planner/Reviewer must verify pinned source and production build separately. Other 13 Audit commands reported pass, both coverage/package gates >=90 and uncached full tests passed, which does not excuse the build failure.
- Original Audit reject report SHA e15cd8e27bbf52e970b31e16453e885f99178b4576adc1f23f66f5c49040fd39 / ledger35afd7e34ac1d0c0ed9af931fd2584e628d0d82ab4dea9f5b9957dd1b9620c4c and full current Audit contract remain independent closure obligations. historical AITEAM820 cause remains unknown under explicitly approved H. H/S/d969 approvals already apply; no repeat approval request.
- Existing healthy Platform resource Macmini Developer01a0fae5 and Kernel Pi Developer01a0fae1-b71e continue; no comments, cancellation, deployment, product code edits or second Runner. Single amendment controller serially replaces Runner only for planning/review.

## Exact Worker result
Blocked via OMAC pending a Harness SDK owner resolution: `go build ./...` fails at unchanged `sdk/harness/conformance.go:1402` because `operationPointer` is defined only in a test file. I did not modify that out-of-scope code.

The other 13 verification commands passed, including uncached `go test -count=1 ./...` and both coverage/package gates. PR #78 is rebased locally at `59c51dd3` but not pushed; the worktree is clean. OMAC recorded the blocker with exit 20, `terminal: true`, `next_action: stop`.

## Actual structured v2 decision
```json
{
  "schema": "omac.decision-required/v1",
  "reason_code": "worker-decision-required",
  "kind": "develop",
  "phase": "authoring",
  "gate": "worker",
  "resume_issue_id": "7b568083-2a29-47d5-a56e-3509b79ebb6c",
  "review_context_binding": {
    "generation": "authoring-78d404d45cdb51ab424e4694",
    "contract_sha256": "f1a4804c619a456d3a094834357544d2db368ecb50e50b918ee2f451f3d654e6"
  },
  "blocker": {
    "schema": "omac.worker-blocker/v2",
    "reason_code": "owner-decision-required",
    "issue_id": "7b568083-2a29-47d5-a56e-3509b79ebb6c",
    "review_context_binding": {
      "generation": "authoring-78d404d45cdb51ab424e4694",
      "contract_sha256": "f1a4804c619a456d3a094834357544d2db368ecb50e50b918ee2f451f3d654e6"
    },
    "handoff_generation": "handoff-b78b0299d191bcd7",
    "worker": "pi-ubuntu-newapi",
    "run_id": "01a0facd-0e42-7b5b-bf3f-fc81ed02fc92",
    "summary": "Required go build fails in unchanged sdk/harness after the PR88 prerequisite merge.",
    "decision_needed": "Ask the harness-sdk owner/coordinator to provide a reviewed fix or another buildable main. AITEAM-820 is not authorized to change sdk/harness. Then explicitly redispatch this node to rerun, push and review PR78.",
    "contract_ref": "verification_commands",
    "evidence": [
      {
        "ref": "origin/main a1837b81e115104b235bd3ed2665af6b3ec157f5:sdk/harness/conformance.go:1402; harness-sdk work item 01a03bd2-6ef8-7b75-a86c-466f6aaabc1e",
        "observation": "`go build ./...` failed: sdk/harness/conformance.go:1402:77 references operationPointer, which is defined only in conformance_test.go:469. The file is unchanged from origin/main; blame attributes it to 52285b83b6 (PR73).",
        "command": "go build ./...",
        "exit_code": 1
      },
      {
        "ref": "PR88 merge b612e4febc46ef2ed742868a080d3a555b0cd35c; source diagnosis/evidence index",
        "observation": "AITEAM-1031 is done and PR88 merged; all 19 indexed evidence files match size/SHA-256. PR78 was rebased locally onto origin/main at 59c51dd399b7b48ef4c3c0cca89a13edab83ebda; clean and unpushed. Other 13 commands passed, both gates are >=90%, and uncached full tests pass. PR78 remote head remains 7fa6e08311f1680967ff20273b56421b698b0219."
      }
    ]
  },
  "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> contracts-audit-usage"
}
```

## Original Worker retained workspace
/home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-820-f3eb3e577f5b/workdir

## Required deliverable
A real complete non-empty minimal amendment proposal, bound to the current full manifest/acceptance/config/owning docs/required contracts and actual block source. Include exact original/changed operations, ownership rationale, unchanged quality/security/history/budgets, minimum authoring recovery and true downstream dependency preservation. Independent Reviewer must confirm executable owner routing and real OMAC stage preconditions, not just topology. If this is an already supported current-owner repair path, provide the exact supported route without dummy operations. Any real additional scope/quality/security/evidence authority choice must be concrete and separated for user decision; do not preselect one.

## Admission and bound inputs
The first normal proposal correctly refused the current worker-decision-required admission. Its exact safe next action was performed once: normal node retry contracts-audit-usage --stage authoring exit0, only amendment planning admission, no Developer or Runner dispatch; original absolute worker21/review3/merge0, manifest retained baseline20/3/0 and ledger remain. Do not treat TODO as a repaired build.
Current complete transport roots are /tmp/oac-audit-harness-build-bound-inputs-20261002 on Macmini and Oracle. Read input-digests.json and verify every bound file (48 roots / 88 files) including current manifest, config, acceptance, report, complete required contract inputs, owning docs, sdk/harness source/tests and root module files. These are immutable copied inputs, not a replacement authoritative plan or a code edit. Repository/Store primary facts remain read authority.
