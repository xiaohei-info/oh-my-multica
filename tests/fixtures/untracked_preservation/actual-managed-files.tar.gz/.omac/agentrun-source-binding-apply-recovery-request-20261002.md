# Concrete apply precondition repair, approved evidence authority retained

The user explicitly approved amend-d969a05c1631 by saying “批准并继续写”. Approval record /tmp/oac-source-binding-user-approval-20261002.json binds reviewed-file SHA ba9688eff9b95934612e245c7ee58e6c86a428a1a4658cbab852a269b2182f0a. Do NOT reopen or ask for the same tested-code-source SHA/tree versus separately sealed evidence-only delivery identity approval.

Normal apply failed exit5 BEFORE manifest write: `node agentrun-cancellation-prerequisite: review recovery requires a valid controller-sealed delivery identity; use omac node retry <manifest> <node> --stage authoring for a fresh submission`. Log /tmp/oac-source-binding-accept-20261002.log. Current normal work show /tmp/oac-source-binding-accept-failed-show-20261002.json confirms TODO/AUTHORING, no controller-sealed delivery identity or fresh submission context, absolute review5 preserved. Current manifest does not contain the approved contract change; no partial apply. Original approved proposal is terminal confirmation/pass, not applied. No Run, Runner or controller active.

Produce a concrete EXECUTABLE minimal supported amendment/recovery for this exact missing runtime precondition, retaining the already approved evidence authority. Independently validate actual stage preconditions against fresh Store delivery/artifact/verification identity, not only _minimal_rerun on static manifest. Determine the supported fresh-authoring/submission route or necessary exact resume-stage operations; coordinator chooses no implementation. Preserve all original rejects, immutable report/ledger references and counters. Do not manufacture identity, bind completed Runs to fabricated new submissions, clear feedback, reset budgets, change stage guards, create plan or generic assessment, or repeat unchanged review-only accept.

Previous round2 recovered nine unrelated started nodes and was independently rejected. Preserve those nodes' runtime facts and definition; if a broader recovery is unavoidable, enumerate its exact scope and practical consequences with independent review, do not silently promise target-only. Only a concrete new material tradeoff beyond the already approved evidence authority may require a new user decision. Ordinary safe reviewed recovery remains authorized.

H and S are already approved and remain fully enforced. Prospective cause/remedy plus PID/start/PPID/state/single owning Wait, full original-held-Wait 5/10/20/30-second deadlines/diagnostic/no Job return or terminal or Complete/siblings/bounded teardown, 90%, unchanged ten-second assertion, pinned shipped-byte package/security all remain. Historical AITEAM820 cause remains unknown. All61done IDs, all original dependencies, Host wholeSDK90+Host90, ownership, schema, permissions, budgets, failed history remain. This is NOT PR88 implementation pass.

Use the exact current local manifest and Store. Remote reference inputs are under /tmp/oac-source-binding-apply-recovery-inputs-20261002 on Oracle and Mac, with complete required_contract directories. Do not substitute old172 or pre-H snapshots. Existing owner workdir and PR88 HEAD1e2d4073b3e90f9c9676bef53a0690ddb4a22109 are retained. Only OMAC Planner/Reviewer supplies any necessary contract/recovery changes; no OAC code or tests by coordinator.

## Approved reviewed envelope
```yaml
schema: omac.dag-amendment/v1
reason: Resolve the final-HEAD evidence self-reference conflict through the narrowest
  supported review-safe contract correction. The prior reject showed that committed
  evidence generated from code source 48881db8e1223ef1f105d3f3f237d50f948a511d was
  delivered in a later PR commit, so the existing cause/remedy gate must distinguish
  the tested code-source SHA/tree from the separately sealed OMAC delivery_identity
  and immutable delivery blobs while retaining the existing requirement to bind the
  final PR delivery identity. This proposal changes only the existing integration
  gate delivery_goal, a review-safe contract field; it preserves every non_goal, runtime
  fact, worker/reviewer, dependency, scope path, typed boundary, release command,
  acceptance responsibility, historical record, threshold, and counter. The node remains
  eligible for review-stage recovery only; no unrelated started successor is reset.
  The owner must explicitly approve the tested-code-source versus later OMAC delivery-identity
  evidence authority; prior H/S approval does not approve that new tradeoff.
operations:
- op: update
  node: agentrun-cancellation-prerequisite
  set:
    contract:
      objective: Resolve the AgentRun cancellation prerequisite through independently
        reproduced source-bound causal/remedy evidence for the cancellation/Wait failure
        class, under the separately human-approved historical-evidence replacement
        decision H; retain the original AITEAM-820 failure as causally unclassified
        history. Preserve already-approved S and independently prove its held-original-Wait,
        deadlines, diagnostic and teardown obligations before normal merge and Audit
        re-verification.
      non_goals:
      - Do not ship AGENTRUN_FIXTURE_MODE, fixture marker/PID hooks, blockForever,
        synthetic all-event generation, or any other test-selected behavior in cmd/agentrun-job/vendor,
        driver production code, or the release bundle; malformed-stream fixtures belong
        only in testdata or non-release test packages.
      - Do not bundle a specific third-party Runtime binary; launch only the exact
        external executable path and ordered arguments fixed by deployment-time launch
        input, without PATH lookup or mutable environment override.
      - Do not accept duplicate started/resumed records, any non-empty line after
        terminal, an acceptance kind that mismatches new versus resume mode, or an
        ordinary event carrying a foreign vendor session identity.
      - Do not complete successfully until the terminal record, clean vendor EOF,
        child exit, critical-tail persistence, and package-proven event provenance
        are all validated.
      - Do not select or reselect Agent, Runtime, model, MCP, Workspace, resource
        bindings, business routes, or stable lineage.
      - Do not require changes to merged scripts/release tooling; package construction,
        source scanning, protocol verification and exact-byte checks remain under
        cmd/agentrun-job/**.
      - 'Do not modify PR #78, Audit/Usage or its permitted AgentDefinition/Preview
        consumer changes, canonical schemas, other domain behavior, the live DAG,
        completed-node contracts, source ownership catalogs, or retry/coverage/security
        thresholds.'
      - Do not treat unchanged-tree green runs, a possible ordering race, observer
        improvements, S approval or approval of H as an implementation pass or reconstruction
        of the original AITEAM-820 ten-second failure. Retain every failed attempt.
        After H is explicitly approved, independently proven prospective causal/remedy
        evidence under the cause-and-remedy gate may satisfy this prerequisite without
        claiming the original process state or historical cause was established. If
        that replacement evidence cannot be established, submit a precise owner-decision
        blocker and leave the prerequisite unresolved.
      - Do not skip, quarantine, delete, soften or increase the ten-second process-disappearance
        deadline of the failing test to obtain a pass. Preserve cancellation reaching
        the actual vendor, child exit AND reaping, one Execute/stream, bounded drain/backpressure,
        critical-tail ACK ordering and no CompleteAgentRun after persistent append
        failure. If observation/fixture code is wrong, prove the defect and preserve
        or strengthen those assertions with positive and negative controls, including
        detection of a genuinely live unreaped child; do not redefine a zombie as
        reaped.
      - Do not decide source versus environment from kill -0 alone. Bind observations
        to the actual child identity, parent/wait ownership and process state, accounting
        for PID reuse, zombies and permission/probe errors. Explain cancellation-to-exit-to-Wait
        ordering using the existing runner, SDK and driver call paths; instrumentation
        belongs only in tests or bounded redacted evidence, not production fixture
        hooks.
      - 'Supporting production/test edits outside cmd/agentrun-job are permitted only
        in the existing internal/agentrun or runtime-sdk cancellation/session-close
        path when causally required by the source-bound cancellation/Wait failure
        class and approved S obligations, not on an invented historical causal link.
        This does not transfer the completed SDK or Job owners or authorize SDK product
        imports, unrelated MCP/planning repair or broader refactoring. Sole additional
        supporting-file exception: this compensation node may remove exactly the redundant
        indirect gopkg.in/yaml.v3 v3.0.1 requirement from root go.mod, retaining the
        existing direct requirement at v3.0.1 and every other byte; go.sum must remain
        byte-identical. This is a one-defect implementation authorization, not transfer
        of the canonical bootstrap-go package/source-catalog ownership. The only additional
        supporting-document authorization is to align docs/design/detailed/06-agent-runtime-detailed-design.md
        sections 8 and 8.2 and docs/references/execution/agent-runtime.md sections
        7 and 9 with already-approved S: confirmed owning Wait plus expired cancellation
        channel-close deadline permits the existing unknown/no-completion failure
        even if driver Events/Result remain open; pending Wait still retains its original
        owner. Preserve normal success EOF/terminal/critical-tail ACK ordering. No
        other design, governance, schema, catalog or completed-owner edits are authorized.
        This narrow documentation responsibility is explicit in the ownership migration;
        it is not a new runtime policy.'
      - A source/fixture cause requires a permanent failing-before/passing-after regression
        and the minimal correction in a new owner PR based on main. An environment-only
        cause requires independently reproducible before/after process evidence and
        a durable bounded environment/setup/cleanup recipe committed with the owner
        PR; no privilege expansion, global process killing, host/cluster policy change
        or new deployment requirement is authorized. If such a tradeoff is genuinely
        necessary, stop for an explicit decision.
      - The diagnostic deliverable must pin the original rejected HEAD and report/ledger
        hashes, actual tested source SHA/tree, Go version, OS/architecture, relevant
        process/reaper conditions, commands/exit codes and redacted evidence digests.
        Distinguish proven source/fixture or environment cause from unproven hypotheses.
        Describe the concrete remedy and how Audit reproduces it after merge; package
        source and release evidence must name the actual new PR HEAD, never the rejected
        HEAD or a temporary modified tree. Separate original retained observation,
        reproduced prospective cause/remedy, and approved residual uncertainty in
        diagnosis.md. A prospective source/fixture or bounded environment proof is
        not retroactive proof of the original failure; do not assert that the original
        failure is repaired or its environment cause excluded.
      - Preserve the inherited agent-run-job release/coverage/protocol gates as written
        below, including the pinned linux/arm64 shipped pair and exact-byte package
        verification. Native reproducer results and shipped-package results are distinct
        evidence. Do not claim the old merged package proves a changed implementation.
      - If required evidence or environment is unavailable, or a separate repository
        failure requires another owner, stop with a precise blocker rather than invent
        evidence, widen scope or declare the prerequisite complete.
      - Do not run broad go mod tidy, upgrade or downgrade dependencies/toolchains,
        change go.sum or other module directives, relax the read-only source/cache
        mounts or module-download-only network policy, or modify release tooling to
        bypass this prerequisite. Independently review the exact one-line module diff
        and rerun every inherited release gate on the final clean committed PR HEAD.
        If any additional module change is required, stop with an owner-decision blocker;
        this amendment does not authorize it.
      - 'Preserve and hand off all existing AITEAM-1031 scoped work and failed evidence
        before authoring: completed Worker Run 01a0f397-2199-7347-9a8c-e671ab7c802a;
        source repository /home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-1031-e671ab7c802a/workdir/open-agent-cluster;
        branch agent/codex-ubuntu-newapi/e671ab7c802a; implementation commit 799bd737f19b48770f393ab148dbcd447339c114
        and diagnosis commit abed8bfc38360c847d328cfaf42475ff77472d2b (tree bfda144ef5640b454ad98611671eace32917c1ec),
        plus ignored artifacts/agentrun-cancellation-prerequisite evidence. These
        are unsubmitted Worker claims, not independent passes or a package delivery.
        Preserve the historical rejected HEAD, report/ledger, all failed attempts
        and absolute counters. The historical cancellation cause remains unproven;
        a module fix, observer improvement or current green run does not satisfy the
        replacement causal/remedy gate. Original numeric PID is recoverable from the
        retained Reviewer Run tool-result seq 83 full output SHA256 14840a218f6da62d98ddf3f3268028855b3978d8c4811096b1ff7d2050042976;
        original start-time/PPID/state/owning-Wait facts have not been established.
        Do not repeat that the numeric PID is missing, and do not infer identity/state/Wait
        from that number. Preserve unknown historical cause explicitly under H, not
        as a fixed historical root.'
      - 'Option S is already human-approved and applied as amend-82e0c1a4d969, recorded
        in AITEAM-1031 comment 01a0f592-f317-7d9f-a49b-43af3fac6b1d. Do not reopen
        or require reapproval of S. Retain its exact safety-first pending-Wait policy,
        availability/residual-access risks, Unknown on owner loss and no finite OS
        completion promise. NEW HUMAN DECISION H IS REQUIRED BEFORE APPLY OR IMPLEMENTATION:
        explicitly approve replacing proof of the original AITEAM-820 historical cause/remedy
        with the evidence-bound prospective cause/remedy gate below, while recording
        the original cause as unknown and accepting that recurrence from an unobserved
        historical environment/identity/reaping cause is not excluded. Bind approval
        to this reviewed amendment and its exact old/new obligation and recovery footprint.
        Coordinator planning authorization, prior retry, S approval, Reviewer pass
        or current green results are not H approval. Without H approval preserve the
        unresolved blocker/work and do not apply or dispatch. Alternatively retain
        the original contract and supply authoritative original process/Wait records
        if recovered; no new live-environment access is authorized.'
      - 'Under explicitly approved option S, replace the contradictory unconditional
        finite-cleanup-plus-Wait-before-return requirement with bounded software shutdown
        and an explicit pending-Wait retention exception. Cancellation still reaches
        the exact configured Runtime through the existing Job -> linked stream-json
        adapter -> Runtime chain. Keep the adapter''s five-second TERM grace then
        group/direct SIGKILL, and the existing ten-second driver observation windows;
        deadline expiry is not proof of death/reaping. Retain the single parent owning
        each child Wait. Do not SIGKILL the adapter merely because its outer grace
        expired while its Runtime Wait is unconfirmed: that destroys the inner wait
        owner and cannot prove Runtime reaping. The adapter must not exit, and Job
        Run/Execute-start failure must not return, until the Runtime owning Wait followed
        by the adapter owning Wait are established. Apply the same rule to startup/acceptance
        failure, malformed stream, timeout, append failure and ordinary cancellation.
        Never return from startFailure after a failed bounded killAndWait as if ownership
        had been discharged.'
      - The pending-Wait exception is not permission for avoidable software deadlock.
        Decouple cancellation escalation and the single owning Wait from blocked acceptance/stdin
        writes, stdout Scan/forwarding, stderr-copy EOF and public event/result consumers
        in the existing driver/adapter cancellation path. Close owned pipe endpoints
        on cancellation/failure and bound post-exit I/O joins; treat forced pipe closure
        as incomplete evidence, never clean success. A pinned Go Cmd.WaitDelay can
        bound post-exit copying, but cannot replace Process.Wait, reap a live process,
        bound a kernel wait that never returns, or by itself unblock caller-owned
        Scanner/Write calls before Wait. Preserve clean EOF and terminal validation
        on success. After verified owning Wait, permanently open driver channels must
        yield the existing unknown/no-completion failure at the existing cancellation
        close deadline (20 seconds from cancellation, immediate if already expired),
        rather than continue waiting for channel EOF. The runner's 30-second drain
        window must not conceal an avoidable post-Wait wait; only the explicitly identified
        pending owning-Wait barrier may remain outstanding. Do not add a supervisor,
        daemon, sidecar, SDK product import, new protocol/package/status schema, privileges,
        host/cluster policy or deployment prerequisite.
      - 'Pending Wait is an unknown physical cleanup condition, not succeeded, cancelled,
        failed-with-proven-exit, or reaped. At the expired cleanup window expose one
        bounded redacted diagnostic through the existing Job diagnostic path; do not
        claim that stderr/logs are a persisted business Observation or that an unavailable
        Platform API accepted it. Never call CompleteAgentRun after persistent append
        failure or manufacture a SDK terminal to unlock the runner. Memory and buffers
        remain bounded, without a busy loop or unbounded diagnostic/event accumulation.
        While the owner remains alive, it continues its original Wait and does not
        start another Runtime/Execute. If that owner or node dies, in-memory wait
        ownership is lost: do not assert reaping, same-Run resume, safe retry or successful
        cleanup from the restart/Pod state. Preserve Unknown and the existing observe-before-retry/new-AgentRun
        boundary; no controller, observer, reaper-adoption or credential-revocation
        capability is created by this amendment. Retained processes can continue occupying
        resources and may retain access until exit/lease expiry; user approval of
        S must acknowledge this availability and residual-access risk, not treat nonterminal
        waiting as complete containment.'
      - 'Preserve both original reject roots and their immutable reject verdicts.
        On the final new PR #88 HEAD, independently satisfy the H replacement gate
        for required-agentrun-cancellation-verification-intermittent-failure while
        explicitly recording its original historical cause as unknown, and independently
        close agentrun-sdk-cancellation-publishes-result-before-driver-reaping with
        the complete S proof; neither root may be silently deleted or marked historically
        fixed. AITEAM-1031 Worker Run 01a0f4ca-dbb9-7e0f-973e-a4ab594c65ee''s production
        red/green evidence proves a reproduced ordering symptom, not an independent
        implementation pass or the original AITEAM-820 PID state. Keep PR88 HEAD 67d1011fcec19bf28df0135d7a495361a0d9941c/tree
        346bbfe405b30b62bbd0a3efb41beb4f3b9b78ea and pre-fix 072c3b5be69d7461c381d699b01df4e291748ff9/tree
        7647332b03939efac82d782fce0b5a61df4db425 as immutable evidence baselines,
        not new verification. Retain all ignored failure logs and review report 87173b88083b360d812880bf9695b7b9da38a2df93757d70194f8b84f9cdbfa1
        / ledger 5fc6e07bdb43088ab02117a99d4d6b247ed8763b7ae24675f470634fd451c5aa.
        The historical reconstruction obligation is replaced only by explicit H approval,
        never by S or the current ordering red/green. Preserve latest PR88 evidence
        baseline 0a267c37c22b5cdc38a13e7751d5375e4ccaf425/tree 7b85fdc0c197a2617056b638e7acc883733e547e,
        review report efdf0fb6dba9e24d537c425b498630c036db087b1efba585cbcede55a347d2df
        and ledger 90fdbf47f5adabd91b73a54cdd71ea5e1a6276f3656da9af12b70760019364fc;
        the new implementation still needs a fresh delivery, independent review and
        normal merge before Audit runs its fresh uncached full gate.'
      verification_commands:
      - GOTOOLCHAIN=go1.26.0 go version
      - mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
        go test -count=1 -json ./cmd/agentrun-job -run '^TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure$'
        > artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
      - python3 -c "import json; rows=[json.loads(x) for x in open('artifacts/agentrun-cancellation-prerequisite/cancellation-test.json')
        if x.strip()]; name='TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure';
        assert any(x.get('Test')==name and x.get('Action')=='run' for x in rows);
        assert any(x.get('Test')==name and x.get('Action')=='pass' for x in rows);
        assert not any(x.get('Action') in ('fail','skip') for x in rows)"
      - GOTOOLCHAIN=go1.26.0 go test -count=1 ./runtime-sdk/... ./internal/agentrun/...
        ./cmd/agentrun-job/...
      - GOTOOLCHAIN=go1.26.0 go vet ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
      - GOTOOLCHAIN=go1.26.0 go build ./cmd/agentrun-job/...
      - test -s artifacts/agentrun-cancellation-prerequisite/diagnosis.md
      - mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -covermode=atomic
        -coverprofile=artifacts/agent-run-job/coverage.out ./internal/agentrun/...
        ./cmd/agentrun-job/...
      - python3 -c "from pathlib import Path; import re,subprocess; p=Path('artifacts/agent-run-job/coverage.out');
        assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True);
        m=re.search(r'^total:\s+\(statements\)\s+([0-9.]+)%$',out,re.M); assert m
        and float(m.group(1)) >= 90"
      - mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -json ./cmd/agentrun-job/...
        -run '^(TestProductionStreamJSONAdapterLaunchesConfiguredCommand|TestPublishedRuntimeAdapterContainsNoFixtureHooks|TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData|TestStreamJSONCleansUpAcceptanceKindMismatch|TestStreamJSONRejectsForeignSessionEvents)$'
        -count=1 > artifacts/agent-run-job/stream-json-hardening.json
      - 'python3 -c "import json; required={''TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData'',
        ''TestPublishedRuntimeAdapterContainsNoFixtureHooks'', ''TestStreamJSONRejectsForeignSessionEvents'',
        ''TestStreamJSONCleansUpAcceptanceKindMismatch'', ''TestProductionStreamJSONAdapterLaunchesConfiguredCommand''};
        rows=[json.loads(x) for x in open(''artifacts/agent-run-job/stream-json-hardening.json'')
        if x.strip()]; passed={x.get(''Test'') for x in rows if x.get(''Action'')==''pass''
        and x.get(''Test'') in required}; assert passed==required, f''missing required
        passing stream-json tests: {sorted(required-passed)}''"'
      - 'python3 -c "from pathlib import Path; roots=[Path(''cmd/agentrun-job/vendor''),Path(''cmd/agentrun-job/driver.go'')];
        files=[]; [files.extend(p for p in ([r] if r.is_file() else r.rglob(''*''))
        if p.is_file() and ''testdata'' not in p.parts and not p.name.endswith(''_test.go''))
        for r in roots]; forbidden=(''AGENTRUN_FIXTURE_MODE'',''AGENTRUN_FIXTURE_MARKER'',''AGENTRUN_FIXTURE_PID_FILE'',''blockForever'');
        hits=[f''{p}:{token}'' for p in files for token in forbidden if token in p.read_text(errors=''ignore'')];
        assert not hits, f''published fixture hooks: {hits}''"'
      - test "$(docker run --rm --platform linux/arm64 golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
        go version)" = "go version go1.26.0 linux/arm64"
      - python3 -c 'from pathlib import Path; import hashlib; assert hashlib.sha256(Path('"'"'go.mod'"'"').read_bytes()).hexdigest()
        == '"'"'cae88fa59fd0eb66eaa902e486882d20f7c12a577093be22ec1fd122c8ca9ef2'"'"',
        '"'"'module change exceeds the approved single duplicate-indirect deletion'"'"';
        assert hashlib.sha256(Path('"'"'go.sum'"'"').read_bytes()).hexdigest() ==
        '"'"'7f069d03a85b59955951c07a4b1b390bc94d95fe815e17d6faaf52b6bcac0027'"'"',
        '"'"'go.sum changed outside authorization'"'"''
      - python3 cmd/agentrun-job/build_release.py --source-revision HEAD --target
        linux/arm64 --build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
        --vendor-package ./cmd/agentrun-job/vendor --driver-identity cmd/agentrun-job/driver_identity.json
        --output artifacts/agent-run-job --network-policy module-download-only
      - python3 -c "from pathlib import Path; import json; d=json.loads(Path('artifacts/agent-run-job/runtime-driver-release-manifest.json').read_text());
        assert d['build']=={'image':'golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7','go_version':'1.26.0','goos':'linux','goarch':'arm64'};
        assert set(d['binaries'])=={'agentrun-job','agentrun-vendor'}; assert d['vendor_source']=='cmd/agentrun-job/vendor'
        and d['vendor_role']=='stream-json-protocol-adapter' and d['bundled_third_party_runtime_count']==0"
      - python3 cmd/agentrun-job/verify_package.py --package-root artifacts/agent-run-job
        --component-manifest artifacts/agent-run-job/component-manifest.json --binaries-manifest
        artifacts/agent-run-job/go-binaries-manifest.json --component-link artifacts/agent-run-job/immutable-component-link.json
        --release-manifest artifacts/agent-run-job/runtime-driver-release-manifest.json
        --driver-identity cmd/agentrun-job/driver_identity.json --expected-target
        linux/arm64 --expected-build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
        --execute-shipped-pair --forbid-build --forbid-fixture-staging --report artifacts/agent-run-job/package-verification.json
      - python3 -c "from pathlib import Path; import json; r=json.loads(Path('artifacts/agent-run-job/package-verification.json').read_text());
        assert r['schema']=='oac.agentrun-package-verification/v1' and r['build_attempted']
        is False and r['fixture_staging_attempted'] is False and r['shipped_pair_executed']
        is True and r['process_tests_passed'] is True and r['published_fixture_hook_count']==0
        and r['external_stream_json_command_executed'] is True and r['native_event_provenance_verified']
        is True"
      - mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
        go test -count=1 -json ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
        > artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
      - test -s artifacts/agentrun-cancellation-prerequisite/evidence-index.json
      integration_gates:
      - name: agentrun-cancellation-cause-and-remedy-gate
        layer: L1
        source_of_truth:
        - docs/design/open-agent-cluster-overview-design.md#55-execution-host-与执行边界
        - docs/design/detailed/06-agent-runtime-detailed-design.md#8-runtime-sdk-调用与实时事件流
        - docs/design/detailed/06-agent-runtime-detailed-design.md#83-usage-采集主链
        - docs/design/detailed/06-agent-runtime-detailed-design.md#10-runtime-sdk-与-agent-job-接口检查
        - docs/design/detailed/09-governance-and-security-detailed-design.md#7-execution-security
        - docs/design/detailed/09-governance-and-security-detailed-design.md#91-权威来源与写入边界
        - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/main_test.go#L179-L219
        - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/adapters_test.go#L609-L649
        - AITEAM-820 reject report attachment 01a0f325-c5a2-7bd0-ae43-624c6d61e485
          SHA256 e15cd8e27bbf52e970b31e16453e885f99178b4576adc1f23f66f5c49040fd39;
          ledger 01a0f325-c91c-7abf-b69f-346fe0f95b39 SHA256 35afd7e34ac1d0c0ed9af931fd2584e628d0d82ab4dea9f5b9957dd1b9620c4c;
          root required-agentrun-cancellation-verification-intermittent-failure
        - .omac/open-agent-cluster.yaml:agent-run-job and runtime-sdk-mcp-launch-compatibility
          (completed source-owner contracts)
        - .omac/open-agent-cluster.acceptance.yaml:UJ-RUN-001
        - docs/references/execution/agent-runtime.md#7-runtime-sdk
        - AITEAM-1031 approved S comment 01a0f592-f317-7d9f-a49b-43af3fac6b1d; applied
          amendment amend-82e0c1a4d969 (policy authority only)
        - AITEAM-1031 latest reject report attachment 01a0f621-0cc8-7205-9ad6-4d89e8ef1a77
          SHA256 efdf0fb6dba9e24d537c425b498630c036db087b1efba585cbcede55a347d2df;
          ledger attachment 01a0f621-1005-71b1-baf6-933faad00165 SHA256 90fdbf47f5adabd91b73a54cdd71ea5e1a6276f3656da9af12b70760019364fc
        - AITEAM-820 Reviewer Run 01a0f309-c400-7722-95e9-d0d1fd842aac tool-result
          seq 83 retained full output SHA256 14840a218f6da62d98ddf3f3268028855b3978d8c4811096b1ff7d2050042976
          (numeric PID and failing assertion only; no historical identity/state/Wait
          proof)
        - docs/references/execution/agent-runtime.md#9-oac-agent-job-与-agentrunevent
        delivery_goal: 'Under explicit H approval, independent Reviewer must verify
          a source-bound prospective cause and reproducible remedy for the cancellation/Wait
          failure class, not reconstruction of the original AITEAM-820 ten-second
          failure. Retain that original failed test and historical root as cause unknown
          with H approval reference, not historically fixed. Independently reproduce
          a permanent failing-before/passing-after regression through the actual built
          Job -> linked stream-json driver -> adapter -> configured Runtime chain;
          pin the immutable before and final code-source SHA/tree actually used for
          tests and release bytes, and bind the final PR HEAD through OMAC''s sealed
          delivery_identity and retrievable immutable delivery-commit blob locations.
          Record exact build/test commands, environment/Go/OS/architecture/reaper
          conditions, command exit codes and redacted evidence hashes. A later evidence-only
          delivery commit is permitted only as the separately sealed delivery identity;
          it must not be mistaken for the code-source revision, and the package/release
          evidence must name the actual final PR delivery identity without requiring
          an artifact to self-name its containing commit. Bind observations in the
          new reproduction to PID plus start identity, PPID, state, the single original
          Wait owner and Wait outcome/order. Demonstrate the causal mechanism and
          why the minimal remedy prevents that reproduced failure; no green retry,
          observer-only result, changed deadline or policy approval counts. The known
          072c3b5be69d7461c381d699b01df4e291748ff9 ordering regression and final 0a267c37c22b5cdc38a13e7751d5375e4ccaf425
          result are reproducible baselines, not new-HEAD verification and not proof
          of the historical ten-second process state. The replacement does NOT require
          making that unknowable historical state known or stretching the existing
          100ms regression into proof of ten-second historical persistence. If claiming
          an environment-only remedy instead, independently demonstrate causal before/after
          process evidence and commit the bounded setup/cleanup recipe without privilege,
          host policy or new deployment requirements; absence of a source diagnosis
          cannot itself establish an environment cause. Diagnose any newly observed
          failure and retain its evidence; block rather than reinterpret a failing
          ten-second assertion. diagnosis.md and evidence-index.json must map each
          assertion, test/subtest, code-source revision/tree, delivery identity, command/exit
          code, raw evidence digest/size and retrievable immutable evidence location
          to its precise limited claim; existence alone is not proof. The user-approved
          S boundary must also be verified: independently distinguish a post-exit
          pipe/channel stall from a still-pending owning Wait; prove bounded cancellation/pipe
          cleanup without killing the adapter that still owns Runtime Wait; include
          startup/no-acceptance, malformed-stream, append-failure and timeout sibling
          paths. With a deterministic held-Wait test seam outside production, observe
          across the existing deadlines that no Job return/terminal/Complete occurs
          and the redacted pending-cleanup diagnostic appears, then release and reap
          every fixture process in bounded test teardown. This controlled hold proves
          the safety rule, not an actually unkillable OS process or a finite OS completion
          guarantee. Once Wait is proven, permanently non-closing Events/Result must
          not prevent the existing bounded unknown/no-completion exit. Preserve the
          ten-second disappearance assertion and live-child/zombie/PID-reuse/probe-error
          controls; rerun the actual built production-chain failing-before/passing-after
          regression and all inherited code-source quality and shipped-byte gates.
          Reviewer must explicitly reject undocumented infinite software waits, premature
          outer-owner killing, fake reaping or treating user policy approval as evidence
          of historical-cause closure. The independent held-original-Wait proof must
          traverse the existing ownership chain, not merely substitute a fake driver
          or delay invoking Wait. Cover startup/no-acceptance, malformed-stream, persistent-append
          and timeout siblings; observe the unchanged five-second escalation, ten-second
          observation, twenty-second SDK cancellation deadline and thirty-second runner
          drain boundary where applicable. While the original Wait is held, adapter/Job
          stay alive, no SDK terminal/result or Complete is published, cancellation
          and owned-pipe cleanup proceed, and exactly one bounded redacted diagnostic
          appears. Then release the hold and prove single-owner reaping and bounded
          teardown for all fixtures. A controlled hold is not evidence of an actually
          unkillable kernel process. Confirm bounded unknown/no-completion after proven
          Wait with nonclosing driver channels, and align only the named owning documentation
          to that already-approved exception. The Developer chooses the minimal test
          seam/remedy, confined to non-release test code for instrumentation; the
          Planner prescribes evidence and ownership, not implementation.'
        covers:
        - agentrun-cancellation-prerequisite
        acceptance_refs:
        - UJ-RUN-001
        commands:
        - GOTOOLCHAIN=go1.26.0 go version
        - mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
          go test -count=1 -json ./cmd/agentrun-job -run '^TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure$'
          > artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
        - python3 -c "import json; rows=[json.loads(x) for x in open('artifacts/agentrun-cancellation-prerequisite/cancellation-test.json')
          if x.strip()]; name='TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure';
          assert any(x.get('Test')==name and x.get('Action')=='run' for x in rows);
          assert any(x.get('Test')==name and x.get('Action')=='pass' for x in rows);
          assert not any(x.get('Action') in ('fail','skip') for x in rows)"
        - GOTOOLCHAIN=go1.26.0 go test -count=1 ./runtime-sdk/... ./internal/agentrun/...
          ./cmd/agentrun-job/...
        - GOTOOLCHAIN=go1.26.0 go vet ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
        - GOTOOLCHAIN=go1.26.0 go build ./cmd/agentrun-job/...
        - test -s artifacts/agentrun-cancellation-prerequisite/diagnosis.md
        - mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
          go test -count=1 -json ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
          > artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
        - test -s artifacts/agentrun-cancellation-prerequisite/evidence-index.json
        artifacts:
        - artifacts/agentrun-cancellation-prerequisite/diagnosis.md
        - artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
        - artifacts/agentrun-cancellation-prerequisite/evidence-index.json
        - artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
      - name: agentrun-cancellation-preserved-release-gate
        layer: L1
        source_of_truth:
        - docs/design/detailed/06-agent-runtime-detailed-design.md:L38-L175
        - docs/design/detailed/06-agent-runtime-detailed-design.md:L305-L451
        - docs/references/execution/agent-runtime.md
        - docs/references/software-delivery/artifacts-release-and-deployment.md:L138-L209
        - five-nodes-recovery-decisions.md
        delivery_goal: Preserve all completed AgentRun Job quality, security, protocol
          and exact-byte release guarantees on the separately delivered cancellation
          remedy; no historical package evidence substitution.
        covers:
        - agentrun-cancellation-prerequisite
        acceptance_refs:
        - UJ-RUN-001
        commands:
        - mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -covermode=atomic
          -coverprofile=artifacts/agent-run-job/coverage.out ./internal/agentrun/...
          ./cmd/agentrun-job/...
        - python3 -c "from pathlib import Path; import re,subprocess; p=Path('artifacts/agent-run-job/coverage.out');
          assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True);
          m=re.search(r'^total:\s+\(statements\)\s+([0-9.]+)%$',out,re.M); assert
          m and float(m.group(1)) >= 90"
        - mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -json ./cmd/agentrun-job/...
          -run '^(TestProductionStreamJSONAdapterLaunchesConfiguredCommand|TestPublishedRuntimeAdapterContainsNoFixtureHooks|TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData|TestStreamJSONCleansUpAcceptanceKindMismatch|TestStreamJSONRejectsForeignSessionEvents)$'
          -count=1 > artifacts/agent-run-job/stream-json-hardening.json
        - 'python3 -c "import json; required={''TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData'',
          ''TestPublishedRuntimeAdapterContainsNoFixtureHooks'', ''TestStreamJSONRejectsForeignSessionEvents'',
          ''TestStreamJSONCleansUpAcceptanceKindMismatch'', ''TestProductionStreamJSONAdapterLaunchesConfiguredCommand''};
          rows=[json.loads(x) for x in open(''artifacts/agent-run-job/stream-json-hardening.json'')
          if x.strip()]; passed={x.get(''Test'') for x in rows if x.get(''Action'')==''pass''
          and x.get(''Test'') in required}; assert passed==required, f''missing required
          passing stream-json tests: {sorted(required-passed)}''"'
        - 'python3 -c "from pathlib import Path; roots=[Path(''cmd/agentrun-job/vendor''),Path(''cmd/agentrun-job/driver.go'')];
          files=[]; [files.extend(p for p in ([r] if r.is_file() else r.rglob(''*''))
          if p.is_file() and ''testdata'' not in p.parts and not p.name.endswith(''_test.go''))
          for r in roots]; forbidden=(''AGENTRUN_FIXTURE_MODE'',''AGENTRUN_FIXTURE_MARKER'',''AGENTRUN_FIXTURE_PID_FILE'',''blockForever'');
          hits=[f''{p}:{token}'' for p in files for token in forbidden if token in
          p.read_text(errors=''ignore'')]; assert not hits, f''published fixture hooks:
          {hits}''"'
        - test "$(docker run --rm --platform linux/arm64 golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
          go version)" = "go version go1.26.0 linux/arm64"
        - python3 cmd/agentrun-job/build_release.py --source-revision HEAD --target
          linux/arm64 --build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
          --vendor-package ./cmd/agentrun-job/vendor --driver-identity cmd/agentrun-job/driver_identity.json
          --output artifacts/agent-run-job --network-policy module-download-only
        - python3 -c "from pathlib import Path; import json; d=json.loads(Path('artifacts/agent-run-job/runtime-driver-release-manifest.json').read_text());
          assert d['build']=={'image':'golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7','go_version':'1.26.0','goos':'linux','goarch':'arm64'};
          assert set(d['binaries'])=={'agentrun-job','agentrun-vendor'}; assert d['vendor_source']=='cmd/agentrun-job/vendor'
          and d['vendor_role']=='stream-json-protocol-adapter' and d['bundled_third_party_runtime_count']==0"
        - python3 cmd/agentrun-job/verify_package.py --package-root artifacts/agent-run-job
          --component-manifest artifacts/agent-run-job/component-manifest.json --binaries-manifest
          artifacts/agent-run-job/go-binaries-manifest.json --component-link artifacts/agent-run-job/immutable-component-link.json
          --release-manifest artifacts/agent-run-job/runtime-driver-release-manifest.json
          --driver-identity cmd/agentrun-job/driver_identity.json --expected-target
          linux/arm64 --expected-build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
          --execute-shipped-pair --forbid-build --forbid-fixture-staging --report
          artifacts/agent-run-job/package-verification.json
        - python3 -c "from pathlib import Path; import json; r=json.loads(Path('artifacts/agent-run-job/package-verification.json').read_text());
          assert r['schema']=='oac.agentrun-package-verification/v1' and r['build_attempted']
          is False and r['fixture_staging_attempted'] is False and r['shipped_pair_executed']
          is True and r['process_tests_passed'] is True and r['published_fixture_hook_count']==0
          and r['external_stream_json_command_executed'] is True and r['native_event_provenance_verified']
          is True"
        required_metrics:
          statement_coverage_percent: 90
          declared_artifact_count: 11
          published_fixture_hook_count: 0
          bundled_third_party_runtime_count: 0
          required_stream_json_hardening_test_count: 5
          shipped_pair_execution_count: 1
          external_stream_json_command_execution_count: 1
          native_event_provenance_failure_count: 0
        artifacts:
        - artifacts/agent-run-job/coverage.out
        - artifacts/agent-run-job/stream-json-hardening.json
        - artifacts/agent-run-job/source-bundle.tar.zst
        - artifacts/agent-run-job/component-manifest.json
        - artifacts/agent-run-job/agentrun-job
        - artifacts/agent-run-job/agentrun-vendor
        - artifacts/agent-run-job/go-binaries-manifest.json
        - artifacts/agent-run-job/immutable-component-link.json
        - artifacts/agent-run-job/runtime-driver-release-manifest.json
        - artifacts/agent-run-job/release-package.tar
        - artifacts/agent-run-job/package-verification.json
      pr_base: main
      acceptance_refs:
      - UJ-RUN-001
      source_of_truth:
      - docs/design/open-agent-cluster-overview-design.md#55-execution-host-与执行边界
      - docs/design/detailed/06-agent-runtime-detailed-design.md#8-runtime-sdk-调用与实时事件流
      - docs/design/detailed/06-agent-runtime-detailed-design.md#83-usage-采集主链
      - docs/design/detailed/06-agent-runtime-detailed-design.md#10-runtime-sdk-与-agent-job-接口检查
      - docs/design/detailed/09-governance-and-security-detailed-design.md#7-execution-security
      - docs/design/detailed/09-governance-and-security-detailed-design.md#91-权威来源与写入边界
      - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/main_test.go#L179-L219
      - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/adapters_test.go#L609-L649
      - AITEAM-820 reject report attachment 01a0f325-c5a2-7bd0-ae43-624c6d61e485 SHA256
        e15cd8e27bbf52e970b31e16453e885f99178b4576adc1f23f66f5c49040fd39; ledger 01a0f325-c91c-7abf-b69f-346fe0f95b39
        SHA256 35afd7e34ac1d0c0ed9af931fd2584e628d0d82ab4dea9f5b9957dd1b9620c4c; root
        required-agentrun-cancellation-verification-intermittent-failure
      - .omac/open-agent-cluster.yaml:agent-run-job and runtime-sdk-mcp-launch-compatibility
        (completed source-owner contracts)
      - .omac/open-agent-cluster.acceptance.yaml:UJ-RUN-001
      - docs/references/execution/agent-runtime.md#7-runtime-sdk
      - AITEAM-1031 approved S comment 01a0f592-f317-7d9f-a49b-43af3fac6b1d; applied
        amendment amend-82e0c1a4d969 (policy authority only)
      - AITEAM-1031 latest reject report attachment 01a0f621-0cc8-7205-9ad6-4d89e8ef1a77
        SHA256 efdf0fb6dba9e24d537c425b498630c036db087b1efba585cbcede55a347d2df; ledger
        attachment 01a0f621-1005-71b1-baf6-933faad00165 SHA256 90fdbf47f5adabd91b73a54cdd71ea5e1a6276f3656da9af12b70760019364fc
      - AITEAM-820 Reviewer Run 01a0f309-c400-7722-95e9-d0d1fd842aac tool-result seq
        83 retained full output SHA256 14840a218f6da62d98ddf3f3268028855b3978d8c4811096b1ff7d2050042976
        (numeric PID and failing assertion only; no historical identity/state/Wait
        proof)
      - docs/references/execution/agent-runtime.md#9-oac-agent-job-与-agentrunevent
      required_contracts:
      - docs/references/execution/agent-runtime.md
      - docs/references/workflow/workflow-and-execution.md
      - five-nodes-recovery-decisions.md
      scope_paths:
      - cmd/agentrun-job/**
      - go.mod
      - docs/design/detailed/06-agent-runtime-detailed-design.md
      - docs/references/execution/agent-runtime.md
      evidence_mode: fixture
      produces:
      - artifact_id: agentrun-cancellation-remedy-evidence
identity_schema: omac.dag-amendment-identity/v2
amendment_id: amend-d969a05c1631
base:
  manifest_sha256: 0546066f2966be40eae7d88785109a7363f1cb3cfe6207eba0261bb10e3d0ec0
  definition_sha256: 3ffb9138e7c717af49e26d20347336cfa58c2d13249499cd6c81589af30e4386
  evidence_sha256:
    agentrun-cancellation-prerequisite: d63e2c90d2a742e97fc42ac9f799dc9421eaa5a2cf228da56245bc637742d97c
  acceptance_sha256: a2cafa439be1850842214d75d55e6c1a706ed679b969e63cd1052abd5de09620
review:
  issue_id: 01a0f8e5-1547-7244-9e7e-fb1b8a978138
  verdict: pass
human_confirmation: pending
analysis:
  changed_nodes:
  - agentrun-cancellation-prerequisite
  derived_started_downstream: []
  minimal_rerun:
    review:
    - agentrun-cancellation-prerequisite
    authoring: []
    merging: []
  historical_contract_corrections: []
  risk: definition changes are CAS-protected; runtime-only drift is rebased only when
    it does not change the minimum recovery set

```
