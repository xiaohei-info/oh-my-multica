# OAC execution interruption: root-cause investigation

Date: 2026-09-26
Status: Diagnosed and reproduced; implementation fixes not applied by this investigation.

This report distinguishes immutable execution evidence, reproduced software
behavior, and the network failure whose physical origin remains unconfirmed.
No live task state or completed-node history was rewritten for this diagnosis.

## 1. Audit: legacy review-ledger semantics block upstream reads

The last Audit worker Run `01a0dbd4-ae4f-7519-8022-1773a5c7b41b`
completed without a runtime error, but could not read required upstream handoffs.
The referenced attachments were downloaded and their SHA-256 values matched
the authoritative metadata. Their persisted cycle rounds are:

| Upstream | WorkItem | Persisted rounds | Reproduced failure |
| --- | --- | --- | --- |
| Bootstrap Go | `5849f786-8c97-42ac-adf9-1c96957f28ee` | `1,2,3,3` | `cycles[3].round must be 4` |
| Release tooling | `152d735a-c373-4967-8ae0-45c191de2eff` | `1,1,2,3,4,5,6` | `cycles[1].round must be 2` |
| Acceptance document | `8e6bd282-6039-41d2-aa00-969a0bf1554a` | `7,8,9,10` | `cycles[0].round must be 1` |

All three current `omac work show` commands were independently rerun and exited
5 with those exact validation failures. This is deterministic, not an Agent
capability failure or a transient download issue.

The historical writer before OMAC commit `ace251c` stored the caller-provided
`round_index`. That commit (2026-08-03) changed the writer to a ledger-local
`len(cycles)+1` sequence and introduced strict sequential validation, while the
schema identifier remained `omac.review-ledger/v1`. The observed historical
ledgers do not satisfy the newer semantics. This establishes an old-data/read
contract mismatch; it does not reconstruct the original writer invocation of
every duplicate historical row.

`build_show_output` invokes convergence resolution even when reading an
already-completed upstream task. These legacy items have no generation fields,
so `current_review_ledger` treats their ledger as current. The invalid-round
ValueError is raised before the special legacy-missing-facts handling, making
the entire upstream `work show` inaccessible.

### Why repeated runs consumed the budget

The worker guide requires reading upstream tasks and stopping when their facts
are inaccessible. The worker did that and explained the blocker in its final
text. There is no typed worker-blocker option in the current `work submit` CLI.
The Runner's handoff path classified the result as `finished-without-submit`,
not an actionable upstream validation failure, and retried until the cumulative
worker counter reached 20. The observed restarted loop consumed rounds 17–20;
these were not 20 newly launched runs in this session.

Fix boundary: legacy/version-aware historical evidence reading or an explicit,
verified migration/reconstruction; keep active convergence validation strict.
Do not edit historical round numbers blindly or mark the ledger as valid.
Route deterministic upstream blockers through structured OMAC control so they
do not consume repeated no-submit retries.

## 2. Harness: recovery reintroduces a superseded review

Before operator retry, Harness had current generation
`amendment-a480e34d70240c4fb69dfbeb` but historical ledger generation
`authoring-d58eaade9c628e882db72cc3`. The current SDK contract requires
negative boundary evidence and leaves the genuine Host positive path downstream.
Its only declared consumed artifact is `contracts-extension-wire-evidence`.

The authoring retry selected historical report attachment
`01a057e2-8016-76fd-b78a-98e5e26503f5`, SHA-256
`fe28dfabb4934258738c9d5c1cffcc983b2d6072cd2af8780184b769be80e51b`.
Its requirements include the genuine Host-installed positive fixture. This
requirement was copied into `worker_handoff.source_review_feedback` and then
exposed as `previous_review` to the new worker.

The concrete chain is:

1. `node._cmd_retry` sees review history but no current report and calls
   `recover_review_rework_context`.
2. That function chooses the newest report/ledger attachments by comment time,
   without checking current review generation or current contract identity.
3. `_operator_retry_feedback` carries those references and blocker texts into
   the new handoff.
4. `_previous_review_context` accepts the handoff's causal fields without a
   binding to the current contract/review generation.

A read-only reproduction using the actual handoff shows
`current_review_ledger(item) is None`, while `_previous_review_context(item)`
still returns that obsolete report and the handoff passes `is_causally_bound()`.
This is a generation-isolation gap, not evidence that the current SDK contract
must be expanded again. The operator authoring retry in this session triggered
the faulty recovery path.

### Why review-stage retry immediately blocked again

`validate_stage_recovery` validates a review delivery identity only when one is
present; a missing identity is accepted. The Runner's
`_reviewer_run_baseline_for_observation` requires that identity to exist and be
complete. A minimal reproduction passes review recovery validation with
`delivery_identity=None` and immediately fails observation with
`the current delivery identity is missing or incomplete`.

Fix boundary: use consistent sealed-delivery preconditions, and bind recovered
review feedback to the applicable generation/contract. A retired review may be
history but must not silently become a new generation's mandatory obligations.

## 3. Runner: the run-list read bypasses transport retry

The Runner log ends while querying Kernel WorkItem
`01a047b8-a9c9-74bb-a30d-3b56c698a78f` through `multica issue runs`, with
`TLS handshake timed out`.

The direct exit chain is:

`MulticaRuntime.list_runs -> _issue_runs -> MulticaStore._run_multica ->
PlatformError -> CLI OmacError handler -> exit code 2`.

`_issue_runs` calls the raw CLI adapter instead of the existing
`_run_idempotent_read` helper. A simulated read failure made exactly one CLI
attempt and zero bounded-read-wrapper calls before propagating the error.
Separately, `_transient_read_failure` recognizes ordinary request timeouts but
does not recognize either English or Chinese TLS-handshake-timeout wording.
Both were reproduced. Fixing the classifier alone would not fix this raw path.

The long-running DAG loop has no outer transient-read recovery around this
exception. It correctly does not invent successful platform observations, but
terminates. The background process was started without an external supervisor,
so its exit also stopped automatic result collection and review dispatch.
Previously dispatched Agent processes continue independently.

Fix boundary: retry explicitly idempotent Run reads through the common bounded
transport policy; distinguish handshake timeout from certificate/authentication
failure; define supervised/read-failure recovery without blindly repeating
writes. The physical reason for the TLS handshake timeout (network/proxy/server
path) has not been established by this investigation.

## Code locations inspected

In `/Volumes/SSD1T/code/ai/oh-my-multica`:

- `src/omac/core/review_convergence.py`: `_validate_common_cycles`,
  `validate_review_ledger`, `advance_review_ledger`.
- `src/omac/core/taskmeta.py`: `current_review_ledger`,
  `WorkerHandoffIntent.is_causally_bound`.
- `src/omac/pipeline/dispatch.py`: `build_show_output`,
  `_previous_review_context`.
- `src/omac/pipeline/convergence.py`: `resolve_convergence`.
- `src/omac/engines/multica.py`: `recover_review_rework_context`,
  `_transient_read_failure`, `_run_idempotent_read`, `_issue_runs`.
- `src/omac/core/stage_recovery.py`: `validate_stage_recovery`.
- `src/omac/cli/commands/node.py`: `_cmd_retry`, `_operator_retry_feedback`.
- `src/omac/pipeline/loop.py`: finished-without-submit retry and reviewer
  baseline observation paths.
- `src/omac/cli/commands/dag.py` and `src/omac/cli/main.py`: Runner loop and
  exception-to-exit-code boundary.

The installed local OMAC imports this checkout. Existing uncommitted changes in
that repository were preserved. This investigation did not modify its source.
Downloaded immutable evidence and read-only reproduction results are under
`/tmp/oac-rootcause-evidence/`; the Runner log is
`/tmp/oac-a-runner-20260926-113641.log`.
