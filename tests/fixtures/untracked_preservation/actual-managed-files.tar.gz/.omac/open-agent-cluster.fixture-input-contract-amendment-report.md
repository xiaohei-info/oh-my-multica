# release-artifact-tooling fixture-input contract blocker

## Trigger

- Manifest: `.omac/open-agent-cluster.yaml`
- Blocked node: `release-artifact-tooling`
- Work item: `152d735a-c373-4967-8ae0-45c191de2eff` (AITEAM-808)
- Existing implementation PR: OAC PR #5
- Superseded amendment issue: `56e888d5-959c-46cd-876e-537e38df13d1` (AITEAM-812)
- Latest Worker Run: `10cbaf3c-d3f4-4fd8-be38-55321240b2bb`

## Confirmed blocker

The accepted evidence-boundary amendment correctly classified this foundational node as `evidence_mode: fixture` and declared its twelve owned outputs, but it copied the prior verification commands unchanged.

Three mandatory verification commands invoke the Artifact Storage and release-handoff verifiers with policy flags only and provide no concrete fixture, release manifest, installation index, storage closure, binding digest, credential reference, probe evidence, or signature input. The same contract requires these verifiers to fail closed when that evidence is absent. Therefore the contract currently requires both no-input success and missing-evidence rejection.

The latest Worker correctly refused to implement contradictory behavior and set the issue to blocked. This is a contract defect, not a Runtime failure and not a request for downstream production release resources.

## Required amendment outcome

Amend only `release-artifact-tooling` unless a directly necessary fixture producer contract must also be made explicit. Preserve the approved DAG topology, work item identity, PR, source ownership boundary, downstream production responsibilities, and `evidence_mode: fixture`.

Replace every no-input positive Artifact Storage or release-handoff verification command with an executable command that reads explicit, deterministic, versioned in-repository positive fixtures owned by this node. The fixtures must contain the minimum internally consistent signed closure, binding digest, credential reference, compatibility/connectivity/readiness evidence, release-manifest commitment, and installation-index commitment needed by the relevant verifier. Positive commands must prove real parsing and cryptographic/digest/commitment checks; they must not rely on implicit defaults, generated source-text assertions, hard-coded success, or missing-input success.

Keep negative/fail-closed behavior covered by executable adversarial tests for absent, mismatched, uncommitted, tampered, inline-secret, and incompatible evidence. Do not require real downstream platform CRDs, workloads, migrations, trusted release artifacts, system-release assembly outputs, or live external services at this node.

Update the node's verification commands, integration-gate commands, scope paths, produced artifacts, required metrics, and responsibility summary together so they describe one coherent fixture-backed contract. If the exact fixture paths do not yet exist, assign their creation to this node under `tests/release-tooling/**` rather than referencing downstream production paths.

The amendment must be derived from the complete supplied `docs/` design corpus, the current manifest, the accepted amendment history, the latest Worker blocker comment, and the existing PR contract. Reviewer must explicitly verify that:

1. every positive verifier command supplies concrete fixture inputs;
2. missing evidence fails closed;
3. no downstream production deliverable becomes an input of this foundational node;
4. the command list is executable from a clean checkout;
5. only the minimal authoring rerun is requested.
