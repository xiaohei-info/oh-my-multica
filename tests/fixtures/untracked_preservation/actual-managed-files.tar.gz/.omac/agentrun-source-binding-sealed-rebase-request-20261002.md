# Rebind the already approved one-field evidence correction to genuine fresh sealed delivery

User approval of d969 (exact old reviewed file SHA ba9688eff9b95934612e245c7ee58e6c86a428a1a4658cbab852a269b2182f0a, “批准并继续写”) remains effective. H/S remain approved. This is the concrete step 5 in independently reviewed recovery3885, not a new evidence/quality decision or generic assessment. Do not ask again for same authority.

Existing recovery issue01a0f9f9 is terminal confirmation/pass; only supersede that attempt. Old d969/3885 envelopes cannot be accepted or edited to fake new base hashes. Produce a fresh normal proposal/envelope from actual current manifest and Store, with exactly the already-approved cause-and-remedy delivery_goal change. Validate real stage preconditions and independence of recovery footprint, not only static classification. No new code, tests, dummy source commit, broad authoring recovery or plan.

Concrete fresh facts: Developer01a0fa1c completed01:14:29 after real new formal work submit, verification attachment01a0fa2d-11c5-7435-b0fc-98808994b01b/comment01a0fa2d-123c-70b2-82df-bdd0ac4fbd78 SHA06441c7252fac282d1502142f0d677aa7e11ea3a45593c01a583406e4940e202/25812B timestamp01:14:12Z. Normal bounded controller collect sealed delivery_identity and dispatched Reviewer01a0fa37, which is now completed with real reject. Current seal remains bound to that fresh Run/uploader/task/verification/PR88HEAD1e2d4073b3e90f9c9676bef53a0690ddb4a22109. Current StoreIN_REVIEW REVIEW/reject with no active owner Run; controller and Runner absent. Fresh installed validate_stage_recovery(store.get_work_item(owner),'review') passed. Do not process reject into another Worker handoff or retire this real seal.

Full independent implementation report SHA593d79240f331f71ebd82d96a9deba4ab80eae734317da1d7891a1c5e1dd92ee/56615B; ledger SHAd5f78aa2575bc0931be92934dbff3b00b1ac026638e942bf6a7c44dab55f3035/27350B. Five retained findings share one source-versus-delivery authority correction, not five code defects. Reviewer independently passed technical cancellation/cause/remedy/release verification and all19 indexed bytes; evidence-only revision difference and rebuilt exact binary digests verified, but does NOT grant implementation acceptance under old gate. Preserve full latest reject/report/ledger and every original failed history/counter. New amendment Reviewer must decide exact semantic equality with human-approved correction, fresh bindings, stage executable, unchanged other nodes/61done/absolute budgets/ownership/commands/H/Sproof90/10sec/pinnedbytes/security/HostwholeSDK90+Host90. Do not waive or reinterpret any finding beyond that exact approved correction. If same correction cannot meet genuine current stage preconditions, return exact evidence and supported safe action; never fabricate identity or modify engine.

Current complete bound inputs on Mac/Oracle: /tmp/oac-source-binding-sealed-inputs-20261002; archive /tmp/oac-source-binding-sealed-inputs-20261002.tar.gz SHA01badd70239155a6e19af99181dc42df9aeb0b999b42b7650424790c2a4df8f9. All required_contract roots copied including directories. Use these exact current bytes for lint/validate; no older172 or pre-H manifest. Live Store must be freshly read independently. Current raw Store/runs, full latest reject+ledger, verification and human approval are included with digests. Do not write live control plane from Planner/Reviewer except formal OMAC work delivery/review.

## Already human-approved exact definition envelope (authority, not current CAS)

```yaml
schema: omac.dag-amendment/v1
reason: Resolve the final-HEAD evidence self-reference conflict through the narrowest
  supported review-safe contract correction. The prior reject showed that committed
  evidence generated from code source 48881db8e1223ef1f105d3f3f237d50f948a511d was
  delivered in a later PR commit, so the existing cause/remedy gate must distinguish
  the tested code-source SHA/tree from the separately sealed OMAC delivery_identity
  and immutable delivery blobs while retaining the existing requirement to bind the
  final PR delivery identity. This proposal changes only the existing integration
  gate delivery_goal, a review-safe contract field; it preserves every non_goal, runtime
  fact, worker/reviewer, dependency, scope path, typed boundary, release command,
  acceptance responsibility, historical record, threshold, and counter. The node remains
  eligible for review-stage recovery only; no unrelated started successor is reset.
  The owner must explicitly approve the tested-code-source versus later OMAC delivery-identity
  evidence authority; prior H/S approval does not approve that new tradeoff.
operations:
- op: update
  node: agentrun-cancellation-prerequisite
  set:
    contract:
      objective: Resolve the AgentRun cancellation prerequisite through independently
        reproduced source-bound causal/remedy evidence for the cancellation/Wait failure
        class, under the separately human-approved historical-evidence replacement
        decision H; retain the original AITEAM-820 failure as causally unclassified
        history. Preserve already-approved S and independently prove its held-original-Wait,
        deadlines, diagnostic and teardown obligations before normal merge and Audit
        re-verification.
      non_goals:
      - Do not ship AGENTRUN_FIXTURE_MODE, fixture marker/PID hooks, blockForever,
        synthetic all-event generation, or any other test-selected behavior in cmd/agentrun-job/vendor,
        driver production code, or the release bundle; malformed-stream fixtures belong
        only in testdata or non-release test packages.
      - Do not bundle a specific third-party Runtime binary; launch only the exact
        external executable path and ordered arguments fixed by deployment-time launch
        input, without PATH lookup or mutable environment override.
      - Do not accept duplicate started/resumed records, any non-empty line after
        terminal, an acceptance kind that mismatches new versus resume mode, or an
        ordinary event carrying a foreign vendor session identity.
      - Do not complete successfully until the terminal record, clean vendor EOF,
        child exit, critical-tail persistence, and package-proven event provenance
        are all validated.
      - Do not select or reselect Agent, Runtime, model, MCP, Workspace, resource
        bindings, business routes, or stable lineage.
      - Do not require changes to merged scripts/release tooling; package construction,
        source scanning, protocol verification and exact-byte checks remain under
        cmd/agentrun-job/**.
      - 'Do not modify PR #78, Audit/Usage or its permitted AgentDefinition/Preview
        consumer changes, canonical schemas, other domain behavior, the live DAG,
        completed-node contracts, source ownership catalogs, or retry/coverage/security
        thresholds.'
      - Do not treat unchanged-tree green runs, a possible ordering race, observer
        improvements, S approval or approval of H as an implementation pass or reconstruction
        of the original AITEAM-820 ten-second failure. Retain every failed attempt.
        After H is explicitly approved, independently proven prospective causal/remedy
        evidence under the cause-and-remedy gate may satisfy this prerequisite without
        claiming the original process state or historical cause was established. If
        that replacement evidence cannot be established, submit a precise owner-decision
        blocker and leave the prerequisite unresolved.
      - Do not skip, quarantine, delete, soften or increase the ten-second process-disappearance
        deadline of the failing test to obtain a pass. Preserve cancellation reaching
        the actual vendor, child exit AND reaping, one Execute/stream, bounded drain/backpressure,
        critical-tail ACK ordering and no CompleteAgentRun after persistent append
        failure. If observation/fixture code is wrong, prove the defect and preserve
        or strengthen those assertions with positive and negative controls, including
        detection of a genuinely live unreaped child; do not redefine a zombie as
        reaped.
      - Do not decide source versus environment from kill -0 alone. Bind observations
        to the actual child identity, parent/wait ownership and process state, accounting
        for PID reuse, zombies and permission/probe errors. Explain cancellation-to-exit-to-Wait
        ordering using the existing runner, SDK and driver call paths; instrumentation
        belongs only in tests or bounded redacted evidence, not production fixture
        hooks.
      - 'Supporting production/test edits outside cmd/agentrun-job are permitted only
        in the existing internal/agentrun or runtime-sdk cancellation/session-close
        path when causally required by the source-bound cancellation/Wait failure
        class and approved S obligations, not on an invented historical causal link.
        This does not transfer the completed SDK or Job owners or authorize SDK product
        imports, unrelated MCP/planning repair or broader refactoring. Sole additional
        supporting-file exception: this compensation node may remove exactly the redundant
        indirect gopkg.in/yaml.v3 v3.0.1 requirement from root go.mod, retaining the
        existing direct requirement at v3.0.1 and every other byte; go.sum must remain
        byte-identical. This is a one-defect implementation authorization, not transfer
        of the canonical bootstrap-go package/source-catalog ownership. The only additional
        supporting-document authorization is to align docs/design/detailed/06-agent-runtime-detailed-design.md
        sections 8 and 8.2 and docs/references/execution/agent-runtime.md sections
        7 and 9 with already-approved S: confirmed owning Wait plus expired cancellation
        channel-close deadline permits the existing unknown/no-completion failure
        even if driver Events/Result remain open; pending Wait still retains its original
        owner. Preserve normal success EOF/terminal/critical-tail ACK ordering. No
        other design, governance, schema, catalog or completed-owner edits are authorized.
        This narrow documentation responsibility is explicit in the ownership migration;
        it is not a new runtime policy.'
      - A source/fixture cause requires a permanent failing-before/passing-after regression
        and the minimal correction in a new owner PR based on main. An environment-only
        cause requires independently reproducible before/after process evidence and
        a durable bounded environment/setup/cleanup recipe committed with the owner
        PR; no privilege expansion, global process killing, host/cluster policy change
        or new deployment requirement is authorized. If such a tradeoff is genuinely
        necessary, stop for an explicit decision.
      - The diagnostic deliverable must pin the original rejected HEAD and report/ledger
        hashes, actual tested source SHA/tree, Go version, OS/architecture, relevant
        process/reaper conditions, commands/exit codes and redacted evidence digests.
        Distinguish proven source/fixture or environment cause from unproven hypotheses.
        Describe the concrete remedy and how Audit reproduces it after merge; package
        source and release evidence must name the actual new PR HEAD, never the rejected
        HEAD or a temporary modified tree. Separate original retained observation,
        reproduced prospective cause/remedy, and approved residual uncertainty in
        diagnosis.md. A prospective source/fixture or bounded environment proof is
        not retroactive proof of the original failure; do not assert that the original
        failure is repaired or its environment cause excluded.
      - Preserve the inherited agent-run-job release/coverage/protocol gates as written
        below, including the pinned linux/arm64 shipped pair and exact-byte package
        verification. Native reproducer results and shipped-package results are distinct
        evidence. Do not claim the old merged package proves a changed implementation.
      - If required evidence or environment is unavailable, or a separate repository
        failure requires another owner, stop with a precise blocker rather than invent
        evidence, widen scope or declare the prerequisite complete.
      - Do not run broad go mod tidy, upgrade or downgrade dependencies/toolchains,
        change go.sum or other module directives, relax the read-only source/cache
        mounts or module-download-only network policy, or modify release tooling to
        bypass this prerequisite. Independently review the exact one-line module diff
        and rerun every inherited release gate on the final clean committed PR HEAD.
        If any additional module change is required, stop with an owner-decision blocker;
        this amendment does not authorize it.
      - 'Preserve and hand off all existing AITEAM-1031 scoped work and failed evidence
        before authoring: completed Worker Run 01a0f397-2199-7347-9a8c-e671ab7c802a;
        source repository /home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-1031-e671ab7c802a/workdir/open-agent-cluster;
        branch agent/codex-ubuntu-newapi/e671ab7c802a; implementation commit 799bd737f19b48770f393ab148dbcd447339c114
        and diagnosis commit abed8bfc38360c847d328cfaf42475ff77472d2b (tree bfda144ef5640b454ad98611671eace32917c1ec),
        plus ignored artifacts/agentrun-cancellation-prerequisite evidence. These
        are unsubmitted Worker claims, not independent passes or a package delivery.
        Preserve the historical rejected HEAD, report/ledger, all failed attempts
        and absolute counters. The historical cancellation cause remains unproven;
        a module fix, observer improvement or current green run does not satisfy the
        replacement causal/remedy gate. Original numeric PID is recoverable from the
        retained Reviewer Run tool-result seq 83 full output SHA256 14840a218f6da62d98ddf3f3268028855b3978d8c4811096b1ff7d2050042976;
        original start-time/PPID/state/owning-Wait facts have not been established.
        Do not repeat that the numeric PID is missing, and do not infer identity/state/Wait
        from that number. Preserve unknown historical cause explicitly under H, not
        as a fixed historical root.'
      - 'Option S is already human-approved and applied as amend-82e0c1a4d969, recorded
        in AITEAM-1031 comment 01a0f592-f317-7d9f-a49b-43af3fac6b1d. Do not reopen
        or require reapproval of S. Retain its exact safety-first pending-Wait policy,
        availability/residual-access risks, Unknown on owner loss and no finite OS
        completion promise. NEW HUMAN DECISION H IS REQUIRED BEFORE APPLY OR IMPLEMENTATION:
        explicitly approve replacing proof of the original AITEAM-820 historical cause/remedy
        with the evidence-bound prospective cause/remedy gate below, while recording
        the original cause as unknown and accepting that recurrence from an unobserved
        historical environment/identity/reaping cause is not excluded. Bind approval
        to this reviewed amendment and its exact old/new obligation and recovery footprint.
        Coordinator planning authorization, prior retry, S approval, Reviewer pass
        or current green results are not H approval. Without H approval preserve the
        unresolved blocker/work and do not apply or dispatch. Alternatively retain
        the original contract and supply authoritative original process/Wait records
        if recovered; no new live-environment access is authorized.'
      - 'Under explicitly approved option S, replace the contradictory unconditional
        finite-cleanup-plus-Wait-before-return requirement with bounded software shutdown
        and an explicit pending-Wait retention exception. Cancellation still reaches
        the exact configured Runtime through the existing Job -> linked stream-json
        adapter -> Runtime chain. Keep the adapter''s five-second TERM grace then
        group/direct SIGKILL, and the existing ten-second driver observation windows;
        deadline expiry is not proof of death/reaping. Retain the single parent owning
        each child Wait. Do not SIGKILL the adapter merely because its outer grace
        expired while its Runtime Wait is unconfirmed: that destroys the inner wait
        owner and cannot prove Runtime reaping. The adapter must not exit, and Job
        Run/Execute-start failure must not return, until the Runtime owning Wait followed
        by the adapter owning Wait are established. Apply the same rule to startup/acceptance
        failure, malformed stream, timeout, append failure and ordinary cancellation.
        Never return from startFailure after a failed bounded killAndWait as if ownership
        had been discharged.'
      - The pending-Wait exception is not permission for avoidable software deadlock.
        Decouple cancellation escalation and the single owning Wait from blocked acceptance/stdin
        writes, stdout Scan/forwarding, stderr-copy EOF and public event/result consumers
        in the existing driver/adapter cancellation path. Close owned pipe endpoints
        on cancellation/failure and bound post-exit I/O joins; treat forced pipe closure
        as incomplete evidence, never clean success. A pinned Go Cmd.WaitDelay can
        bound post-exit copying, but cannot replace Process.Wait, reap a live process,
        bound a kernel wait that never returns, or by itself unblock caller-owned
        Scanner/Write calls before Wait. Preserve clean EOF and terminal validation
        on success. After verified owning Wait, permanently open driver channels must
        yield the existing unknown/no-completion failure at the existing cancellation
        close deadline (20 seconds from cancellation, immediate if already expired),
        rather than continue waiting for channel EOF. The runner's 30-second drain
        window must not conceal an avoidable post-Wait wait; only the explicitly identified
        pending owning-Wait barrier may remain outstanding. Do not add a supervisor,
        daemon, sidecar, SDK product import, new protocol/package/status schema, privileges,
        host/cluster policy or deployment prerequisite.
      - 'Pending Wait is an unknown physical cleanup condition, not succeeded, cancelled,
        failed-with-proven-exit, or reaped. At the expired cleanup window expose one
        bounded redacted diagnostic through the existing Job diagnostic path; do not
        claim that stderr/logs are a persisted business Observation or that an unavailable
        Platform API accepted it. Never call CompleteAgentRun after persistent append
        failure or manufacture a SDK terminal to unlock the runner. Memory and buffers
        remain bounded, without a busy loop or unbounded diagnostic/event accumulation.
        While the owner remains alive, it continues its original Wait and does not
        start another Runtime/Execute. If that owner or node dies, in-memory wait
        ownership is lost: do not assert reaping, same-Run resume, safe retry or successful
        cleanup from the restart/Pod state. Preserve Unknown and the existing observe-before-retry/new-AgentRun
        boundary; no controller, observer, reaper-adoption or credential-revocation
        capability is created by this amendment. Retained processes can continue occupying
        resources and may retain access until exit/lease expiry; user approval of
        S must acknowledge this availability and residual-access risk, not treat nonterminal
        waiting as complete containment.'
      - 'Preserve both original reject roots and their immutable reject verdicts.
        On the final new PR #88 HEAD, independently satisfy the H replacement gate
        for required-agentrun-cancellation-verification-intermittent-failure while
        explicitly recording its original historical cause as unknown, and independently
        close agentrun-sdk-cancellation-publishes-result-before-driver-reaping with
        the complete S proof; neither root may be silently deleted or marked historically
        fixed. AITEAM-1031 Worker Run 01a0f4ca-dbb9-7e0f-973e-a4ab594c65ee''s production
        red/green evidence proves a reproduced ordering symptom, not an independent
        implementation pass or the original AITEAM-820 PID state. Keep PR88 HEAD 67d1011fcec19bf28df0135d7a495361a0d9941c/tree
        346bbfe405b30b62bbd0a3efb41beb4f3b9b78ea and pre-fix 072c3b5be69d7461c381d699b01df4e291748ff9/tree
        7647332b03939efac82d782fce0b5a61df4db425 as immutable evidence baselines,
        not new verification. Retain all ignored failure logs and review report 87173b88083b360d812880bf9695b7b9da38a2df93757d70194f8b84f9cdbfa1
        / ledger 5fc6e07bdb43088ab02117a99d4d6b247ed8763b7ae24675f470634fd451c5aa.
        The historical reconstruction obligation is replaced only by explicit H approval,
        never by S or the current ordering red/green. Preserve latest PR88 evidence
        baseline 0a267c37c22b5cdc38a13e7751d5375e4ccaf425/tree 7b85fdc0c197a2617056b638e7acc883733e547e,
        review report efdf0fb6dba9e24d537c425b498630c036db087b1efba585cbcede55a347d2df
        and ledger 90fdbf47f5adabd91b73a54cdd71ea5e1a6276f3656da9af12b70760019364fc;
        the new implementation still needs a fresh delivery, independent review and
        normal merge before Audit runs its fresh uncached full gate.'
      verification_commands:
      - GOTOOLCHAIN=go1.26.0 go version
      - mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
        go test -count=1 -json ./cmd/agentrun-job -run '^TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure$'
        > artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
      - python3 -c "import json; rows=[json.loads(x) for x in open('artifacts/agentrun-cancellation-prerequisite/cancellation-test.json')
        if x.strip()]; name='TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure';
        assert any(x.get('Test')==name and x.get('Action')=='run' for x in rows);
        assert any(x.get('Test')==name and x.get('Action')=='pass' for x in rows);
        assert not any(x.get('Action') in ('fail','skip') for x in rows)"
      - GOTOOLCHAIN=go1.26.0 go test -count=1 ./runtime-sdk/... ./internal/agentrun/...
        ./cmd/agentrun-job/...
      - GOTOOLCHAIN=go1.26.0 go vet ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
      - GOTOOLCHAIN=go1.26.0 go build ./cmd/agentrun-job/...
      - test -s artifacts/agentrun-cancellation-prerequisite/diagnosis.md
      - mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -covermode=atomic
        -coverprofile=artifacts/agent-run-job/coverage.out ./internal/agentrun/...
        ./cmd/agentrun-job/...
      - python3 -c "from pathlib import Path; import re,subprocess; p=Path('artifacts/agent-run-job/coverage.out');
        assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True);
        m=re.search(r'^total:\s+\(statements\)\s+([0-9.]+)%$',out,re.M); assert m
        and float(m.group(1)) >= 90"
      - mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -json ./cmd/agentrun-job/...
        -run '^(TestProductionStreamJSONAdapterLaunchesConfiguredCommand|TestPublishedRuntimeAdapterContainsNoFixtureHooks|TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData|TestStreamJSONCleansUpAcceptanceKindMismatch|TestStreamJSONRejectsForeignSessionEvents)$'
        -count=1 > artifacts/agent-run-job/stream-json-hardening.json
      - 'python3 -c "import json; required={''TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData'',
        ''TestPublishedRuntimeAdapterContainsNoFixtureHooks'', ''TestStreamJSONRejectsForeignSessionEvents'',
        ''TestStreamJSONCleansUpAcceptanceKindMismatch'', ''TestProductionStreamJSONAdapterLaunchesConfiguredCommand''};
        rows=[json.loads(x) for x in open(''artifacts/agent-run-job/stream-json-hardening.json'')
        if x.strip()]; passed={x.get(''Test'') for x in rows if x.get(''Action'')==''pass''
        and x.get(''Test'') in required}; assert passed==required, f''missing required
        passing stream-json tests: {sorted(required-passed)}''"'
      - 'python3 -c "from pathlib import Path; roots=[Path(''cmd/agentrun-job/vendor''),Path(''cmd/agentrun-job/driver.go'')];
        files=[]; [files.extend(p for p in ([r] if r.is_file() else r.rglob(''*''))
        if p.is_file() and ''testdata'' not in p.parts and not p.name.endswith(''_test.go''))
        for r in roots]; forbidden=(''AGENTRUN_FIXTURE_MODE'',''AGENTRUN_FIXTURE_MARKER'',''AGENTRUN_FIXTURE_PID_FILE'',''blockForever'');
        hits=[f''{p}:{token}'' for p in files for token in forbidden if token in p.read_text(errors=''ignore'')];
        assert not hits, f''published fixture hooks: {hits}''"'
      - test "$(docker run --rm --platform linux/arm64 golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
        go version)" = "go version go1.26.0 linux/arm64"
      - python3 -c 'from pathlib import Path; import hashlib; assert hashlib.sha256(Path('"'"'go.mod'"'"').read_bytes()).hexdigest()
        == '"'"'cae88fa59fd0eb66eaa902e486882d20f7c12a577093be22ec1fd122c8ca9ef2'"'"',
        '"'"'module change exceeds the approved single duplicate-indirect deletion'"'"';
        assert hashlib.sha256(Path('"'"'go.sum'"'"').read_bytes()).hexdigest() ==
        '"'"'7f069d03a85b59955951c07a4b1b390bc94d95fe815e17d6faaf52b6bcac0027'"'"',
        '"'"'go.sum changed outside authorization'"'"''
      - python3 cmd/agentrun-job/build_release.py --source-revision HEAD --target
        linux/arm64 --build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
        --vendor-package ./cmd/agentrun-job/vendor --driver-identity cmd/agentrun-job/driver_identity.json
        --output artifacts/agent-run-job --network-policy module-download-only
      - python3 -c "from pathlib import Path; import json; d=json.loads(Path('artifacts/agent-run-job/runtime-driver-release-manifest.json').read_text());
        assert d['build']=={'image':'golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7','go_version':'1.26.0','goos':'linux','goarch':'arm64'};
        assert set(d['binaries'])=={'agentrun-job','agentrun-vendor'}; assert d['vendor_source']=='cmd/agentrun-job/vendor'
        and d['vendor_role']=='stream-json-protocol-adapter' and d['bundled_third_party_runtime_count']==0"
      - python3 cmd/agentrun-job/verify_package.py --package-root artifacts/agent-run-job
        --component-manifest artifacts/agent-run-job/component-manifest.json --binaries-manifest
        artifacts/agent-run-job/go-binaries-manifest.json --component-link artifacts/agent-run-job/immutable-component-link.json
        --release-manifest artifacts/agent-run-job/runtime-driver-release-manifest.json
        --driver-identity cmd/agentrun-job/driver_identity.json --expected-target
        linux/arm64 --expected-build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
        --execute-shipped-pair --forbid-build --forbid-fixture-staging --report artifacts/agent-run-job/package-verification.json
      - python3 -c "from pathlib import Path; import json; r=json.loads(Path('artifacts/agent-run-job/package-verification.json').read_text());
        assert r['schema']=='oac.agentrun-package-verification/v1' and r['build_attempted']
        is False and r['fixture_staging_attempted'] is False and r['shipped_pair_executed']
        is True and r['process_tests_passed'] is True and r['published_fixture_hook_count']==0
        and r['external_stream_json_command_executed'] is True and r['native_event_provenance_verified']
        is True"
      - mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
        go test -count=1 -json ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
        > artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
      - test -s artifacts/agentrun-cancellation-prerequisite/evidence-index.json
      integration_gates:
      - name: agentrun-cancellation-cause-and-remedy-gate
        layer: L1
        source_of_truth:
        - docs/design/open-agent-cluster-overview-design.md#55-execution-host-与执行边界
        - docs/design/detailed/06-agent-runtime-detailed-design.md#8-runtime-sdk-调用与实时事件流
        - docs/design/detailed/06-agent-runtime-detailed-design.md#83-usage-采集主链
        - docs/design/detailed/06-agent-runtime-detailed-design.md#10-runtime-sdk-与-agent-job-接口检查
        - docs/design/detailed/09-governance-and-security-detailed-design.md#7-execution-security
        - docs/design/detailed/09-governance-and-security-detailed-design.md#91-权威来源与写入边界
        - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/main_test.go#L179-L219
        - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/adapters_test.go#L609-L649
        - AITEAM-820 reject report attachment 01a0f325-c5a2-7bd0-ae43-624c6d61e485
          SHA256 e15cd8e27bbf52e970b31e16453e885f99178b4576adc1f23f66f5c49040fd39;
          ledger 01a0f325-c91c-7abf-b69f-346fe0f95b39 SHA256 35afd7e34ac1d0c0ed9af931fd2584e628d0d82ab4dea9f5b9957dd1b9620c4c;
          root required-agentrun-cancellation-verification-intermittent-failure
        - .omac/open-agent-cluster.yaml:agent-run-job and runtime-sdk-mcp-launch-compatibility
          (completed source-owner contracts)
        - .omac/open-agent-cluster.acceptance.yaml:UJ-RUN-001
        - docs/references/execution/agent-runtime.md#7-runtime-sdk
        - AITEAM-1031 approved S comment 01a0f592-f317-7d9f-a49b-43af3fac6b1d; applied
          amendment amend-82e0c1a4d969 (policy authority only)
        - AITEAM-1031 latest reject report attachment 01a0f621-0cc8-7205-9ad6-4d89e8ef1a77
          SHA256 efdf0fb6dba9e24d537c425b498630c036db087b1efba585cbcede55a347d2df;
          ledger attachment 01a0f621-1005-71b1-baf6-933faad00165 SHA256 90fdbf47f5adabd91b73a54cdd71ea5e1a6276f3656da9af12b70760019364fc
        - AITEAM-820 Reviewer Run 01a0f309-c400-7722-95e9-d0d1fd842aac tool-result
          seq 83 retained full output SHA256 14840a218f6da62d98ddf3f3268028855b3978d8c4811096b1ff7d2050042976
          (numeric PID and failing assertion only; no historical identity/state/Wait
          proof)
        - docs/references/execution/agent-runtime.md#9-oac-agent-job-与-agentrunevent
        delivery_goal: 'Under explicit H approval, independent Reviewer must verify
          a source-bound prospective cause and reproducible remedy for the cancellation/Wait
          failure class, not reconstruction of the original AITEAM-820 ten-second
          failure. Retain that original failed test and historical root as cause unknown
          with H approval reference, not historically fixed. Independently reproduce
          a permanent failing-before/passing-after regression through the actual built
          Job -> linked stream-json driver -> adapter -> configured Runtime chain;
          pin the immutable before and final code-source SHA/tree actually used for
          tests and release bytes, and bind the final PR HEAD through OMAC''s sealed
          delivery_identity and retrievable immutable delivery-commit blob locations.
          Record exact build/test commands, environment/Go/OS/architecture/reaper
          conditions, command exit codes and redacted evidence hashes. A later evidence-only
          delivery commit is permitted only as the separately sealed delivery identity;
          it must not be mistaken for the code-source revision, and the package/release
          evidence must name the actual final PR delivery identity without requiring
          an artifact to self-name its containing commit. Bind observations in the
          new reproduction to PID plus start identity, PPID, state, the single original
          Wait owner and Wait outcome/order. Demonstrate the causal mechanism and
          why the minimal remedy prevents that reproduced failure; no green retry,
          observer-only result, changed deadline or policy approval counts. The known
          072c3b5be69d7461c381d699b01df4e291748ff9 ordering regression and final 0a267c37c22b5cdc38a13e7751d5375e4ccaf425
          result are reproducible baselines, not new-HEAD verification and not proof
          of the historical ten-second process state. The replacement does NOT require
          making that unknowable historical state known or stretching the existing
          100ms regression into proof of ten-second historical persistence. If claiming
          an environment-only remedy instead, independently demonstrate causal before/after
          process evidence and commit the bounded setup/cleanup recipe without privilege,
          host policy or new deployment requirements; absence of a source diagnosis
          cannot itself establish an environment cause. Diagnose any newly observed
          failure and retain its evidence; block rather than reinterpret a failing
          ten-second assertion. diagnosis.md and evidence-index.json must map each
          assertion, test/subtest, code-source revision/tree, delivery identity, command/exit
          code, raw evidence digest/size and retrievable immutable evidence location
          to its precise limited claim; existence alone is not proof. The user-approved
          S boundary must also be verified: independently distinguish a post-exit
          pipe/channel stall from a still-pending owning Wait; prove bounded cancellation/pipe
          cleanup without killing the adapter that still owns Runtime Wait; include
          startup/no-acceptance, malformed-stream, append-failure and timeout sibling
          paths. With a deterministic held-Wait test seam outside production, observe
          across the existing deadlines that no Job return/terminal/Complete occurs
          and the redacted pending-cleanup diagnostic appears, then release and reap
          every fixture process in bounded test teardown. This controlled hold proves
          the safety rule, not an actually unkillable OS process or a finite OS completion
          guarantee. Once Wait is proven, permanently non-closing Events/Result must
          not prevent the existing bounded unknown/no-completion exit. Preserve the
          ten-second disappearance assertion and live-child/zombie/PID-reuse/probe-error
          controls; rerun the actual built production-chain failing-before/passing-after
          regression and all inherited code-source quality and shipped-byte gates.
          Reviewer must explicitly reject undocumented infinite software waits, premature
          outer-owner killing, fake reaping or treating user policy approval as evidence
          of historical-cause closure. The independent held-original-Wait proof must
          traverse the existing ownership chain, not merely substitute a fake driver
          or delay invoking Wait. Cover startup/no-acceptance, malformed-stream, persistent-append
          and timeout siblings; observe the unchanged five-second escalation, ten-second
          observation, twenty-second SDK cancellation deadline and thirty-second runner
          drain boundary where applicable. While the original Wait is held, adapter/Job
          stay alive, no SDK terminal/result or Complete is published, cancellation
          and owned-pipe cleanup proceed, and exactly one bounded redacted diagnostic
          appears. Then release the hold and prove single-owner reaping and bounded
          teardown for all fixtures. A controlled hold is not evidence of an actually
          unkillable kernel process. Confirm bounded unknown/no-completion after proven
          Wait with nonclosing driver channels, and align only the named owning documentation
          to that already-approved exception. The Developer chooses the minimal test
          seam/remedy, confined to non-release test code for instrumentation; the
          Planner prescribes evidence and ownership, not implementation.'
        covers:
        - agentrun-cancellation-prerequisite
        acceptance_refs:
        - UJ-RUN-001
        commands:
        - GOTOOLCHAIN=go1.26.0 go version
        - mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
          go test -count=1 -json ./cmd/agentrun-job -run '^TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure$'
          > artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
        - python3 -c "import json; rows=[json.loads(x) for x in open('artifacts/agentrun-cancellation-prerequisite/cancellation-test.json')
          if x.strip()]; name='TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure';
          assert any(x.get('Test')==name and x.get('Action')=='run' for x in rows);
          assert any(x.get('Test')==name and x.get('Action')=='pass' for x in rows);
          assert not any(x.get('Action') in ('fail','skip') for x in rows)"
        - GOTOOLCHAIN=go1.26.0 go test -count=1 ./runtime-sdk/... ./internal/agentrun/...
          ./cmd/agentrun-job/...
        - GOTOOLCHAIN=go1.26.0 go vet ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
        - GOTOOLCHAIN=go1.26.0 go build ./cmd/agentrun-job/...
        - test -s artifacts/agentrun-cancellation-prerequisite/diagnosis.md
        - mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
          go test -count=1 -json ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
          > artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
        - test -s artifacts/agentrun-cancellation-prerequisite/evidence-index.json
        artifacts:
        - artifacts/agentrun-cancellation-prerequisite/diagnosis.md
        - artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
        - artifacts/agentrun-cancellation-prerequisite/evidence-index.json
        - artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
      - name: agentrun-cancellation-preserved-release-gate
        layer: L1
        source_of_truth:
        - docs/design/detailed/06-agent-runtime-detailed-design.md:L38-L175
        - docs/design/detailed/06-agent-runtime-detailed-design.md:L305-L451
        - docs/references/execution/agent-runtime.md
        - docs/references/software-delivery/artifacts-release-and-deployment.md:L138-L209
        - five-nodes-recovery-decisions.md
        delivery_goal: Preserve all completed AgentRun Job quality, security, protocol
          and exact-byte release guarantees on the separately delivered cancellation
          remedy; no historical package evidence substitution.
        covers:
        - agentrun-cancellation-prerequisite
        acceptance_refs:
        - UJ-RUN-001
        commands:
        - mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -covermode=atomic
          -coverprofile=artifacts/agent-run-job/coverage.out ./internal/agentrun/...
          ./cmd/agentrun-job/...
        - python3 -c "from pathlib import Path; import re,subprocess; p=Path('artifacts/agent-run-job/coverage.out');
          assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True);
          m=re.search(r'^total:\s+\(statements\)\s+([0-9.]+)%$',out,re.M); assert
          m and float(m.group(1)) >= 90"
        - mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -json ./cmd/agentrun-job/...
          -run '^(TestProductionStreamJSONAdapterLaunchesConfiguredCommand|TestPublishedRuntimeAdapterContainsNoFixtureHooks|TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData|TestStreamJSONCleansUpAcceptanceKindMismatch|TestStreamJSONRejectsForeignSessionEvents)$'
          -count=1 > artifacts/agent-run-job/stream-json-hardening.json
        - 'python3 -c "import json; required={''TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData'',
          ''TestPublishedRuntimeAdapterContainsNoFixtureHooks'', ''TestStreamJSONRejectsForeignSessionEvents'',
          ''TestStreamJSONCleansUpAcceptanceKindMismatch'', ''TestProductionStreamJSONAdapterLaunchesConfiguredCommand''};
          rows=[json.loads(x) for x in open(''artifacts/agent-run-job/stream-json-hardening.json'')
          if x.strip()]; passed={x.get(''Test'') for x in rows if x.get(''Action'')==''pass''
          and x.get(''Test'') in required}; assert passed==required, f''missing required
          passing stream-json tests: {sorted(required-passed)}''"'
        - 'python3 -c "from pathlib import Path; roots=[Path(''cmd/agentrun-job/vendor''),Path(''cmd/agentrun-job/driver.go'')];
          files=[]; [files.extend(p for p in ([r] if r.is_file() else r.rglob(''*''))
          if p.is_file() and ''testdata'' not in p.parts and not p.name.endswith(''_test.go''))
          for r in roots]; forbidden=(''AGENTRUN_FIXTURE_MODE'',''AGENTRUN_FIXTURE_MARKER'',''AGENTRUN_FIXTURE_PID_FILE'',''blockForever'');
          hits=[f''{p}:{token}'' for p in files for token in forbidden if token in
          p.read_text(errors=''ignore'')]; assert not hits, f''published fixture hooks:
          {hits}''"'
        - test "$(docker run --rm --platform linux/arm64 golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
          go version)" = "go version go1.26.0 linux/arm64"
        - python3 cmd/agentrun-job/build_release.py --source-revision HEAD --target
          linux/arm64 --build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
          --vendor-package ./cmd/agentrun-job/vendor --driver-identity cmd/agentrun-job/driver_identity.json
          --output artifacts/agent-run-job --network-policy module-download-only
        - python3 -c "from pathlib import Path; import json; d=json.loads(Path('artifacts/agent-run-job/runtime-driver-release-manifest.json').read_text());
          assert d['build']=={'image':'golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7','go_version':'1.26.0','goos':'linux','goarch':'arm64'};
          assert set(d['binaries'])=={'agentrun-job','agentrun-vendor'}; assert d['vendor_source']=='cmd/agentrun-job/vendor'
          and d['vendor_role']=='stream-json-protocol-adapter' and d['bundled_third_party_runtime_count']==0"
        - python3 cmd/agentrun-job/verify_package.py --package-root artifacts/agent-run-job
          --component-manifest artifacts/agent-run-job/component-manifest.json --binaries-manifest
          artifacts/agent-run-job/go-binaries-manifest.json --component-link artifacts/agent-run-job/immutable-component-link.json
          --release-manifest artifacts/agent-run-job/runtime-driver-release-manifest.json
          --driver-identity cmd/agentrun-job/driver_identity.json --expected-target
          linux/arm64 --expected-build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
          --execute-shipped-pair --forbid-build --forbid-fixture-staging --report
          artifacts/agent-run-job/package-verification.json
        - python3 -c "from pathlib import Path; import json; r=json.loads(Path('artifacts/agent-run-job/package-verification.json').read_text());
          assert r['schema']=='oac.agentrun-package-verification/v1' and r['build_attempted']
          is False and r['fixture_staging_attempted'] is False and r['shipped_pair_executed']
          is True and r['process_tests_passed'] is True and r['published_fixture_hook_count']==0
          and r['external_stream_json_command_executed'] is True and r['native_event_provenance_verified']
          is True"
        required_metrics:
          statement_coverage_percent: 90
          declared_artifact_count: 11
          published_fixture_hook_count: 0
          bundled_third_party_runtime_count: 0
          required_stream_json_hardening_test_count: 5
          shipped_pair_execution_count: 1
          external_stream_json_command_execution_count: 1
          native_event_provenance_failure_count: 0
        artifacts:
        - artifacts/agent-run-job/coverage.out
        - artifacts/agent-run-job/stream-json-hardening.json
        - artifacts/agent-run-job/source-bundle.tar.zst
        - artifacts/agent-run-job/component-manifest.json
        - artifacts/agent-run-job/agentrun-job
        - artifacts/agent-run-job/agentrun-vendor
        - artifacts/agent-run-job/go-binaries-manifest.json
        - artifacts/agent-run-job/immutable-component-link.json
        - artifacts/agent-run-job/runtime-driver-release-manifest.json
        - artifacts/agent-run-job/release-package.tar
        - artifacts/agent-run-job/package-verification.json
      pr_base: main
      acceptance_refs:
      - UJ-RUN-001
      source_of_truth:
      - docs/design/open-agent-cluster-overview-design.md#55-execution-host-与执行边界
      - docs/design/detailed/06-agent-runtime-detailed-design.md#8-runtime-sdk-调用与实时事件流
      - docs/design/detailed/06-agent-runtime-detailed-design.md#83-usage-采集主链
      - docs/design/detailed/06-agent-runtime-detailed-design.md#10-runtime-sdk-与-agent-job-接口检查
      - docs/design/detailed/09-governance-and-security-detailed-design.md#7-execution-security
      - docs/design/detailed/09-governance-and-security-detailed-design.md#91-权威来源与写入边界
      - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/main_test.go#L179-L219
      - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/adapters_test.go#L609-L649
      - AITEAM-820 reject report attachment 01a0f325-c5a2-7bd0-ae43-624c6d61e485 SHA256
        e15cd8e27bbf52e970b31e16453e885f99178b4576adc1f23f66f5c49040fd39; ledger 01a0f325-c91c-7abf-b69f-346fe0f95b39
        SHA256 35afd7e34ac1d0c0ed9af931fd2584e628d0d82ab4dea9f5b9957dd1b9620c4c; root
        required-agentrun-cancellation-verification-intermittent-failure
      - .omac/open-agent-cluster.yaml:agent-run-job and runtime-sdk-mcp-launch-compatibility
        (completed source-owner contracts)
      - .omac/open-agent-cluster.acceptance.yaml:UJ-RUN-001
      - docs/references/execution/agent-runtime.md#7-runtime-sdk
      - AITEAM-1031 approved S comment 01a0f592-f317-7d9f-a49b-43af3fac6b1d; applied
        amendment amend-82e0c1a4d969 (policy authority only)
      - AITEAM-1031 latest reject report attachment 01a0f621-0cc8-7205-9ad6-4d89e8ef1a77
        SHA256 efdf0fb6dba9e24d537c425b498630c036db087b1efba585cbcede55a347d2df; ledger
        attachment 01a0f621-1005-71b1-baf6-933faad00165 SHA256 90fdbf47f5adabd91b73a54cdd71ea5e1a6276f3656da9af12b70760019364fc
      - AITEAM-820 Reviewer Run 01a0f309-c400-7722-95e9-d0d1fd842aac tool-result seq
        83 retained full output SHA256 14840a218f6da62d98ddf3f3268028855b3978d8c4811096b1ff7d2050042976
        (numeric PID and failing assertion only; no historical identity/state/Wait
        proof)
      - docs/references/execution/agent-runtime.md#9-oac-agent-job-与-agentrunevent
      required_contracts:
      - docs/references/execution/agent-runtime.md
      - docs/references/workflow/workflow-and-execution.md
      - five-nodes-recovery-decisions.md
      scope_paths:
      - cmd/agentrun-job/**
      - go.mod
      - docs/design/detailed/06-agent-runtime-detailed-design.md
      - docs/references/execution/agent-runtime.md
      evidence_mode: fixture
      produces:
      - artifact_id: agentrun-cancellation-remedy-evidence
identity_schema: omac.dag-amendment-identity/v2
amendment_id: amend-d969a05c1631
base:
  manifest_sha256: 0546066f2966be40eae7d88785109a7363f1cb3cfe6207eba0261bb10e3d0ec0
  definition_sha256: 3ffb9138e7c717af49e26d20347336cfa58c2d13249499cd6c81589af30e4386
  evidence_sha256:
    agentrun-cancellation-prerequisite: d63e2c90d2a742e97fc42ac9f799dc9421eaa5a2cf228da56245bc637742d97c
  acceptance_sha256: a2cafa439be1850842214d75d55e6c1a706ed679b969e63cd1052abd5de09620
review:
  issue_id: 01a0f8e5-1547-7244-9e7e-fb1b8a978138
  verdict: pass
human_confirmation: pending
analysis:
  changed_nodes:
  - agentrun-cancellation-prerequisite
  derived_started_downstream: []
  minimal_rerun:
    review:
    - agentrun-cancellation-prerequisite
    authoring: []
    merging: []
  historical_contract_corrections: []
  risk: definition changes are CAS-protected; runtime-only drift is rebased only when
    it does not change the minimum recovery set

```

## Latest independent implementation review

```yaml
review_protocol: omac.review/v2
review_goals:
- 'Independently review the entire PR #88 scoped diff and source-bound prospective
  cause/remedy without reconstructing unknown AITEAM-820 history.'
- Verify approved S ownership, bounded I/O, 5/10/20/30-second boundaries, diagnostic
  and released-fixture cleanup.
- Rerun all inherited quality/security/protocol/pinned shipped-byte gates and distinguish
  code source from genuine delivery identity under the currently returned contract.
diff_reviewed: true
tests_rerun: true
integration_tests_rerun: true
coverage_checked: true
full_review_completed: true
summary: Technical cancellation and release verification passes; reject the still-unapplied
  evidence-authority definition correction. Five retained obligation-level findings
  share that one required correction, rather than representing five independent implementation
  defects. H, S and d969 approval are not reopened. No implementation acceptance or
  merge is claimed.
obligation_results:
- obligation_id: dimension:authority
  status: fail
  evidence: 'Current work show contract_ref SHA256 de032ea2a2ec984af392e7d33b3c2df49ed4228b19e6bf1e8f66c98b9b2c42fc
    still has the old cause-and-remedy delivery_goal and final-HEAD obligations. git
    and GitHub agree on final HEAD 1e2d4073b3e90f9c9676bef53a0690ddb4a22109/tree e0ad5512a2b4ac123090cc36e4769126f717e07c.
    HEAD evidence-index.json delivery.head, diagnosis and committed release source_revision
    name 48881db8e1223ef1f105d3f3f237d50f948a511d/tree 372375831167326f3c80ffbb32f2f970a2d25bea.
    The difference is evidence-only: cmd, internal, runtime-sdk, modules and docs
    have no changes between these revisions. All 19 committed indexed records hash-check.
    Independent rebuilding at actual HEAD succeeds and yields exactly the same job/adapter
    binary digests. Issue metadata now has a real controller-sealed delivery_identity
    for fresh Worker Run 01a0fa1c-e697-75c6-bdcf-4072ea0434d1 and verification 06441c7252fac282d1502142f0d677aa7e11ea3a45593c01a583406e4940e202.
    Coordinator comment 01a0fa1c-0624-717d-a31e-7d9291e83606 explicitly says the old
    manifest is unchanged and permits this ordinary review before the definition correction.'
- obligation_id: dimension:structure
  status: pass
  evidence: Read full scoped code/test/doc diff and declared contracts. All 19 indexed
    committed records exist with exact bytes/SHA256, including the formerly absent
    verification.yaml. No parallel product schema or Runtime selection was added.
    Trace-only UJ-RUN-001 does not create a full live E2E obligation.
- obligation_id: dimension:execution
  status: pass
  evidence: All 20 exact declared verification commands were independently exercised
    and passed, including uncached scope tests, vet/build, coverage 90.6%, five required
    protocol tests, zero production fixture hooks, authorized one-line go.mod deletion/unchanged
    go.sum, pinned Go 1.26.0 linux/arm64 build, and exact shipped-pair verification
    without building/staging during verification. Fresh HEAD-built job/adapter digests
    exactly equal the committed shipped binaries. Formal closure remains blocked only
    by the unchanged source-versus-delivery evaluation obligation.
- obligation_id: dimension:ownership
  status: pass
  evidence: Reviewed runner -> standalone SDK -> Job driver -> linked adapter -> exact
    configured Runtime. Adapter exclusively owns Runtime Wait and 5-second TERM/KILL
    escalation; Job exclusively owns adapter Wait and never kills it while inner Wait
    is pending. Cancellation closes owned pipe endpoints independently of blocked
    launch/scan/forwarding. Supporting SDK/runner cancellation changes, single module-line
    deletion and two named documentation alignments stay within explicit authorization.
    No Audit/Usage, controller, supervisor, host policy or deployment prerequisite
    change.
- obligation_id: dimension:evidence
  status: fail
  evidence: 'All committed indexed digests/lengths and verification.yaml reference
    are correct; immutable Git blobs at delivery HEAD are retrievable. Fresh verification
    seal is genuine. The remaining evaluation mismatch is the single authority blocker:
    committed source snapshot and sealed evidence-only delivery identity are distinct
    but current contract has not applied the approved distinction.'
- obligation_id: dimension:regression
  status: fail
  evidence: 'Independent pre-fix permanent built-chain regression failed at the intended
    early-Job-return assertion (exit 1), after its PID/start-identity/PPID/live-nonzombie
    checks; the same test passes at actual HEAD. Fresh four-sibling held-Wait runs
    passed at 12/31/31/31 seconds with one bounded redacted diagnostic each, closed
    owned stdout, no Job return/SDK terminal/Complete before release, and process-chain
    reaping after release. The seam invokes real exec.Cmd.Wait and holds propagation
    of its result: OS child is already reaped during this controlled hold; it is not
    an unkillable-kernel claim. Real live-child before-Wait evidence is separately
    exercised. Post-confirmed-Wait nonclosing-channel unknown/no-completion test passes.
    Historical AITEAM-820 cause remains unknown under H; no historical ten-second
    state is reconstructed. Functional regression is proven; current contract final-source
    mapping is not closed pending the named authority correction. Historical report
    3fe4c303792c51dbd87938b8a9f1ae6d55b079345855ca17564fbdd9c9323658 and ledger f060a5259edaa30493dc5eda13d19df62f0143f439dfbda334f3b77b9a659d7f
    remain immutable.'
- obligation_id: integration:agentrun-cancellation-cause-and-remedy-gate
  status: fail
  evidence: 'Independent pre-fix permanent built-chain regression failed at the intended
    early-Job-return assertion (exit 1), after its PID/start-identity/PPID/live-nonzombie
    checks; the same test passes at actual HEAD. Fresh four-sibling held-Wait runs
    passed at 12/31/31/31 seconds with one bounded redacted diagnostic each, closed
    owned stdout, no Job return/SDK terminal/Complete before release, and process-chain
    reaping after release. The seam invokes real exec.Cmd.Wait and holds propagation
    of its result: OS child is already reaped during this controlled hold; it is not
    an unkillable-kernel claim. Real live-child before-Wait evidence is separately
    exercised. Post-confirmed-Wait nonclosing-channel unknown/no-completion test passes.
    Historical AITEAM-820 cause remains unknown under H; no historical ten-second
    state is reconstructed. Its current final-HEAD evidence binding is blocked by
    the single authority mismatch, not by a new process/test failure.'
- obligation_id: integration:agentrun-cancellation-preserved-release-gate
  status: fail
  evidence: All 20 exact declared verification commands were independently exercised
    and passed, including uncached scope tests, vet/build, coverage 90.6%, five required
    protocol tests, zero production fixture hooks, authorized one-line go.mod deletion/unchanged
    go.sum, pinned Go 1.26.0 linux/arm64 build, and exact shipped-pair verification
    without building/staging during verification. Fresh HEAD-built job/adapter digests
    exactly equal the committed shipped binaries. Formal closure remains blocked only
    by the unchanged source-versus-delivery evaluation obligation.
prior_blocker_results: []
prior_blocker_scope: Current work show explicitly returns prior_open_blockers=[] and
  previous_review is absent. Formal prior_blocker_results is therefore empty. Prior
  reject report/ledger remain historical input; related lineage findings are consolidated
  into their stable underlying root, not erased or counted as five new failures.
acceptance_mapping:
- acceptance: UJ-RUN-001
  status: fail
  evidence: 'Independent pre-fix permanent built-chain regression failed at the intended
    early-Job-return assertion (exit 1), after its PID/start-identity/PPID/live-nonzombie
    checks; the same test passes at actual HEAD. Fresh four-sibling held-Wait runs
    passed at 12/31/31/31 seconds with one bounded redacted diagnostic each, closed
    owned stdout, no Job return/SDK terminal/Complete before release, and process-chain
    reaping after release. The seam invokes real exec.Cmd.Wait and holds propagation
    of its result: OS child is already reaped during this controlled hold; it is not
    an unkillable-kernel claim. Real live-child before-Wait evidence is separately
    exercised. Post-confirmed-Wait nonclosing-channel unknown/no-completion test passes.
    Historical AITEAM-820 cause remains unknown under H; no historical ten-second
    state is reconstructed. Cancellation-prerequisite contribution only: full acceptance
    trace remains gated on authoritative evidence evaluation, normal merge and downstream
    fresh Audit verification; no live user journey was claimed.'
integration_gate_mapping:
- gate: agentrun-cancellation-cause-and-remedy-gate
  status: pass
  status_scope: Declared command, metric and artifact verification passed; this is not delivery-goal acceptance.
  delivery_goal_status: fail
  delivery_goal_failure: The unchanged source-versus-delivery evidence rule remains blocked; see failed integration obligation and retained blocker.
  source_of_truth:
  - docs/design/open-agent-cluster-overview-design.md#55-execution-host-与执行边界
  - docs/design/detailed/06-agent-runtime-detailed-design.md#8-runtime-sdk-调用与实时事件流
  - docs/design/detailed/06-agent-runtime-detailed-design.md#83-usage-采集主链
  - docs/design/detailed/06-agent-runtime-detailed-design.md#10-runtime-sdk-与-agent-job-接口检查
  - docs/design/detailed/09-governance-and-security-detailed-design.md#7-execution-security
  - docs/design/detailed/09-governance-and-security-detailed-design.md#91-权威来源与写入边界
  - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/main_test.go#L179-L219
  - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/adapters_test.go#L609-L649
  - AITEAM-820 reject report attachment 01a0f325-c5a2-7bd0-ae43-624c6d61e485 SHA256
    e15cd8e27bbf52e970b31e16453e885f99178b4576adc1f23f66f5c49040fd39; ledger 01a0f325-c91c-7abf-b69f-346fe0f95b39
    SHA256 35afd7e34ac1d0c0ed9af931fd2584e628d0d82ab4dea9f5b9957dd1b9620c4c; root
    required-agentrun-cancellation-verification-intermittent-failure
  - .omac/open-agent-cluster.yaml:agent-run-job and runtime-sdk-mcp-launch-compatibility
    (completed source-owner contracts)
  - .omac/open-agent-cluster.acceptance.yaml:UJ-RUN-001
  - docs/references/execution/agent-runtime.md#7-runtime-sdk
  - AITEAM-1031 approved S comment 01a0f592-f317-7d9f-a49b-43af3fac6b1d; applied amendment
    amend-82e0c1a4d969 (policy authority only)
  - AITEAM-1031 latest reject report attachment 01a0f621-0cc8-7205-9ad6-4d89e8ef1a77
    SHA256 efdf0fb6dba9e24d537c425b498630c036db087b1efba585cbcede55a347d2df; ledger
    attachment 01a0f621-1005-71b1-baf6-933faad00165 SHA256 90fdbf47f5adabd91b73a54cdd71ea5e1a6276f3656da9af12b70760019364fc
  - AITEAM-820 Reviewer Run 01a0f309-c400-7722-95e9-d0d1fd842aac tool-result seq 83
    retained full output SHA256 14840a218f6da62d98ddf3f3268028855b3978d8c4811096b1ff7d2050042976
    (numeric PID and failing assertion only; no historical identity/state/Wait proof)
  - docs/references/execution/agent-runtime.md#9-oac-agent-job-与-agentrunevent
  delivery_goal: 'Under explicit H approval, independent Reviewer must verify a source-bound
    prospective cause and reproducible remedy for the cancellation/Wait failure class,
    not reconstruction of the original AITEAM-820 ten-second failure. Retain that
    original failed test and historical root as cause unknown with H approval reference,
    not historically fixed. Independently reproduce a permanent failing-before/passing-after
    regression through the actual built Job -> linked stream-json driver -> adapter
    -> configured Runtime chain; pin immutable before and final source SHA/tree, exact
    build/test commands, environment/Go/OS/architecture/reaper conditions, command
    exit codes and redacted evidence hashes. Bind observations in the new reproduction
    to PID plus start identity, PPID, state, the single original Wait owner and Wait
    outcome/order. Demonstrate the causal mechanism and why the minimal remedy prevents
    that reproduced failure; no green retry, observer-only result, changed deadline
    or policy approval counts. The known 072c3b5be69d7461c381d699b01df4e291748ff9
    ordering regression and final 0a267c37c22b5cdc38a13e7751d5375e4ccaf425 result
    are reproducible baselines, not new-HEAD verification and not proof of the historical
    ten-second process state. The replacement does NOT require making that unknowable
    historical state known or stretching the existing 100ms regression into proof
    of ten-second historical persistence. If claiming an environment-only remedy instead,
    independently demonstrate causal before/after process evidence and commit the
    bounded setup/cleanup recipe without privilege, host policy or new deployment
    requirements; absence of a source diagnosis cannot itself establish an environment
    cause. Diagnose any newly observed failure and retain its evidence; block rather
    than reinterpret a failing ten-second assertion. diagnosis.md and evidence-index.json
    must map each assertion, test/subtest, source revision, command/exit code, raw
    evidence digest/size and retrievable immutable evidence location to its precise
    limited claim; existence alone is not proof. The user-approved S boundary must
    also be verified: independently distinguish a post-exit pipe/channel stall from
    a still-pending owning Wait; prove bounded cancellation/pipe cleanup without killing
    the adapter that still owns Runtime Wait; include startup/no-acceptance, malformed-stream,
    append-failure and timeout sibling paths. With a deterministic held-Wait test
    seam outside production, observe across the existing deadlines that no Job return/terminal/Complete
    occurs and the redacted pending-cleanup diagnostic appears, then release and reap
    every fixture process in bounded test teardown. This controlled hold proves the
    safety rule, not an actually unkillable OS process or a finite OS completion guarantee.
    Once Wait is proven, permanently non-closing Events/Result must not prevent the
    existing bounded unknown/no-completion exit. Preserve the ten-second disappearance
    assertion and live-child/zombie/PID-reuse/probe-error controls; rerun the actual
    built production-chain failing-before/passing-after regression and all inherited
    final-HEAD quality and shipped-byte gates. Reviewer must explicitly reject undocumented
    infinite software waits, premature outer-owner killing, fake reaping or treating
    user policy approval as evidence of historical-cause closure. The independent
    held-original-Wait proof must traverse the existing ownership chain, not merely
    substitute a fake driver or delay invoking Wait. Cover startup/no-acceptance,
    malformed-stream, persistent-append and timeout siblings; observe the unchanged
    five-second escalation, ten-second observation, twenty-second SDK cancellation
    deadline and thirty-second runner drain boundary where applicable. While the original
    Wait is held, adapter/Job stay alive, no SDK terminal/result or Complete is published,
    cancellation and owned-pipe cleanup proceed, and exactly one bounded redacted
    diagnostic appears. Then release the hold and prove single-owner reaping and bounded
    teardown for all fixtures. A controlled test hold is not evidence of an actually
    unkillable kernel process. Confirm bounded unknown/no-completion after proven
    Wait with nonclosing driver channels, and align only the named owning documentation
    to that already-approved exception. The Developer chooses the minimal test seam/remedy,
    confined to non-release test code for instrumentation; the Planner prescribes
    evidence and ownership, not implementation.'
  commands:
  - &id001
    cmd: GOTOOLCHAIN=go1.26.0 go version
    exit_code: 0
    summary: go version go1.26.0 linux/arm64
  - &id002
    cmd: mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
      go test -count=1 -json ./cmd/agentrun-job -run '^TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure$'
      > artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
    exit_code: 0
    summary: ''
  - &id003
    cmd: python3 -c "import json; rows=[json.loads(x) for x in open('artifacts/agentrun-cancellation-prerequisite/cancellation-test.json')
      if x.strip()]; name='TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure';
      assert any(x.get('Test')==name and x.get('Action')=='run' for x in rows); assert
      any(x.get('Test')==name and x.get('Action')=='pass' for x in rows); assert not
      any(x.get('Action') in ('fail','skip') for x in rows)"
    exit_code: 0
    summary: ''
  - &id004
    cmd: GOTOOLCHAIN=go1.26.0 go test -count=1 ./runtime-sdk/... ./internal/agentrun/...
      ./cmd/agentrun-job/...
    exit_code: 0
    summary: "ok  \tgithub.com/xiaohei-info/open-agent-cluster/runtime-sdk\t20.632s\n\
      ok  \tgithub.com/xiaohei-info/open-agent-cluster/internal/agentrun\t0.070s\n\
      ok  \tgithub.com/xiaohei-info/open-agent-cluster/cmd/agentrun-job\t162.972s\n\
      ok  \tgithub.com/xiaohei-info/open-agent-cluster/cmd/agentrun-job/vendor\t0.358s"
  - &id005
    cmd: GOTOOLCHAIN=go1.26.0 go vet ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
    exit_code: 0
    summary: ''
  - &id006
    cmd: GOTOOLCHAIN=go1.26.0 go build ./cmd/agentrun-job/...
    exit_code: 0
    summary: ''
  - &id007
    cmd: test -s artifacts/agentrun-cancellation-prerequisite/diagnosis.md
    exit_code: 0
    summary: ''
  - &id018
    cmd: mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
      go test -count=1 -json ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
      > artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
    exit_code: 0
    summary: Uncached scoped suite passed; 224 passing test/subtest records and no
      fail/skip records.
  - &id019
    cmd: test -s artifacts/agentrun-cancellation-prerequisite/evidence-index.json
    exit_code: 0
    summary: ''
  metrics: {}
  artifacts:
  - artifacts/agentrun-cancellation-prerequisite/diagnosis.md
  - artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
  - artifacts/agentrun-cancellation-prerequisite/evidence-index.json
  - artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
  evidence: 'Independent pre-fix permanent built-chain regression failed at the intended
    early-Job-return assertion (exit 1), after its PID/start-identity/PPID/live-nonzombie
    checks; the same test passes at actual HEAD. Fresh four-sibling held-Wait runs
    passed at 12/31/31/31 seconds with one bounded redacted diagnostic each, closed
    owned stdout, no Job return/SDK terminal/Complete before release, and process-chain
    reaping after release. The seam invokes real exec.Cmd.Wait and holds propagation
    of its result: OS child is already reaped during this controlled hold; it is not
    an unkillable-kernel claim. Real live-child before-Wait evidence is separately
    exercised. Post-confirmed-Wait nonclosing-channel unknown/no-completion test passes.
    Historical AITEAM-820 cause remains unknown under H; no historical ten-second
    state is reconstructed. Its current final-HEAD evidence binding is blocked by
    the single authority mismatch, not by a new process/test failure.'
  name: agentrun-cancellation-cause-and-remedy-gate
  layer: L1
- gate: agentrun-cancellation-preserved-release-gate
  status: pass
  status_scope: Declared command, metric and artifact verification passed; this is not delivery-goal acceptance.
  delivery_goal_status: fail
  delivery_goal_failure: The unchanged source-versus-delivery evidence rule remains blocked; see failed integration obligation and retained blocker.
  source_of_truth:
  - docs/design/detailed/06-agent-runtime-detailed-design.md:L38-L175
  - docs/design/detailed/06-agent-runtime-detailed-design.md:L305-L451
  - docs/references/execution/agent-runtime.md
  - docs/references/software-delivery/artifacts-release-and-deployment.md:L138-L209
  - five-nodes-recovery-decisions.md
  delivery_goal: Preserve all completed AgentRun Job quality, security, protocol and
    exact-byte release guarantees on the separately delivered cancellation remedy;
    no historical package evidence substitution.
  commands:
  - &id008
    cmd: mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -covermode=atomic
      -coverprofile=artifacts/agent-run-job/coverage.out ./internal/agentrun/... ./cmd/agentrun-job/...
    exit_code: 0
    summary: 'Coverage suite passed: internal/agentrun 93.1%, cmd/agentrun-job 90.0%,
      adapter 89.7%; total 90.6%.'
  - &id009
    cmd: python3 -c "from pathlib import Path; import re,subprocess; p=Path('artifacts/agent-run-job/coverage.out');
      assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True);
      m=re.search(r'^total:\s+\(statements\)\s+([0-9.]+)%$',out,re.M); assert m and
      float(m.group(1)) >= 90"
    exit_code: 0
    summary: Fresh total statement coverage 90.6%; >=90% assertion passed.
  - &id010
    cmd: mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -json ./cmd/agentrun-job/...
      -run '^(TestProductionStreamJSONAdapterLaunchesConfiguredCommand|TestPublishedRuntimeAdapterContainsNoFixtureHooks|TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData|TestStreamJSONCleansUpAcceptanceKindMismatch|TestStreamJSONRejectsForeignSessionEvents)$'
      -count=1 > artifacts/agent-run-job/stream-json-hardening.json
    exit_code: 0
    summary: ''
  - &id011
    cmd: 'python3 -c "import json; required={''TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData'',
      ''TestPublishedRuntimeAdapterContainsNoFixtureHooks'', ''TestStreamJSONRejectsForeignSessionEvents'',
      ''TestStreamJSONCleansUpAcceptanceKindMismatch'', ''TestProductionStreamJSONAdapterLaunchesConfiguredCommand''};
      rows=[json.loads(x) for x in open(''artifacts/agent-run-job/stream-json-hardening.json'')
      if x.strip()]; passed={x.get(''Test'') for x in rows if x.get(''Action'')==''pass''
      and x.get(''Test'') in required}; assert passed==required, f''missing required
      passing stream-json tests: {sorted(required-passed)}''"'
    exit_code: 0
    summary: ''
  - &id012
    cmd: 'python3 -c "from pathlib import Path; roots=[Path(''cmd/agentrun-job/vendor''),Path(''cmd/agentrun-job/driver.go'')];
      files=[]; [files.extend(p for p in ([r] if r.is_file() else r.rglob(''*''))
      if p.is_file() and ''testdata'' not in p.parts and not p.name.endswith(''_test.go''))
      for r in roots]; forbidden=(''AGENTRUN_FIXTURE_MODE'',''AGENTRUN_FIXTURE_MARKER'',''AGENTRUN_FIXTURE_PID_FILE'',''blockForever'');
      hits=[f''{p}:{token}'' for p in files for token in forbidden if token in p.read_text(errors=''ignore'')];
      assert not hits, f''published fixture hooks: {hits}''"'
    exit_code: 0
    summary: ''
  - &id013
    cmd: test "$(docker run --rm --platform linux/arm64 golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
      go version)" = "go version go1.26.0 linux/arm64"
    exit_code: 0
    summary: ''
  - &id014
    cmd: python3 cmd/agentrun-job/build_release.py --source-revision HEAD --target
      linux/arm64 --build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
      --vendor-package ./cmd/agentrun-job/vendor --driver-identity cmd/agentrun-job/driver_identity.json
      --output artifacts/agent-run-job --network-policy module-download-only
    exit_code: 0
    summary: Pinned linux/arm64 builder completed successfully for committed HEAD;
      fresh release manifest identifies 1e2d4073b3e90f9c9676bef53a0690ddb4a22109.
  - &id015
    cmd: python3 -c "from pathlib import Path; import json; d=json.loads(Path('artifacts/agent-run-job/runtime-driver-release-manifest.json').read_text());
      assert d['build']=={'image':'golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7','go_version':'1.26.0','goos':'linux','goarch':'arm64'};
      assert set(d['binaries'])=={'agentrun-job','agentrun-vendor'}; assert d['vendor_source']=='cmd/agentrun-job/vendor'
      and d['vendor_role']=='stream-json-protocol-adapter' and d['bundled_third_party_runtime_count']==0"
    exit_code: 0
    summary: ''
  - &id016
    cmd: python3 cmd/agentrun-job/verify_package.py --package-root artifacts/agent-run-job
      --component-manifest artifacts/agent-run-job/component-manifest.json --binaries-manifest
      artifacts/agent-run-job/go-binaries-manifest.json --component-link artifacts/agent-run-job/immutable-component-link.json
      --release-manifest artifacts/agent-run-job/runtime-driver-release-manifest.json
      --driver-identity cmd/agentrun-job/driver_identity.json --expected-target linux/arm64
      --expected-build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
      --execute-shipped-pair --forbid-build --forbid-fixture-staging --report artifacts/agent-run-job/package-verification.json
    exit_code: 0
    summary: '{"build_attempted": false, "bundled_third_party_runtime_count": 0, "external_stream_json_command_executed":
      true, "external_stream_json_command_execution_count": 1, "fixture_staging_attempted":
      false, "native_event_provenance_failure_count": 0, "native_event_provenance_verified":
      true, "package_rebuild_attempt_count": 0, "process_tests_passed": true, "published_fixture_hook_count":
      0, "schema": "oac.agentrun-package-verification/v1", "shipped_pair": {"completion_count":
      1, "event_types": ["started", "message", "terminal"], "external_runtime_marker":
      true, "native_event_provenance": true}, "shipped_pair_executed": true, "shipped_pair_execution_count":
      1, "target": "linux/arm64", "testdata_payload_count": 0}'
  - &id017
    cmd: python3 -c "from pathlib import Path; import json; r=json.loads(Path('artifacts/agent-run-job/package-verification.json').read_text());
      assert r['schema']=='oac.agentrun-package-verification/v1' and r['build_attempted']
      is False and r['fixture_staging_attempted'] is False and r['shipped_pair_executed']
      is True and r['process_tests_passed'] is True and r['published_fixture_hook_count']==0
      and r['external_stream_json_command_executed'] is True and r['native_event_provenance_verified']
      is True"
    exit_code: 0
    summary: ''
  metrics:
    statement_coverage_percent: 90.6
    declared_artifact_count: 11
    published_fixture_hook_count: 0
    bundled_third_party_runtime_count: 0
    required_stream_json_hardening_test_count: 5
    shipped_pair_execution_count: 1
    external_stream_json_command_execution_count: 1
    native_event_provenance_failure_count: 0
  artifacts:
  - artifacts/agent-run-job/coverage.out
  - artifacts/agent-run-job/stream-json-hardening.json
  - artifacts/agent-run-job/source-bundle.tar.zst
  - artifacts/agent-run-job/component-manifest.json
  - artifacts/agent-run-job/agentrun-job
  - artifacts/agent-run-job/agentrun-vendor
  - artifacts/agent-run-job/go-binaries-manifest.json
  - artifacts/agent-run-job/immutable-component-link.json
  - artifacts/agent-run-job/runtime-driver-release-manifest.json
  - artifacts/agent-run-job/release-package.tar
  - artifacts/agent-run-job/package-verification.json
  evidence: All 20 exact declared verification commands were independently exercised
    and passed, including uncached scope tests, vet/build, coverage 90.6%, five required
    protocol tests, zero production fixture hooks, authorized one-line go.mod deletion/unchanged
    go.sum, pinned Go 1.26.0 linux/arm64 build, and exact shipped-pair verification
    without building/staging during verification. Fresh HEAD-built job/adapter digests
    exactly equal the committed shipped binaries. Formal closure remains blocked only
    by the unchanged source-versus-delivery evaluation obligation.
  name: agentrun-cancellation-preserved-release-gate
  layer: L1
commands:
- *id001
- *id002
- *id003
- *id004
- *id005
- *id006
- *id007
- *id008
- *id009
- *id010
- *id011
- *id012
- *id013
- cmd: python3 -c 'from pathlib import Path; import hashlib; assert hashlib.sha256(Path('"'"'go.mod'"'"').read_bytes()).hexdigest()
    == '"'"'cae88fa59fd0eb66eaa902e486882d20f7c12a577093be22ec1fd122c8ca9ef2'"'"',
    '"'"'module change exceeds the approved single duplicate-indirect deletion'"'"';
    assert hashlib.sha256(Path('"'"'go.sum'"'"').read_bytes()).hexdigest() == '"'"'7f069d03a85b59955951c07a4b1b390bc94d95fe815e17d6faaf52b6bcac0027'"'"',
    '"'"'go.sum changed outside authorization'"'"''
  exit_code: 0
  summary: ''
- *id014
- *id015
- *id016
- *id017
- *id018
- *id019
env_setup:
- Linux 6.17.0-1011-oracle aarch64; native and Docker architecture arm64; GOTOOLCHAIN=go1.26.0.
- Pinned Docker Go 1.26.0 linux/arm64 builder; module-download-only network and read-only
  source/cache mounts through unchanged build_release.py.
- Declared local fixtures only; no new live environment, privilege, supervisor, reaper
  adoption or host policy. Reviewer-generated evidence modifies output artifacts,
  not implementation files.
reviewed_identity:
  pr_url: https://github.com/xiaohei-info/open-agent-cluster/pull/88
  base: main
  delivery_head: 1e2d4073b3e90f9c9676bef53a0690ddb4a22109
  delivery_tree: e0ad5512a2b4ac123090cc36e4769126f717e07c
  committed_evidence_tested_source: 48881db8e1223ef1f105d3f3f237d50f948a511d
  committed_evidence_tested_tree: 372375831167326f3c80ffbb32f2f970a2d25bea
  pre_fix_source: 072c3b5be69d7461c381d699b01df4e291748ff9
  pre_fix_tree: 7647332b03939efac82d782fce0b5a61df4db425
  worker_verification_sha256: 06441c7252fac282d1502142f0d677aa7e11ea3a45593c01a583406e4940e202
  sealed_worker_run_id: 01a0fa1c-e697-75c6-bdcf-4072ea0434d1
  delivery_is_evidence_only: true
  code_modules_and_docs_equal_between_source_and_delivery: true
reviewer_evidence:
- path: review-evidence/independent-before.json
  bytes: 2004
  sha256: 18edd69c7b59d6bfe92b906dc6084a9fbfeb60b4e67cecd61b2ea28922c7d0dd
  availability: Reviewer-run output hash, not a public/local-path delivery link; committed
    evidence locations are separately pinned in committed_evidence_checks.
- path: artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
  bytes: 220164
  sha256: 92b1b10cdad8fd43f5944aa6c74cc468c146cefbe94f402e06b557bb9cacd60b
  availability: Reviewer-run output hash, not a public/local-path delivery link; committed
    evidence locations are separately pinned in committed_evidence_checks.
- path: artifacts/agentrun-cancellation-prerequisite/built-production-chain-process.json
  bytes: 1723
  sha256: a1dc48df504b42b389b925add39cf82631548389951fb632673f39e7495038f9
  availability: Reviewer-run output hash, not a public/local-path delivery link; committed
    evidence locations are separately pinned in committed_evidence_checks.
- path: artifacts/agentrun-cancellation-prerequisite/held-wait-process-evidence.jsonl
  bytes: 2745
  sha256: 884dc14f2b0756a879b4a25187b522777009f2ad89f468e9935829115c39e457
  availability: Reviewer-run output hash, not a public/local-path delivery link; committed
    evidence locations are separately pinned in committed_evidence_checks.
- path: artifacts/agent-run-job/coverage.out
  bytes: 63348
  sha256: 73dd02a308fef0dd08fb36c341ae9eb0065cffb0fbea25dcd0081e17658920e7
  availability: Reviewer-run output hash, not a public/local-path delivery link; committed
    evidence locations are separately pinned in committed_evidence_checks.
- path: artifacts/agent-run-job/package-verification.json
  bytes: 676
  sha256: b310699b5e7775721d11c3dd6fc6ea3f63fa4c55c2028dbbeb8a39dc5309394d
  availability: Reviewer-run output hash, not a public/local-path delivery link; committed
    evidence locations are separately pinned in committed_evidence_checks.
- path: artifacts/agent-run-job/runtime-driver-release-manifest.json
  bytes: 841
  sha256: d8c343466391619c4d137c96494fb22ad547dcb9080b04b5a8a702a213620a45
  availability: Reviewer-run output hash, not a public/local-path delivery link; committed
    evidence locations are separately pinned in committed_evidence_checks.
committed_evidence_checks:
- path: artifacts/agentrun-cancellation-prerequisite/diagnosis.md
  expected_bytes: 7809
  expected_sha256: 3c3302329b337af120e166ad4757b4d1986c6bc9ba1ab62fc8b67c1bde9953a6
  observed:
    bytes: 7809
    sha256: 3c3302329b337af120e166ad4757b4d1986c6bc9ba1ab62fc8b67c1bde9953a6
  match: true
- path: artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
  expected_bytes: 1662
  expected_sha256: 2a85d0f17fe5974da82b7c3108eaf0cf42f971948069a58473e7280527f5ac2f
  observed:
    bytes: 1662
    sha256: 2a85d0f17fe5974da82b7c3108eaf0cf42f971948069a58473e7280527f5ac2f
  match: true
- path: artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
  expected_bytes: 220190
  expected_sha256: 29d6a541ec84eaf629f45a9ff0db735f5bdb72900205d831e0b5d030778c68d2
  observed:
    bytes: 220190
    sha256: 29d6a541ec84eaf629f45a9ff0db735f5bdb72900205d831e0b5d030778c68d2
  match: true
- path: artifacts/agentrun-cancellation-prerequisite/built-chain-production-before.json
  expected_bytes: 2007
  expected_sha256: 4ddb3d3dba8296d643872cf54dcb68737c85402dfb3fe332c1de3108730ba210
  observed:
    bytes: 2007
    sha256: 4ddb3d3dba8296d643872cf54dcb68737c85402dfb3fe332c1de3108730ba210
  match: true
- path: artifacts/agentrun-cancellation-prerequisite/pre-fix-source-cause-final/artifacts/agentrun-cancellation-prerequisite/built-production-chain-process.json
  expected_bytes: 2053
  expected_sha256: c06071a3722be05458c4ed653ad11e8e67e940859bd8ed4639a5226fd8bb57df
  observed:
    bytes: 2053
    sha256: c06071a3722be05458c4ed653ad11e8e67e940859bd8ed4639a5226fd8bb57df
  match: true
- path: artifacts/agentrun-cancellation-prerequisite/built-production-chain-process.json
  expected_bytes: 1723
  expected_sha256: b389c33e0b492ce09a6bdd8836c118991d346d3a1d0b1e9e7971a5466c0960f7
  observed:
    bytes: 1723
    sha256: b389c33e0b492ce09a6bdd8836c118991d346d3a1d0b1e9e7971a5466c0960f7
  match: true
- path: artifacts/agentrun-cancellation-prerequisite/held-wait-process-evidence.jsonl
  expected_bytes: 2745
  expected_sha256: 8957ee77a264b913a588c8fe8fb079d3ca0b897349bb131727ba786865a1f948
  observed:
    bytes: 2745
    sha256: 8957ee77a264b913a588c8fe8fb079d3ca0b897349bb131727ba786865a1f948
  match: true
- path: artifacts/agent-run-job/coverage.out
  expected_bytes: 63348
  expected_sha256: f354f02288efa843cc2dbdf7bf7ed22b6293f8ad37ec03ecc9ae77b7e4f88695
  observed:
    bytes: 63348
    sha256: f354f02288efa843cc2dbdf7bf7ed22b6293f8ad37ec03ecc9ae77b7e4f88695
  match: true
- path: artifacts/agent-run-job/stream-json-hardening.json
  expected_bytes: 8616
  expected_sha256: b2a1f41b63795bae12341d74ddc4054f17cee7d6c86bd97ac4a2f0ae2a49b017
  observed:
    bytes: 8616
    sha256: b2a1f41b63795bae12341d74ddc4054f17cee7d6c86bd97ac4a2f0ae2a49b017
  match: true
- path: artifacts/agent-run-job/source-bundle.tar.zst
  expected_bytes: 17842
  expected_sha256: bdf8a0a61387277ce779a24841fa3fdaca1ed514b329f8b39b2e4d01c794af9c
  observed:
    bytes: 17842
    sha256: bdf8a0a61387277ce779a24841fa3fdaca1ed514b329f8b39b2e4d01c794af9c
  match: true
- path: artifacts/agent-run-job/component-manifest.json
  expected_bytes: 2240
  expected_sha256: 15ab42d6e5e6302ad30d0b0d5d2e067c4f14911f9077ba566bd5c04f26b76ea1
  observed:
    bytes: 2240
    sha256: 15ab42d6e5e6302ad30d0b0d5d2e067c4f14911f9077ba566bd5c04f26b76ea1
  match: true
- path: artifacts/agent-run-job/agentrun-job
  expected_bytes: 6357118
  expected_sha256: e6fa73538b354ab51832de3b04d8da84ff6d5934a5d1adefe3c2c56a31295a12
  observed:
    bytes: 6357118
    sha256: e6fa73538b354ab51832de3b04d8da84ff6d5934a5d1adefe3c2c56a31295a12
  match: true
- path: artifacts/agent-run-job/agentrun-vendor
  expected_bytes: 2293886
  expected_sha256: b0dabd3ad8efc05a89ae4ae9cda9dba85e10d1357bc40d8c84fe6092ae80ee81
  observed:
    bytes: 2293886
    sha256: b0dabd3ad8efc05a89ae4ae9cda9dba85e10d1357bc40d8c84fe6092ae80ee81
  match: true
- path: artifacts/agent-run-job/go-binaries-manifest.json
  expected_bytes: 488
  expected_sha256: 3425502451cd0ade6f768743af26b3f985f9c5c58d134a9aa6fd238c984cde02
  observed:
    bytes: 488
    sha256: 3425502451cd0ade6f768743af26b3f985f9c5c58d134a9aa6fd238c984cde02
  match: true
- path: artifacts/agent-run-job/immutable-component-link.json
  expected_bytes: 328
  expected_sha256: fd64a8d2b758da2fe4441744fce024b3bb7eff9e2134d5288c4f627e5363c315
  observed:
    bytes: 328
    sha256: fd64a8d2b758da2fe4441744fce024b3bb7eff9e2134d5288c4f627e5363c315
  match: true
- path: artifacts/agent-run-job/runtime-driver-release-manifest.json
  expected_bytes: 841
  expected_sha256: 0836974a4f814f77eda9620e7dc03d2cf1d09fef67295adbda6812b18d42e31a
  observed:
    bytes: 841
    sha256: 0836974a4f814f77eda9620e7dc03d2cf1d09fef67295adbda6812b18d42e31a
  match: true
- path: artifacts/agent-run-job/release-package.tar
  expected_bytes: 8683520
  expected_sha256: 25eb0b30d0fb4a8229c93896f090f549b07e51cd6109507d49c4d9b2cc06b73b
  observed:
    bytes: 8683520
    sha256: 25eb0b30d0fb4a8229c93896f090f549b07e51cd6109507d49c4d9b2cc06b73b
  match: true
- path: artifacts/agent-run-job/package-verification.json
  expected_bytes: 676
  expected_sha256: b310699b5e7775721d11c3dd6fc6ea3f63fa4c55c2028dbbeb8a39dc5309394d
  observed:
    bytes: 676
    sha256: b310699b5e7775721d11c3dd6fc6ea3f63fa4c55c2028dbbeb8a39dc5309394d
  match: true
- path: artifacts/agentrun-cancellation-prerequisite/verification.yaml
  expected_bytes: 25971
  expected_sha256: b4fe58c96276dc4e95a325c8b3580744e4a475ff789147d6490676bf04b6aaa1
  observed:
    bytes: 25971
    sha256: b4fe58c96276dc4e95a325c8b3580744e4a475ff789147d6490676bf04b6aaa1
  match: true
retained_historical_roots:
- root_cause_key: required-agentrun-cancellation-verification-intermittent-failure
  historical_verdict: reject remains immutable
  historical_cause: unknown; numeric PID is present, original start identity/PPID/state/Wait
    are not established
  current_disposition: H prospective functional evidence independently reproduced;
    formal prerequisite acceptance pending the one authority correction.
- root_cause_key: agentrun-sdk-cancellation-publishes-result-before-driver-reaping
  historical_verdict: reject remains immutable
  current_disposition: Current ordering remedy and full S safety-result-boundary proof
    independently pass; formal final-delivery acceptance pending authority correction.
historical_review_findings:
- root_cause_key: final-release-source-revision-mismatch
  current_disposition: Functional checks pass; the same source/delivery evaluation
    aspect is retained once as final-release-source-revision-mismatch.
- root_cause_key: cancellation-cause-and-remedy-evidence-open
  current_disposition: Functional checks pass; the same source/delivery evaluation
    aspect is retained once as final-release-source-revision-mismatch.
- root_cause_key: cancellation-final-head-regression-unbound
  current_disposition: Functional checks pass; the same source/delivery evaluation
    aspect is retained once as final-release-source-revision-mismatch.
- root_cause_key: cancellation-evidence-index-and-lineage-missing
  current_disposition: The missing verification.yaml/reference defect is fixed and
    all 19 index hashes match; final delivery authority aspect is consolidated in
    final-release-source-revision-mismatch.
- root_cause_key: preserved-release-evidence-stale
  current_disposition: Functional checks pass; the same source/delivery evaluation
    aspect is retained once as final-release-source-revision-mismatch.
blockers:
- root_cause_key: final-release-source-revision-mismatch
  obligation_id: dimension:authority
  classification: unchanged
  owner: omac-coordinator
  severity: high
  summary: The currently returned contract still evaluates evidence against the final
    PR HEAD; the approved source-versus-delivery identity correction has not been
    applied. The committed evidence names tested source 48881db8e1223ef1f105d3f3f237d50f948a511d
    while the genuine delivered PR HEAD is 1e2d4073b3e90f9c9676bef53a0690ddb4a22109.
  impact: A technical pass cannot be promoted to implementation acceptance under this
    unchanged contract. This is one evidence-authority/definition blocker, not five
    independent code defects, missing H/S approval, a missing controller seal, or
    a failing cancellation/release test.
  evidence: 'Current work show contract_ref SHA256 de032ea2a2ec984af392e7d33b3c2df49ed4228b19e6bf1e8f66c98b9b2c42fc
    still has the old cause-and-remedy delivery_goal and final-HEAD obligations. git
    and GitHub agree on final HEAD 1e2d4073b3e90f9c9676bef53a0690ddb4a22109/tree e0ad5512a2b4ac123090cc36e4769126f717e07c.
    HEAD evidence-index.json delivery.head, diagnosis and committed release source_revision
    name 48881db8e1223ef1f105d3f3f237d50f948a511d/tree 372375831167326f3c80ffbb32f2f970a2d25bea.
    The difference is evidence-only: cmd, internal, runtime-sdk, modules and docs
    have no changes between these revisions. All 19 committed indexed records hash-check.
    Independent rebuilding at actual HEAD succeeds and yields exactly the same job/adapter
    binary digests. Issue metadata now has a real controller-sealed delivery_identity
    for fresh Worker Run 01a0fa1c-e697-75c6-bdcf-4072ea0434d1 and verification 06441c7252fac282d1502142f0d677aa7e11ea3a45593c01a583406e4940e202.
    Coordinator comment 01a0fa1c-0624-717d-a31e-7d9291e83606 explicitly says the old
    manifest is unchanged and permits this ordinary review before the definition correction.'
  required_fix: Use the already approved d969 source/delivery evidence authority,
    not another approval or an artifact self-naming/dummy source-commit loop. After
    this formal review finishes, the authorized coordinator/controller must preserve
    the genuine current delivery seal, verification bytes and this reject history;
    freshly rebase and independently review the supported one-field cause-and-remedy
    delivery_goal correction against those current facts, then apply it through normal
    OMAC authority and resume independent review. Bind immutable HEAD blob locations
    and the separately sealed delivery identity to the actual tested code-source SHA/tree
    and exact package bytes. Do not fabricate/overwrite a seal, reset counters, reopen
    H/S, broaden scope or silently retire the seal through another Worker handoff.
    Reviewer does not execute amendment, recovery, retry, manifest or platform writes.
  causal_group: source-versus-delivery-evidence-authority
- root_cause_key: cancellation-cause-and-remedy-evidence-open
  obligation_id: integration:agentrun-cancellation-cause-and-remedy-gate
  classification: unchanged
  owner: omac-coordinator
  severity: high
  summary: Prospective functional cause/remedy passes, but its delivered evidence
    still uses the tested-source snapshot rather than the final delivery identity
    under the unchanged gate.
  impact: This formal obligation cannot close under the currently returned evidence-evaluation
    rule. It shares the already-approved source/delivery authority correction with
    the other findings; it is not a separately failing implementation test.
  evidence: 'Current work show contract_ref SHA256 de032ea2a2ec984af392e7d33b3c2df49ed4228b19e6bf1e8f66c98b9b2c42fc
    still has the old cause-and-remedy delivery_goal and final-HEAD obligations. git
    and GitHub agree on final HEAD 1e2d4073b3e90f9c9676bef53a0690ddb4a22109/tree e0ad5512a2b4ac123090cc36e4769126f717e07c.
    HEAD evidence-index.json delivery.head, diagnosis and committed release source_revision
    name 48881db8e1223ef1f105d3f3f237d50f948a511d/tree 372375831167326f3c80ffbb32f2f970a2d25bea.
    The difference is evidence-only: cmd, internal, runtime-sdk, modules and docs
    have no changes between these revisions. All 19 committed indexed records hash-check.
    Independent rebuilding at actual HEAD succeeds and yields exactly the same job/adapter
    binary digests. Issue metadata now has a real controller-sealed delivery_identity
    for fresh Worker Run 01a0fa1c-e697-75c6-bdcf-4072ea0434d1 and verification 06441c7252fac282d1502142f0d677aa7e11ea3a45593c01a583406e4940e202.
    Coordinator comment 01a0fa1c-0624-717d-a31e-7d9291e83606 explicitly says the old
    manifest is unchanged and permits this ordinary review before the definition correction.'
  required_fix: Use the already approved d969 source/delivery evidence authority,
    not another approval or an artifact self-naming/dummy source-commit loop. After
    this formal review finishes, the authorized coordinator/controller must preserve
    the genuine current delivery seal, verification bytes and this reject history;
    freshly rebase and independently review the supported one-field cause-and-remedy
    delivery_goal correction against those current facts, then apply it through normal
    OMAC authority and resume independent review. Bind immutable HEAD blob locations
    and the separately sealed delivery identity to the actual tested code-source SHA/tree
    and exact package bytes. Do not fabricate/overwrite a seal, reset counters, reopen
    H/S, broaden scope or silently retire the seal through another Worker handoff.
    Reviewer does not execute amendment, recovery, retry, manifest or platform writes.
  causal_group: source-versus-delivery-evidence-authority
- root_cause_key: cancellation-final-head-regression-unbound
  obligation_id: dimension:regression
  classification: unchanged
  owner: omac-coordinator
  severity: high
  summary: Fresh final-HEAD regression passes, but the committed after-regression/source
    records retain the prior tested-source binding; the approved source-versus-delivery
    distinction has not been installed.
  impact: This formal obligation cannot close under the currently returned evidence-evaluation
    rule. It shares the already-approved source/delivery authority correction with
    the other findings; it is not a separately failing implementation test.
  evidence: 'Current work show contract_ref SHA256 de032ea2a2ec984af392e7d33b3c2df49ed4228b19e6bf1e8f66c98b9b2c42fc
    still has the old cause-and-remedy delivery_goal and final-HEAD obligations. git
    and GitHub agree on final HEAD 1e2d4073b3e90f9c9676bef53a0690ddb4a22109/tree e0ad5512a2b4ac123090cc36e4769126f717e07c.
    HEAD evidence-index.json delivery.head, diagnosis and committed release source_revision
    name 48881db8e1223ef1f105d3f3f237d50f948a511d/tree 372375831167326f3c80ffbb32f2f970a2d25bea.
    The difference is evidence-only: cmd, internal, runtime-sdk, modules and docs
    have no changes between these revisions. All 19 committed indexed records hash-check.
    Independent rebuilding at actual HEAD succeeds and yields exactly the same job/adapter
    binary digests. Issue metadata now has a real controller-sealed delivery_identity
    for fresh Worker Run 01a0fa1c-e697-75c6-bdcf-4072ea0434d1 and verification 06441c7252fac282d1502142f0d677aa7e11ea3a45593c01a583406e4940e202.
    Coordinator comment 01a0fa1c-0624-717d-a31e-7d9291e83606 explicitly says the old
    manifest is unchanged and permits this ordinary review before the definition correction.'
  required_fix: Use the already approved d969 source/delivery evidence authority,
    not another approval or an artifact self-naming/dummy source-commit loop. After
    this formal review finishes, the authorized coordinator/controller must preserve
    the genuine current delivery seal, verification bytes and this reject history;
    freshly rebase and independently review the supported one-field cause-and-remedy
    delivery_goal correction against those current facts, then apply it through normal
    OMAC authority and resume independent review. Bind immutable HEAD blob locations
    and the separately sealed delivery identity to the actual tested code-source SHA/tree
    and exact package bytes. Do not fabricate/overwrite a seal, reset counters, reopen
    H/S, broaden scope or silently retire the seal through another Worker handoff.
    Reviewer does not execute amendment, recovery, retry, manifest or platform writes.
  causal_group: source-versus-delivery-evidence-authority
- root_cause_key: cancellation-evidence-index-and-lineage-missing
  obligation_id: dimension:evidence
  classification: unchanged
  owner: omac-coordinator
  severity: high
  summary: The formerly absent verification.yaml is fixed and all 19 index entries
    hash-check; the remaining final-source/delivery lineage interpretation is still
    blocked under the unchanged contract.
  impact: This formal obligation cannot close under the currently returned evidence-evaluation
    rule. It shares the already-approved source/delivery authority correction with
    the other findings; it is not a separately failing implementation test.
  evidence: 'Current work show contract_ref SHA256 de032ea2a2ec984af392e7d33b3c2df49ed4228b19e6bf1e8f66c98b9b2c42fc
    still has the old cause-and-remedy delivery_goal and final-HEAD obligations. git
    and GitHub agree on final HEAD 1e2d4073b3e90f9c9676bef53a0690ddb4a22109/tree e0ad5512a2b4ac123090cc36e4769126f717e07c.
    HEAD evidence-index.json delivery.head, diagnosis and committed release source_revision
    name 48881db8e1223ef1f105d3f3f237d50f948a511d/tree 372375831167326f3c80ffbb32f2f970a2d25bea.
    The difference is evidence-only: cmd, internal, runtime-sdk, modules and docs
    have no changes between these revisions. All 19 committed indexed records hash-check.
    Independent rebuilding at actual HEAD succeeds and yields exactly the same job/adapter
    binary digests. Issue metadata now has a real controller-sealed delivery_identity
    for fresh Worker Run 01a0fa1c-e697-75c6-bdcf-4072ea0434d1 and verification 06441c7252fac282d1502142f0d677aa7e11ea3a45593c01a583406e4940e202.
    Coordinator comment 01a0fa1c-0624-717d-a31e-7d9291e83606 explicitly says the old
    manifest is unchanged and permits this ordinary review before the definition correction.'
  required_fix: Use the already approved d969 source/delivery evidence authority,
    not another approval or an artifact self-naming/dummy source-commit loop. After
    this formal review finishes, the authorized coordinator/controller must preserve
    the genuine current delivery seal, verification bytes and this reject history;
    freshly rebase and independently review the supported one-field cause-and-remedy
    delivery_goal correction against those current facts, then apply it through normal
    OMAC authority and resume independent review. Bind immutable HEAD blob locations
    and the separately sealed delivery identity to the actual tested code-source SHA/tree
    and exact package bytes. Do not fabricate/overwrite a seal, reset counters, reopen
    H/S, broaden scope or silently retire the seal through another Worker handoff.
    Reviewer does not execute amendment, recovery, retry, manifest or platform writes.
  causal_group: source-versus-delivery-evidence-authority
- root_cause_key: preserved-release-evidence-stale
  obligation_id: integration:agentrun-cancellation-preserved-release-gate
  classification: unchanged
  owner: omac-coordinator
  severity: high
  summary: Fresh pinned final-HEAD package verifies and exact shipped binary bytes
    match, but the committed package/release manifest still names the separate tested-source
    SHA without the applied delivery-identity evaluation rule.
  impact: This formal obligation cannot close under the currently returned evidence-evaluation
    rule. It shares the already-approved source/delivery authority correction with
    the other findings; it is not a separately failing implementation test.
  evidence: 'Current work show contract_ref SHA256 de032ea2a2ec984af392e7d33b3c2df49ed4228b19e6bf1e8f66c98b9b2c42fc
    still has the old cause-and-remedy delivery_goal and final-HEAD obligations. git
    and GitHub agree on final HEAD 1e2d4073b3e90f9c9676bef53a0690ddb4a22109/tree e0ad5512a2b4ac123090cc36e4769126f717e07c.
    HEAD evidence-index.json delivery.head, diagnosis and committed release source_revision
    name 48881db8e1223ef1f105d3f3f237d50f948a511d/tree 372375831167326f3c80ffbb32f2f970a2d25bea.
    The difference is evidence-only: cmd, internal, runtime-sdk, modules and docs
    have no changes between these revisions. All 19 committed indexed records hash-check.
    Independent rebuilding at actual HEAD succeeds and yields exactly the same job/adapter
    binary digests. Issue metadata now has a real controller-sealed delivery_identity
    for fresh Worker Run 01a0fa1c-e697-75c6-bdcf-4072ea0434d1 and verification 06441c7252fac282d1502142f0d677aa7e11ea3a45593c01a583406e4940e202.
    Coordinator comment 01a0fa1c-0624-717d-a31e-7d9291e83606 explicitly says the old
    manifest is unchanged and permits this ordinary review before the definition correction.'
  required_fix: Use the already approved d969 source/delivery evidence authority,
    not another approval or an artifact self-naming/dummy source-commit loop. After
    this formal review finishes, the authorized coordinator/controller must preserve
    the genuine current delivery seal, verification bytes and this reject history;
    freshly rebase and independently review the supported one-field cause-and-remedy
    delivery_goal correction against those current facts, then apply it through normal
    OMAC authority and resume independent review. Bind immutable HEAD blob locations
    and the separately sealed delivery identity to the actual tested code-source SHA/tree
    and exact package bytes. Do not fabricate/overwrite a seal, reset counters, reopen
    H/S, broaden scope or silently retire the seal through another Worker handoff.
    Reviewer does not execute amendment, recovery, retry, manifest or platform writes.
  causal_group: source-versus-delivery-evidence-authority
nits: []
independent_before:
  command: GOTOOLCHAIN=go1.26.0 go test -count=1 -json ./cmd/agentrun-job -run '^TestBuiltEntrypointWaitsForRuntimeWaitOnPersistentAppendFailure$'
  source: 072c3b5be69d7461c381d699b01df4e291748ff9
  exit_code: 1
  failure: built Job returned before the production Runtime Wait completed
  scope_limit: The checked-in pre-fix test validates process-chain identity and live
    non-zombie Runtime before this failing assertion; it does not emit a separate
    fresh process JSON. The immutable indexed Worker process JSON is separately inspected
    and hash-checked, not relabeled as Reviewer output.
independent_after:
  source: 1e2d4073b3e90f9c9676bef53a0690ddb4a22109
  exit_code: 0
  passing_test_and_subtest_records: 224
  fail_or_skip_records: 0
  held_wait_scenarios:
  - scenario: startup without acceptance
    held_ms_after_cancel_marker: 12000
    pending_diagnostic_count: 1
    process_chain_reaped_after_release: true
  - scenario: malformed stream
    held_ms_after_cancel_marker: 31000
    pending_diagnostic_count: 1
    process_chain_reaped_after_release: true
  - scenario: persistent append failure
    held_ms_after_cancel_marker: 31000
    pending_diagnostic_count: 1
    process_chain_reaped_after_release: true
  - scenario: runtime timeout
    held_ms_after_cancel_marker: 31000
    pending_diagnostic_count: 1
    process_chain_reaped_after_release: true
  shipped_job_sha256: e6fa73538b354ab51832de3b04d8da84ff6d5934a5d1adefe3c2c56a31295a12
  shipped_adapter_sha256: b0dabd3ad8efc05a89ae4ae9cda9dba85e10d1357bc40d8c84fe6092ae80ee81
schema_adaptation: Every failed obligation is linked to its retained stable finding,
  as required by the installed validator. These findings are grouped under one evidence-authority
  correction; no technical test result or verdict changed to satisfy schema validation.

```
