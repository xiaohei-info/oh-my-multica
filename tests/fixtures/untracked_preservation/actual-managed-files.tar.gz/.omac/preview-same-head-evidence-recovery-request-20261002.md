# Source-bound Preview same-HEAD evidence recovery request

Produce a concrete executable OMAC amendment or identify an already supported exact recovery command for release-preview-audit-vocabulary-repair (issue 01a0fbda-754c-70c8-8a42-d0449091216b). Do not use a plan, generic assessment, unchanged retry, invented code commit, waived reviewer obligation or coordinator implementation. This request is prepared while the actual Worker is still active; it is NOT permission to cancel, comment/unassign that Worker, propose against unknown submission facts, apply a proposal or start another Runner. Refresh all Store/Run/manifest/HEAD facts after its terminal outcome before creating any attempt.

## Observed causal facts

The sole original independent reject is preview-repair-immutable-evidence-not-published: full report86ac81cad4b4b5bd9a170e8289d925cdd6d6620227dbe876554be1ea9a60f869/22653B and ledger081af40a3750f49901058ca870e45a0898208d2df38fe1a11967c8f5666ad66b/4439B. Declared code/test checks passed independently; this does not waive publication or prove the new artifacts.

PR91 retains HEAD1dd603b45fe0ef9ac4bbc2ac75b0d1e64f2ed277. Formal resubmissions occurred on Runs01a0fc25,01a0fc64 and01a0fc69; the latest completed12:08:48 with a new verification attachment01a0fc82-ff9d-7c52-afb2-a8da93e41c38 SHA b044e29bcfabd8da6715a179f10e0e64993a44bee7279eee4176268ab7467937/14758B. The r3 release targets that exact HEAD and includes publicly retrievable per-file URLs and checksums; these are author evidence, still requiring independent review.

A read-only invocation of installed _worker_handoff_has_new_delivery on captured formal DONE/AUTHORING Store facts returns false: the attachment is new but source verdict is reject and submitted HEAD equals baseline HEAD. Exact captured experiment /tmp/oac-preview-same-head-predicate-1259-20261002.json; raw source /tmp/oac-preview-raw-oracle-1227-20261002.json. This is an intentional conservative same-HEAD policy, not a confirmed OMAC code defect. Normal Runner consequently spawned authoring revisions2,3,4 instead of independent review. Do not manufacture product-source changes to defeat the guard.

Current latest Worker01a0fca3-1807-7814-96f0-683b2eff8773 running12:42:22; native messages /tmp/oac-preview-messages-oracle-1258-20261002.json show12:55 work-submit exit2 during artifacts metadata write (Unknown outcome). Its result must be observed before any coordinated recovery. Sole Runner77280 exited12:49:35 after bounded platform read timeouts; no current control writer.

## Required exact decision and executable proof

Independently inspect current contracts and supported same-HEAD/causal-seal recovery capabilities. Preserve original rejected subject/report/ledger, all real Worker runs, exact PR HEAD, uploader/verification causation and full evidence bytes. Existing Executor-only approval for historical Agent-session witness is NOT Preview approval; never copy or broaden it, forge controller-sealed identity, or treat new publication as independent pass. If an additional evidence authority is actually necessary, deliver its precise source tuple, security/quality consequence and independently reviewed choice for explicit user decision. Do not assume that choice in advance.

If a manifest amendment is necessary, provide minimal real operations and demonstrate actual current-stage preconditions, definition/evidence CAS, independent implementation Reviewer delivery, and exact recovery/budget effects. No empty or dummy operations, no global head-policy relaxation, no hand-edited apply ledger, no uncontrolled contract cascade. Preserve current consumed budgets and history; any necessary refreshed budget must be identified as a separate exact choice rather than hidden under evidence authorization. Scope/10commands/5original+3canonical tests/90gate/ownership package and original publication obligation stay unchanged. Keep SDK23/fulluncached85/wholeSDK90/Host90, Audit originale15cd8+35afd7/retained59c51, original62done, H/S/d969/pinnedbytes/security/historicalcauseunknown unchanged. Do not reopen completed producers or authorize live Workspace actions.

Platform capability B awaiting explicit reviewbaseline10->12 approval and Kernel review20/20 exhausted with report482a69/ledgerb3cc are separate; do not absorb either into this recovery. Target if an amendment is necessary: .omac/preview-same-head-evidence-recovery-reviewed-20261002.yaml.

## Captured current verification reference (not future control authority)

```json
{
  "comment_id": "01a0fc83-007e-71cb-abcf-65443b0d265e",
  "attachment_id": "01a0fc82-ff9d-7c52-afb2-a8da93e41c38",
  "sha256": "b044e29bcfabd8da6715a179f10e0e64993a44bee7279eee4176268ab7467937",
  "bytes": 14758,
  "filename": "omac-verification-b044e29bcfab.yaml"
}
```

## Fresh terminal outcome 2026-10-02 13:31 UTC

Run01a0fca3-1807-7814-96f0-683b2eff8773 completed13:29:10. Its actual work submit13:28:17 returned oktrue/terminaltrue/stop; fresh StoreDONE AUTHORING matches it. Latest attachment01a0fccb-2a9b-77f5-b8a4-776d0c6644a2/comment01a0fccb-2b78-78ff-8151-57e8895a298d SHA b044e29bcfabd8da6715a179f10e0e64993a44bee7279eee4176268ab7467937/14758B. This resolves the earlier unknown submission; no new code HEAD or independent review. No active Preview Run or control writer. Prepared request is now admitted for concrete routing, not apply or implementation. Full current inputs are mirrored at /tmp/oac-preview-recovery-bound-20261002 on Mac and Oracle; use .omac/open-agent-cluster.yaml there as exact current input, never stale remote repository manifest. Original reports and fresh raw/native snapshots reside under evidence/. Input-digests.json is a transport witness, not replacement authority.
