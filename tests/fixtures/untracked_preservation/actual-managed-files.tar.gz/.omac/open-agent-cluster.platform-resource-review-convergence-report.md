# contracts-platform-resource review convergence decision

## Trigger

- Manifest: `.omac/open-agent-cluster.yaml`
- Node: `contracts-platform-resource`
- Work item: `1b8e6ca8-4372-4974-a909-8994d0b05990` (`AITEAM-815`)
- Existing implementation: OAC PR #8
- Current PR head: `66efa82f66bdd763e25355d7bef9da95841b5bb1`
- OMAC decision: `review-convergence-exhausted`
- Semantic review cycles: 13
- Open blockers: 6
- Open responsibility dimensions: authority, structure, ownership, execution, evidence

OMAC derived this decision from the durable `omac.review-ledger/v1` attached to
the work item. Infrastructure retries are not part of these 13 semantic review
cycles. Do not dispatch another Worker revision for the current monolithic node.

## Evidence that the current node boundary is not independently reviewable

- The current task combines more than one independently testable state-contract
  responsibility under one package path.
- PR #8 contains 5,501 added lines across three files and fourteen commits.
- `contracts/workflow/resource/resource.go` alone contains 3,235 added lines.
- The integration gate has passed throughout review, while authoritative,
  structural, ownership, execution and evidence obligations remain open.
- Review initially converged from four blockers to one, then later cycles exposed
  additional independent roots. The problem is task-boundary mismatch, not a
  request to relax the authoritative contracts or Reviewer standard.

## Open semantic roots that must remain authoritative

1. `authoritative-resource-schema-not-implemented`
   - Exact Plan, Harness, InvocationRequest, Decision, Question and Answer wire
     contracts remain incomplete or mutually inconsistent.
2. `executable-plan-and-input-graph-integrity-unvalidated`
   - Active Plan replacement, retained identities, dependencies and obsolete-node
     semantics are not validated as one exact transition.
3. `run-projection-identity-and-transition-coherence-missing`
   - Agent, Component and Human Run identity, reports, active execution and state
     transitions are not closed bidirectionally.
4. `workflow-convergence-and-required-obligations-unvalidated`
   - Terminal Workflow outcomes, historical Plans and obsolete WorkUnits can claim
     convergence without complete authoritative evidence.
5. `dispatch-and-transition-admission-not-fail-closed`
   - Dispatch material and lifecycle transitions do not prove all authoritative
     executable preconditions.
6. `runtime-evidence-projection-not-closed`
   - Successful and terminal projections do not require the immutable Run, Gate,
     output, Decision, Question and Answer evidence that justifies them.

The exact blocker IDs, evidence and required fixes remain authoritative in the
work item's `review_ledger_ref` and `required_closures`; do not replace them with
this summary.

## Required amendment outcome

Use the complete supplied `docs/` corpus, current manifest, current PR #8 and the
work item's review ledger to replace the oversized delivery boundary with the
smallest independently PR-able, testable and reviewable contract nodes.

The amendment must:

- preserve all correct implementation and tests already present in PR #8;
- avoid discarding or manually rewriting the work-item, PR or review history;
- separate remaining responsibilities along authoritative semantic boundaries,
  not merely by arbitrary file size or line count;
- make leaf-node source ownership non-overlapping enough for safe parallel work;
- include a final platform-resource conformance node that depends on every leaf
  contract and runs the cross-contract invariants;
- rewire existing downstream dependencies to the final conformance node rather
  than allowing partial contracts to unblock consumers;
- preserve the published API/package boundary unless the owning design explicitly
  requires a change;
- keep every existing authoritative invariant, coverage requirement, integration
  gate and acceptance responsibility at an appropriate leaf or aggregate node;
- request only the minimum recovery set needed to preserve completed OAC work.

Candidate responsibility slices for Orchestrator evaluation include:

- base Workflow, WorkUnit, Artifact, Decision, Question and Answer DTO envelopes;
- Plan activation/replacement and executable input-graph integrity;
- typed Run projections, report sequence and lifecycle transitions;
- InvocationRequest, dispatch closure and admission preconditions;
- Workflow convergence, terminal outcome and immutable evidence closure;
- final cross-contract conformance.

These are candidate semantic boundaries, not a manually approved DAG. The
Orchestrator must confirm or revise them from the authoritative design.

## Reviewer requirements

Reviewer must verify that:

1. every amended node has one independently reviewable semantic responsibility;
2. the six open root causes are owned exactly once across leaf or conformance nodes;
3. PR #8's already-correct work is preserved and assigned to the proper boundary;
4. downstream nodes cannot consume an incomplete subset of platform contracts;
5. parallel leaf nodes do not require concurrent edits to the same implementation
   ownership surface without an explicit ordering dependency;
6. the final conformance node proves cross-contract identity, transitions,
   dispatch, convergence and evidence closure;
7. no product scope, security boundary, acceptance journey or authoritative
   contract is relaxed to make review pass;
8. the recovery set is minimal and does not rerun completed unrelated nodes.
