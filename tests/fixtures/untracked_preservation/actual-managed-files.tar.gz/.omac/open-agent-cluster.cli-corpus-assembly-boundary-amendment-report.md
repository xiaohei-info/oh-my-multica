# release-artifact-tooling CLI corpus and assembly-boundary blocker

## Trigger

- Manifest: `.omac/open-agent-cluster.yaml`
- Blocked node: `release-artifact-tooling`
- Work item: `152d735a-c373-4967-8ae0-45c191de2eff` (AITEAM-808)
- Existing implementation PR: OAC PR #5, current head `bdfcf737ab6b3fefe22c4640978ca8b8a68caa3d`
- Superseded amendment issue: `828afcad-a5bc-4e9c-b917-204b66739348` (AITEAM-813)
- Latest Worker Run: `7d67ae41-b464-47ed-a9b9-13009b22c9a0`

## Completed work that must be preserved

The accepted fixture-input amendment successfully resolved the no-input Artifact Storage verifier conflict. PR #5 now contains explicit versioned signed fixtures, digest-bound Compact and External bindings, probe evidence, closure, release/index commitments, trusted public key and signature verification, report outputs, and missing-input fail-closed behavior. The complete `tests/release-tooling` suite passed with 31 tests at `bdfcf73`.

Do not discard, redo, or move this completed implementation to another node.

## Confirmed remaining contract defects

### 1. Fabricated package CLI corpus

The mandatory command requires a 200-occurrence / 100-distinct package CLI corpus with fixed source and contract digests. The checked-in fixture currently contains only aggregate counts and digests. `package_component.py` fills the missing command list by fabricating `frozen-package-command-*` strings and reports those fabricated strings as executed invocations.

This reproduces an earlier valid Reviewer blocker: aggregate counters and generated placeholders are not compatibility evidence. At the same time, the current contract supplies no authoritative command corpus or deterministic derivation rule from an owned source, so the Worker cannot honestly create the required 100 commands without inventing product history.

### 2. Downstream production assembly obligations remain in the foundational node

The node description and accepted evidence boundary state that production CRDs, workloads, migrations, installers, complete system-release assembly, platform release evidence, trusted-release outputs, and live services belong to downstream nodes and are not inputs of this foundational fixture-evidenced node.

However, unchanged commands and semantic-audit requirements still require `system-release-assembly` package roots and complete assembly/consumer closure, including `packaging/system-release/**`, while those downstream payloads do not yet exist. This causes the Worker to block on CRDs, workloads, migrations, installers and ownership inputs that the same contract declares out of scope.

## Required amendment outcome

Amend only `release-artifact-tooling` unless a directly necessary responsibility correction must be made on an unstarted downstream node. Preserve topology, work item, PR history, completed fixture implementation, `evidence_mode: fixture`, omitted `consumes`, acceptance responsibilities, and downstream production ownership.

### CLI compatibility contract

- Replace the aggregate-only/fabricated corpus requirement with real executable compatibility evidence.
- Every declared invocation must be present as concrete structured data and must be parsed and executed through the actual CLI entry point or an explicitly approved deterministic adapter that invokes the same parser and validation path.
- Define the corpus source of truth and deterministic derivation rule from files owned by this node. Do not invent a historical 100-command corpus merely to satisfy old fixed counters or hashes.
- If the authoritative docs define behavior categories rather than exactly 100 commands, use complete category/variant coverage with derived metrics and content digests instead of preserving arbitrary cardinalities.
- Preserve backward-compatible legacy CLI behavior required by the design, but remove hard-coded expected hashes/counts that have no independently reviewable source.
- Require adversarial tests that prove malformed or unsupported legacy invocations fail for the correct reason and that placeholder/generated command names cannot satisfy the gate.

### Assembly boundary

- Keep static ownership assertions that this tooling must understand or validate, but do not require production assembly payloads or completed downstream component manifests at this node.
- Move production assembly payload/closure verification to the existing downstream owner(s) already present in the DAG, without changing their product responsibilities or making them rerun unless they have started and are genuinely affected.
- Remove current-node verification commands, metrics, named tests, and semantic-audit obligations that can pass only after downstream CRDs, workloads, migrations, installers, trusted-release or system-release assembly outputs exist.
- Continue to test the tooling against complete deterministic in-repository fixtures owned by `release-artifact-tooling`; fixtures must not be represented as production release evidence.

## Reviewer requirements

Reviewer must explicitly verify that:

1. no CLI compatibility result can be produced from aggregate counters or synthesized placeholder command names;
2. every positive CLI invocation is concrete, executable, provenance-bound, and derived from an identified owned source;
3. arbitrary historical counts/hashes are not retained without authority;
4. the target node no longer requires downstream production assembly payloads or completed downstream manifests;
5. static ownership checks remain strong and fail closed without becoming production payload checks;
6. the existing signed Artifact Storage fixture implementation and its tests remain required;
7. only the minimum authoring recovery set is requested, preferably only `release-artifact-tooling`.

Derive the amendment from the complete supplied `docs/` corpus, current manifest, accepted amendment history, latest Worker blocker comment, and PR #5 facts. If the docs genuinely require a fixed historical corpus or production payload at this stage, identify the exact owning authority and stop for a product decision instead of fabricating evidence.
