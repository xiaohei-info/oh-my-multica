# Open Agent Cluster running-DAG acceptance responsibility defect

Date: 2026-07-27

## Decision

The approved and already-running manifest must not be regenerated or manually
edited. Produce one reviewed `omac.dag-amendment/v1` patch that migrates the
acceptance-responsibility layer of the existing 145-node DAG while preserving
its topology, implementation ownership, verification commands, issue/PR facts,
and completed delivery facts.

## Authoritative inputs

- Current manifest: `.omac/open-agent-cluster.yaml`
- Current acceptance artifact: `.omac/open-agent-cluster.acceptance.yaml`
- All design documents under `docs/`
- Repository governance: `AGENTS.md`
- Acceptance issue: `289a13bf-cede-4b5b-ba86-d72f0bef8164`
- Orchestrator/decomposition issue: `8e6bd282-6039-41d2-aa00-969a0bf1554a`

The acceptance artifact contains 61 flows, 922 total executable steps, 495
explicit business Actions, and 427 flow-level authority/setup/evidence/cleanup
steps.

## Observed systemic defect

- All 145 nodes use legacy `contract.acceptance`.
- No node uses `acceptance_claims`, `acceptance_contributions`, or
  `acceptance_refs`.
- Each of the 61 flows is currently interpreted as having between 3 and 17
  full-flow owners.
- The old field conflates full-flow ownership, partial business-Action
  contribution, and traceability.
- The three bootstrap failures are symptoms of this global defect, not the
  complete affected set.

Examples:

- `UJ-PUBLIC-ENTRY-001` is claimed by 8 nodes, including
  `bootstrap-console`, although the bootstrap node cannot independently prove
  the complete public-entry journey.
- `UJ-KERNEL-001` is claimed by `bootstrap-go` and multiple later Kernel and
  integration nodes, although bootstrap only supplies a local toolchain
  contribution.
- `UJ-PLATFORM-INSTALL-001` is claimed by 15 nodes.
- `source-ownership-baseline-contract` is already done/merged but incorrectly
  claims both `UJ-PLATFORM-INSTALL-001` and `UJ-OAC-UPGRADE-001`; it only
  publishes the immutable source-ownership baseline and cannot prove either
  complete user journey.

## Required responsibility migration

For every node contract, replace the legacy acceptance interpretation with the
minimum correct combination of:

- `acceptance_claims`: only flows the node independently proves end to end;
- `acceptance_contributions`: exact `flow_id` and business `action_ids` whose
  implementation/evidence is owned by the node;
- `acceptance_refs`: trace-only flow references that create no node-local
  acceptance obligation.

The resulting global responsibility matrix must satisfy all of the following:

1. Every flow has exactly one feasible canonical full-flow owner.
2. Every business Action has at least one contribution owner.
3. The canonical full-flow owner equals or transitively depends on all
   contribution owners for that flow.
4. Flow-level authority/setup/evidence/cleanup steps remain the responsibility
   of the full-flow owner and are not copied into every node contract.
5. No legacy `contract.acceptance` remains in the migrated manifest.
6. Existing objectives, source-of-truth references, non-goals, verification
   commands, integration gates, PR bases, coverage gates, scope paths, workers,
   reviewers, titles, descriptions, risks, and DAG dependencies remain unchanged
   unless a separately evidenced defect makes a change unavoidable.

## Runtime preservation and minimum recovery

Only four nodes have existing work items. Preserve all issue IDs, PRs,
verification attachments, Reviewer artifacts, bounce history, and merge facts.

### `bootstrap-e2e`

- Work item: `f4e8dbee-68b1-4c32-8ae0-07ee8ed40d1c`
- PR: `https://github.com/xiaohei-info/open-agent-cluster/pull/4`
- Reviewer verdict: `pass`
- Required recovery: `merging` only.
- Do not rerun Worker or Reviewer solely because a temporary merge observation
  previously consumed the merge retry budget.

### `bootstrap-console`

- Work item: `ea309848-059d-431a-a93a-accc090cce27`
- PR: `https://github.com/xiaohei-info/open-agent-cluster/pull/2`
- Verification attachment already exists.
- Required recovery: `review` after the corrected contract is attached, provided
  PR head and verification evidence are unchanged.
- Do not return to Worker for an acceptance-responsibility-only correction.

### `bootstrap-go`

- Work item: `5849f786-8c97-42ac-adf9-1c96957f28ee`
- PR: `https://github.com/xiaohei-info/open-agent-cluster/pull/3`
- Verification attachment already exists.
- Required recovery: `review` after the corrected contract is attached, provided
  PR head and verification evidence are unchanged.
- The historical worker retry exhaustion must not force another implementation
  run when the implementation scope is unchanged.

### `source-ownership-baseline-contract`

- Work item: `0598495f-ca61-4044-a2e3-730adee4eab7`
- PR: `https://github.com/xiaohei-info/open-agent-cluster/pull/1`
- Current state: done and merged.
- Apply only a reviewed historical acceptance-responsibility correction.
- Preserve `done`, `merged`, `merged_at`, work item, PR, artifacts,
  verification, and all delivery evidence.
- Do not dispatch an Agent, reopen review, replay merge, or rewrite any
  implementation field.

Nodes without a work item may receive definition-only contract migration. They
must not create Agent Runs during amendment application; normal DAG scheduling
may start them only after the amendment has been Reviewer-approved, manually
accepted, fully applied, and their dependencies are satisfied.

## Prohibited outcomes

- Do not regenerate the full plan or replace the manifest wholesale.
- Do not patch runtime fields in the amendment.
- Do not change implementation scope to make a responsibility matrix pass.
- Do not assign full-flow ownership to early bootstrap/component nodes merely
  because they contribute one Action.
- Do not duplicate all 922 step IDs into the manifest.
- Do not cancel or rerun any Agent Run as part of proposal/review.
- Do not apply the amendment before Reviewer pass and explicit human approval.

## Reviewer obligations

Review the whole responsibility matrix in one pass rather than sampling only
the three bootstrap nodes. Verify exact business-Action closure, canonical
full-owner dependency closure, unchanged non-responsibility contract fields,
the done-node historical correction boundary, evidence/CAS bindings, and the
computed minimum recovery stages. Any missing, duplicate, unreachable, or
impossible responsibility is a blocker.
