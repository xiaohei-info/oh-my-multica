# Root exact OAC API Agent + MCP owner assessment request

Root owns OAC decisions under latest direct human steering and9512. This is one Source-coherent candidate assessment; Planner must verify current canonical design/source/commonowner/causaldeps/overlap/minimumoperations and merge or split. Neither shared words nor this grouping label is technical proof. If either independent route is ready while another needs separate owner/scope, deliver the concrete minimum ready group and exact additional-scope request; do not force a batch or omit actual changed/derived targets.

Exact initial held/allowed existing nodes: api-agent and mcp-catalog-governed-hardening. No effects outside the eventual Source-derived authorized envelope; any additional existing owner/derived target/new compensating publication must be returned as a concrete Source-bound scope request before effects. All current DONE producers remain immutable. No emptyops, genericassessment, unchanged Worker retry, Sourcecontract weakening, Root OAC implementation, fictional canonical decisions/testports as production, local MCP truthstore/runtime/auditledger, or inner imports of HTTP DTOs. Public workflow writer remains Platform Core; semantic owners remain narrow. Preserve original security, binding-only credential handling, RequestContext vs persisted context identity, actual canonical evaluated decisions, immutable publication, CAS/idempotency/Unknown/restart/compatibility/consumed launch proof. Reviewer original findings are unresolved, not Root technical verdict.

The current Source HEAD is 0dae29d869278750a051cf91272f577639c59b4b, authenticated remote main and captured public files Git exact. Original APIAgent inspected f0987a71/PR105; MCP original13da8715/PR103 plus dirty seven files preserved byteexact, not a fresh approved delivery. All original reports/ledgers/native/v2/source/failed submit history and full prior scope approvals are immutable. Existing config or captured counter arithmetic is not a grant. Require budget_policy:preserve every actual affected+derived approved effective absolute/relative consumed/remaining/limits and full generation/history/CAS. SDK0/12 and Conformance2/2 remain separate UNKNOWN; no grants/reset/refund/tightening/omission as revocation/ScopeTransfer/DONEreopen. FULL183/current80DONE/WHOLE20metadata/originalapproved18/264698-step8/history/security immutable. Future fresh independent Reviewer must cover every original root/command/ledger and Source-derived minimum operations; no apply in this assessment scope.

Execution-host input handoff: this Mac report .omac/api-mcp-grouped-owner-20261006/assessment-report.md maps to /home/ubuntu/code/open-agent-cluster/.omac/api-mcp-grouped-owner-20261006/assessment-report.md. Exact owner-request.json will be copied with SHA/fullbytes before dispatch, never stale Oracle runtime manifest. Readonly Source inputs bundle is /home/ubuntu/code/open-agent-cluster/.omac/api-mcp-grouped-owner-20261006/readonly-inputs.tar and input-index.json; extract immutable analysis inputs to task temporary directory if needed, never overwrite active control/config/source. Root's manifest snapshot is immutable ANALYSIS_ONLY and not an alternative active truth store. Use MacRoot source_of_truth current request binding; no missing-file or stale remote replacement.

Official OMAC Planner owns actual design/source verification and a coherent minimum proposal, fresh independent Reviewer owns technical verdict. The separate platform-fixer chat is not an OAC planner or owner. Workspace external infrastructure remains deferred; no human routine questions.

## Complete original API Agent request, independent report and ledger

### queued-request.md

# Current api-agent owner responsibility request

Queued factual coordination request under Root9512, not admission, a proposal, implementation or product verdict. The actual terminal Worker v2 and full independent reject report/ledger are bound in /tmp/oac-api-agent-production-owner-bound-0855-20261004. Planner must inspect full current owning overview/detailed/exact references/acceptance/deploy boundaries and current physical source, rather than treating Worker owner-gap claims as a technical verdict. Current sampled main is 86624dab82924df9ba2a74107c45084ccaa5e7f2; source bytes here are immutable source captures, not retrieval of historical declared production Artifacts.

Node api-agent, issue 01a1048e-0327-70a5-84b8-d2967af606ea, reviewed head f0987a71ee760836601bb676e2bcd59b72ba0d08 remains uncompleted. Its actual blocker binding, generation including actual None, full contract, original failures, all review cycles and absolute/effective approved budgets remain authoritative. Do not reopen or amend any current DONE producer, including AgentDefinition/AgentTemplate/AgentModelPolicy/Authorization/Audit contracts and every one of the current 71 done FULLobjects. All 18 retained approved budget records remain exact.

Derive a smallest genuine current-uncompleted or necessary compensating owner/scope/dependency/typed immutable proof repair from the actual owning design and source. Verify whether each reported absence is real and which semantic owner can lawfully supply it. Keep canonical RequestContext, evaluated control provenance, immutable audit/write boundaries, northbound adapters and inward dependencies intact. Do not fabricate policy/provider provenance, create a parallel audit schema/store, import adapter DTOs inward, label test applications as production, waive the original rejection, or invent an API/contract on Root's behalf. No generic assessment, empty operations, unchanged resume, plan route, fake evidence/ROOTs, direct merge or product PASS.

Any necessary affected/derived recoveries must explicitly use budget_policy: preserve: original absolute/relative consumed and remaining budgets, approved authority, limits, baseline/CAS identity and complete history; no implicit refund, reset or historical fixture as live admission. A genuinely new proposal requires a fresh independent Reviewer and full report/ledger, terminal controller, current minimal operation/stage/source/Store/CAS/related-terminal/all-current-done/budget guards before Root acceptable apply. The ordinary Runner is the sole control writer; no parallel B controller. Healthy related execution is preserved and old terminal observations are not current admission proof.

This request queues inputs only. Before formal admission refresh all current source/main/Store/native/CAS/done/budget bindings. Preserve original reports and Worker source unchanged. Workspace external resources remain deferred; no Root OAC code/test/contract design, live operation, or OMAC fixer product implementation. Target .omac/api-agent-production-owner-reviewed-20261004.yaml.


### omac-review-report-cb08fc44a86d.yaml

review_protocol: omac.review/v2
review_goals:
- Verify the complete PR against the authoritative Agent API and Project/Team contracts without requiring trace-only
  acceptance refs to prove full UI journeys.
- Independently reproduce all declared commands, coverage, stable generation, upstream manifest lineage and release
  ownership closure.
- Check that HTTP operations reach owning governed use cases, preserve immutable publication/CAS/idempotency, and
  document public failure semantics.
summary: 'Reject: all four declared verification commands pass and total statement coverage is 93.4%, but the API
  is connected only to a test implementation of a new interface, and the public command error/governance contracts
  are incomplete.'
pr_url: https://github.com/xiaohei-info/open-agent-cluster/pull/105
reviewed_head_sha: f0987a71ee760836601bb676e2bcd59b72ba0d08
pr_base: main
diff_reviewed: true
tests_rerun: true
integration_tests_rerun: true
coverage_checked: true
full_review_completed: true
obligation_results:
- obligation_id: dimension:authority
  status: fail
  evidence: Verified contract attachment SHA-256 93553b7c0e6b0717921b2ab8677f1a83da5c47cc08667eb378738ce4320fcbb4,
    all named detailed-design anchors, Project/Team reference and UJ-AGENT-001..006. API command declarations omit
    required failure/governance semantics; see api-agent-public-command-contract-incomplete.
- obligation_id: dimension:structure
  status: fail
  evidence: Inspected every one of the 10 added PR files and traced Application methods and constructor usages throughout
    the repository. Only testApplication implements the new interface. Real template and definition application
    contracts are incompatible and no production translator connects them; see api-agent-owner-use-cases-disconnected.
- obligation_id: dimension:execution
  status: pass
  evidence: Independently ran all four exact contract verification commands to exit 0 in a clean checkout of the
    sealed head with Go 1.26.0, Python 3.14.3 and zstd 1.5.7. Existing transport/security-negative cases ran as
    part of the declared package tests; no undeclared probes or attack experiments were added. The passing command
    suite does not prove the missing production composition.
- obligation_id: dimension:ownership
  status: pass
  evidence: The complete main-relative diff changes only api/openapi/agents/** and internal/httpapi/agents/**. Handler
    holds only an Application dependency and does not persist catalog, publication, workflow, runtime, audit or
    lifecycle business state. Both API source roots passed the canonical ownership closure check; upstream ownership/catalog/tools
    remained unchanged.
- obligation_id: dimension:evidence
  status: pass
  evidence: Reproduced the three upstream manifests at cb1bc1c94c92fe69a2cb7191078f999bbe472b93, 74327d6fe453374055771bbf8ef5926c2db48326
    and e91e20ef2e47e62c057ac25e4fc00066488c3245 using their declared package commands, not fabricated fixtures.
    Canonical API manifest verifier passed exact component api-agent, both owned roots and all three generated inputs.
    AgentDefinition adaptation retains component_id agent-definition. All four declared artifacts exist and are
    nonempty.
- obligation_id: dimension:regression
  status: pass
  evidence: work show has no prior_open_blockers and review cycle_count 0. Inspected the full changed scope rather
    than limiting review to packaging or worker summaries. Source generation leaves no tracked or untracked drift
    and reviewed source remains unchanged.
- obligation_id: integration:api-agent-gate
  status: pass
  evidence: All four api-agent-gate command invocations exit 0. Reproduced total statement coverage 93.4% against
    minimum 90, four nonempty declared artifacts, stable OpenAPI generation, and exact ownership/generated-input
    packaging verification. This is a pass of the declared executable gate, not a waiver of the structural and public-contract
    findings.
prior_blocker_results: []
acceptance_mapping:
- acceptance: UJ-AGENT-001
  status: fail
  evidence: 'Trace-only API-boundary assessment, not a full-journey claim: Template inheritance is exercised via
    a test-only closure invoking templates.Application.Instantiate; template-backed production publication is not
    connected.'
- acceptance: UJ-AGENT-002
  status: fail
  evidence: 'Trace-only API-boundary assessment, not a full-journey claim: Confirmed custom Skill removal and ordering
    are exercised through a test-only template closure; no production bridge publishes the customized immutable
    definition.'
- acceptance: UJ-AGENT-003
  status: fail
  evidence: 'Trace-only API-boundary assessment, not a full-journey claim: Fixed model identities round-trip in
    OpenAPI DTO tests, but the production publication bridge is absent.'
- acceptance: UJ-AGENT-004
  status: fail
  evidence: 'Trace-only API-boundary assessment, not a full-journey claim: Ordered cross-provider identities are
    preserved by mock publication; the real publication use case is not connected.'
- acceptance: UJ-AGENT-005
  status: fail
  evidence: 'Trace-only API-boundary assessment, not a full-journey claim: CAS/idempotency fields are forwarded
    to testApplication, but real owner-side refusal/atomic publication and safe error translation are not exercised
    by production composition.'
- acceptance: UJ-AGENT-006
  status: fail
  evidence: 'Trace-only API-boundary assessment, not a full-journey claim: Blank publication test returns a fabricated
    definition instead of calling definitions.Application.PublishBlank; actual request-to-owner translation is missing.'
integration_gate_mapping:
- gate: api-agent-gate
  status: pass
  source_of_truth:
  - docs/design/detailed/10-web-api-cli-detailed-design.md:L1392-L1428
  - docs/design/detailed/10-web-api-cli-detailed-design.md:L355-L638
  - docs/design/detailed/10-web-api-cli-detailed-design.md:L1375-L1545
  delivery_goal: Expose AgentTemplate, model policy and AgentDefinition lifecycle operations without adapter-owned
    business state.
  commands:
  - cmd: mkdir -p artifacts/api-agent && go test -covermode=atomic -coverprofile=artifacts/api-agent/coverage.out
      ./api/openapi/agents/... ./internal/httpapi/agents/...
    exit_code: 0
    summary: "ok  \tgithub.com/xiaohei-info/open-agent-cluster/api/openapi/agents\t(cached)\tcoverage: 100.0% of\
      \ statements\nok  \tgithub.com/xiaohei-info/open-agent-cluster/api/openapi/agents/generator\t(cached)\tcoverage:\
      \ 75.0% of statements\nok  \tgithub.com/xiaohei-info/open-agent-cluster/internal/httpapi/agents\t(cached)\t\
      coverage: 92.7% of statements"
  - cmd: python3 -c "from pathlib import Path; import re,subprocess; p=Path('artifacts/api-agent/coverage.out');
      assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True);
      m=re.search(r'^total:\s+\(statements\)\s+([0-9.]+)%$',out,re.M); assert m and float(m.group(1)) >= 90"
    exit_code: 0
    summary: Completed successfully with no output.
  - cmd: go list ./api/openapi/agents/... | grep -q . && go generate ./api/openapi/agents/... && git diff --exit-code
      -- api/openapi/agents && test -z "$(git ls-files --others --exclude-standard -- api/openapi/agents)"
    exit_code: 0
    summary: Completed successfully with no output.
  - cmd: python3 scripts/release/package_component.py --component api-agent --kind platform-core-adapter-source
      --input api/openapi/agents --input internal/httpapi/agents --generated-input artifacts/agent-template/component-manifest.json
      --generated-input artifacts/agent-model-policy/component-manifest.json --generated-input artifacts/agent-definition-audit-consumer-adaptation/component-manifest.json
      --require-generated-input-digest --bundle artifacts/api-agent/source-bundle.tar.zst --component-manifest artifacts/api-agent/component-manifest.json
      --digest-output artifacts/api-agent/bundle-digest.txt --ownership-baseline contracts/release/source-ownership-baseline.yaml
      --ownership-catalog contracts/release/source-ownership-catalog.yaml --owner api-agent --require-all-owner-sources-accounted
      && python3 scripts/release/verify_component_manifest.py --manifest artifacts/api-agent/component-manifest.json
      --bundle artifacts/api-agent/source-bundle.tar.zst --expected-component api-agent --require-owned-source api/openapi/agents
      --require-owned-source internal/httpapi/agents --require-generated-input artifacts/agent-template/component-manifest.json
      --require-generated-input artifacts/agent-model-policy/component-manifest.json --require-generated-input artifacts/agent-definition-audit-consumer-adaptation/component-manifest.json
      --ownership-catalog contracts/release/source-ownership-catalog.yaml --require-all-owner-sources-accounted
    exit_code: 0
    summary: 'bundle=artifacts/api-agent/source-bundle.tar.zst

      manifest=artifacts/api-agent/component-manifest.json

      component manifest verification passed'
  metrics:
    statement_coverage_percent: 93.4
    declared_artifact_count: 4
  artifacts:
  - artifacts/api-agent/coverage.out
  - artifacts/api-agent/bundle-digest.txt
  - artifacts/api-agent/component-manifest.json
  - artifacts/api-agent/source-bundle.tar.zst
  notes: Declared commands reproduce successfully. Publication and lifecycle tests substitute testApplication; passing
    this gate is not evidence that owning production use cases are exposed.
blockers:
- root_cause_key: api-agent-owner-use-cases-disconnected
  obligation_id: dimension:structure
  classification: new
  owner: api-agent
  severity: high
  summary: HTTP operations have no production bridge to the owning Agent application use cases.
  impact: The delivered package can dispatch to mocks but cannot instantiate/publish/manage Agents using the checked-in
    upstream applications. Governance, server-resolved runtime defaults, immutable publication and lifecycle reference
    protection remain promises of an unimplemented interface rather than an exposed capability.
  evidence: internal/httpapi/agents/handler.go:50-65 introduces a 10-method Application interface taking API-owned
    DTOs; handler.go:71-73 only injects it. Repository-wide symbol searches find its methods implemented solely
    in handler_test.go:503-572 and all constructor uses in tests. Actual templates.Application.Instantiate at internal/agents/templates/templates.go:120
    takes templates.InstantiateRequest, whereas definitions.Application.PublishBlank at internal/agents/definitions/definitions.go:332
    takes PublishBlankRequest with RequestContextID, an existing Agent/CAS and already-resolved runtime bindings.
    No production code translates the public request, calculates instruction digests, resolves runtime requests/defaults,
    preserves template provenance, or bridges catalog/lifecycle calls. Publication/lifecycle tests at handler_test.go:130-225,263-284
    return fabricated test results rather than exercising these owner boundaries; only template test closures at
    :60-65,:91-95 invoke an actual upstream application.
  required_fix: Supply production transport-to-owner composition using the actual inward-facing use-case contracts
    (or explicitly resolve an owner-contract prerequisite through the authorized process). Translate the public
    inputs/results and safe classified failures; derive server-owned values at the owning application boundary;
    preserve RequestContext/audit provenance, CAS/idempotency, template provenance and reference protection. Do
    not add business state or lifecycle rules in the HTTP adapter and do not force inner application modules to
    import API DTOs. Extend the declared package suite to exercise this production bridge with deterministic owner-port
    fixtures, including template and blank publication and lifecycle refusal paths.
- root_cause_key: api-agent-public-command-contract-incomplete
  obligation_id: dimension:authority
  classification: new
  owner: api-agent
  severity: medium
  summary: Published command schemas do not specify the required governance and actual failure outcomes.
  impact: Web/oactl/third-party clients cannot rely on the single published OpenAPI contract to authenticate, handle
    lifecycle denial/not-found/unavailability, or distinguish protected-reference/business refusal from a stale
    CAS retry. Required command semantics are not defined consistently across clients.
  evidence: docs/design/detailed/10-web-api-cli-detailed-design.md:1398-1409 requires each command to define RequestContext,
    authorization action, Admission boundary, business refusal, conflict, retryable/nonretryable errors and audit
    semantics. api/openapi/agents/openapi.yaml:169-225 declares only 200/409 for each lifecycle command, despite
    handler.go:80-83 returning 403 for missing governance context, :216-220 returning 400, and :318-331 mapping
    404/403/503/500. The document has no security scheme/security requirement and lifecycle operations contain no
    authorization, Admission or audit contract. Its Conflict response at :259-263 combines CAS, idempotency and
    protected-reference conflicts, while handler.go:324-325 provides the same refresh-and-retry message for all
    of them. Publication describes governance generically at openapi.yaml:106-111 but does not define its authorization
    action or retry semantics.
  required_fix: Complete the authoritative OpenAPI command contracts with the supported authenticated RequestContext
    transport, authorization actions, Admission applicability and audit semantics (link the owning governance contract
    where appropriate). Declare every supported HTTP failure or a typed default error response, including lifecycle
    400/403/404/503/internal failures. Preserve safe machine-readable distinctions and next actions for stale revision,
    idempotency mismatch and protected-reference/business refusal. Add schema/HTTP conformance checks to the existing
    declared suite instead of testing only spec substring presence.
nits: []
evidence:
  coverage_total_percent: 93.4
  bundle_sha256: 84d87b4ea43c9d23079e1d33acdaf022f379acffd851a1f2537f9c58d7cded4e
  source_revision: f0987a71ee760836601bb676e2bcd59b72ba0d08
  upstream_manifest_digests:
    artifacts/agent-definition-audit-consumer-adaptation/component-manifest.json: 11ba585edda7a6a402c1883efcafd70cd3d5e94ceabc025a49364aed52bb0d22
    artifacts/agent-model-policy/component-manifest.json: 4fa8ff20b72b0c37de6f7398bd98681976d4e552786610a776f2802ee70bb0d7
    artifacts/agent-template/component-manifest.json: 95e2b81f7a74b920677154a556b7dda935b5ffcdd30cbcf408bb8ba2ae9b0ca7
  scope_note: UJ refs are trace-only; no missing screenshots, frontend journeys, undeclared live service, or downstream
    runtime evidence was treated as a blocker. Findings concern the current API deliverable itself.


### omac-review-ledger-3bdc754ebc7f.yaml

schema: omac.review-ledger/v2
cycles:
- round: 1
  subject_digest: 4855c4853513dccc8aceabd2f3bf32ce801eea0a9e46cc656235691d43926043
  report_digest: 4d39b4447264f66ce888b2ba2230165bc82821f607f062c896758082f7b90d4e
  verdict: reject
  obligation_results:
    dimension:authority: fail
    dimension:structure: fail
    dimension:execution: pass
    dimension:ownership: pass
    dimension:evidence: pass
    dimension:regression: pass
    integration:api-agent-gate: pass
  new_count: 2
  fixed_count: 0
  regressed_count: 0
  unchanged_count: 0
  open_count: 2
  prior_open_blocker_ids: []
  open_blocker_ids: &id001
  - BLK-3ae8ac149441
  - BLK-9beec89d4933
  reported_blocker_ids: *id001
  blocker_facts_schema: omac.review-cycle-blocker-facts/v1
  blocker_facts:
  - blocker_id: BLK-3ae8ac149441
    root_cause_key: api-agent-public-command-contract-incomplete
    obligation_id: dimension:authority
    summary: Published command schemas do not specify the required governance and
      actual failure outcomes.
    evidence: docs/design/detailed/10-web-api-cli-detailed-design.md:1398-1409 requires
      each command to define RequestContext, authorization action, Admission boundary,
      business refusal, conflict, retryable/nonretryable errors and audit semantics.
      api/openapi/agents/openapi.yaml:169-225 declares only 200/409 for each lifecycle
      command, despite handler.go:80-83 returning 403 for missing governance context,
      :216-220 returning 400, and :318-331 mapping 404/403/503/500. The document has
      no security scheme/security requirement and lifecycle operations contain no
      authorization, Admission or audit contract. Its Conflict response at :259-263
      combines CAS, idempotency and protected-reference conflicts, while handler.go:324-325
      provides the same refresh-and-retry message for all of them. Publication describes
      governance generically at openapi.yaml:106-111 but does not define its authorization
      action or retry semantics.
    required_fix: Complete the authoritative OpenAPI command contracts with the supported
      authenticated RequestContext transport, authorization actions, Admission applicability
      and audit semantics (link the owning governance contract where appropriate).
      Declare every supported HTTP failure or a typed default error response, including
      lifecycle 400/403/404/503/internal failures. Preserve safe machine-readable
      distinctions and next actions for stale revision, idempotency mismatch and protected-reference/business
      refusal. Add schema/HTTP conformance checks to the existing declared suite instead
      of testing only spec substring presence.
    status: open
    classification: new
    owner: api-agent
  - blocker_id: BLK-9beec89d4933
    root_cause_key: api-agent-owner-use-cases-disconnected
    obligation_id: dimension:structure
    summary: HTTP operations have no production bridge to the owning Agent application
      use cases.
    evidence: internal/httpapi/agents/handler.go:50-65 introduces a 10-method Application
      interface taking API-owned DTOs; handler.go:71-73 only injects it. Repository-wide
      symbol searches find its methods implemented solely in handler_test.go:503-572
      and all constructor uses in tests. Actual templates.Application.Instantiate
      at internal/agents/templates/templates.go:120 takes templates.InstantiateRequest,
      whereas definitions.Application.PublishBlank at internal/agents/definitions/definitions.go:332
      takes PublishBlankRequest with RequestContextID, an existing Agent/CAS and already-resolved
      runtime bindings. No production code translates the public request, calculates
      instruction digests, resolves runtime requests/defaults, preserves template
      provenance, or bridges catalog/lifecycle calls. Publication/lifecycle tests
      at handler_test.go:130-225,263-284 return fabricated test results rather than
      exercising these owner boundaries; only template test closures at :60-65,:91-95
      invoke an actual upstream application.
    required_fix: Supply production transport-to-owner composition using the actual
      inward-facing use-case contracts (or explicitly resolve an owner-contract prerequisite
      through the authorized process). Translate the public inputs/results and safe
      classified failures; derive server-owned values at the owning application boundary;
      preserve RequestContext/audit provenance, CAS/idempotency, template provenance
      and reference protection. Do not add business state or lifecycle rules in the
      HTTP adapter and do not force inner application modules to import API DTOs.
      Extend the declared package suite to exercise this production bridge with deterministic
      owner-port fixtures, including template and blank publication and lifecycle
      refusal paths.
    status: open
    classification: new
    owner: api-agent
blockers:
- blocker_id: BLK-3ae8ac149441
  root_cause_key: api-agent-public-command-contract-incomplete
  obligation_id: dimension:authority
  summary: Published command schemas do not specify the required governance and actual
    failure outcomes.
  evidence: docs/design/detailed/10-web-api-cli-detailed-design.md:1398-1409 requires
    each command to define RequestContext, authorization action, Admission boundary,
    business refusal, conflict, retryable/nonretryable errors and audit semantics.
    api/openapi/agents/openapi.yaml:169-225 declares only 200/409 for each lifecycle
    command, despite handler.go:80-83 returning 403 for missing governance context,
    :216-220 returning 400, and :318-331 mapping 404/403/503/500. The document has
    no security scheme/security requirement and lifecycle operations contain no authorization,
    Admission or audit contract. Its Conflict response at :259-263 combines CAS, idempotency
    and protected-reference conflicts, while handler.go:324-325 provides the same
    refresh-and-retry message for all of them. Publication describes governance generically
    at openapi.yaml:106-111 but does not define its authorization action or retry
    semantics.
  required_fix: Complete the authoritative OpenAPI command contracts with the supported
    authenticated RequestContext transport, authorization actions, Admission applicability
    and audit semantics (link the owning governance contract where appropriate). Declare
    every supported HTTP failure or a typed default error response, including lifecycle
    400/403/404/503/internal failures. Preserve safe machine-readable distinctions
    and next actions for stale revision, idempotency mismatch and protected-reference/business
    refusal. Add schema/HTTP conformance checks to the existing declared suite instead
    of testing only spec substring presence.
  status: open
  classification: new
  owner: api-agent
  first_seen_round: 1
  last_seen_round: 1
  seen_count: 1
- blocker_id: BLK-9beec89d4933
  root_cause_key: api-agent-owner-use-cases-disconnected
  obligation_id: dimension:structure
  summary: HTTP operations have no production bridge to the owning Agent application
    use cases.
  evidence: internal/httpapi/agents/handler.go:50-65 introduces a 10-method Application
    interface taking API-owned DTOs; handler.go:71-73 only injects it. Repository-wide
    symbol searches find its methods implemented solely in handler_test.go:503-572
    and all constructor uses in tests. Actual templates.Application.Instantiate at
    internal/agents/templates/templates.go:120 takes templates.InstantiateRequest,
    whereas definitions.Application.PublishBlank at internal/agents/definitions/definitions.go:332
    takes PublishBlankRequest with RequestContextID, an existing Agent/CAS and already-resolved
    runtime bindings. No production code translates the public request, calculates
    instruction digests, resolves runtime requests/defaults, preserves template provenance,
    or bridges catalog/lifecycle calls. Publication/lifecycle tests at handler_test.go:130-225,263-284
    return fabricated test results rather than exercising these owner boundaries;
    only template test closures at :60-65,:91-95 invoke an actual upstream application.
  required_fix: Supply production transport-to-owner composition using the actual
    inward-facing use-case contracts (or explicitly resolve an owner-contract prerequisite
    through the authorized process). Translate the public inputs/results and safe
    classified failures; derive server-owned values at the owning application boundary;
    preserve RequestContext/audit provenance, CAS/idempotency, template provenance
    and reference protection. Do not add business state or lifecycle rules in the
    HTTP adapter and do not force inner application modules to import API DTOs. Extend
    the declared package suite to exercise this production bridge with deterministic
    owner-port fixtures, including template and blank publication and lifecycle refusal
    paths.
  status: open
  classification: new
  owner: api-agent
  first_seen_round: 1
  last_seen_round: 1
  seen_count: 1


## Complete original MCP worker block v2, owning Source supplement, independent report and ledger

### actual-worker-block-v2.json

{
  "ok": false,
  "exit_code": 20,
  "terminal": true,
  "decision_required": {
    "schema": "omac.decision-required/v1",
    "reason_code": "worker-decision-required",
    "kind": "develop",
    "phase": "authoring",
    "gate": "worker",
    "resume_issue_id": "01a103e4-4377-7af9-b3c9-dd1b118c6af1",
    "review_context_binding": {
      "generation": null,
      "contract_sha256": "0d05320b8b3317af156d1834b421afbf800c630368cca2550f5a479d293dd52a"
    },
    "blocker": {
      "schema": "omac.worker-blocker/v2",
      "reason_code": "owner-decision-required",
      "issue_id": "01a103e4-4377-7af9-b3c9-dd1b118c6af1",
      "review_context_binding": {
        "generation": null,
        "contract_sha256": "0d05320b8b3317af156d1834b421afbf800c630368cca2550f5a479d293dd52a"
      },
      "handoff_generation": "handoff-17979b921971475e",
      "worker": "codex-macmini-newapi",
      "run_id": "01a10497-db0d-799c-9d0b-19bc6e184b36",
      "summary": "The review requires production MCP persistence and consumed-launch proof, but this checkout has no canonical owners for either. Adding local authorities would violate the contract.",
      "decision_needed": "Identify the canonical Platform Core transaction/receipt API and AgentRun consumed-launch receipt API for MCP, or approve extending the canonical owner scope. Do not add an MCP-local store or runtime.",
      "contract_ref": "non_goals",
      "evidence": [
        {
          "ref": "internal/platformcore/agentrun/application.go:881",
          "observation": "The Platform Core Store commits AgentRun runs/events/completion only; it exposes no MCP catalog transaction."
        },
        {
          "ref": "internal/agents/definitions/definitions.go:302",
          "observation": "DefinitionStore persists AgentDefinition publication, not MCP definitions or MCP command/audit transactions."
        },
        {
          "ref": "internal/mcp/governed.go:278,336",
          "observation": "MCPStore and MCPRuntimeMaterializer are ports with no non-test implementation in this checkout."
        },
        {
          "ref": "internal/agentrun/runner.go:30",
          "observation": "AgentRun's MCPInjectionMaterializer returns an injection path, not a consumed-launch receipt. Full MCP tests and all five declared commands pass at 90.0% coverage; they cannot prove the missing production owners."
        }
      ]
    },
    "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> mcp-catalog-governed-hardening"
  },
  "next_action": "stop"
}

### owning-authority-supplement.json

{
  "at": "2026-10-04T04:08:16.149804+00:00",
  "authority_docs_full": 20,
  "authority_root_and_worker_bytes_identical": true,
  "related_current_node_fullobjects": 17,
  "worker_source_files": 40,
  "worker_head": "13da87159867368a30634d04cf45500894d91f98",
  "root_head": "3bb312be997324b24106d4e8b12b714dcb73a2f0",
  "worker_source_roots_absent": [
    "contracts/mcp",
    "contracts/governance/authorization",
    "internal/runtime"
  ],
  "original_partial_source_not_changed": true,
  "not_formal_admission": true,
  "remaining_before_admission": [
    "Fresh canonical/current-main source and related Store controls/terminal Runs",
    "Post-install capability verification and current guard rebinding",
    "Planner independent proposal and fresh Reviewer"
  ]
}

### omac-review-report-83c997d95bd8.yaml

{
  "review_protocol": "omac.review/v2",
  "review_goals": [
    "Verify system-owned definition identity and digest, binding-only secret handling, durable restart-safe reservation/replay, canonical governance/credential lineage, and exact runtime materialization proof.",
    "Independently rerun every declared L1 gate command at the sealed PR head and inspect the complete changed scope without modifying author code or platform state."
  ],
  "summary": "Reject PR #103 at 13da87159867368a30634d04cf45500894d91f98. Every declared executable gate command passes and coverage is 90.2%, but four contract defects remain: heuristic inline-secret handling, interfaces-only canonical persistence/runtime delivery, audit projections used as authorization/admission decisions, and request/context audit identity conflation.",
  "pr_url": "https://github.com/xiaohei-info/open-agent-cluster/pull/103",
  "reviewed_head_sha": "13da87159867368a30634d04cf45500894d91f98",
  "pr_base": "main",
  "diff_reviewed": true,
  "tests_rerun": true,
  "integration_tests_rerun": true,
  "coverage_checked": true,
  "full_review_completed": true,
  "environment": [
    "Independent detached clone at the exact sealed PR head; Go 1.26.0 linux/arm64 and Python 3.14.3.",
    "No external services required by env_setup; only the contract-declared local verification was executed."
  ],
  "obligation_results": [
    {
      "obligation_id": "dimension:authority",
      "status": "pass",
      "evidence": "Current work-show contract, sealed delivery identity, PR main base/head, amendment decision, and all cited design/reference anchors were inspected. Semantic conflicts are explicitly reported as blockers rather than silently resolved."
    },
    {
      "obligation_id": "dimension:structure",
      "status": "fail",
      "evidence": "New production file declares ports, while canonical persistence/runtime implementations and production-capable composition are absent; restart/runtime proof exists only in test fixtures. See mcp-hardening-disconnected-canonical-owners."
    },
    {
      "obligation_id": "dimension:execution",
      "status": "fail",
      "evidence": "All five exact declared commands pass at the reviewed head, but Header/Environment handling remains heuristic and does not establish binding-only fail-closed semantics. See mcp-inline-secret-heuristic-classification."
    },
    {
      "obligation_id": "dimension:ownership",
      "status": "fail",
      "evidence": "Existing authz/admission canonical decision contracts are replaced at the MCP port boundary by insufficient audit-control projections. See mcp-governance-audit-projection-used-as-decision. No new database, HTTP DTO, Runtime implementation, or audit ledger was introduced."
    },
    {
      "obligation_id": "dimension:evidence",
      "status": "fail",
      "evidence": "Bundle/manifest source revision and ownership verified, but audit validation conflates external request_id with persisted request_context_id. See mcp-audit-request-id-context-id-conflation."
    },
    {
      "obligation_id": "dimension:regression",
      "status": "pass",
      "evidence": "No prior_open_blockers in current work-show context. All seven changed files, the complete new use case and tests, changed helper paths, and neighboring canonical contracts were reviewed; all eight required regressions were independently rerun. Their proof limitations are reported, not treated as full acceptance."
    },
    {
      "obligation_id": "integration:mcp-catalog-governed-hardening-gate",
      "status": "pass",
      "evidence": "The exact five declared gate commands passed; 90.2% coverage, eight named regressions present and passing, four nonempty artifacts, canonical mcp-catalog packaging/ownership verified. This status records executable gate reproduction only, not closure of the semantic blockers."
    }
  ],
  "prior_blocker_results": [],
  "acceptance_mapping": [
    {
      "acceptance": "UJ-MCP-001",
      "status": "fail",
      "evidence": "Trace-only acceptance reference, not a complete UI journey claim. Catalog contribution is not acceptable because inline-secret and canonical-owner/lineage requirements remain open. No full UI end-to-end execution was required or claimed."
    }
  ],
  "integration_gate_mapping": [
    {
      "gate": "mcp-catalog-governed-hardening-gate",
      "status": "pass",
      "source_of_truth": [
        "api-mcp-amendment-decision.md",
        "docs/design/open-agent-cluster-overview-design.md:L68-L95",
        "docs/design/open-agent-cluster-overview-design.md:L189-L243",
        "docs/design/open-agent-cluster-overview-design.md:L585-L590",
        "docs/design/detailed/09-governance-and-security-detailed-design.md:L11-L45",
        "docs/design/detailed/09-governance-and-security-detailed-design.md:L278-L402",
        "docs/design/detailed/09-governance-and-security-detailed-design.md:L408-L474",
        "docs/design/detailed/09-governance-and-security-detailed-design.md:L553-L572",
        "docs/design/detailed/10-web-api-cli-detailed-design.md:L426-L486",
        "docs/design/detailed/10-web-api-cli-detailed-design.md:L1375-L1545",
        "docs/references/governance/security-and-enterprise.md:L236-L317",
        "docs/references/governance/security-and-enterprise.md:L402-L488",
        "docs/references/execution/agent-runtime.md:L130-L223",
        "contracts/agentrun/agentrun.go:L618-L735",
        "docs/delivery/acceptance-and-validation.md:L300-L313"
      ],
      "delivery_goal": "Prove the canonical mcp-catalog component persists stable definitions and command records durably, rejects every inline-secret path, uses exact governance and credential-use identities, and returns ready only for a complete runtime materialization proof.",
      "commands": [
        {
          "cmd": "mkdir -p artifacts/mcp-catalog-governed-hardening && go test -covermode=atomic -coverprofile=artifacts/mcp-catalog-governed-hardening/coverage.out ./internal/mcp/...",
          "exit_code": 0,
          "summary": "Package suite passed; 90.2% statement coverage."
        },
        {
          "cmd": "go test ./internal/mcp/... -run '^(TestGovernedMCPUseCaseSystemOwnsIdentityAndDigest|TestGovernedMCPUseCaseRejectsInlineSecretValues|TestGovernedMCPUseCaseDurableCreateReplaySurvivesRestart|TestGovernedMCPUseCaseDurableProbeReplaySurvivesRestart|TestGovernedMCPUseCaseDurableMaterializationReplaySurvivesRestart|TestGovernedMCPUseCasePreservesUnknownCommitOutcome|TestGovernedMCPUseCaseUsesCanonicalGovernanceLineage|TestGovernedMCPUseCaseValidatesExactMaterializationProof)$' -count=1",
          "exit_code": 0,
          "summary": "All eight named regressions passed."
        },
        {
          "cmd": "python3 -c \"from pathlib import Path; import re,subprocess; p=Path('artifacts/mcp-catalog-governed-hardening/coverage.out'); assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True); m=re.search(r'^total:\\s+\\(statements\\)\\s+([0-9.]+)%$',out,re.M); assert m and float(m.group(1)) >= 90\"",
          "exit_code": 0,
          "summary": "Coverage threshold assertion passed at 90.2%."
        },
        {
          "cmd": "python3 scripts/release/package_component.py --component mcp-catalog --kind platform-core-dependency-source --input internal/mcp --bundle artifacts/mcp-catalog-governed-hardening/source-bundle.tar.zst --component-manifest artifacts/mcp-catalog-governed-hardening/component-manifest.json --digest-output artifacts/mcp-catalog-governed-hardening/bundle-digest.txt --ownership-baseline contracts/release/source-ownership-baseline.yaml --owner mcp-catalog --require-all-owner-sources-accounted",
          "exit_code": 0,
          "summary": "Generated canonical mcp-catalog bundle, digest, and manifest."
        },
        {
          "cmd": "python3 scripts/release/verify_component_manifest.py --manifest artifacts/mcp-catalog-governed-hardening/component-manifest.json --bundle artifacts/mcp-catalog-governed-hardening/source-bundle.tar.zst --expected-component mcp-catalog --check-schema schemas/release-component-manifest.schema.json --require-owned-source internal/mcp/types.go --require-owned-source internal/mcp/import.go --ownership-catalog contracts/release/source-ownership-catalog.yaml --require-all-owner-sources-accounted",
          "exit_code": 0,
          "summary": "Schema, bundle, and source-ownership verification passed."
        }
      ],
      "metrics": {
        "statement_coverage_percent": 90.2,
        "required_hardening_regression_test_count": 8,
        "caller_authored_definition_identity_accept_count": 0,
        "inline_secret_value_accept_count": 0,
        "unknown_outcome_promoted_to_success_count": 0,
        "materialization_binding_or_payload_mismatch_accept_count": 0,
        "declared_artifact_count": 4
      },
      "metric_scope": "Zero acceptance counts describe only the supplied negative regression fixtures that ran successfully. They do not prove universal rejection or production behavior; blockers explain the unproven secret/governance/persistence/runtime invariants.",
      "artifacts": [
        "artifacts/mcp-catalog-governed-hardening/coverage.out",
        "artifacts/mcp-catalog-governed-hardening/source-bundle.tar.zst",
        "artifacts/mcp-catalog-governed-hardening/bundle-digest.txt",
        "artifacts/mcp-catalog-governed-hardening/component-manifest.json"
      ],
      "source_revision": "13da87159867368a30634d04cf45500894d91f98",
      "bundle_sha256": "a4a61efb6bfb19a1bf9853f750373b947c869582f72ccac823985031fa5fca57"
    }
  ],
  "commands": [
    {
      "cmd": "mkdir -p artifacts/mcp-catalog-governed-hardening && go test -covermode=atomic -coverprofile=artifacts/mcp-catalog-governed-hardening/coverage.out ./internal/mcp/...",
      "exit_code": 0,
      "summary": "Package suite passed; 90.2% statement coverage."
    },
    {
      "cmd": "go test ./internal/mcp/... -run '^(TestGovernedMCPUseCaseSystemOwnsIdentityAndDigest|TestGovernedMCPUseCaseRejectsInlineSecretValues|TestGovernedMCPUseCaseDurableCreateReplaySurvivesRestart|TestGovernedMCPUseCaseDurableProbeReplaySurvivesRestart|TestGovernedMCPUseCaseDurableMaterializationReplaySurvivesRestart|TestGovernedMCPUseCasePreservesUnknownCommitOutcome|TestGovernedMCPUseCaseUsesCanonicalGovernanceLineage|TestGovernedMCPUseCaseValidatesExactMaterializationProof)$' -count=1",
      "exit_code": 0,
      "summary": "All eight named regressions passed."
    },
    {
      "cmd": "python3 -c \"from pathlib import Path; import re,subprocess; p=Path('artifacts/mcp-catalog-governed-hardening/coverage.out'); assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True); m=re.search(r'^total:\\s+\\(statements\\)\\s+([0-9.]+)%$',out,re.M); assert m and float(m.group(1)) >= 90\"",
      "exit_code": 0,
      "summary": "Coverage threshold assertion passed at 90.2%."
    },
    {
      "cmd": "python3 scripts/release/package_component.py --component mcp-catalog --kind platform-core-dependency-source --input internal/mcp --bundle artifacts/mcp-catalog-governed-hardening/source-bundle.tar.zst --component-manifest artifacts/mcp-catalog-governed-hardening/component-manifest.json --digest-output artifacts/mcp-catalog-governed-hardening/bundle-digest.txt --ownership-baseline contracts/release/source-ownership-baseline.yaml --owner mcp-catalog --require-all-owner-sources-accounted",
      "exit_code": 0,
      "summary": "Generated canonical mcp-catalog bundle, digest, and manifest."
    },
    {
      "cmd": "python3 scripts/release/verify_component_manifest.py --manifest artifacts/mcp-catalog-governed-hardening/component-manifest.json --bundle artifacts/mcp-catalog-governed-hardening/source-bundle.tar.zst --expected-component mcp-catalog --check-schema schemas/release-component-manifest.schema.json --require-owned-source internal/mcp/types.go --require-owned-source internal/mcp/import.go --ownership-catalog contracts/release/source-ownership-catalog.yaml --require-all-owner-sources-accounted",
      "exit_code": 0,
      "summary": "Schema, bundle, and source-ownership verification passed."
    }
  ],
  "blockers": [
    {
      "root_cause_key": "mcp-inline-secret-heuristic-classification",
      "obligation_id": "dimension:execution",
      "classification": "new",
      "severity": "high",
      "summary": "Inline Header and Environment values are still classified by heuristics, not an authoritative binding-only boundary.",
      "impact": "Caller-provided values that do not trigger the name/value heuristic are retained in definitions, configuration digests, launch payloads, and durable records. The hardening does not establish the required zero inline-secret acceptance invariant.",
      "evidence": "internal/mcp/types.go:439-447 and :471-480 accept values whenever isSensitiveName and looksLikeSecretValue are false; internal/mcp/import.go:197-220 copies those values into the candidate. internal/mcp/import.go:309-328 is a marker/prefix/length detector, not authoritative non-secret classification. The declared negative regression at internal/mcp/governed_test.go:93-111 exercises only one heuristic-positive value. api-mcp-amendment-decision.md:9 explicitly rejects heuristic secret bypasses and requires approved CredentialBinding handling. This is static evidence; no additional bypass experiment was constructed.",
      "required_fix": "Replace caller-value heuristic classification with the approved authoritative binding-only flow for Header/Environment material. If the product retains non-sensitive literals, their admissibility must be determined by a system-owned constrained schema, not by caller assertions or absence of secret markers. Apply the same rule to import, create, update, persisted validation, and materialization, and extend the declared regressions accordingly."
    },
    {
      "root_cause_key": "mcp-hardening-disconnected-canonical-owners",
      "obligation_id": "dimension:structure",
      "classification": "new",
      "severity": "high",
      "summary": "Durable persistence and runtime consumption are delivered only as interfaces and test implementations.",
      "impact": "The delivery proves application behavior against a private JSON fixture, not restart-safe canonical persistence or actual runtime consumption. No production implementation can instantiate the new governed path at this head using the delivered ports.",
      "evidence": "internal/mcp/governed.go:258-267 declares MCPStore; :320-333 declares/injects runtime and governance ports. Repository-wide symbol/implementation searches find ReserveCommand and CommitCommand(MCPCommandCommit) implementations only in internal/mcp/governed_test.go:650-730, and the new runtime signature only in the same test file at :555-578. GovernedMCPUseCase has no non-test composition site. The restart tests reopen testMCPStore JSON at :624-634; testMCPRuntime calculates a launch and manufactures a ready proof at :573-578 without consuming it. All seven changed files are under internal/mcp. The contract calls for durable command reservation/replay and exact authoritative runtime materialization, not just a port declaration.",
      "required_fix": "Implement and exercise adapters into the existing canonical Platform Core transaction/persistence owner and Runtime/AgentRun owner, with production-capable component composition. Prove atomic definition/command/audit persistence, durable restart/replay, unknown reservation retention, and proof emitted by actual launch consumption. Keep these adapters on the canonical authorities; do not add an MCP-local persistence store, runtime, or audit ledger, and do not change public HTTP/OpenAPI DTOs."
    },
    {
      "root_cause_key": "mcp-governance-audit-projection-used-as-decision",
      "obligation_id": "dimension:ownership",
      "classification": "new",
      "severity": "high",
      "summary": "Authorization and Admission ports return audit projections instead of exact canonical decisions.",
      "impact": "The use case cannot verify that an allow/admit result belongs to the evaluated request or retain/enforce the canonical decision obligations, constraints, required checks, and freshness. A syntactically populated audit control is accepted as authority.",
      "evidence": "internal/mcp/governed.go:73-79 returns audit.EvaluatedControl for both decisions; :865-907 validates only that projection. audit.EvaluatedControl and its provenance at contracts/governance/audit/contract.go:78-158 have no request digest or evaluation time. In contrast, contracts/governance/authz/contract.go:185-232 defines AuthorizationDecision with request digest, policy provenance, paired matched grants, obligations, and evaluated time; contracts/governance/admission/contract.go:471-553 defines ExecutionAdmissionDecision with request digest, required check keys, temporal validation, and constraints. The MCP tests return fixed controls at internal/mcp/governed_test.go:409-430 and do not exercise canonical decisions. docs/design/detailed/09-governance-and-security-detailed-design.md:296 and :367-402 prohibit cross-request reuse and require the exact decisions in the persistence boundary.",
      "required_fix": "Consume the existing typed AuthorizationDecision and ExecutionAdmissionDecision contracts through canonical owner adapters. Verify exact request-digest linkage, retain full decision lineage, and propagate/enforce any tightening obligations and constraints before connector/runtime execution. Derive audit EvaluatedControl only after validating authoritative decisions; persist the decisions and audit links through the canonical transaction owner."
    },
    {
      "root_cause_key": "mcp-audit-request-id-context-id-conflation",
      "obligation_id": "dimension:evidence",
      "classification": "new",
      "severity": "medium",
      "summary": "Audit validation incorrectly equates external request_id with persisted request_context_id.",
      "impact": "A canonical audit event carrying a distinct persisted RequestContext identity is rejected. Events built to satisfy the current check instead lose the canonical persisted context linkage required by Audit Explorer.",
      "evidence": "internal/mcp/governed.go:928 requires event.RequestContextID == command.RequestContext.RequestID. internal/mcp/governed_test.go:446 fabricates the event using the same equality. contracts/identity/requestcontext/request_context.go:37 exposes external RequestID; docs/references/governance/security-and-enterprise.md:305-317 expressly distinguishes persisted request_context_id and external request_id and requires authority-issued store binding.",
      "required_fix": "Carry the canonical persisted RequestContext identity/receipt from the existing governance persistence boundary separately from the external request ID. Validate audit attribution against that canonical identity and preserve both identities in their intended fields. Update the declared lineage regression to use distinct request and persisted context IDs."
    }
  ],
  "nits": [],
  "evidence_boundary": "No additional exploit/bypass, network-target probe, or security experiment was constructed. Findings beyond the declared negative tests are from static code/contract and implementation-usage inspection; no sensitive payloads or raw sensitive logs are reproduced."
}


### omac-review-ledger-82ea8c08452f.yaml

schema: omac.review-ledger/v2
cycles:
- round: 1
  subject_digest: 35ca65598134682065e2f07235305bdf231d887ea0dc046ca280aa22b007fe73
  report_digest: d3a4231824f50dbdeb4b24fca5588caa2f228113f71b1c34ec59392844308f2e
  verdict: reject
  obligation_results:
    dimension:authority: pass
    dimension:structure: fail
    dimension:execution: fail
    dimension:ownership: fail
    dimension:evidence: fail
    dimension:regression: pass
    integration:mcp-catalog-governed-hardening-gate: pass
  new_count: 4
  fixed_count: 0
  regressed_count: 0
  unchanged_count: 0
  open_count: 4
  prior_open_blocker_ids: []
  open_blocker_ids: &id001
  - BLK-41716b28a81a
  - BLK-5bc1614d11c7
  - BLK-c17700bf1f0d
  - BLK-dd6dac26dc8c
  reported_blocker_ids: *id001
  blocker_facts_schema: omac.review-cycle-blocker-facts/v1
  blocker_facts:
  - blocker_id: BLK-41716b28a81a
    root_cause_key: mcp-governance-audit-projection-used-as-decision
    obligation_id: dimension:ownership
    summary: Authorization and Admission ports return audit projections instead of
      exact canonical decisions.
    evidence: internal/mcp/governed.go:73-79 returns audit.EvaluatedControl for both
      decisions; :865-907 validates only that projection. audit.EvaluatedControl and
      its provenance at contracts/governance/audit/contract.go:78-158 have no request
      digest or evaluation time. In contrast, contracts/governance/authz/contract.go:185-232
      defines AuthorizationDecision with request digest, policy provenance, paired
      matched grants, obligations, and evaluated time; contracts/governance/admission/contract.go:471-553
      defines ExecutionAdmissionDecision with request digest, required check keys,
      temporal validation, and constraints. The MCP tests return fixed controls at
      internal/mcp/governed_test.go:409-430 and do not exercise canonical decisions.
      docs/design/detailed/09-governance-and-security-detailed-design.md:296 and :367-402
      prohibit cross-request reuse and require the exact decisions in the persistence
      boundary.
    required_fix: Consume the existing typed AuthorizationDecision and ExecutionAdmissionDecision
      contracts through canonical owner adapters. Verify exact request-digest linkage,
      retain full decision lineage, and propagate/enforce any tightening obligations
      and constraints before connector/runtime execution. Derive audit EvaluatedControl
      only after validating authoritative decisions; persist the decisions and audit
      links through the canonical transaction owner.
    status: open
    classification: new
  - blocker_id: BLK-5bc1614d11c7
    root_cause_key: mcp-hardening-disconnected-canonical-owners
    obligation_id: dimension:structure
    summary: Durable persistence and runtime consumption are delivered only as interfaces
      and test implementations.
    evidence: internal/mcp/governed.go:258-267 declares MCPStore; :320-333 declares/injects
      runtime and governance ports. Repository-wide symbol/implementation searches
      find ReserveCommand and CommitCommand(MCPCommandCommit) implementations only
      in internal/mcp/governed_test.go:650-730, and the new runtime signature only
      in the same test file at :555-578. GovernedMCPUseCase has no non-test composition
      site. The restart tests reopen testMCPStore JSON at :624-634; testMCPRuntime
      calculates a launch and manufactures a ready proof at :573-578 without consuming
      it. All seven changed files are under internal/mcp. The contract calls for durable
      command reservation/replay and exact authoritative runtime materialization,
      not just a port declaration.
    required_fix: Implement and exercise adapters into the existing canonical Platform
      Core transaction/persistence owner and Runtime/AgentRun owner, with production-capable
      component composition. Prove atomic definition/command/audit persistence, durable
      restart/replay, unknown reservation retention, and proof emitted by actual launch
      consumption. Keep these adapters on the canonical authorities; do not add an
      MCP-local persistence store, runtime, or audit ledger, and do not change public
      HTTP/OpenAPI DTOs.
    status: open
    classification: new
  - blocker_id: BLK-c17700bf1f0d
    root_cause_key: mcp-inline-secret-heuristic-classification
    obligation_id: dimension:execution
    summary: Inline Header and Environment values are still classified by heuristics,
      not an authoritative binding-only boundary.
    evidence: internal/mcp/types.go:439-447 and :471-480 accept values whenever isSensitiveName
      and looksLikeSecretValue are false; internal/mcp/import.go:197-220 copies those
      values into the candidate. internal/mcp/import.go:309-328 is a marker/prefix/length
      detector, not authoritative non-secret classification. The declared negative
      regression at internal/mcp/governed_test.go:93-111 exercises only one heuristic-positive
      value. api-mcp-amendment-decision.md:9 explicitly rejects heuristic secret bypasses
      and requires approved CredentialBinding handling. This is static evidence; no
      additional bypass experiment was constructed.
    required_fix: Replace caller-value heuristic classification with the approved
      authoritative binding-only flow for Header/Environment material. If the product
      retains non-sensitive literals, their admissibility must be determined by a
      system-owned constrained schema, not by caller assertions or absence of secret
      markers. Apply the same rule to import, create, update, persisted validation,
      and materialization, and extend the declared regressions accordingly.
    status: open
    classification: new
  - blocker_id: BLK-dd6dac26dc8c
    root_cause_key: mcp-audit-request-id-context-id-conflation
    obligation_id: dimension:evidence
    summary: Audit validation incorrectly equates external request_id with persisted
      request_context_id.
    evidence: internal/mcp/governed.go:928 requires event.RequestContextID == command.RequestContext.RequestID.
      internal/mcp/governed_test.go:446 fabricates the event using the same equality.
      contracts/identity/requestcontext/request_context.go:37 exposes external RequestID;
      docs/references/governance/security-and-enterprise.md:305-317 expressly distinguishes
      persisted request_context_id and external request_id and requires authority-issued
      store binding.
    required_fix: Carry the canonical persisted RequestContext identity/receipt from
      the existing governance persistence boundary separately from the external request
      ID. Validate audit attribution against that canonical identity and preserve
      both identities in their intended fields. Update the declared lineage regression
      to use distinct request and persisted context IDs.
    status: open
    classification: new
blockers:
- blocker_id: BLK-41716b28a81a
  root_cause_key: mcp-governance-audit-projection-used-as-decision
  obligation_id: dimension:ownership
  summary: Authorization and Admission ports return audit projections instead of exact
    canonical decisions.
  evidence: internal/mcp/governed.go:73-79 returns audit.EvaluatedControl for both
    decisions; :865-907 validates only that projection. audit.EvaluatedControl and
    its provenance at contracts/governance/audit/contract.go:78-158 have no request
    digest or evaluation time. In contrast, contracts/governance/authz/contract.go:185-232
    defines AuthorizationDecision with request digest, policy provenance, paired matched
    grants, obligations, and evaluated time; contracts/governance/admission/contract.go:471-553
    defines ExecutionAdmissionDecision with request digest, required check keys, temporal
    validation, and constraints. The MCP tests return fixed controls at internal/mcp/governed_test.go:409-430
    and do not exercise canonical decisions. docs/design/detailed/09-governance-and-security-detailed-design.md:296
    and :367-402 prohibit cross-request reuse and require the exact decisions in the
    persistence boundary.
  required_fix: Consume the existing typed AuthorizationDecision and ExecutionAdmissionDecision
    contracts through canonical owner adapters. Verify exact request-digest linkage,
    retain full decision lineage, and propagate/enforce any tightening obligations
    and constraints before connector/runtime execution. Derive audit EvaluatedControl
    only after validating authoritative decisions; persist the decisions and audit
    links through the canonical transaction owner.
  status: open
  classification: new
  first_seen_round: 1
  last_seen_round: 1
  seen_count: 1
- blocker_id: BLK-5bc1614d11c7
  root_cause_key: mcp-hardening-disconnected-canonical-owners
  obligation_id: dimension:structure
  summary: Durable persistence and runtime consumption are delivered only as interfaces
    and test implementations.
  evidence: internal/mcp/governed.go:258-267 declares MCPStore; :320-333 declares/injects
    runtime and governance ports. Repository-wide symbol/implementation searches find
    ReserveCommand and CommitCommand(MCPCommandCommit) implementations only in internal/mcp/governed_test.go:650-730,
    and the new runtime signature only in the same test file at :555-578. GovernedMCPUseCase
    has no non-test composition site. The restart tests reopen testMCPStore JSON at
    :624-634; testMCPRuntime calculates a launch and manufactures a ready proof at
    :573-578 without consuming it. All seven changed files are under internal/mcp.
    The contract calls for durable command reservation/replay and exact authoritative
    runtime materialization, not just a port declaration.
  required_fix: Implement and exercise adapters into the existing canonical Platform
    Core transaction/persistence owner and Runtime/AgentRun owner, with production-capable
    component composition. Prove atomic definition/command/audit persistence, durable
    restart/replay, unknown reservation retention, and proof emitted by actual launch
    consumption. Keep these adapters on the canonical authorities; do not add an MCP-local
    persistence store, runtime, or audit ledger, and do not change public HTTP/OpenAPI
    DTOs.
  status: open
  classification: new
  first_seen_round: 1
  last_seen_round: 1
  seen_count: 1
- blocker_id: BLK-c17700bf1f0d
  root_cause_key: mcp-inline-secret-heuristic-classification
  obligation_id: dimension:execution
  summary: Inline Header and Environment values are still classified by heuristics,
    not an authoritative binding-only boundary.
  evidence: internal/mcp/types.go:439-447 and :471-480 accept values whenever isSensitiveName
    and looksLikeSecretValue are false; internal/mcp/import.go:197-220 copies those
    values into the candidate. internal/mcp/import.go:309-328 is a marker/prefix/length
    detector, not authoritative non-secret classification. The declared negative regression
    at internal/mcp/governed_test.go:93-111 exercises only one heuristic-positive
    value. api-mcp-amendment-decision.md:9 explicitly rejects heuristic secret bypasses
    and requires approved CredentialBinding handling. This is static evidence; no
    additional bypass experiment was constructed.
  required_fix: Replace caller-value heuristic classification with the approved authoritative
    binding-only flow for Header/Environment material. If the product retains non-sensitive
    literals, their admissibility must be determined by a system-owned constrained
    schema, not by caller assertions or absence of secret markers. Apply the same
    rule to import, create, update, persisted validation, and materialization, and
    extend the declared regressions accordingly.
  status: open
  classification: new
  first_seen_round: 1
  last_seen_round: 1
  seen_count: 1
- blocker_id: BLK-dd6dac26dc8c
  root_cause_key: mcp-audit-request-id-context-id-conflation
  obligation_id: dimension:evidence
  summary: Audit validation incorrectly equates external request_id with persisted
    request_context_id.
  evidence: internal/mcp/governed.go:928 requires event.RequestContextID == command.RequestContext.RequestID.
    internal/mcp/governed_test.go:446 fabricates the event using the same equality.
    contracts/identity/requestcontext/request_context.go:37 exposes external RequestID;
    docs/references/governance/security-and-enterprise.md:305-317 expressly distinguishes
    persisted request_context_id and external request_id and requires authority-issued
    store binding.
  required_fix: Carry the canonical persisted RequestContext identity/receipt from
    the existing governance persistence boundary separately from the external request
    ID. Validate audit attribution against that canonical identity and preserve both
    identities in their intended fields. Update the declared lineage regression to
    use distinct request and persisted context IDs.
  status: open
  classification: new
  first_seen_round: 1
  last_seen_round: 1
  seen_count: 1


## Current full Source file proof

{
  "at": "2026-10-06T03:35:00.947225+00:00",
  "head": "0dae29d869278750a051cf91272f577639c59b4b",
  "authenticated_remote_MAIN": "0dae29d869278750a051cf91272f577639c59b4b",
  "all_live_public_bytes_Git_exact": true,
  "files": [
    {
      "source_path": "AGENTS.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/AGENTS.md",
      "bytes": 18404,
      "sha256": "2d4ee15006894589233d50c4e057a9d8012fa2fc8048323218deb55cb17715ef",
      "git_blob": "c8ee86693f46b067b42c6e3a99a93b7a52189dbc"
    },
    {
      "source_path": "account-locale-ownership-decision.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/account-locale-ownership-decision.md",
      "bytes": 4959,
      "sha256": "2ee85c6551db299f14f4903e5b0086e678208b38c6a3cba276c8a32a5f1a5be6",
      "git_blob": "8f2928080928118f64eab51bad614e990e356362"
    },
    {
      "source_path": "api-mcp-amendment-decision.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/api-mcp-amendment-decision.md",
      "bytes": 2692,
      "sha256": "5ccf20286a6c38190654844711db13700dfa649de264df7460ad3d91a41752d2",
      "git_blob": "7bf541cd91ce5ee0f6fb7e1acaeceac347ab0de1"
    },
    {
      "source_path": "b-class-structural-decomposition-decisions.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/b-class-structural-decomposition-decisions.md",
      "bytes": 3868,
      "sha256": "bee2866be23e0d5fe6f77a245f7f3177522308d5bd3ebbd14fb2baf0d9e37f19",
      "git_blob": "5f9706cd2dbba86c44af756bb7ba3d1b2a8300fc"
    },
    {
      "source_path": "contracts/agent/contract.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/agent/contract.go",
      "bytes": 23353,
      "sha256": "113ec2a59de11bb8b95e1c683bd4c0a0b91800539f6900010f2556022a92f1a9",
      "git_blob": "5ab24e1b1760be479c90b2b37ad0f6306875e462"
    },
    {
      "source_path": "contracts/agent/contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/agent/contract_test.go",
      "bytes": 27409,
      "sha256": "425551e6e038077213de196d015c372f8e3327065ff5f483d0e26bb44d5bf808",
      "git_blob": "e090b7b054d5631c3395a646f7c463a4060d52cb"
    },
    {
      "source_path": "contracts/governance/admission/contract.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/admission/contract.go",
      "bytes": 19871,
      "sha256": "2645fb0cc36ef5dd1ec210ab0af3031f1ba17ee5ec0aa4f17530f3ae0f756926",
      "git_blob": "e203d330afcb6a34bf7aa50eb259ff50f63070bc"
    },
    {
      "source_path": "contracts/governance/admission/contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/admission/contract_test.go",
      "bytes": 17067,
      "sha256": "115d5019f5279696db440b799ce0960477b4058c9cf426ad6f798a72cc07baed",
      "git_blob": "0ee229bf099e43bc9adc5aedc57b5cfa29c46563"
    },
    {
      "source_path": "contracts/governance/audit/audit.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/audit.go",
      "bytes": 96,
      "sha256": "0b6e29778ecafd32b29d492239f752ec6cd987a5cd9062f37caa3d845da75535",
      "git_blob": "515796070a9f41302e0bacac4b6a5288e65e9a3e"
    },
    {
      "source_path": "contracts/governance/audit/contract.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/contract.go",
      "bytes": 104939,
      "sha256": "bc1777f387b8908a1173cf2e0238af9f41542016f9bd426a0126fca0916ce174",
      "git_blob": "7f987ad3264f83749976320715d02efbf8703584"
    },
    {
      "source_path": "contracts/governance/audit/contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/contract_test.go",
      "bytes": 9994,
      "sha256": "d9e6098143081a92dee4ea6a083c38cd35a2b4ea1be3bc1f1de1751f2cf8e50f",
      "git_blob": "1894a655015248a13f625924e5004bb94839709f"
    },
    {
      "source_path": "contracts/governance/audit/control_outcome_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/control_outcome_test.go",
      "bytes": 1305,
      "sha256": "f58c8a20b7b6f853ee9ad5b97356e0e9aa159ab68a9cdedf365c1b074b0f1ed1",
      "git_blob": "37acd1586dc7b1e9331ddd667b4a553a17e6b189"
    },
    {
      "source_path": "contracts/governance/audit/coverage_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/coverage_test.go",
      "bytes": 34808,
      "sha256": "910e76aa948c6f4e49f123931a87bc6ae6baa98fd0d046e117c78ab0d49ca661",
      "git_blob": "3d96420f4030a2940208bc69a578ae7501e07f3a"
    },
    {
      "source_path": "contracts/governance/audit/export_contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/export_contract_test.go",
      "bytes": 4146,
      "sha256": "8a535023b744db03dc432c1ea4305de2fcdf53a5efc7dedb354763d8c0c7a55d",
      "git_blob": "80dba40a87b78691344ea93ab0844c749689c9c3"
    },
    {
      "source_path": "contracts/governance/audit/internal/auditstore/receipt.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/internal/auditstore/receipt.go",
      "bytes": 1624,
      "sha256": "014341f915069a58822febd009e110a62a9b1ede2bbdfe8916f6c46849b51775",
      "git_blob": "85ea7352a27f1f3825d63b1f6fd8a73c4965ee14"
    },
    {
      "source_path": "contracts/governance/audit/internal/auditstore/receipt_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/internal/auditstore/receipt_test.go",
      "bytes": 995,
      "sha256": "287d03ad1c4bb51324d9d3809d3e4a2462f8f0dad0d8c1c47131b1920ba0fd99",
      "git_blob": "8f73032804111e6a05e252cadfdb57b6088373da"
    },
    {
      "source_path": "contracts/governance/audit/internal/store/store_boundary_external_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/internal/store/store_boundary_external_test.go",
      "bytes": 5763,
      "sha256": "4b115509b54f8dc78d400321f10bbbf6e4a6601418ee88647e71121f82592bbd",
      "git_blob": "979bf456879a3ea36e8e00613007ba8ecca94620"
    },
    {
      "source_path": "contracts/governance/audit/new_review_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/new_review_test.go",
      "bytes": 42882,
      "sha256": "fd80f2c17d324df0320ec0e98ea4a7a25d56a33efc2efbb125ff9ac6d57c61bb",
      "git_blob": "f8cb1f2322cac580b59ca7cef05531912a463330"
    },
    {
      "source_path": "contracts/governance/audit/review_contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/review_contract_test.go",
      "bytes": 27040,
      "sha256": "1a6394935c5e5787a43256e5312a9b1b41420c77b8b1b0b999fe5e899a4ef61a",
      "git_blob": "45f611f0498380a9c86b6ee8c7d79da9b16cfc75"
    },
    {
      "source_path": "contracts/governance/audit/review_regression_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/review_regression_test.go",
      "bytes": 36809,
      "sha256": "9d42bf64fcdbf6e1267cde51be60f2db1f860689b0ff88bdce98239d356b54b8",
      "git_blob": "1f165a84c1d0680fa8bfc1e809d8be3ae77b4041"
    },
    {
      "source_path": "contracts/governance/audit/store_boundary_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/store_boundary_test.go",
      "bytes": 1746,
      "sha256": "aed783625b6e3692b9263ba20faf6aa83c44f4d7e97aa9882b395d412cd7c156",
      "git_blob": "b1d8174d2797eed8ae8e1250976b0b13c2069081"
    },
    {
      "source_path": "contracts/governance/audit/wire_contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/audit/wire_contract_test.go",
      "bytes": 8888,
      "sha256": "d7fbeb37d42b99141a71304294a90cb5e5f9919218a5d3a555faa9d0fb69f66d",
      "git_blob": "893167cf9fe98999b16db609acc2b2070eefc1b7"
    },
    {
      "source_path": "contracts/governance/authz/contract.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/authz/contract.go",
      "bytes": 8630,
      "sha256": "ea144e4ee917672eb49051ccebbcc812b4c150c78f2bfc0d4bd29a58da3ccd4c",
      "git_blob": "89ae9700a53ca4573db9e66d0ef69a935b0df609"
    },
    {
      "source_path": "contracts/governance/authz/contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/authz/contract_test.go",
      "bytes": 10405,
      "sha256": "74a2ec5b1fb10b9fffd689991f8184cdfbbf29777d08e0400fad9e7eafce9cd9",
      "git_blob": "c302738756f5e98796d4fb55f791d2a2585c6788"
    },
    {
      "source_path": "contracts/governance/credential/doc.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/credential/doc.go",
      "bytes": 310,
      "sha256": "aa54a50ecf02a7c9a8d74ed65f60def5db9cbfe060b51eeda0c173ad1ea1a68e",
      "git_blob": "bfe75ae29de5dc132b102f381f3c497efd7df4e9"
    },
    {
      "source_path": "contracts/governance/credential/exported_surface_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/credential/exported_surface_test.go",
      "bytes": 1926,
      "sha256": "0f92e61f590987d8f605e35a271ab875c938681501e7a32bb2e9c0faa935d5bf",
      "git_blob": "3abbb397d9631003cdd124b493124b2993e3e055"
    },
    {
      "source_path": "contracts/governance/credential/wire.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/credential/wire.go",
      "bytes": 26657,
      "sha256": "dbc02ed64ceea60923248ad73f7254b7573b1909f0354f599a0fd9e1e9417c5c",
      "git_blob": "453b5e5f4d11a13c1a95d9abf8ec320248565899"
    },
    {
      "source_path": "contracts/governance/credential/wire_contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/credential/wire_contract_test.go",
      "bytes": 12855,
      "sha256": "660b101622ed7e373f1b4cf03110459fd5e7f12854e488e4d5ef9dcd5d17a9f5",
      "git_blob": "462ce7fa061631898f46d755593bd242bdd00878"
    },
    {
      "source_path": "contracts/governance/credential/wire_validation_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/credential/wire_validation_test.go",
      "bytes": 19164,
      "sha256": "bf058da4742df4a781c8fee1fb0fa2849a3b17728b874152dcea78afd3b726c5",
      "git_blob": "728405491210a18574201529f203e8e4d1fdd091"
    },
    {
      "source_path": "contracts/governance/usage/contract.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/usage/contract.go",
      "bytes": 113877,
      "sha256": "0d5668d43c2adf94af54a7dba4d9a27a3d6ccf033b384577c047c948f869c7a7",
      "git_blob": "5ccdb34de4df774f559dba4858207784617a1da0"
    },
    {
      "source_path": "contracts/governance/usage/contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/usage/contract_test.go",
      "bytes": 13608,
      "sha256": "9378aadd5a9267911b973d6b329a4102642b919bb0f9414b35b84671cd9d99b3",
      "git_blob": "3395e7fc5b68a26cf106b59618c2be9f58ce3d45"
    },
    {
      "source_path": "contracts/governance/usage/coverage_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/usage/coverage_test.go",
      "bytes": 29087,
      "sha256": "1f617a61b2d54243bca5a365468ee48b7c743ce89f573c0dba240d2b3c182094",
      "git_blob": "494b6f8aca4dcb8328aecba1c009557826226a50"
    },
    {
      "source_path": "contracts/governance/usage/new_review_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/usage/new_review_test.go",
      "bytes": 45880,
      "sha256": "21aa0438ebac64b8009d7d5104c5226dcd3a76a5c98ab3f35c9ec54a098cac9d",
      "git_blob": "10e479b9fbfa6814136dd8fd2a0384e8474c7688"
    },
    {
      "source_path": "contracts/governance/usage/review_contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/usage/review_contract_test.go",
      "bytes": 23703,
      "sha256": "5eb3245ac6f245808d2bdd101dc87456899b25cc5605cbed4a9c128803d57fea",
      "git_blob": "3daf55f74b514886c88c47951d722deb2627f382"
    },
    {
      "source_path": "contracts/governance/usage/review_regression_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/usage/review_regression_test.go",
      "bytes": 22306,
      "sha256": "1b2d6065eee839feb3381dd77df96740913b2b2048a319ce667dc94883c0dc92",
      "git_blob": "886e8fc693fd25a58fd6e115b9c1deba8a77310f"
    },
    {
      "source_path": "contracts/governance/usage/wire_contract_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/governance/usage/wire_contract_test.go",
      "bytes": 9700,
      "sha256": "b45f2a21ed67cb3440dadce6ac15d7b6ef165528e0fea4b0811b29a3ebffd4b2",
      "git_blob": "3b58649361bbdf310d2c1d0f73198d995b6dfb8b"
    },
    {
      "source_path": "contracts/project/canonical.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/project/canonical.go",
      "bytes": 7213,
      "sha256": "2acd4963293a42b564f1f9f52b49d40f05c8c4a8f55e4f38a1a99f1916b5d5ec",
      "git_blob": "061af9b340681494492b3c6186eb99c8df062e58"
    },
    {
      "source_path": "contracts/project/contracts_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/project/contracts_test.go",
      "bytes": 8404,
      "sha256": "b734aa52d6e66df4862c1284576a2cf800aac1950840aa4d706ca80d771b9b83",
      "git_blob": "ee18671b73d43c25a6bdb7d125b47cc5807da8db"
    },
    {
      "source_path": "contracts/project/convergence_regression_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/project/convergence_regression_test.go",
      "bytes": 37211,
      "sha256": "903c6ad6f47dffc9332e5b7be2796a1a08f213ad51ae3a3004a9d0448420b420",
      "git_blob": "f5e7e1dc71df060ce4a7d8da5cf7ee6beb4ea754"
    },
    {
      "source_path": "contracts/project/review_regression_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/project/review_regression_test.go",
      "bytes": 14021,
      "sha256": "cd6fd5b15a095f6d332a0cebe3dac1328c69b1605d0be7c0daec03ee3d83c08b",
      "git_blob": "330158141a3d873adb27a9187750d5dd660eaf33"
    },
    {
      "source_path": "contracts/project/types.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/project/types.go",
      "bytes": 16572,
      "sha256": "0bf0a702ffbd68e04a29393b3728551aef18dcf04c5704d465d9f4d267038053",
      "git_blob": "1044e2211a88f3ff0a1f60b14cd7259fa9d8e12f"
    },
    {
      "source_path": "contracts/project/validation.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/project/validation.go",
      "bytes": 50180,
      "sha256": "0d66039f6e2bfde6a5a840c4a823506cd1bacd9c1a227eb2f2b948b64ce3cc5c",
      "git_blob": "1edb6c33a74a711d648325bf2d4deff12e59485c"
    },
    {
      "source_path": "contracts/project/validation_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/project/validation_test.go",
      "bytes": 25091,
      "sha256": "01dcacea78d868e2af1f355b66b256691887270142404c4f3a4fdf33dba83339",
      "git_blob": "4025bdf91e62423334487a03d413e3e0c4c125c7"
    },
    {
      "source_path": "contracts/release/kernel-lifecycle-additive-ownership/addition.yaml",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/release/kernel-lifecycle-additive-ownership/addition.yaml",
      "bytes": 1099,
      "sha256": "fcf95904eda9494f2bae7243fcb3a339d01c12e377ad334af567df8bd539e087",
      "git_blob": "c2a2209dc1d52ae090f23b85b409853d26cb8470"
    },
    {
      "source_path": "contracts/release/kernel-lifecycle-additive-ownership/tests/test_kernel_lifecycle_additive_ownership.py",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/release/kernel-lifecycle-additive-ownership/tests/test_kernel_lifecycle_additive_ownership.py",
      "bytes": 7503,
      "sha256": "6980c13d62cbd434684d1d2f7a790f9244f1a9c97b6e7327b937187f6dfbbe56",
      "git_blob": "15e8976dad26a0ed88eda46a373003b7c73d5cb8"
    },
    {
      "source_path": "contracts/release/kernel-lifecycle-additive-ownership/verify.py",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/release/kernel-lifecycle-additive-ownership/verify.py",
      "bytes": 17956,
      "sha256": "54599879bac0f65ca7a547f9adebb73327d030c6f2b25a68ae88fa3763aa1379",
      "git_blob": "8a8ba79b8055c12de0114d78fdfc1a606a6f2750"
    },
    {
      "source_path": "contracts/release/kernel-lifecycle-contract-ownership.yaml",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/release/kernel-lifecycle-contract-ownership.yaml",
      "bytes": 5694,
      "sha256": "a268a0fff5fb82529383856b5940395600bbd70daba211ec015766254028dfdc",
      "git_blob": "8b93737dfd421a6bd89cd6ce830a0e054b0ee20a"
    },
    {
      "source_path": "contracts/release/source-ownership-baseline.yaml",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/release/source-ownership-baseline.yaml",
      "bytes": 16822,
      "sha256": "69a6f8b5bce02e9d1b9992d6949e169121010911dd5c3781f78b9f39994b55f5",
      "git_blob": "f9f6be7d57d4ac09a89115c224a7b719fdd24ccf"
    },
    {
      "source_path": "contracts/release/source-ownership-catalog.yaml",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/release/source-ownership-catalog.yaml",
      "bytes": 18606,
      "sha256": "f7e96c861be3e8aef085da65c157c1d1d38290765df0bcc701f1d41e6fb0e820",
      "git_blob": "ddbd0921f473c656796f38b015a6e8b914472e16"
    },
    {
      "source_path": "contracts/release/system-release-tooling-ownership.yaml",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/contracts/release/system-release-tooling-ownership.yaml",
      "bytes": 2984,
      "sha256": "b26550c8bd2cc7ff0c2d884cfb2b6bee0ca453231ef328b436a13023b20bffa0",
      "git_blob": "00ca0e1a39b61ad010260ea6a6c5f87becde7133"
    },
    {
      "source_path": "docs/delivery/acceptance-and-validation.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/delivery/acceptance-and-validation.md",
      "bytes": 299769,
      "sha256": "e84705b5307724f2f8f803ee2f212e32ef144bac079013b419d16713d5edc3ac",
      "git_blob": "f8425517ab9bd6e935b078052774e1aa5f419c40"
    },
    {
      "source_path": "docs/deploy-ops/deployment-and-operations-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/deploy-ops/deployment-and-operations-design.md",
      "bytes": 32859,
      "sha256": "cea3fe1e0d1d5566e742a14cbde98a401a0d996f08f4085676beb98b2c1820c4",
      "git_blob": "006fea52e085c176efec0d08ff9ba4d5ecab0158"
    },
    {
      "source_path": "docs/design/detailed/02-project-and-agent-team-detailed-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/detailed/02-project-and-agent-team-detailed-design.md",
      "bytes": 44158,
      "sha256": "77e98399e609bb677e18c6c207767899c952daade5ed5dca226c98e984ad394b",
      "git_blob": "cc9084487c474c35b707157e1ffef5dfc938ad11"
    },
    {
      "source_path": "docs/design/detailed/03-workflow-platform-core-detailed-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/detailed/03-workflow-platform-core-detailed-design.md",
      "bytes": 70846,
      "sha256": "3b34e3dbee0e13e31a9cdb004631bac2ef1a4b8f7452ff3d87b35533742a2156",
      "git_blob": "39bcbeeefe3ccbe2231b87c70a65742788773098"
    },
    {
      "source_path": "docs/design/detailed/05-kubernetes-native-control-plane-detailed-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/detailed/05-kubernetes-native-control-plane-detailed-design.md",
      "bytes": 52824,
      "sha256": "05ef0dfbf66daf68c7ae9863701485aa40a2d24e898ea3743a33463515fac97d",
      "git_blob": "6553f3c3ff90accd5077ad403906d5bf551e6ce6"
    },
    {
      "source_path": "docs/design/detailed/06-agent-runtime-detailed-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/detailed/06-agent-runtime-detailed-design.md",
      "bytes": 49187,
      "sha256": "b186953d7cd58e239f759ed7160b904d2dccc0d265746175135843ffdd58e5e4",
      "git_blob": "7475f48ad0ee6ac99f391842142ab49303b38bc1"
    },
    {
      "source_path": "docs/design/detailed/08-component-and-extension-detailed-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/detailed/08-component-and-extension-detailed-design.md",
      "bytes": 42136,
      "sha256": "6bc50c99a5066ef613537ea14a8a99512f433405ab67afb2b09d98b187411f04",
      "git_blob": "757086c567b299ad8cb5b1c825019f1cf9551567"
    },
    {
      "source_path": "docs/design/detailed/09-governance-and-security-detailed-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/detailed/09-governance-and-security-detailed-design.md",
      "bytes": 81529,
      "sha256": "112d7a6ff48ac97d6a8779fbd27aa88beb99d1b63f8a295a39e921c559594934",
      "git_blob": "9e754983ab1b6506634db264d1704a5869ca3c8b"
    },
    {
      "source_path": "docs/design/detailed/10-web-api-cli-detailed-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/detailed/10-web-api-cli-detailed-design.md",
      "bytes": 183512,
      "sha256": "6883d10c9f09faa03c055c7a12ec53c8cbfdf223855b655b12f0df63d43c6f39",
      "git_blob": "222e95b48f08048a56c2c8c290b875309523bc89"
    },
    {
      "source_path": "docs/design/detailed/11-software-delivery-detailed-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/detailed/11-software-delivery-detailed-design.md",
      "bytes": 66620,
      "sha256": "96ab602d53ef516250f41d472f093428f8037cb9b16fbf25b4e90f2246b75e6e",
      "git_blob": "783ad6098ac39c2fc341d8aa8619295c801b8843"
    },
    {
      "source_path": "docs/design/open-agent-cluster-overview-design.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/design/open-agent-cluster-overview-design.md",
      "bytes": 102981,
      "sha256": "d0132d814dac38f21fb8dc75cefea3c110acd4dffb15784291bf59d6be45afe7",
      "git_blob": "772e68f31af3a54b476953a38725f33f4e693922"
    },
    {
      "source_path": "docs/references/cloud-native/kubernetes-resources.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/cloud-native/kubernetes-resources.md",
      "bytes": 22093,
      "sha256": "1e180ca347413c031d34fe426c14a635e753ef3db8bec6ea504e9dc964077882",
      "git_blob": "972186f8a71683b18bc028255734cbdd986d8066"
    },
    {
      "source_path": "docs/references/conventions.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/conventions.md",
      "bytes": 14658,
      "sha256": "184bda55ad6432844dbe701af63d7c4a544c360e367fbf543e67e84840482c25",
      "git_blob": "2225265bfcff83c8f36e70452ad1bc6320b988f6"
    },
    {
      "source_path": "docs/references/execution/agent-runtime.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/execution/agent-runtime.md",
      "bytes": 38015,
      "sha256": "466c54051d655d562c1afe97e6c3828546edeb6a86284634ef87c5ee95d2891d",
      "git_blob": "8a9e57f173f4b573c6942075e28174a9a202aa67"
    },
    {
      "source_path": "docs/references/extension/component-governance.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/extension/component-governance.md",
      "bytes": 25461,
      "sha256": "c05aceee0bc3d826c0719ad278f27492473a83018d174099786c272ce240f2d0",
      "git_blob": "75dba7b098668faeb94b5fc85e083ad7839afffb"
    },
    {
      "source_path": "docs/references/extension/plugin-contracts.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/extension/plugin-contracts.md",
      "bytes": 17042,
      "sha256": "fcd02305d50c12640bec7de64b25a84f3c1c6d2ca169eae81073448b5038be6b",
      "git_blob": "eb7895869e49a8a56ed2c8d5ac456c68385e1815"
    },
    {
      "source_path": "docs/references/governance/security-and-enterprise.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/governance/security-and-enterprise.md",
      "bytes": 63725,
      "sha256": "d4b310c4491e6ff0880bf7dc4512e61c20455fd0277596c34284124a98715a44",
      "git_blob": "b4cc8dba01bebf87461355eb8e03d3ec34fd0460"
    },
    {
      "source_path": "docs/references/project-and-team/project-and-agent-team.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/project-and-team/project-and-agent-team.md",
      "bytes": 45342,
      "sha256": "cb8228f14011cf36df8af2cef401b2e157f7ae10c598f7e8de42faee3e52321d",
      "git_blob": "896852486dde297cddf6e0b6e9905aa9533bc62e"
    },
    {
      "source_path": "docs/references/software-delivery/artifacts-release-and-deployment.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/software-delivery/artifacts-release-and-deployment.md",
      "bytes": 33518,
      "sha256": "af63916ce4dde95e6a6953efc4fcde7e32b4287184c6521b5920aaf193908a27",
      "git_blob": "95cab8f592dd5f7eae94a1598451cf24b1aece6a"
    },
    {
      "source_path": "docs/references/workflow/workflow-and-execution.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/docs/references/workflow/workflow-and-execution.md",
      "bytes": 36262,
      "sha256": "8c9b4fff0ad48c67d5ef61871799f2042b995aa68e92c602d902d83c2cee3f40",
      "git_blob": "6bc8b1f43829063e84b718d722ae8f7586ee7570"
    },
    {
      "source_path": "five-nodes-recovery-decisions.md",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/five-nodes-recovery-decisions.md",
      "bytes": 5913,
      "sha256": "7bd38663b73a6175947bc1343df993019b8c6570be7413620eed89f64cf1e1af",
      "git_blob": "c2fdcbfb19a54aacfb9e3d2b07fb326343e3d3e8"
    },
    {
      "source_path": "internal/admission/engine.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/admission/engine.go",
      "bytes": 8603,
      "sha256": "858a26c0bd1105beb28d50c207820b6dd7d43961498356b71d69e8e06681f0d1",
      "git_blob": "e446c44cd153ecd1f895499b4703242f1ab32a9a"
    },
    {
      "source_path": "internal/admission/engine_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/admission/engine_test.go",
      "bytes": 15347,
      "sha256": "c3b259882455d26af6b95b8bc66a17fda885a8effade8661eaf427a53222cb7e",
      "git_blob": "fa223a7b3664b1259bccb00854643af388c07d9b"
    },
    {
      "source_path": "internal/agentrun/assembly.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agentrun/assembly.go",
      "bytes": 2645,
      "sha256": "6d79a508af8ff2c32d6ce6c082ba7c4ce607aed359b837d79d09156f02af489a",
      "git_blob": "4ce359d277b430329b2729e1241abfd4d8cbc8c5"
    },
    {
      "source_path": "internal/agentrun/assembly_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agentrun/assembly_test.go",
      "bytes": 6333,
      "sha256": "266ec2aa0754bc8bb0e93970ed348f76bfb0152cd1fd46627834fbae48867258",
      "git_blob": "ab58219992596ebecedbb89f2f2b8f365e908bb8"
    },
    {
      "source_path": "internal/agentrun/runner.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agentrun/runner.go",
      "bytes": 15252,
      "sha256": "645ce0658051fed94344d1cb1ced5bbbe2f1e6449a1343be3322f5d01b5fd7d1",
      "git_blob": "15d7622e56be2f9558b7e189d93e69c2937b8077"
    },
    {
      "source_path": "internal/agentrun/runner_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agentrun/runner_test.go",
      "bytes": 23082,
      "sha256": "0475a3a9858e1b93c353752dbe2c92c012641064a002afbd0e33d66490fc65eb",
      "git_blob": "5404ad3a54c8f68a7857e90aaba65f889106566a"
    },
    {
      "source_path": "internal/agents/definitions/application_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agents/definitions/application_test.go",
      "bytes": 74386,
      "sha256": "a4472cde2d77092093831f5661c2fb9174f1ce05e2d2dcc01f8bd27b208163a4",
      "git_blob": "c1d5125f501d5ad3c6a848b5d3c798ae4e01d906"
    },
    {
      "source_path": "internal/agents/definitions/definitions.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agents/definitions/definitions.go",
      "bytes": 57636,
      "sha256": "d9ad66f15bd3351807f2ee65a95e11db7d2e4b28c6dbbcc8fc82faaf92d44090",
      "git_blob": "9860ea3268dba4eb56ef6a17842b1ec36a279ee1"
    },
    {
      "source_path": "internal/agents/modelpolicy/policy.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agents/modelpolicy/policy.go",
      "bytes": 9527,
      "sha256": "4e2a4c34612899950f670f6f20f66c1e8362813738edafb538b62a6c8cc05007",
      "git_blob": "f475fb8625425fb1ce777655b630b0eb33eb698a"
    },
    {
      "source_path": "internal/agents/modelpolicy/policy_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agents/modelpolicy/policy_test.go",
      "bytes": 18182,
      "sha256": "040db671898d854b3caa1b169bc8e8e6bf33de4f4d671998631505ae500ff849",
      "git_blob": "d3e78834d7823b3bac6af5b3c560ec206e457599"
    },
    {
      "source_path": "internal/agents/templates/templates.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agents/templates/templates.go",
      "bytes": 8090,
      "sha256": "434c4cbd0191b2345a08e2d8717cc2ff206aabfac43740a8039bed5d3f7f5080",
      "git_blob": "b3220ed28f37d21d0c9525a3341f2c9e8afa3f48"
    },
    {
      "source_path": "internal/agents/templates/templates_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/agents/templates/templates_test.go",
      "bytes": 16871,
      "sha256": "afea9d3378e5019b2fab44ccdb562d22d20fd65fda461cf6a416d1c6c379e8a5",
      "git_blob": "a0cd15301b88e7f3be91916f00984348d4faf280"
    },
    {
      "source_path": "internal/authorization/candidate.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/authorization/candidate.go",
      "bytes": 17779,
      "sha256": "f5882bff473ff5308e3aa8193e2711ceffe3cb4eba80b1817a484a3988ac4562",
      "git_blob": "a26b5f0c4c7c810c59ee92519de039241fde4b54"
    },
    {
      "source_path": "internal/authorization/catalog.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/authorization/catalog.go",
      "bytes": 3503,
      "sha256": "0d069a05a49147f2547c138dd54cca9a54fa9500111847bd28c95b1f23b237b9",
      "git_blob": "e656fff7adf0d3e9426621dcfbf0bfe630fd3082"
    },
    {
      "source_path": "internal/authorization/engine.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/authorization/engine.go",
      "bytes": 21876,
      "sha256": "c884b5704789d2eb02936f1b9260140c437c856e9bfc41b9c80f3f5a52cdf089",
      "git_blob": "daf3e8eba25b0a6e325bf6f277076ad815945747"
    },
    {
      "source_path": "internal/authorization/engine_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/authorization/engine_test.go",
      "bytes": 49807,
      "sha256": "f60467f35304707c3723459c56ce13deaaff61f26328ea465c420ceba369c341",
      "git_blob": "a09a4e2f8edb954044ef453c62c03fb3e4ae7e91"
    },
    {
      "source_path": "internal/authorization/policy.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/authorization/policy.go",
      "bytes": 7179,
      "sha256": "819b91934a01277c6069bfca9838d4c2374d3619d179f9defd7aa8ba4c042ac0",
      "git_blob": "160ae4a02756acb7624677a058a4c07386ee917c"
    },
    {
      "source_path": "internal/mcp/coverage_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/mcp/coverage_test.go",
      "bytes": 20496,
      "sha256": "bbcb15344ced1cfccd2dd9ea09cf10cba96084952135dcbf9f6a67cf2c92c2da",
      "git_blob": "b85b3e8b167d4540f17f81804b174408a0808b94"
    },
    {
      "source_path": "internal/mcp/import.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/mcp/import.go",
      "bytes": 12618,
      "sha256": "612adec4034798648f1b20a860edfce6324234d375fb8de6f6956f79d37b22d4",
      "git_blob": "8e17df695df9a793d178e33af57c599ee9f5b05d"
    },
    {
      "source_path": "internal/mcp/materialize.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/mcp/materialize.go",
      "bytes": 7885,
      "sha256": "4b02cc9017d723e5ee5870a5223434ccf0e852d081e086cd27fcb561987bb125",
      "git_blob": "58779567bf1acdd48aa7208e331939c06f206e67"
    },
    {
      "source_path": "internal/mcp/mcp_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/mcp/mcp_test.go",
      "bytes": 20336,
      "sha256": "463edf60c5bccf097babe4428f0a7a48b3b5aaf7e65434a5ac507d8dd6aabd2c",
      "git_blob": "28df1309e7cf22e3821e41095f22144599fcfaba"
    },
    {
      "source_path": "internal/mcp/probe.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/mcp/probe.go",
      "bytes": 18550,
      "sha256": "f0f3f0ff25b8381d44023c08ac377b88e67669de4988320d36bd11fb4b8dd735",
      "git_blob": "1c9c31bcb8755628648d778d373b98ceecfa2a4d"
    },
    {
      "source_path": "internal/mcp/types.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/mcp/types.go",
      "bytes": 24022,
      "sha256": "93166ed5e2e46d0feab122d5fb8e78d66b7907e66ab68917cbf6892cb98a3d6a",
      "git_blob": "75b353ffd66bb1155e309a9455ccea529bf1a258"
    },
    {
      "source_path": "internal/platformcore/agentrun/application.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/platformcore/agentrun/application.go",
      "bytes": 112260,
      "sha256": "89246c433654d1991eb2cd34c543493456feb5b5339d904f93667078c2dcc7cf",
      "git_blob": "73de4c648b1af13f3e1e6062f1dd6d73fbb43f6c"
    },
    {
      "source_path": "internal/platformcore/agentrun/application_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/platformcore/agentrun/application_test.go",
      "bytes": 104687,
      "sha256": "80a26d3b17d6838b4d049da3f42de46b589a5ffa02c69e5b1f4642d90bd9969b",
      "git_blob": "1b506acce73c50b4c1228aa3e7695bcdd599901b"
    },
    {
      "source_path": "internal/platformcore/agentrun/coverage_test.go",
      "file": "/tmp/oac-api-mcp-grouped-owner-preparation-0331-20261006/current-MAIN-Source/internal/platformcore/agentrun/coverage_test.go",
      "bytes": 66171,
      "sha256": "246c6f6a8369d486de5f8aeb1dfb6dcb894c6763d1aed0581c3941c5db7ccc65",
      "git_blob": "811204679ec8784e5989ac18d34ffbd5350e7063"
    }
  ]
}

## Full original input index proof

{
  "at": "2026-10-06T03:33:40.775772+00:00",
  "files": [
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-Store-0819.json",
      "bytes": 38047,
      "sha256": "76e200824f81123c0229cbab04af000a899999768d310c2122b44108767390b4"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-binding.json",
      "bytes": 265,
      "sha256": "92a488ee553727309e653d0f92ae00a6c9e9f9de82a783f89a32c0010bc02c5f"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/full-native-messages.json",
      "bytes": 431326,
      "sha256": "bc43eac155f33174a9740a90e8d990b68f2be789a7954da3ef56c859573097b0"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-capture.json",
      "bytes": 13295,
      "sha256": "f42316a2333a9fc9523f106c23733a9e13ffad3ff726569da92a2eaf8823654b"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/captured-manifest.yaml",
      "bytes": 2287824,
      "sha256": "7ce5920e13fab5d2fab0e27ff0e88a8d013858bb2481c63699eafcbc00b5657c"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/Root9512.json",
      "bytes": 1081,
      "sha256": "9512a6735dc4fea22961757d58bf2cceabc787186675373757fc052b72307db4"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/omac-review-ledger-3bdc754ebc7f.yaml",
      "bytes": 9124,
      "sha256": "3bdc754ebc7f580358a579a7b8e79c87d8ac25be3dab2fe23c8f4db7229d6655"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/omac-review-report-cb08fc44a86d.yaml",
      "bytes": 14987,
      "sha256": "cb08fc44a86dbf7682bb22bb58d7a1b887a86f5981ebe9f6e3095a85dcee99af"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/queued-request.md",
      "bytes": 3075,
      "sha256": "2f9e5695f59d4b3e24eb50bb9c06dd1afb4edadbd4c5252d0bffdd0b8a8d419c"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/account-locale-ownership-decision.md",
      "bytes": 4959,
      "sha256": "2ee85c6551db299f14f4903e5b0086e678208b38c6a3cba276c8a32a5f1a5be6"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/AGENTS.md",
      "bytes": 18404,
      "sha256": "2d4ee15006894589233d50c4e057a9d8012fa2fc8048323218deb55cb17715ef"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/account-locale-ownership-decision.md",
      "bytes": 4959,
      "sha256": "2ee85c6551db299f14f4903e5b0086e678208b38c6a3cba276c8a32a5f1a5be6"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/AGENTS.md",
      "bytes": 18404,
      "sha256": "2d4ee15006894589233d50c4e057a9d8012fa2fc8048323218deb55cb17715ef"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/api/openapi/agents/openapi.gen.go",
      "bytes": 22327,
      "sha256": "d451c5bfb98def64e22d37f715f89cbda6a53c767e8775e1af6a384f9c4e005a"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/api/openapi/agents/types.go",
      "bytes": 10107,
      "sha256": "9959a7de89582663a65927275996c19be0eafb98ee8ed5d456621301216902e7"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/api/openapi/agents/openapi_test.go",
      "bytes": 10810,
      "sha256": "2e26c464e1dc6851d6ed25033e8184522d18e1a59ed79a8cea116cab143a4100"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/api/openapi/agents/generated-files.txt",
      "bytes": 15,
      "sha256": "8d0ff929f7cdb2a80d1527e13c79970effa0d9026d51ef670ff96bd6e36f9776"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/api/openapi/agents/doc.go",
      "bytes": 115,
      "sha256": "0525319c2029567a67538b67897f6acccc717430e2d5e2d890d5c5092585e30e"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/api/openapi/agents/openapi.yaml",
      "bytes": 21562,
      "sha256": "68a959eac617a005e2aa45560e0bb947ca4a6bf99631993f381d1dd95be937ce"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/api/openapi/agents/generator/main.go",
      "bytes": 1026,
      "sha256": "5389866d6f13825fe924001538b538f300329377290b9865816463430d4ab0a2"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/api/openapi/agents/generator/main_test.go",
      "bytes": 1212,
      "sha256": "d47dec294f4aaf92ef5ff300c508b8159137bd53f0b2916d7402d5465637dbe6"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/open-agent-cluster-overview-design.md",
      "bytes": 102981,
      "sha256": "d0132d814dac38f21fb8dc75cefea3c110acd4dffb15784291bf59d6be45afe7"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/references/conventions.md",
      "bytes": 14658,
      "sha256": "184bda55ad6432844dbe701af63d7c4a544c360e367fbf543e67e84840482c25"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/deploy-ops/deployment-and-operations-design.md",
      "bytes": 32859,
      "sha256": "cea3fe1e0d1d5566e742a14cbde98a401a0d996f08f4085676beb98b2c1820c4"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/delivery/acceptance-and-validation.md",
      "bytes": 299769,
      "sha256": "e84705b5307724f2f8f803ee2f212e32ef144bac079013b419d16713d5edc3ac"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/references/project-and-team/project-and-agent-team.md",
      "bytes": 45342,
      "sha256": "cb8228f14011cf36df8af2cef401b2e157f7ae10c598f7e8de42faee3e52321d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/references/extension/component-governance.md",
      "bytes": 25461,
      "sha256": "c05aceee0bc3d826c0719ad278f27492473a83018d174099786c272ce240f2d0"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/references/extension/plugin-contracts.md",
      "bytes": 17042,
      "sha256": "fcd02305d50c12640bec7de64b25a84f3c1c6d2ca169eae81073448b5038be6b"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/references/software-delivery/artifacts-release-and-deployment.md",
      "bytes": 33518,
      "sha256": "af63916ce4dde95e6a6953efc4fcde7e32b4287184c6521b5920aaf193908a27"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/references/execution/agent-runtime.md",
      "bytes": 38015,
      "sha256": "466c54051d655d562c1afe97e6c3828546edeb6a86284634ef87c5ee95d2891d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/references/workflow/workflow-and-execution.md",
      "bytes": 36262,
      "sha256": "8c9b4fff0ad48c67d5ef61871799f2042b995aa68e92c602d902d83c2cee3f40"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/references/governance/security-and-enterprise.md",
      "bytes": 63725,
      "sha256": "d4b310c4491e6ff0880bf7dc4512e61c20455fd0277596c34284124a98715a44"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/detailed/09-governance-and-security-detailed-design.md",
      "bytes": 81529,
      "sha256": "112d7a6ff48ac97d6a8779fbd27aa88beb99d1b63f8a295a39e921c559594934"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/detailed/05-kubernetes-native-control-plane-detailed-design.md",
      "bytes": 52824,
      "sha256": "05ef0dfbf66daf68c7ae9863701485aa40a2d24e898ea3743a33463515fac97d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/detailed/06-agent-runtime-detailed-design.md",
      "bytes": 49187,
      "sha256": "b186953d7cd58e239f759ed7160b904d2dccc0d265746175135843ffdd58e5e4"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/detailed/03-workflow-platform-core-detailed-design.md",
      "bytes": 70846,
      "sha256": "3b34e3dbee0e13e31a9cdb004631bac2ef1a4b8f7452ff3d87b35533742a2156"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/detailed/08-component-and-extension-detailed-design.md",
      "bytes": 42136,
      "sha256": "6bc50c99a5066ef613537ea14a8a99512f433405ab67afb2b09d98b187411f04"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/detailed/02-project-and-agent-team-detailed-design.md",
      "bytes": 44158,
      "sha256": "77e98399e609bb677e18c6c207767899c952daade5ed5dca226c98e984ad394b"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/detailed/10-web-api-cli-detailed-design.md",
      "bytes": 183512,
      "sha256": "6883d10c9f09faa03c055c7a12ec53c8cbfdf223855b655b12f0df63d43c6f39"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/docs/design/detailed/11-software-delivery-detailed-design.md",
      "bytes": 66620,
      "sha256": "96ab602d53ef516250f41d472f093428f8037cb9b16fbf25b4e90f2246b75e6e"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/admission/engine_test.go",
      "bytes": 15347,
      "sha256": "c3b259882455d26af6b95b8bc66a17fda885a8effade8661eaf427a53222cb7e"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/admission/engine.go",
      "bytes": 8603,
      "sha256": "858a26c0bd1105beb28d50c207820b6dd7d43961498356b71d69e8e06681f0d1"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/httpapi/agents/handler.go",
      "bytes": 14082,
      "sha256": "e608bd8ac769c4a4c4f2ca3dbe62f2acad13e11ca4a8da455b689d3e716acabd"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/httpapi/agents/handler_test.go",
      "bytes": 28981,
      "sha256": "d290ab22c010428237e0d705ba5115960953c0db22ebd2342e2819bb3ac7fdb7"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/agents/templates/templates_test.go",
      "bytes": 16871,
      "sha256": "afea9d3378e5019b2fab44ccdb562d22d20fd65fda461cf6a416d1c6c379e8a5"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/agents/templates/templates.go",
      "bytes": 8090,
      "sha256": "434c4cbd0191b2345a08e2d8717cc2ff206aabfac43740a8039bed5d3f7f5080"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/agents/modelpolicy/policy_test.go",
      "bytes": 18182,
      "sha256": "040db671898d854b3caa1b169bc8e8e6bf33de4f4d671998631505ae500ff849"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/agents/modelpolicy/policy.go",
      "bytes": 9527,
      "sha256": "4e2a4c34612899950f670f6f20f66c1e8362813738edafb538b62a6c8cc05007"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/agents/definitions/definitions.go",
      "bytes": 57636,
      "sha256": "d9ad66f15bd3351807f2ee65a95e11db7d2e4b28c6dbbcc8fc82faaf92d44090"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/internal/agents/definitions/application_test.go",
      "bytes": 74386,
      "sha256": "a4472cde2d77092093831f5661c2fb9174f1ce05e2d2dcc01f8bd27b208163a4"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/release/source-ownership-catalog.yaml",
      "bytes": 18606,
      "sha256": "f7e96c861be3e8aef085da65c157c1d1d38290765df0bcc701f1d41e6fb0e820"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/release/source-ownership-baseline.yaml",
      "bytes": 16822,
      "sha256": "69a6f8b5bce02e9d1b9992d6949e169121010911dd5c3781f78b9f39994b55f5"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/project/types.go",
      "bytes": 16572,
      "sha256": "0bf0a702ffbd68e04a29393b3728551aef18dcf04c5704d465d9f4d267038053"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/project/convergence_regression_test.go",
      "bytes": 37211,
      "sha256": "903c6ad6f47dffc9332e5b7be2796a1a08f213ad51ae3a3004a9d0448420b420"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/project/canonical.go",
      "bytes": 7213,
      "sha256": "2acd4963293a42b564f1f9f52b49d40f05c8c4a8f55e4f38a1a99f1916b5d5ec"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/project/review_regression_test.go",
      "bytes": 14021,
      "sha256": "cd6fd5b15a095f6d332a0cebe3dac1328c69b1605d0be7c0daec03ee3d83c08b"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/project/validation.go",
      "bytes": 50180,
      "sha256": "0d66039f6e2bfde6a5a840c4a823506cd1bacd9c1a227eb2f2b948b64ce3cc5c"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/project/contracts_test.go",
      "bytes": 8404,
      "sha256": "b734aa52d6e66df4862c1284576a2cf800aac1950840aa4d706ca80d771b9b83"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/project/validation_test.go",
      "bytes": 25091,
      "sha256": "01dcacea78d868e2af1f355b66b256691887270142404c4f3a4fdf33dba83339"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/credential/exported_surface_test.go",
      "bytes": 1926,
      "sha256": "0f92e61f590987d8f605e35a271ab875c938681501e7a32bb2e9c0faa935d5bf"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/credential/wire_contract_test.go",
      "bytes": 12855,
      "sha256": "660b101622ed7e373f1b4cf03110459fd5e7f12854e488e4d5ef9dcd5d17a9f5"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/credential/wire_validation_test.go",
      "bytes": 19164,
      "sha256": "bf058da4742df4a781c8fee1fb0fa2849a3b17728b874152dcea78afd3b726c5"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/credential/doc.go",
      "bytes": 310,
      "sha256": "aa54a50ecf02a7c9a8d74ed65f60def5db9cbfe060b51eeda0c173ad1ea1a68e"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/credential/wire.go",
      "bytes": 26657,
      "sha256": "dbc02ed64ceea60923248ad73f7254b7573b1909f0354f599a0fd9e1e9417c5c"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/admission/contract_test.go",
      "bytes": 17067,
      "sha256": "115d5019f5279696db440b799ce0960477b4058c9cf426ad6f798a72cc07baed"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/admission/contract.go",
      "bytes": 19871,
      "sha256": "2645fb0cc36ef5dd1ec210ab0af3031f1ba17ee5ec0aa4f17530f3ae0f756926"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/usage/wire_contract_test.go",
      "bytes": 9700,
      "sha256": "b45f2a21ed67cb3440dadce6ac15d7b6ef165528e0fea4b0811b29a3ebffd4b2"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/usage/new_review_test.go",
      "bytes": 45880,
      "sha256": "21aa0438ebac64b8009d7d5104c5226dcd3a76a5c98ab3f35c9ec54a098cac9d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/usage/coverage_test.go",
      "bytes": 26451,
      "sha256": "a21af8018d6b0deb96d61db547bae6260a45e680b1ee56147d435539312faad3"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/usage/review_regression_test.go",
      "bytes": 22306,
      "sha256": "1b2d6065eee839feb3381dd77df96740913b2b2048a319ce667dc94883c0dc92"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/usage/contract_test.go",
      "bytes": 13608,
      "sha256": "9378aadd5a9267911b973d6b329a4102642b919bb0f9414b35b84671cd9d99b3"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/usage/contract.go",
      "bytes": 112301,
      "sha256": "a35271733246eaedc9cebeaadf7e55697b620116cac1774cb86857662027147f"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/usage/review_contract_test.go",
      "bytes": 23703,
      "sha256": "5eb3245ac6f245808d2bdd101dc87456899b25cc5605cbed4a9c128803d57fea"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/audit.go",
      "bytes": 96,
      "sha256": "0b6e29778ecafd32b29d492239f752ec6cd987a5cd9062f37caa3d845da75535"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/wire_contract_test.go",
      "bytes": 8888,
      "sha256": "d7fbeb37d42b99141a71304294a90cb5e5f9919218a5d3a555faa9d0fb69f66d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/export_contract_test.go",
      "bytes": 4146,
      "sha256": "8a535023b744db03dc432c1ea4305de2fcdf53a5efc7dedb354763d8c0c7a55d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/new_review_test.go",
      "bytes": 42882,
      "sha256": "fd80f2c17d324df0320ec0e98ea4a7a25d56a33efc2efbb125ff9ac6d57c61bb"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/coverage_test.go",
      "bytes": 34808,
      "sha256": "910e76aa948c6f4e49f123931a87bc6ae6baa98fd0d046e117c78ab0d49ca661"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/store_boundary_test.go",
      "bytes": 1746,
      "sha256": "aed783625b6e3692b9263ba20faf6aa83c44f4d7e97aa9882b395d412cd7c156"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/review_regression_test.go",
      "bytes": 36809,
      "sha256": "9d42bf64fcdbf6e1267cde51be60f2db1f860689b0ff88bdce98239d356b54b8"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/contract_test.go",
      "bytes": 9994,
      "sha256": "d9e6098143081a92dee4ea6a083c38cd35a2b4ea1be3bc1f1de1751f2cf8e50f"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/control_outcome_test.go",
      "bytes": 1305,
      "sha256": "f58c8a20b7b6f853ee9ad5b97356e0e9aa159ab68a9cdedf365c1b074b0f1ed1"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/contract.go",
      "bytes": 104939,
      "sha256": "bc1777f387b8908a1173cf2e0238af9f41542016f9bd426a0126fca0916ce174"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/review_contract_test.go",
      "bytes": 27040,
      "sha256": "1a6394935c5e5787a43256e5312a9b1b41420c77b8b1b0b999fe5e899a4ef61a"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/authz/contract_test.go",
      "bytes": 10405,
      "sha256": "74a2ec5b1fb10b9fffd689991f8184cdfbbf29777d08e0400fad9e7eafce9cd9"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/authz/contract.go",
      "bytes": 8630,
      "sha256": "ea144e4ee917672eb49051ccebbcc812b4c150c78f2bfc0d4bd29a58da3ccd4c"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/internal/auditstore/receipt.go",
      "bytes": 1624,
      "sha256": "014341f915069a58822febd009e110a62a9b1ede2bbdfe8916f6c46849b51775"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/internal/auditstore/receipt_test.go",
      "bytes": 995,
      "sha256": "287d03ad1c4bb51324d9d3809d3e4a2462f8f0dad0d8c1c47131b1920ba0fd99"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/worker-source/contracts/governance/audit/internal/store/store_boundary_external_test.go",
      "bytes": 5763,
      "sha256": "4b115509b54f8dc78d400321f10bbbf6e4a6601418ee88647e71121f82592bbd"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/open-agent-cluster-overview-design.md",
      "bytes": 102981,
      "sha256": "d0132d814dac38f21fb8dc75cefea3c110acd4dffb15784291bf59d6be45afe7"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/references/conventions.md",
      "bytes": 14658,
      "sha256": "184bda55ad6432844dbe701af63d7c4a544c360e367fbf543e67e84840482c25"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/deploy-ops/deployment-and-operations-design.md",
      "bytes": 32859,
      "sha256": "cea3fe1e0d1d5566e742a14cbde98a401a0d996f08f4085676beb98b2c1820c4"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/delivery/acceptance-and-validation.md",
      "bytes": 299769,
      "sha256": "e84705b5307724f2f8f803ee2f212e32ef144bac079013b419d16713d5edc3ac"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/references/project-and-team/project-and-agent-team.md",
      "bytes": 45342,
      "sha256": "cb8228f14011cf36df8af2cef401b2e157f7ae10c598f7e8de42faee3e52321d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/references/extension/component-governance.md",
      "bytes": 25461,
      "sha256": "c05aceee0bc3d826c0719ad278f27492473a83018d174099786c272ce240f2d0"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/references/extension/plugin-contracts.md",
      "bytes": 17042,
      "sha256": "fcd02305d50c12640bec7de64b25a84f3c1c6d2ca169eae81073448b5038be6b"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/references/software-delivery/artifacts-release-and-deployment.md",
      "bytes": 33518,
      "sha256": "af63916ce4dde95e6a6953efc4fcde7e32b4287184c6521b5920aaf193908a27"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/references/execution/agent-runtime.md",
      "bytes": 38015,
      "sha256": "466c54051d655d562c1afe97e6c3828546edeb6a86284634ef87c5ee95d2891d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/references/workflow/workflow-and-execution.md",
      "bytes": 36262,
      "sha256": "8c9b4fff0ad48c67d5ef61871799f2042b995aa68e92c602d902d83c2cee3f40"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/references/governance/security-and-enterprise.md",
      "bytes": 63725,
      "sha256": "d4b310c4491e6ff0880bf7dc4512e61c20455fd0277596c34284124a98715a44"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/detailed/09-governance-and-security-detailed-design.md",
      "bytes": 81529,
      "sha256": "112d7a6ff48ac97d6a8779fbd27aa88beb99d1b63f8a295a39e921c559594934"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/detailed/05-kubernetes-native-control-plane-detailed-design.md",
      "bytes": 52824,
      "sha256": "05ef0dfbf66daf68c7ae9863701485aa40a2d24e898ea3743a33463515fac97d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/detailed/06-agent-runtime-detailed-design.md",
      "bytes": 49187,
      "sha256": "b186953d7cd58e239f759ed7160b904d2dccc0d265746175135843ffdd58e5e4"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/detailed/03-workflow-platform-core-detailed-design.md",
      "bytes": 70846,
      "sha256": "3b34e3dbee0e13e31a9cdb004631bac2ef1a4b8f7452ff3d87b35533742a2156"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/detailed/08-component-and-extension-detailed-design.md",
      "bytes": 42136,
      "sha256": "6bc50c99a5066ef613537ea14a8a99512f433405ab67afb2b09d98b187411f04"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/detailed/02-project-and-agent-team-detailed-design.md",
      "bytes": 44158,
      "sha256": "77e98399e609bb677e18c6c207767899c952daade5ed5dca226c98e984ad394b"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/detailed/10-web-api-cli-detailed-design.md",
      "bytes": 183512,
      "sha256": "6883d10c9f09faa03c055c7a12ec53c8cbfdf223855b655b12f0df63d43c6f39"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/docs/design/detailed/11-software-delivery-detailed-design.md",
      "bytes": 66620,
      "sha256": "96ab602d53ef516250f41d472f093428f8037cb9b16fbf25b4e90f2246b75e6e"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/admission/engine_test.go",
      "bytes": 15347,
      "sha256": "c3b259882455d26af6b95b8bc66a17fda885a8effade8661eaf427a53222cb7e"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/admission/engine.go",
      "bytes": 8603,
      "sha256": "858a26c0bd1105beb28d50c207820b6dd7d43961498356b71d69e8e06681f0d1"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/authorization/catalog.go",
      "bytes": 3503,
      "sha256": "0d069a05a49147f2547c138dd54cca9a54fa9500111847bd28c95b1f23b237b9"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/authorization/engine_test.go",
      "bytes": 49807,
      "sha256": "f60467f35304707c3723459c56ce13deaaff61f26328ea465c420ceba369c341"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/authorization/policy.go",
      "bytes": 7179,
      "sha256": "819b91934a01277c6069bfca9838d4c2374d3619d179f9defd7aa8ba4c042ac0"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/authorization/engine.go",
      "bytes": 21876,
      "sha256": "c884b5704789d2eb02936f1b9260140c437c856e9bfc41b9c80f3f5a52cdf089"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/authorization/candidate.go",
      "bytes": 17779,
      "sha256": "f5882bff473ff5308e3aa8193e2711ceffe3cb4eba80b1817a484a3988ac4562"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/agents/templates/templates_test.go",
      "bytes": 16871,
      "sha256": "afea9d3378e5019b2fab44ccdb562d22d20fd65fda461cf6a416d1c6c379e8a5"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/agents/templates/templates.go",
      "bytes": 8090,
      "sha256": "434c4cbd0191b2345a08e2d8717cc2ff206aabfac43740a8039bed5d3f7f5080"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/agents/modelpolicy/policy_test.go",
      "bytes": 18182,
      "sha256": "040db671898d854b3caa1b169bc8e8e6bf33de4f4d671998631505ae500ff849"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/agents/modelpolicy/policy.go",
      "bytes": 9527,
      "sha256": "4e2a4c34612899950f670f6f20f66c1e8362813738edafb538b62a6c8cc05007"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/agents/definitions/definitions.go",
      "bytes": 57636,
      "sha256": "d9ad66f15bd3351807f2ee65a95e11db7d2e4b28c6dbbcc8fc82faaf92d44090"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/internal/agents/definitions/application_test.go",
      "bytes": 74386,
      "sha256": "a4472cde2d77092093831f5661c2fb9174f1ce05e2d2dcc01f8bd27b208163a4"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/release/source-ownership-catalog.yaml",
      "bytes": 18606,
      "sha256": "f7e96c861be3e8aef085da65c157c1d1d38290765df0bcc701f1d41e6fb0e820"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/release/source-ownership-baseline.yaml",
      "bytes": 16822,
      "sha256": "69a6f8b5bce02e9d1b9992d6949e169121010911dd5c3781f78b9f39994b55f5"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/project/types.go",
      "bytes": 16572,
      "sha256": "0bf0a702ffbd68e04a29393b3728551aef18dcf04c5704d465d9f4d267038053"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/project/convergence_regression_test.go",
      "bytes": 37211,
      "sha256": "903c6ad6f47dffc9332e5b7be2796a1a08f213ad51ae3a3004a9d0448420b420"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/project/canonical.go",
      "bytes": 7213,
      "sha256": "2acd4963293a42b564f1f9f52b49d40f05c8c4a8f55e4f38a1a99f1916b5d5ec"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/project/review_regression_test.go",
      "bytes": 14021,
      "sha256": "cd6fd5b15a095f6d332a0cebe3dac1328c69b1605d0be7c0daec03ee3d83c08b"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/project/validation.go",
      "bytes": 50180,
      "sha256": "0d66039f6e2bfde6a5a840c4a823506cd1bacd9c1a227eb2f2b948b64ce3cc5c"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/project/contracts_test.go",
      "bytes": 8404,
      "sha256": "b734aa52d6e66df4862c1284576a2cf800aac1950840aa4d706ca80d771b9b83"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/project/validation_test.go",
      "bytes": 25091,
      "sha256": "01dcacea78d868e2af1f355b66b256691887270142404c4f3a4fdf33dba83339"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/credential/exported_surface_test.go",
      "bytes": 1926,
      "sha256": "0f92e61f590987d8f605e35a271ab875c938681501e7a32bb2e9c0faa935d5bf"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/credential/wire_contract_test.go",
      "bytes": 12855,
      "sha256": "660b101622ed7e373f1b4cf03110459fd5e7f12854e488e4d5ef9dcd5d17a9f5"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/credential/wire_validation_test.go",
      "bytes": 19164,
      "sha256": "bf058da4742df4a781c8fee1fb0fa2849a3b17728b874152dcea78afd3b726c5"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/credential/doc.go",
      "bytes": 310,
      "sha256": "aa54a50ecf02a7c9a8d74ed65f60def5db9cbfe060b51eeda0c173ad1ea1a68e"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/credential/wire.go",
      "bytes": 26657,
      "sha256": "dbc02ed64ceea60923248ad73f7254b7573b1909f0354f599a0fd9e1e9417c5c"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/admission/contract_test.go",
      "bytes": 17067,
      "sha256": "115d5019f5279696db440b799ce0960477b4058c9cf426ad6f798a72cc07baed"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/admission/contract.go",
      "bytes": 19871,
      "sha256": "2645fb0cc36ef5dd1ec210ab0af3031f1ba17ee5ec0aa4f17530f3ae0f756926"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/usage/wire_contract_test.go",
      "bytes": 9700,
      "sha256": "b45f2a21ed67cb3440dadce6ac15d7b6ef165528e0fea4b0811b29a3ebffd4b2"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/usage/new_review_test.go",
      "bytes": 45880,
      "sha256": "21aa0438ebac64b8009d7d5104c5226dcd3a76a5c98ab3f35c9ec54a098cac9d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/usage/coverage_test.go",
      "bytes": 26451,
      "sha256": "a21af8018d6b0deb96d61db547bae6260a45e680b1ee56147d435539312faad3"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/usage/review_regression_test.go",
      "bytes": 22306,
      "sha256": "1b2d6065eee839feb3381dd77df96740913b2b2048a319ce667dc94883c0dc92"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/usage/contract_test.go",
      "bytes": 13608,
      "sha256": "9378aadd5a9267911b973d6b329a4102642b919bb0f9414b35b84671cd9d99b3"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/usage/contract.go",
      "bytes": 112301,
      "sha256": "a35271733246eaedc9cebeaadf7e55697b620116cac1774cb86857662027147f"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/usage/review_contract_test.go",
      "bytes": 23703,
      "sha256": "5eb3245ac6f245808d2bdd101dc87456899b25cc5605cbed4a9c128803d57fea"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/audit.go",
      "bytes": 96,
      "sha256": "0b6e29778ecafd32b29d492239f752ec6cd987a5cd9062f37caa3d845da75535"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/wire_contract_test.go",
      "bytes": 8888,
      "sha256": "d7fbeb37d42b99141a71304294a90cb5e5f9919218a5d3a555faa9d0fb69f66d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/export_contract_test.go",
      "bytes": 4146,
      "sha256": "8a535023b744db03dc432c1ea4305de2fcdf53a5efc7dedb354763d8c0c7a55d"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/new_review_test.go",
      "bytes": 42882,
      "sha256": "fd80f2c17d324df0320ec0e98ea4a7a25d56a33efc2efbb125ff9ac6d57c61bb"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/coverage_test.go",
      "bytes": 34808,
      "sha256": "910e76aa948c6f4e49f123931a87bc6ae6baa98fd0d046e117c78ab0d49ca661"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/store_boundary_test.go",
      "bytes": 1746,
      "sha256": "aed783625b6e3692b9263ba20faf6aa83c44f4d7e97aa9882b395d412cd7c156"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/review_regression_test.go",
      "bytes": 36809,
      "sha256": "9d42bf64fcdbf6e1267cde51be60f2db1f860689b0ff88bdce98239d356b54b8"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/contract_test.go",
      "bytes": 9994,
      "sha256": "d9e6098143081a92dee4ea6a083c38cd35a2b4ea1be3bc1f1de1751f2cf8e50f"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/control_outcome_test.go",
      "bytes": 1305,
      "sha256": "f58c8a20b7b6f853ee9ad5b97356e0e9aa159ab68a9cdedf365c1b074b0f1ed1"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/contract.go",
      "bytes": 104939,
      "sha256": "bc1777f387b8908a1173cf2e0238af9f41542016f9bd426a0126fca0916ce174"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/review_contract_test.go",
      "bytes": 27040,
      "sha256": "1a6394935c5e5787a43256e5312a9b1b41420c77b8b1b0b999fe5e899a4ef61a"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/authz/contract_test.go",
      "bytes": 10405,
      "sha256": "74a2ec5b1fb10b9fffd689991f8184cdfbbf29777d08e0400fad9e7eafce9cd9"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/authz/contract.go",
      "bytes": 8630,
      "sha256": "ea144e4ee917672eb49051ccebbcc812b4c150c78f2bfc0d4bd29a58da3ccd4c"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/internal/auditstore/receipt.go",
      "bytes": 1624,
      "sha256": "014341f915069a58822febd009e110a62a9b1ede2bbdfe8916f6c46849b51775"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/internal/auditstore/receipt_test.go",
      "bytes": 995,
      "sha256": "287d03ad1c4bb51324d9d3809d3e4a2462f8f0dad0d8c1c47131b1920ba0fd99"
    },
    {
      "path": "/tmp/oac-api-agent-production-owner-bound-0855-20261004/current-main-source/contracts/governance/audit/internal/store/store_boundary_external_test.go",
      "bytes": 5763,
      "sha256": "4b115509b54f8dc78d400321f10bbbf6e4a6601418ee88647e71121f82592bbd"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/Root9512-delegation.json",
      "bytes": 1081,
      "sha256": "9512a6735dc4fea22961757d58bf2cceabc787186675373757fc052b72307db4"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/actual-worker-block-v2.json",
      "bytes": 2563,
      "sha256": "a210ec3f1193cd11fd846762094cd7acb6bd8a5f8b1305ab1935700dae25257d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/capture-manifest.json",
      "bytes": 1059,
      "sha256": "e66a13967a849d4584ec01df4f7e0734244178adde3adb34a6fe367222277699"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-authority/.omac/config.yaml",
      "bytes": 609,
      "sha256": "ce86ba40522897f0977d17db5bc3934c2ad9a8a0199f887f1ac3d1fad2834470"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-authority/.omac/mcp-production-proof-owner-request-20261004.md",
      "bytes": 4946,
      "sha256": "42618b6b536d05fd44e12401193e0cf5cf03a85e5fcb65239ecb01f358df7ee4"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-authority/.omac/open-agent-cluster.acceptance.yaml",
      "bytes": 1439865,
      "sha256": "9f3969e0052f1eb3cd7101481150e96a52fd2035705ef91db42a2ed898b5f082"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-authority/.omac/open-agent-cluster.yaml",
      "bytes": 2287788,
      "sha256": "0f2e2d33ccb3fa35b06f22542e0daf34b22f457727a64838111a5efa6574401a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/agent-definition.json",
      "bytes": 4581,
      "sha256": "6dc2275c63f38081717e827cf1d98d62d1bc7ce2ce3d7251e18d521cb1113db0"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/agent-run-job.json",
      "bytes": 14026,
      "sha256": "2392a3768bee58c21bd244e61e47be87a6fa81c76430ebd41f6dc30039b5c0c6"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/agentrun-cancellation-prerequisite.json",
      "bytes": 41667,
      "sha256": "6a9fb5a12a0737bac58e54d0c8eb8a4f18f8ffd2b543533e34459df484794658"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/api-mcp.json",
      "bytes": 9719,
      "sha256": "c3deb2f64098365d69cd85041cc14b30d21ee7454ce4e3883364e4e682de4400"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/audit-ledger.json",
      "bytes": 34697,
      "sha256": "6f8a71f275b608343c3a830a9c08d9798a7248761126a63098f8bb6f33e7c15c"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/authorization.json",
      "bytes": 4526,
      "sha256": "930b9a513aa65ec78f3d6bf8905b382de0f636744320647fb20116c404209519"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/contracts-audit-usage.json",
      "bytes": 25384,
      "sha256": "0442e81d2921f5dfda9f2a688fb97fdd9f127f2b28ed79235cf7e4d5e54b91a0"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/contracts-authz-admission.json",
      "bytes": 4753,
      "sha256": "343b984bb3377e78401b319c7a6e121666513f863d61a76ad52354b0144ec612"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/credential-store.json",
      "bytes": 8760,
      "sha256": "708fa1230fa97979b92459bdcb5700e5b5727e3788b6f49e6c8f51249c7d7121"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/execution-admission.json",
      "bytes": 4629,
      "sha256": "c0a8889c9076d49c772938ad874c6d4bd94e970252add9adb70f477409981b27"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/mcp-catalog-governed-hardening.json",
      "bytes": 9848,
      "sha256": "6e1397acc2cc258f91a89037bf4b2f4dba3f39600245a0855dd3f457163da0c1"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/mcp-catalog.json",
      "bytes": 4312,
      "sha256": "86d5b6eb6a3f65046dd17db13a17db180745be40c4e9e4ea30b773e850f9d7d7"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/platform-agentrun.json",
      "bytes": 5115,
      "sha256": "2d82819cf9a688c8433b4c6b6edbcf25989a8bf780f21d7c5fa82272f0365818"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/release-artifact-tooling.json",
      "bytes": 47493,
      "sha256": "f5ee86f93ba84585012711dd16f1e7556fe9565447077029eb0cb218e0db5eb2"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/runtime-sdk-mcp-launch-compatibility.json",
      "bytes": 6590,
      "sha256": "74f5218587c89863742ea2221bc3a495f6d320dd6fea6d469847ce5f7c1e061b"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/source-ownership-baseline-contract.json",
      "bytes": 5168,
      "sha256": "a39c1c4751bffb169c71fdbadecc2972b9306c89a07f133707fc3d69e3e49036"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-control/system-release-tooling-ownership-contract.json",
      "bytes": 11271,
      "sha256": "46ff7e10e5db999b9895154eb4c1c7cd301db552706ff695158acd513e9fc55f"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/api-mcp-amendment-decision.md",
      "bytes": 2692,
      "sha256": "5ccf20286a6c38190654844711db13700dfa649de264df7460ad3d91a41752d2"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/agent/contract.go",
      "bytes": 23353,
      "sha256": "113ec2a59de11bb8b95e1c683bd4c0a0b91800539f6900010f2556022a92f1a9"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/agent/contract_test.go",
      "bytes": 27409,
      "sha256": "425551e6e038077213de196d015c372f8e3327065ff5f483d0e26bb44d5bf808"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/admission/contract.go",
      "bytes": 19871,
      "sha256": "2645fb0cc36ef5dd1ec210ab0af3031f1ba17ee5ec0aa4f17530f3ae0f756926"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/admission/contract_test.go",
      "bytes": 17067,
      "sha256": "115d5019f5279696db440b799ce0960477b4058c9cf426ad6f798a72cc07baed"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/audit.go",
      "bytes": 96,
      "sha256": "0b6e29778ecafd32b29d492239f752ec6cd987a5cd9062f37caa3d845da75535"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/contract.go",
      "bytes": 104939,
      "sha256": "bc1777f387b8908a1173cf2e0238af9f41542016f9bd426a0126fca0916ce174"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/contract_test.go",
      "bytes": 9994,
      "sha256": "d9e6098143081a92dee4ea6a083c38cd35a2b4ea1be3bc1f1de1751f2cf8e50f"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/control_outcome_test.go",
      "bytes": 1305,
      "sha256": "f58c8a20b7b6f853ee9ad5b97356e0e9aa159ab68a9cdedf365c1b074b0f1ed1"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/coverage_test.go",
      "bytes": 34808,
      "sha256": "910e76aa948c6f4e49f123931a87bc6ae6baa98fd0d046e117c78ab0d49ca661"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/export_contract_test.go",
      "bytes": 4146,
      "sha256": "8a535023b744db03dc432c1ea4305de2fcdf53a5efc7dedb354763d8c0c7a55d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/internal/auditstore/receipt.go",
      "bytes": 1624,
      "sha256": "014341f915069a58822febd009e110a62a9b1ede2bbdfe8916f6c46849b51775"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/internal/auditstore/receipt_test.go",
      "bytes": 995,
      "sha256": "287d03ad1c4bb51324d9d3809d3e4a2462f8f0dad0d8c1c47131b1920ba0fd99"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/internal/store/store_boundary_external_test.go",
      "bytes": 5763,
      "sha256": "4b115509b54f8dc78d400321f10bbbf6e4a6601418ee88647e71121f82592bbd"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/new_review_test.go",
      "bytes": 42882,
      "sha256": "fd80f2c17d324df0320ec0e98ea4a7a25d56a33efc2efbb125ff9ac6d57c61bb"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/review_contract_test.go",
      "bytes": 27040,
      "sha256": "1a6394935c5e5787a43256e5312a9b1b41420c77b8b1b0b999fe5e899a4ef61a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/review_regression_test.go",
      "bytes": 36809,
      "sha256": "9d42bf64fcdbf6e1267cde51be60f2db1f860689b0ff88bdce98239d356b54b8"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/store_boundary_test.go",
      "bytes": 1746,
      "sha256": "aed783625b6e3692b9263ba20faf6aa83c44f4d7e97aa9882b395d412cd7c156"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/audit/wire_contract_test.go",
      "bytes": 8888,
      "sha256": "d7fbeb37d42b99141a71304294a90cb5e5f9919218a5d3a555faa9d0fb69f66d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/authz/contract.go",
      "bytes": 8630,
      "sha256": "ea144e4ee917672eb49051ccebbcc812b4c150c78f2bfc0d4bd29a58da3ccd4c"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/authz/contract_test.go",
      "bytes": 10405,
      "sha256": "74a2ec5b1fb10b9fffd689991f8184cdfbbf29777d08e0400fad9e7eafce9cd9"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/credential/doc.go",
      "bytes": 310,
      "sha256": "aa54a50ecf02a7c9a8d74ed65f60def5db9cbfe060b51eeda0c173ad1ea1a68e"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/credential/exported_surface_test.go",
      "bytes": 1926,
      "sha256": "0f92e61f590987d8f605e35a271ab875c938681501e7a32bb2e9c0faa935d5bf"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/credential/wire.go",
      "bytes": 26657,
      "sha256": "dbc02ed64ceea60923248ad73f7254b7573b1909f0354f599a0fd9e1e9417c5c"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/credential/wire_contract_test.go",
      "bytes": 12855,
      "sha256": "660b101622ed7e373f1b4cf03110459fd5e7f12854e488e4d5ef9dcd5d17a9f5"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/credential/wire_validation_test.go",
      "bytes": 19164,
      "sha256": "bf058da4742df4a781c8fee1fb0fa2849a3b17728b874152dcea78afd3b726c5"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/usage/contract.go",
      "bytes": 112301,
      "sha256": "a35271733246eaedc9cebeaadf7e55697b620116cac1774cb86857662027147f"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/usage/contract_test.go",
      "bytes": 13608,
      "sha256": "9378aadd5a9267911b973d6b329a4102642b919bb0f9414b35b84671cd9d99b3"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/usage/coverage_test.go",
      "bytes": 26451,
      "sha256": "a21af8018d6b0deb96d61db547bae6260a45e680b1ee56147d435539312faad3"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/usage/new_review_test.go",
      "bytes": 45880,
      "sha256": "21aa0438ebac64b8009d7d5104c5226dcd3a76a5c98ab3f35c9ec54a098cac9d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/usage/review_contract_test.go",
      "bytes": 23703,
      "sha256": "5eb3245ac6f245808d2bdd101dc87456899b25cc5605cbed4a9c128803d57fea"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/usage/review_regression_test.go",
      "bytes": 22306,
      "sha256": "1b2d6065eee839feb3381dd77df96740913b2b2048a319ce667dc94883c0dc92"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/governance/usage/wire_contract_test.go",
      "bytes": 9700,
      "sha256": "b45f2a21ed67cb3440dadce6ac15d7b6ef165528e0fea4b0811b29a3ebffd4b2"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/release/kernel-lifecycle-additive-ownership/addition.yaml",
      "bytes": 1099,
      "sha256": "fcf95904eda9494f2bae7243fcb3a339d01c12e377ad334af567df8bd539e087"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/release/kernel-lifecycle-additive-ownership/tests/test_kernel_lifecycle_additive_ownership.py",
      "bytes": 7503,
      "sha256": "6980c13d62cbd434684d1d2f7a790f9244f1a9c97b6e7327b937187f6dfbbe56"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/release/kernel-lifecycle-additive-ownership/verify.py",
      "bytes": 17956,
      "sha256": "54599879bac0f65ca7a547f9adebb73327d030c6f2b25a68ae88fa3763aa1379"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/release/kernel-lifecycle-contract-ownership.yaml",
      "bytes": 5694,
      "sha256": "a268a0fff5fb82529383856b5940395600bbd70daba211ec015766254028dfdc"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/release/source-ownership-baseline.yaml",
      "bytes": 16822,
      "sha256": "69a6f8b5bce02e9d1b9992d6949e169121010911dd5c3781f78b9f39994b55f5"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/release/source-ownership-catalog.yaml",
      "bytes": 18606,
      "sha256": "f7e96c861be3e8aef085da65c157c1d1d38290765df0bcc701f1d41e6fb0e820"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/contracts/release/system-release-tooling-ownership.yaml",
      "bytes": 2984,
      "sha256": "b26550c8bd2cc7ff0c2d884cfb2b6bee0ca453231ef328b436a13023b20bffa0"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/docs/references/cloud-native/kubernetes-resources.md",
      "bytes": 22093,
      "sha256": "1e180ca347413c031d34fe426c14a635e753ef3db8bec6ea504e9dc964077882"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/five-nodes-recovery-decisions.md",
      "bytes": 5913,
      "sha256": "7bd38663b73a6175947bc1343df993019b8c6570be7413620eed89f64cf1e1af"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/agentrun/assembly.go",
      "bytes": 2645,
      "sha256": "6d79a508af8ff2c32d6ce6c082ba7c4ce607aed359b837d79d09156f02af489a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/agentrun/assembly_test.go",
      "bytes": 6333,
      "sha256": "266ec2aa0754bc8bb0e93970ed348f76bfb0152cd1fd46627834fbae48867258"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/agentrun/runner.go",
      "bytes": 15252,
      "sha256": "645ce0658051fed94344d1cb1ced5bbbe2f1e6449a1343be3322f5d01b5fd7d1"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/agentrun/runner_test.go",
      "bytes": 23082,
      "sha256": "0475a3a9858e1b93c353752dbe2c92c012641064a002afbd0e33d66490fc65eb"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/agents/definitions/application_test.go",
      "bytes": 74386,
      "sha256": "a4472cde2d77092093831f5661c2fb9174f1ce05e2d2dcc01f8bd27b208163a4"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/agents/definitions/definitions.go",
      "bytes": 57636,
      "sha256": "d9ad66f15bd3351807f2ee65a95e11db7d2e4b28c6dbbcc8fc82faaf92d44090"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/authorization/candidate.go",
      "bytes": 17779,
      "sha256": "f5882bff473ff5308e3aa8193e2711ceffe3cb4eba80b1817a484a3988ac4562"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/authorization/catalog.go",
      "bytes": 3503,
      "sha256": "0d069a05a49147f2547c138dd54cca9a54fa9500111847bd28c95b1f23b237b9"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/authorization/engine.go",
      "bytes": 21876,
      "sha256": "c884b5704789d2eb02936f1b9260140c437c856e9bfc41b9c80f3f5a52cdf089"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/authorization/engine_test.go",
      "bytes": 49807,
      "sha256": "f60467f35304707c3723459c56ce13deaaff61f26328ea465c420ceba369c341"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/authorization/policy.go",
      "bytes": 7179,
      "sha256": "819b91934a01277c6069bfca9838d4c2374d3619d179f9defd7aa8ba4c042ac0"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/mcp/coverage_test.go",
      "bytes": 20496,
      "sha256": "bbcb15344ced1cfccd2dd9ea09cf10cba96084952135dcbf9f6a67cf2c92c2da"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/mcp/import.go",
      "bytes": 12618,
      "sha256": "612adec4034798648f1b20a860edfce6324234d375fb8de6f6956f79d37b22d4"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/mcp/materialize.go",
      "bytes": 7885,
      "sha256": "4b02cc9017d723e5ee5870a5223434ccf0e852d081e086cd27fcb561987bb125"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/mcp/mcp_test.go",
      "bytes": 20336,
      "sha256": "463edf60c5bccf097babe4428f0a7a48b3b5aaf7e65434a5ac507d8dd6aabd2c"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/mcp/probe.go",
      "bytes": 18550,
      "sha256": "f0f3f0ff25b8381d44023c08ac377b88e67669de4988320d36bd11fb4b8dd735"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/mcp/types.go",
      "bytes": 24022,
      "sha256": "93166ed5e2e46d0feab122d5fb8e78d66b7907e66ab68917cbf6892cb98a3d6a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/platformcore/agentrun/application.go",
      "bytes": 112260,
      "sha256": "89246c433654d1991eb2cd34c543493456feb5b5339d904f93667078c2dcc7cf"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/platformcore/agentrun/application_test.go",
      "bytes": 104687,
      "sha256": "80a26d3b17d6838b4d049da3f42de46b589a5ffa02c69e5b1f4642d90bd9969b"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source/internal/platformcore/agentrun/coverage_test.go",
      "bytes": 66171,
      "sha256": "246c6f6a8369d486de5f8aeb1dfb6dcb894c6763d1aed0581c3941c5db7ccc65"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-main-source-binding.json",
      "bytes": 1164,
      "sha256": "b12fe287a3d951bde22ed6495ee53379d0b4b1465d481c5c6f8fdeeb7d3892b9"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-manifest.yaml",
      "bytes": 2287788,
      "sha256": "0f2e2d33ccb3fa35b06f22542e0daf34b22f457727a64838111a5efa6574401a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/agent-definition-Runs.json",
      "bytes": 41568,
      "sha256": "9d11cba8197cc7b24fe7841b4722b2ec8a9bb6bd7b5a1c5fa7756d5f7f4328b1"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/agent-definition-Store.json",
      "bytes": 40564,
      "sha256": "86d0acc12ead1e51278bf8d10dfded9d6f3e90236c2658db0fbd6d05c07b939c"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/agent-run-job-Runs.json",
      "bytes": 153437,
      "sha256": "715c2432db0475910f8ceec894c1f9753ea43f835f85b78e9c03c01cc1dc2bfa"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/agent-run-job-Store.json",
      "bytes": 112196,
      "sha256": "a54991803474fc34cc837f7108b8e2ba6243fba7d9e7a19ae22795607faeb500"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/agentrun-cancellation-prerequisite-Runs.json",
      "bytes": 43844,
      "sha256": "b510095fe5eabd0b35e5c49be408b3f8e2969edb8272d52384006a6c2cf86526"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/agentrun-cancellation-prerequisite-Store.json",
      "bytes": 63311,
      "sha256": "a6c1681390f4bcd19c4ab25509e572edd966c6723932b5eb6452b8a55e9b4678"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/api-mcp-Runs.json",
      "bytes": 21631,
      "sha256": "0b68dda0922e2647688ab4c4944a3386f63c46c9d968e4cf193d116d3fd57734"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/api-mcp-Store.json",
      "bytes": 25970,
      "sha256": "4b024d184651933950abf92e4d82a0a210718ed29789fec6e1e23fc09f45e754"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/audit-ledger-Runs.json",
      "bytes": 9131,
      "sha256": "d5ca27692c7e35dec99685a16fd44ffb6c2964594614d378f5c5cdd1c7c17723"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/audit-ledger-Store.json",
      "bytes": 28140,
      "sha256": "395402dbbaf43ad48067a8e00501af8718b17c9302ccbf5f119aac45352bbdda"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/authorization-Runs.json",
      "bytes": 12939,
      "sha256": "37796d691e2365b3aaaadf74c78babae93a93ccf98c6f92de945a6313f330a32"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/authorization-Store.json",
      "bytes": 18408,
      "sha256": "382f2f247e7f52052775237004644bbe5b8b85aa53db72bfb0ed103e85957fed"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/contracts-audit-usage-Runs.json",
      "bytes": 690889,
      "sha256": "1d3f80d0bac59f5172e0e194a16b429b83806e1ebddd4697d3d819db69184c75"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/contracts-audit-usage-Store.json",
      "bytes": 352571,
      "sha256": "19393b45016338831f68b62e2070929932edb87277505f9d18a6bdb619c3d345"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/contracts-authz-admission-Runs.json",
      "bytes": 32680,
      "sha256": "ea7dfe05d199b332ef5dd288457ed620dcb9fca3a1811e0d7460e799c689607c"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/contracts-authz-admission-Store.json",
      "bytes": 30457,
      "sha256": "eb9f9ab0ead9c15b87455fe46a4d84dc7ee3a06b3be604010363bfcdeb728cf2"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/credential-store-Runs.json",
      "bytes": 10080,
      "sha256": "d9b58d206a1e877199795e9c769dd2e27bec66d43f4322a7cc6e100468e3e293"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/credential-store-Store.json",
      "bytes": 18980,
      "sha256": "e98e5964318f12df1cf0371ee8746a935b16a57f715b9055b5b4f1f5c7d69ade"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/execution-admission-Runs.json",
      "bytes": 11235,
      "sha256": "f340120c4696127becb261ff8886548823a4463ed067127c3acdf08663cd71d4"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/execution-admission-Store.json",
      "bytes": 17734,
      "sha256": "434c39307204215581d9f890270d953c2f5f8033f721c331f04b801eb29c6463"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/mcp-catalog-Runs.json",
      "bytes": 11918,
      "sha256": "a38287bd9aaf68f7fe53edee815cc41e31eae311104c9980e3a28b0d37fce00e"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/mcp-catalog-Store.json",
      "bytes": 18005,
      "sha256": "7caaff6747906d75d4f7a6cc0f2659a981e90fa6c2228b232d9810a3b3c9c6f8"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/mcp-catalog-governed-hardening-Runs.json",
      "bytes": 8037,
      "sha256": "4a3c45f68d36fc3f415f8dccb4d97260fcee755d4a9fa15f624c5bdda759bd11"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/mcp-catalog-governed-hardening-Store.json",
      "bytes": 19234,
      "sha256": "237cba1eb1be9b8b9f485aa035c0b5581f77d7412264bd27bbb9ba7f160a64d3"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/observation.json",
      "bytes": 5856,
      "sha256": "83eb379955a7fc7aab41dec3241caafe2ed5065a6aab9dafa0cb88b149072972"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/platform-agentrun-Runs.json",
      "bytes": 152464,
      "sha256": "cf8c4161e8cb8345b360387e98947bdd581f521d64c8e5e73e0b89faab267634"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/platform-agentrun-Store.json",
      "bytes": 108749,
      "sha256": "69622eb8bd6dfa7989c80500eb1ce9e2662e5c83ab4451333de0dd0ff307acf2"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/release-artifact-tooling-Runs.json",
      "bytes": 104229,
      "sha256": "d196a57e89488319c7db4a644aa481c1ff7a5306763e7e84932c17261f15c127"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/release-artifact-tooling-Store.json",
      "bytes": 43232,
      "sha256": "76a7bea5948d10023aba8910ddba0cf6364b557e39a9320bf7af16f739c6bea5"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/runtime-sdk-mcp-launch-compatibility-Runs.json",
      "bytes": 7567,
      "sha256": "d81d2a394e5c1c8e401e49c0ddf1706b821fe522cc80d2523ea99819233d397c"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/runtime-sdk-mcp-launch-compatibility-Store.json",
      "bytes": 17476,
      "sha256": "eebb51d97a80df386f9c6252583e964a6ce7aa4175992a18a0adf1a6bb89f050"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/source-ownership-baseline-contract-Runs.json",
      "bytes": 7522,
      "sha256": "212cb533c2813e5e9a9805e7754f0f1b66c10b2b4a43682fef10eb0cf6562f0f"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/source-ownership-baseline-contract-Store.json",
      "bytes": 6330,
      "sha256": "ae45370e7aa5558a1a2da57174518be0e14c7cbd221523ad98d33e818a49e3c6"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/system-release-tooling-ownership-contract-Runs.json",
      "bytes": 29200,
      "sha256": "d65424f8d0192d3e2ce4dbfcd5a232bf763b0cf94495ceeda598b241184fb234"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-native-controls-0429/system-release-tooling-ownership-contract-Store.json",
      "bytes": 18463,
      "sha256": "12df2c69d4569f903772dd8582684d8309634ac297252df39340d36930c3302a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-owner-contract.json",
      "bytes": 9848,
      "sha256": "6e1397acc2cc258f91a89037bf4b2f4dba3f39600245a0855dd3f457163da0c1"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/AGENTS.md",
      "bytes": 18404,
      "sha256": "2d4ee15006894589233d50c4e057a9d8012fa2fc8048323218deb55cb17715ef"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/docs/delivery/acceptance-and-validation.md",
      "bytes": 299769,
      "sha256": "e84705b5307724f2f8f803ee2f212e32ef144bac079013b419d16713d5edc3ac"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/docs/design/detailed/05-kubernetes-native-control-plane-detailed-design.md",
      "bytes": 52824,
      "sha256": "05ef0dfbf66daf68c7ae9863701485aa40a2d24e898ea3743a33463515fac97d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/docs/design/detailed/09-governance-and-security-detailed-design.md",
      "bytes": 81529,
      "sha256": "112d7a6ff48ac97d6a8779fbd27aa88beb99d1b63f8a295a39e921c559594934"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/docs/design/open-agent-cluster-overview-design.md",
      "bytes": 102981,
      "sha256": "d0132d814dac38f21fb8dc75cefea3c110acd4dffb15784291bf59d6be45afe7"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/agentrun/runner.go",
      "bytes": 15252,
      "sha256": "645ce0658051fed94344d1cb1ced5bbbe2f1e6449a1343be3322f5d01b5fd7d1"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/agents/definitions/definitions.go",
      "bytes": 55907,
      "sha256": "67c333d4866a6df9a73a35594490aa9fd8ceec201ecf62436a5258e6b36d2f59"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/mcp/coverage_test.go",
      "bytes": 21760,
      "sha256": "22fc6b09cc3457013c78ead84bb197ce67345143375b4ad182b845563cf9902a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/mcp/governed.go",
      "bytes": 66080,
      "sha256": "968d9d62bf1763e5b3d92b6b2deb69146f9fae913c03e76f1e0439b8b99e5a02"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/mcp/governed_test.go",
      "bytes": 80838,
      "sha256": "c3d6bb58b5ff3b516f916a0bd395d2ded0a3c6f4ebb2b089e9f1cf48d215b213"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/mcp/import.go",
      "bytes": 12458,
      "sha256": "e2918c7f83191c2c75bce2e6cac206519bc294a5c9ba8839e4708afcef370310"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/mcp/materialize.go",
      "bytes": 7885,
      "sha256": "4b02cc9017d723e5ee5870a5223434ccf0e852d081e086cd27fcb561987bb125"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/mcp/mcp_test.go",
      "bytes": 23861,
      "sha256": "ddd4e2ea609a1cfd99655c2c57308f2c5feed399913388ad2d63601d8536c54f"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/mcp/probe.go",
      "bytes": 18993,
      "sha256": "32145e16c8e6734301caacd4ac1267a0d082bb9f81cf585fd9414d89d8b127de"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/mcp/types.go",
      "bytes": 24091,
      "sha256": "dad5c113f31f3d184dc53e095a9fff1767d427ffd0bdcbf1fb66481534844147"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-source/internal/platformcore/agentrun/application.go",
      "bytes": 112260,
      "sha256": "89246c433654d1991eb2cd34c543493456feb5b5339d904f93667078c2dcc7cf"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/admission/contract.go",
      "bytes": 19871,
      "sha256": "2645fb0cc36ef5dd1ec210ab0af3031f1ba17ee5ec0aa4f17530f3ae0f756926"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/admission/contract_test.go",
      "bytes": 17067,
      "sha256": "115d5019f5279696db440b799ce0960477b4058c9cf426ad6f798a72cc07baed"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/audit.go",
      "bytes": 96,
      "sha256": "0b6e29778ecafd32b29d492239f752ec6cd987a5cd9062f37caa3d845da75535"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/contract.go",
      "bytes": 104939,
      "sha256": "bc1777f387b8908a1173cf2e0238af9f41542016f9bd426a0126fca0916ce174"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/contract_test.go",
      "bytes": 9994,
      "sha256": "d9e6098143081a92dee4ea6a083c38cd35a2b4ea1be3bc1f1de1751f2cf8e50f"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/control_outcome_test.go",
      "bytes": 1305,
      "sha256": "f58c8a20b7b6f853ee9ad5b97356e0e9aa159ab68a9cdedf365c1b074b0f1ed1"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/coverage_test.go",
      "bytes": 34808,
      "sha256": "910e76aa948c6f4e49f123931a87bc6ae6baa98fd0d046e117c78ab0d49ca661"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/export_contract_test.go",
      "bytes": 4146,
      "sha256": "8a535023b744db03dc432c1ea4305de2fcdf53a5efc7dedb354763d8c0c7a55d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/internal/auditstore/receipt.go",
      "bytes": 1624,
      "sha256": "014341f915069a58822febd009e110a62a9b1ede2bbdfe8916f6c46849b51775"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/internal/auditstore/receipt_test.go",
      "bytes": 995,
      "sha256": "287d03ad1c4bb51324d9d3809d3e4a2462f8f0dad0d8c1c47131b1920ba0fd99"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/internal/store/store_boundary_external_test.go",
      "bytes": 5763,
      "sha256": "4b115509b54f8dc78d400321f10bbbf6e4a6601418ee88647e71121f82592bbd"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/new_review_test.go",
      "bytes": 42882,
      "sha256": "fd80f2c17d324df0320ec0e98ea4a7a25d56a33efc2efbb125ff9ac6d57c61bb"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/review_contract_test.go",
      "bytes": 27040,
      "sha256": "1a6394935c5e5787a43256e5312a9b1b41420c77b8b1b0b999fe5e899a4ef61a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/review_regression_test.go",
      "bytes": 36809,
      "sha256": "9d42bf64fcdbf6e1267cde51be60f2db1f860689b0ff88bdce98239d356b54b8"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/store_boundary_test.go",
      "bytes": 1746,
      "sha256": "aed783625b6e3692b9263ba20faf6aa83c44f4d7e97aa9882b395d412cd7c156"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/governance/audit/wire_contract_test.go",
      "bytes": 8888,
      "sha256": "d7fbeb37d42b99141a71304294a90cb5e5f9919218a5d3a555faa9d0fb69f66d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/release/kernel-lifecycle-additive-ownership/addition.yaml",
      "bytes": 1099,
      "sha256": "fcf95904eda9494f2bae7243fcb3a339d01c12e377ad334af567df8bd539e087"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/release/kernel-lifecycle-additive-ownership/tests/test_kernel_lifecycle_additive_ownership.py",
      "bytes": 7503,
      "sha256": "6980c13d62cbd434684d1d2f7a790f9244f1a9c97b6e7327b937187f6dfbbe56"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/release/kernel-lifecycle-additive-ownership/verify.py",
      "bytes": 17956,
      "sha256": "54599879bac0f65ca7a547f9adebb73327d030c6f2b25a68ae88fa3763aa1379"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/release/kernel-lifecycle-contract-ownership.yaml",
      "bytes": 5694,
      "sha256": "a268a0fff5fb82529383856b5940395600bbd70daba211ec015766254028dfdc"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/release/source-ownership-baseline.yaml",
      "bytes": 16822,
      "sha256": "69a6f8b5bce02e9d1b9992d6949e169121010911dd5c3781f78b9f39994b55f5"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/release/source-ownership-catalog.yaml",
      "bytes": 18606,
      "sha256": "f7e96c861be3e8aef085da65c157c1d1d38290765df0bcc701f1d41e6fb0e820"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/contracts/release/system-release-tooling-ownership.yaml",
      "bytes": 2984,
      "sha256": "b26550c8bd2cc7ff0c2d884cfb2b6bee0ca453231ef328b436a13023b20bffa0"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/agentrun/assembly.go",
      "bytes": 2645,
      "sha256": "6d79a508af8ff2c32d6ce6c082ba7c4ce607aed359b837d79d09156f02af489a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/agentrun/assembly_test.go",
      "bytes": 6333,
      "sha256": "266ec2aa0754bc8bb0e93970ed348f76bfb0152cd1fd46627834fbae48867258"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/agentrun/runner.go",
      "bytes": 15252,
      "sha256": "645ce0658051fed94344d1cb1ced5bbbe2f1e6449a1343be3322f5d01b5fd7d1"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/agentrun/runner_test.go",
      "bytes": 23082,
      "sha256": "0475a3a9858e1b93c353752dbe2c92c012641064a002afbd0e33d66490fc65eb"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/agents/definitions/application_test.go",
      "bytes": 69785,
      "sha256": "7e893aa06c4b2f660b090b4f01831652cd8ad0be3249b78dc02740686f5f14f6"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/agents/definitions/definitions.go",
      "bytes": 55907,
      "sha256": "67c333d4866a6df9a73a35594490aa9fd8ceec201ecf62436a5258e6b36d2f59"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/mcp/coverage_test.go",
      "bytes": 21760,
      "sha256": "22fc6b09cc3457013c78ead84bb197ce67345143375b4ad182b845563cf9902a"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/mcp/governed.go",
      "bytes": 66080,
      "sha256": "968d9d62bf1763e5b3d92b6b2deb69146f9fae913c03e76f1e0439b8b99e5a02"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/mcp/governed_test.go",
      "bytes": 80838,
      "sha256": "c3d6bb58b5ff3b516f916a0bd395d2ded0a3c6f4ebb2b089e9f1cf48d215b213"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/mcp/import.go",
      "bytes": 12458,
      "sha256": "e2918c7f83191c2c75bce2e6cac206519bc294a5c9ba8839e4708afcef370310"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/mcp/materialize.go",
      "bytes": 7885,
      "sha256": "4b02cc9017d723e5ee5870a5223434ccf0e852d081e086cd27fcb561987bb125"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/mcp/mcp_test.go",
      "bytes": 23861,
      "sha256": "ddd4e2ea609a1cfd99655c2c57308f2c5feed399913388ad2d63601d8536c54f"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/mcp/probe.go",
      "bytes": 18993,
      "sha256": "32145e16c8e6734301caacd4ac1267a0d082bb9f81cf585fd9414d89d8b127de"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/mcp/types.go",
      "bytes": 24091,
      "sha256": "dad5c113f31f3d184dc53e095a9fff1767d427ffd0bdcbf1fb66481534844147"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/platformcore/agentrun/application.go",
      "bytes": 112260,
      "sha256": "89246c433654d1991eb2cd34c543493456feb5b5339d904f93667078c2dcc7cf"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/platformcore/agentrun/application_test.go",
      "bytes": 104687,
      "sha256": "80a26d3b17d6838b4d049da3f42de46b589a5ffa02c69e5b1f4642d90bd9969b"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/current-worker-source/internal/platformcore/agentrun/coverage_test.go",
      "bytes": 66171,
      "sha256": "246c6f6a8369d486de5f8aeb1dfb6dcb894c6763d1aed0581c3941c5db7ccc65"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/exact-source-authority/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/adapters_test.go",
      "bytes": 57233,
      "sha256": "c7ba0b08e5a13f6fd5be8401d4268e705099d3fde2e9932769a43baf5dddeb35"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/exact-source-authority/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/main_test.go",
      "bytes": 20440,
      "sha256": "fa44d6ff30d4c274c342ca75b07206985e37e26f111cf1febd30bc749eb1bb6b"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/exact-source-authority/e1e48af331c0d568257e0eb2cbb88c1f19c97cb0/b-class-structural-decomposition-decisions.md",
      "bytes": 3868,
      "sha256": "bee2866be23e0d5fe6f77a245f7f3177522308d5bd3ebbd14fb2baf0d9e37f19"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/exact-source-authority/e4dc2f94b033adbbe3dbb979be88b351d72481c8/contracts/governance/audit/contract.go",
      "bytes": 104939,
      "sha256": "bc1777f387b8908a1173cf2e0238af9f41542016f9bd426a0126fca0916ce174"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/exact-source-authority/e4dc2f94b033adbbe3dbb979be88b351d72481c8/contracts/governance/audit/internal/auditstore/receipt.go",
      "bytes": 1624,
      "sha256": "014341f915069a58822febd009e110a62a9b1ede2bbdfe8916f6c46849b51775"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/full-native-messages.json",
      "bytes": 771576,
      "sha256": "0c0e487810309c114cbc1cf513c70ed5239e0cbcb7db6f70ff10113cf3545eb4"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/input-index-0408.json",
      "bytes": 19648,
      "sha256": "f56f65e604ca3c6b46b962cb034770a25e49a5ec28e517b2fcf31ada684529c6"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/input-index-0418.json",
      "bytes": 31135,
      "sha256": "0a1264f3c0cea80d78a5d69ef0d34f22a867b90738c97c4dc5ad93e0135c2113"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/omac-review-ledger-82ea8c08452f.yaml",
      "bytes": 13065,
      "sha256": "82ea8c08452f336d5a47bc50aee22d9da2f38430af48dc45057e6f7b9c5b7f8c"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/omac-review-report-83c997d95bd8.yaml",
      "bytes": 19510,
      "sha256": "83c997d95bd850e1ae40941d35ae68f8c4c94207929dc15d6d7d982999095ce3"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/AGENTS.md",
      "bytes": 18404,
      "sha256": "2d4ee15006894589233d50c4e057a9d8012fa2fc8048323218deb55cb17715ef"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/delivery/acceptance-and-validation.md",
      "bytes": 299769,
      "sha256": "e84705b5307724f2f8f803ee2f212e32ef144bac079013b419d16713d5edc3ac"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/deploy-ops/deployment-and-operations-design.md",
      "bytes": 32859,
      "sha256": "cea3fe1e0d1d5566e742a14cbde98a401a0d996f08f4085676beb98b2c1820c4"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/detailed/02-project-and-agent-team-detailed-design.md",
      "bytes": 44158,
      "sha256": "77e98399e609bb677e18c6c207767899c952daade5ed5dca226c98e984ad394b"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/detailed/03-workflow-platform-core-detailed-design.md",
      "bytes": 70846,
      "sha256": "3b34e3dbee0e13e31a9cdb004631bac2ef1a4b8f7452ff3d87b35533742a2156"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/detailed/05-kubernetes-native-control-plane-detailed-design.md",
      "bytes": 52824,
      "sha256": "05ef0dfbf66daf68c7ae9863701485aa40a2d24e898ea3743a33463515fac97d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/detailed/06-agent-runtime-detailed-design.md",
      "bytes": 49187,
      "sha256": "b186953d7cd58e239f759ed7160b904d2dccc0d265746175135843ffdd58e5e4"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/detailed/08-component-and-extension-detailed-design.md",
      "bytes": 42136,
      "sha256": "6bc50c99a5066ef613537ea14a8a99512f433405ab67afb2b09d98b187411f04"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/detailed/09-governance-and-security-detailed-design.md",
      "bytes": 81529,
      "sha256": "112d7a6ff48ac97d6a8779fbd27aa88beb99d1b63f8a295a39e921c559594934"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/detailed/10-web-api-cli-detailed-design.md",
      "bytes": 183512,
      "sha256": "6883d10c9f09faa03c055c7a12ec53c8cbfdf223855b655b12f0df63d43c6f39"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/detailed/11-software-delivery-detailed-design.md",
      "bytes": 66620,
      "sha256": "96ab602d53ef516250f41d472f093428f8037cb9b16fbf25b4e90f2246b75e6e"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/design/open-agent-cluster-overview-design.md",
      "bytes": 102981,
      "sha256": "d0132d814dac38f21fb8dc75cefea3c110acd4dffb15784291bf59d6be45afe7"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/references/conventions.md",
      "bytes": 14658,
      "sha256": "184bda55ad6432844dbe701af63d7c4a544c360e367fbf543e67e84840482c25"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/references/execution/agent-runtime.md",
      "bytes": 38015,
      "sha256": "466c54051d655d562c1afe97e6c3828546edeb6a86284634ef87c5ee95d2891d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/references/extension/component-governance.md",
      "bytes": 25461,
      "sha256": "c05aceee0bc3d826c0719ad278f27492473a83018d174099786c272ce240f2d0"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/references/extension/plugin-contracts.md",
      "bytes": 17042,
      "sha256": "fcd02305d50c12640bec7de64b25a84f3c1c6d2ca169eae81073448b5038be6b"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/references/governance/security-and-enterprise.md",
      "bytes": 63725,
      "sha256": "d4b310c4491e6ff0880bf7dc4512e61c20455fd0277596c34284124a98715a44"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/references/project-and-team/project-and-agent-team.md",
      "bytes": 45342,
      "sha256": "cb8228f14011cf36df8af2cef401b2e157f7ae10c598f7e8de42faee3e52321d"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/references/software-delivery/artifacts-release-and-deployment.md",
      "bytes": 33518,
      "sha256": "af63916ce4dde95e6a6953efc4fcde7e32b4287184c6521b5920aaf193908a27"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority/docs/references/workflow/workflow-and-execution.md",
      "bytes": 36262,
      "sha256": "8c9b4fff0ad48c67d5ef61871799f2042b995aa68e92c602d902d83c2cee3f40"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/owning-authority-supplement.json",
      "bytes": 772,
      "sha256": "5105eb1ea3d373f20cea6b8fe3bd4d71041467b8c78322fbf308356f963ea8e5"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/partial-working.patch",
      "bytes": 98409,
      "sha256": "a1ef484bcbda629c996302a72cbb23ab4dab417eb71a9f3010d45c01558981aa"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/required-source-reference-capture-0432.json",
      "bytes": 2166,
      "sha256": "c8b43b93932caa84b8693d266e1965c2b383e94a85f693f5ab5a85bffe3b2c75"
    },
    {
      "path": "/tmp/oac-mcp-production-owner-bound-20261004/worktree-status.txt",
      "bytes": 198,
      "sha256": "e9503dc3f2bd27292084c3a92df48b845a6728aef7ab3d0f8472de5464576a5b"
    }
  ],
  "count": 374,
  "bytes": 22369122,
  "all_original_packet_bytes_sha_exact": true,
  "mechanical_preservation_not_Product_verdict": true
}

