# release-artifact-tooling evidence-boundary amendment trigger

## Current state

- Manifest: `.omac/open-agent-cluster.yaml`
- Blocked node: `release-artifact-tooling`
- Existing work item: `152d735a-c373-4967-8ae0-45c191de2eff` (AITEAM-808)
- Existing implementation PR: OAC PR #5
- The node is self-blocked after a Worker interpreted Reviewer feedback as requiring downstream production release resources.

## Confirmed design intent

The original Orchestrator deliverable and the already accepted system-release-boundary amendment describe this node as the foundational deterministic `system-release-tooling` delivery boundary. It packages the tooling source itself and verifies the tooling with complete, executable fixtures under `tests/release-tooling/**`.

Real platform schema migration bundles, workload manifests, trusted release fixtures, system-release assembly, platform release evidence, integration release validation, and final acceptance are authored by later downstream nodes in the existing DAG. This node must not wait for those downstream production deliverables.

## Valid Reviewer findings that remain in scope

The node must not satisfy its contract through source-string assertions, hard-coded metrics, no-input verifier success, fabricated command execution, incomplete tool runtime dependencies, or an archive whose format does not match its declared extension. Positive and adversarial fixture tests must execute the actual tooling behavior and prove the declared rejection conditions.

## Boundary conflict to correct

Reviewer feedback also requested concrete final installation resources and the complete production system-release closure from this foundational node. Those production artifacts are owned by downstream nodes and are not available through this node's transitive upstream dependency closure. Treating them as current-node inputs caused an invalid platform-level block instead of bounded Worker rework.

## Requested amendment outcome

Use the current OMAC typed contract-boundary mechanism to remove this ambiguity while preserving the approved DAG and existing work item:

- Amend only the minimum nodes necessary to express an unambiguous producer/consumer relationship.
- Declare the appropriate evidence mode for `release-artifact-tooling` so complete executable fixtures are valid evidence while fake or no-input evidence remains invalid.
- Declare the artifacts this node owns. The running legacy Manifest's already-completed upstream producer nodes do not yet declare typed `produces`, so preserve their existing dependency semantics by omitting the `consumes` field entirely (`transitional-upstream`). Do not emit `consumes: []`, which would falsely assert that the verification commands use no upstream inputs, and do not invent dependencies on downstream production artifacts.
- Make allowed inputs, forbidden downstream inputs, and owned outputs explicit in the node responsibility summary.
- Preserve the existing objective, verification strength, issue identity, implementation PR, history, and downstream node responsibilities.
- Do not restructure the DAG, recreate completed nodes, move final release assembly into this node, or weaken the valid Reviewer findings.

The amendment must be derived from all authoritative design documents supplied through `--docs docs/`, the current manifest, and the previously accepted amendment evidence. If those authorities conflict, stop with an explicit decision instead of silently choosing a new product boundary.

## OMAC compatibility correction

OMAC merge commit `54ed7e4dbb1613e71db577ab64b66a750f772904` distinguishes three input policies:

- omitted `consumes`: transitional use of inputs from transitive upstream dependencies;
- `consumes: []`: explicitly no external inputs;
- non-empty `consumes`: exact typed allowlist whose producers declare matching outputs.

For this amendment, use the first policy by omitting `consumes`. The existing verification commands consume repository contracts and tooling delivered by completed upstream nodes, while those legacy nodes cannot be retroactively given complete typed producer contracts through this implementation-affecting amendment. Non-upstream and downstream production inputs remain forbidden.
