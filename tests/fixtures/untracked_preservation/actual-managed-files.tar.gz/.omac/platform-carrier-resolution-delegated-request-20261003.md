## Latest runtime correction after factual authorization handoff

Old SDKDeveloper01a101b0 stopped12:21:35 after misreading the historical member authorization hold; no repaired new evidence was submitted. SoleRunner31684/31680 naturally exited12:21:26 return20 before coordinator SIGINT (ProcessLookupError means already dead, no Agent was cancelled). Coordinator at0SDKactive handed off latest direct delegation, consumedabcdhistory and fullnew0ba/89ff independent feedback; supportedSDKauthoringretry exit0 preservedabsolute1/2/0baseline0/0/0 and allfacts. A bounded normaldagrun maxparallel1/maxround1 dispatched newactualUbuntuDeveloper01a101bf-006b-7412-af52-258d6979a7cd at12:31:03, created/started12:30:57, and exited10 normally. That SDKAgent is now the healthy execution to preserve; no normalRunner remains during this amendment. The paragraph below describing old01a101b0 as healthy is historical and superseded by this exact correction.

Bound input snapshot: /tmp/oac-platform-carrier-delegated-bound-inputs-20261003/current contains the current manifest/config/acceptance/requiredcontracts and owning docs. Sibling authority/worker/pinned directories preserve the fullold/newreports, delegation/decisions and actual untouched dirtysource/fullpinnedtests. This is input transport, not apply authority. New target .omac/platform-carrier-resolution-delegated-reviewed-20261003.yaml. Existing rejected partial6f must not be applied.

# Sufficient Platform carrier restoration under delegated internal decision authority

Latest direct human instruction supersedes the earlier individual human approval/selection requirements for OAC internal choices. It authorizes the coordinator to decide against OAC's owning design and goals. This is NOT a fabricated human selection, not a product implementation verdict, and not permission to apply the rejected partial candidate. No OAC code/contract implementation has been done by the coordinator.

Produce a concrete, complete sufficient revised running-DAG amendment through the existing OMAC amendment route. Supersede terminal rejected amendment AITEAM1049 /01a1014d-7cf8-71d6-805d-644338b3ffb1, not the canonical old assessment. The fresh independent rejection report3c30/18849 and ledger64ee/8923, rootBLK-8b075c79846f, are retained in full. Rework Planner01a1017a explicitly stopped for D1-D4 directions; those directions are now provided below. Do not repeat the same partial6f candidate, generic assessment, plan route, empty operations, unchanged resume or another stop asking the human to approve an internal choice.

## Direct human delegation (verbatim, authority SHA9512a6735dc4fea22961757d58bf2cceabc787186675373757fc052b72307db4)

```json
{
  "schema": "oac.user-delegation/v1",
  "at": "2026-10-03T12:23:39.572483+00:00",
  "source": "Direct human message in the current OAC coordination thread",
  "user_text": "后续此类无需我批准和选择，请你根据 oac 的设计和目标，帮我进行决策，只有无论如何都需要我提供外部依赖信息才能继续推进的需要问我，其他的问题你都基于 oac 项目的理解进行判断和决策",
  "scope": "Coordinator decides OAC internal product/architecture/owner/contract/recovery/approval choices based on authoritative OAC design and goals, including current Platform D1-D4. Ask only when indispensable external dependency information must come from the human. Supersedes prior per-item human approval requirements for these internal decisions. Independent Planner/Reviewer, exact source proof, single writer, supported operations, budgets and tests remain mandatory. Does not turn a rejected proposal into a pass; no OAC implementation by coordinator. Workspace external information and existing explicit deferral remain unresolved."
}
```

## Coordinator decisions under that delegation (SHA9c45d89684cdaf6e1622d27f2a6d21ec6c0e40c58bce50b1d3bc21c35deaf5f3)

```json
{
  "schema": "oac.coordinator-decision/v1",
  "at": "2026-10-03T12:23:39.572483+00:00",
  "authority_file": "/tmp/oac-internal-decisions-delegation-20261003.json",
  "authority_sha256": "9512a6735dc4fea22961757d58bf2cceabc787186675373757fc052b72307db4",
  "not_direct_human_selection": true,
  "source_issue": "01a1014d-7cf8-71d6-805d-644338b3ffb1",
  "source_blocker": "BLK-8b075c79846f",
  "decisions": [
    {
      "id": "D1",
      "choice": "Use current typed Project configuration snapshot. Distinguish absent required input from valid numeric revision zero at the input/serialization boundary; retain exact Project/configuration digest, typed repository/environment/capability inputs and immutable snapshot provenance. Do not resurrect unpublished prototype string fields.",
      "authority": [
        "docs/design/open-agent-cluster-overview-design.md#3",
        "docs/design/detailed/03-workflow-platform-core-detailed-design.md#21-workflow",
        "docs/references/project-and-team/project-and-agent-team.md#1-project",
        "docs/references/workflow/workflow-and-execution.md#1-workflow"
      ]
    },
    {
      "id": "D2",
      "choice": "Schema is required for formal Artifact and must reject missing or incompatible schema through its legitimate owner. Producer evidence may use the current exact author-lineage, typed provenance and producing Run/Component facts when they establish the same ownership/identity/digest assertions; no redundant legacy field solely for compatibility, no weakening of missing producer proof. Authorize minimal compensating schema/evidence owner work identified by the Planner.",
      "authority": [
        "docs/design/detailed/03-workflow-platform-core-detailed-design.md#24-artifact",
        "docs/references/software-delivery/artifacts-release-and-deployment.md#1-共同-artifact-语义"
      ]
    },
    {
      "id": "D3",
      "choice": "Use current CausedBy identity with complete typed immutable source records establishing allowed category, exact ID and digest. Enforce all declared Question/Artifact/Gate/command causal cases and reject missing, unknown, mismatched, unproved or cross-subject facts. Answer-only validation or a nonempty string is insufficient. Planner must supply a complete executable mapping and narrow compensating owner if current validation cannot enforce it; minimal typed boundary corrections consistent with the owning reference are authorized, no unneeded legacy field restoration.",
      "authority": [
        "docs/design/detailed/03-workflow-platform-core-detailed-design.md#27-decision",
        "docs/references/workflow/workflow-and-execution.md#61-decision-与澄清"
      ]
    },
    {
      "id": "D4",
      "choice": "Use current Plan model retaining executed WorkUnit definitions in the successor Plan and immutable historical Plan/Run/Lineage/evidence. Obsolete remains restricted to never-executed nodes. Adapt the pinned historical fixture to the current retention model while proving its original preservation/failure invariants; do not permit removal/Obsolete of executed responsibility or reopen completed nodes.",
      "authority": [
        "docs/design/detailed/03-workflow-platform-core-detailed-design.md#23-workunit-的-plan-来源",
        "docs/design/detailed/03-workflow-platform-core-detailed-design.md#53-计划变化",
        "docs/references/workflow/workflow-and-execution.md#8-workunit-状态与主转换"
      ]
    },
    {
      "id": "input-artifact-kind",
      "choice": "Workflow InputArtifactIDs carries Artifact identities only; keep DecisionIDs separate. Authorize the narrowly scoped contextual admission tightening with real independent implementation review.",
      "authority": [
        "docs/references/workflow/workflow-and-execution.md#1-workflow"
      ]
    }
  ],
  "application_boundary": "Do not apply rejected6f partial candidate. Planner must deliver a sufficient complete minimal amendment with all original-to-current scenario/failure-cause mappings, narrow owners/deps/unique exact artifacts and tests; fresh independent review and current CAS/stage/budget checks before coordinator decision to accept/apply. Preserve all64done, original29Tests14helpers, original4commands/package90, budgets/history/source evidence. If additional internal choices emerge, propose a concrete recommendation grounded in owning design; coordinator resolves them under this delegation, no repeated human-choice stop. Only genuinely absent external inputs need escalation."
}
```

These decisions select current authoritative semantics, not compatibility with unpublished prototypes. For each D1-D4 provide the exact original-to-current carrier, valid/invalid input, assertion and expected failure-cause mapping. Retaining names alone or unrelated negative assertions cannot close the original aggregate blocker. A wire/DTO must distinguish required absence from legal zero at its real input boundary; an in-memory zero assertion does not prove that. Producer proof must trace the actual producing responsibility and exact subject/digest; optional/malformed-present tests do not replace missing-required negatives. Decision must cover all legitimate cause kinds, not only Answer/Question. Executed historical WorkUnits must remain intact while the new active Plan carries the correct retained definitions. Restore same-carrier omissions including the original JSON-unmarshal negative.

Identify the minimal legal production owners needed for every unresolved case, including Artifact schema-requiredness and Workflow Artifact input kind. Use narrow compensating successors after the corresponding merged producer; never reopen/overwrite a done node. Any new owner must name concrete scoped source files, real conformance/negative tests, exact commands, uniquely published head-bound artifacts, independent Reviewer and upstream ordering. The aggregate stays test-only and depends on real independently merged owners before complete semantic restoration. Do not duplicate truth, introduce a new generic framework or extend product scope. If current records cannot support a promised mapping, include the actual minimum design/owner correction with its concrete reason and complete affected owning-document/reference/acceptance path; coordinator can decide additional internal tradeoffs under the attached delegation, so do not leave an unresolved internal choice as a substitute for a sufficient proposal.

Preserve all178 current nodes/all64done full objects, original BLK-30432e7dcdee report00483/23836+ledger4d943/18413, every29Test/14helper/positive-negative scenario and failure cause, original4commands/fullpackage90/deterministic packaging. No budget refund/clear/limitchange: Platformabsolute20/12/0 acceptedbaseline20/12/0, Ext20/19/0/direct0/4/0 and other baselines/history intact. Keep frozen Kernel bytes and no unknown/provenance/security/quality weakening. Exact current stage/CAS/recovery/minimal-derived set must be independently checked. No implementation or apply by Planner/Reviewer. Coordinator may accept/apply the freshly reviewed sufficient minimal result after exact current checks under the latest delegation; no further individual human approval is needed for an internal OAC choice.

SDK is independent: requestabcd is already consumedstep8, no replay/reprepare. New SDK independent Reviewer01a1019d completed12:14:04 reject newBLK-b1b208243999 publication semantic checkpoint overwritten by full suite; priorBLK309source mismatch fixed. Fullreport0ba346/132746+ledger89ff/12931 are retained. NormalexistingUbuntuDeveloper01a101b0-6066-788e-92f1-2932a56a8d18 is healthy running, started12:14:58; all23commands/SDK85/wholeSDK90/Host90/PR90sourceandhistory unchanged. Do not comment, cancel, unassign, mutate SDK or consume any new submission while this amendment controller owns the single control-write window. SDK execution Agent may continue. Kernel20/20/20 sixroots and Audit original fullfreshHEADuncacheddouble90 after actualSDKindependentmerge remain. Workspace external environment authorization is still deferred; no live operations.

## Full new independent rejection

review_protocol: omac.review/v2
review_goals:
- Independently review the exact submitted running-DAG amendment against all eleven
  formal obligations and the source-bound request, without applying it or changing
  shared state.
- Check the complete operations, producer ownership, original regression authority,
  minimal recovery and counter preservation; distinguish static amendment validity
  from complete executable restoration.
- Check all before/after acceptance responsibility rows and retain every original
  aggregate regression and historical blocker obligation.
diff_reviewed: true
tests_rerun: true
integration_tests_rerun: true
coverage_checked: true
full_review_completed: true
summary: REJECT. The two operations are structurally valid, preserve completed/runtime
  facts and correctly route the reported Artifact-input predicate to a compensating
  Workflow admission owner. However, the proposal explicitly leaves D1-D4 unresolved
  and says it is not sufficient to resume the complete pinned aggregate suite. A schema-requiredness
  discrepancy and three carrier/fixture decisions have no approved resolution or executable
  compensation path in these operations. Independent review cannot turn this known
  partial topology repair into a passed sufficient recovery amendment. No project
  code, live manifest, counters, controller, SDK hold or platform recovery was changed.
reviewed_deliverable:
  comment_id: 01a1016b-5503-7df4-aa69-b67fb4ff10fd
  attachment_id: 01a1016b-5496-7bcf-a7f1-b7f479ca76cd
  sha256: 6f96c57cb45fe3a8e4cadb9c31ae7495bbbfbc543188845164670dec9e890844
  bytes: 39283
  filename: omac-deliverable-6f96c57cb45f.md
environment:
- Current OMAC amendment/reviewer context was refreshed before report preparation;
  task remains review/in_review and deliverable SHA256 is unchanged. No env_setup
  was supplied for this amendment.
- The transported current manifest is the attempt-bound input, not live apply authority.
  The managed manifest-runtime checkout is not used as the amendment base.
- Only the amendment contract commands were executed locally. No OAC Go tests, security
  experiments, producer rework, controller, retry or apply was run. Future owner/aggregate
  verification is not reported as executed.
- OMAC uses its installed pipx interpreter. In-memory proposal validation, complete
  candidate diff, responsibility matrix and recovery analysis did not write any manifest.
verification_results:
- command: omac dag check .omac/open-agent-cluster.yaml --no-review
  exit_code: 0
  result: Lint passed on the bound 178-node manifest.
- command: omac dag show .omac/open-agent-cluster.yaml --output json
  exit_code: 0
  result: Complete manifest JSON parsed; integration gate running-dag-amendment was
    independently reproduced.
- command: In-memory OMAC validate_proposal / _apply_definition / _minimal_rerun and
    responsibility_matrix on bound manifest and authoritative acceptance document
  exit_code: 0
  result: No proposal validation errors. Candidate 179 nodes. Exactly one existing
    node changes; all 64 done objects and meta are identical. Both computed 61-row
    matrices exactly match formal before/after obligations. Minimal authoring set
    is new admission owner, aggregate, contracts-extension and direct-deployment;
    no review/merging or immutable downstream recovery.
- command: bash -n for all seven new-owner verification commands; ast.parse for embedded
    Python checks
  exit_code: 0
  result: All seven commands parse. This checks syntax only, not future product execution.
coverage_assessment: Current amendment contract coverage_gate=0. Future admission
  owner retains >=90% aggregate.go statement coverage and six named subtest run/pass
  assertions; aggregate retains its four original commands, complete-package >=90%
  coverage and unchanged deterministic packaging gate. No fresh product coverage is
  claimed.
acceptance_matrix_assessment:
  flow_count: 61
  business_action_count: 495
  full_owners: Every flow retains exactly one full owner, final-acceptance-closeout.
    All original contribution owners/counts are unchanged.
  gaps: No missing/unknown business Actions or unreachable contribution owners before
    or after.
  dependency_change: Every full-owner closure adds only contracts-platform-resource-input-artifact-admission,
    with no removed node. Only UJ-WORKFLOW-001 and UJ-DECISION-001 acquire that additional
    trace node. No full-flow claim or Action contribution is assigned to the new leaf.
  historical_corrections: None; the formal historical_contract_corrections list is
    empty.
runtime_assessment:
  base_definition_sha256: 5003e2197f8e799ed9b51205422917b75784f22889875019e2f0eaec1470d5f1
  candidate_definition_sha256: a60ae625f1c5eefe20a78abacc2b75612bb151e25054cb498be1854df3204180
  changed_fields: Existing aggregate changes only blocked_by and contract objective/consumes.
    Its worker, test-only scope, all other contract fields, original four commands
    and complete gate remain identical. New owner touches aggregate.go and aggregate_test.go
    only, after merged capability/convergence prerequisites; it does not reopen the
    completed convergence owner.
  stages: New owner starts authoring; aggregate needs authoring after the real new
    upstream implementation and evidence, not review/merging of the old failed/unsealed
    head. OMAC derives authoring recovery for exactly the two started successors contracts-extension
    and direct-deployment; they are affected, not claimed unaffected. All others retain
    their objects and natural dependency barriers.
  counters: Fresh work-show reads confirm aggregate absolute worker/review/merge 20/12/0,
    extension 20/19/0 and direct-deployment 0/4/0. In-memory candidate preserves all
    meta/accepted baseline authority. No refund, limit increase or baseline clearing
    is proposed or performed.
  apply_boundary: Current fresh Store/control/Run and definition/evidence CAS remain
    required at any later authorized apply. This review is not a current-state apply
    witness or human approval.
artifact_assessment:
- Fresh GH reads confirm PR85 MERGED head 758a61cbcf54549038cec36c0e258942a8fa97e4,
  merge d532ec3c36bcc5dd7e721b1d2978a7e78a573175; PR92 MERGED head dc0dc026e1b04516aa726cb7377fc1149abec5e8,
  merge 55181020a9b8c1e45de2d095f45646aac1bc22f8. PR8 remains OPEN at 60440b198d0ed5eda2f1d66371b9504a4ec2f68b,
  base main.
- All six declared producer work-show reads completed with exit 0; scopes and stored
  pass/pass-with-nits history agree with the proposed compensating ownership. Completed
  histories are unverified-history, not a new product verdict.
- Independent local byte/hash checks matched both pinned tests, untouched 72264-byte
  dirty patch (5a3c940c954c1ffcee671f1f89b8e444666979700a275f027c6d044b5c4c78d0),
  original report (00483ca42e8d2d98741e4fa578967ce16ea8fedd6b480b10e2e0bd5f5c49567d/23836
  bytes), ledger (4d943d149b4489939b3b70bea0de0f268ec9b9c9b54fd458e2fc61c17f29357c/18413
  bytes), and both frozen Kernel source digests.
- The proposal explicitly reports unrecovered historical Run/Dispatch/Convergence/Capability
  physical artifact paths. This reviewer did not recover those bytes and does not
  certify their hashes or historical passing execution. Materialization remains fail-closed
  before consumption; done facts must not be rewritten to conceal missing evidence.
  Future owner must publish retrievable exact-head artifacts.
historical_regression_disposition: 'The current amendment has no prior_open_blockers,
  so prior_blocker_results is empty. This does not close the aggregate historical
  BLK-30432e7dcdee / pinned-regression-semantics-not-preserved: that original report/ledger
  remains intact and open. All 29 Test functions and 14 helpers remain by name in
  the transported dirty tests, but names are not semantic closure. Static comparison
  still shows the project-revision negative inverted to a zero-positive and the JSON
  unmarshal negative missing. Some ownership/dispatch regressions have improved; none
  authorizes marking the complete restoration passed.'
acceptance_mapping:
- acceptance: The amendment is schema-valid and changes only the minimum required nodes
  status: pass
  evidence: In-memory OMAC validation has no errors; one narrow compensation and one consumer update, with no unrelated changes. Complete restoration sufficiency remains blocked under dimension:regression.
- acceptance: Done/merged facts and unaffected node runtime state remain immutable
  status: pass
  evidence: All 64 done full objects and all unaffected node objects/meta are identical in the candidate; no runtime fields are patched.
- acceptance: The output states why each changed node resumes at review, authoring, or merging
  status: pass
  evidence: Independent minimal-rerun agrees with authoring for the new owner/aggregate and the two derived started successors; no review or merging recovery.
integration_gate_mapping:
- gate: running-dag-amendment
  status: pass
  source_of_truth:
  - .omac/open-agent-cluster.yaml
  - docs/design/open-agent-cluster-overview-design.md
  - docs/design/detailed/03-workflow-platform-core-detailed-design.md
  - docs/references/workflow/workflow-and-execution.md
  delivery_goal: reviewable minimal manifest diff
  commands:
  - cmd: omac dag show .omac/open-agent-cluster.yaml --output json
    exit_code: 0
    summary: Complete bound manifest JSON parsed; independent in-memory proposal validation and full diff checks pass.
  notes: Static control-plane gate only; this is not product conformance or authority to apply the knowingly incomplete restoration proposal.
prior_blocker_results: []
nits: []
obligation_results:
- obligation_id: dimension:authority
  status: pass
  evidence: Read the owning overview, detailed03 and Workflow reference, exact amendment
    and original reject/ledger. Workflow reference:17-18 explicitly separates Artifact
    inputs from DecisionIDs; detailed03:159 permits selected Artifact/Decision reuse
    through those separate carriers. TypedReference.Validate remains general. Specific
    human approval of the fresh behavior tightening remains mandatory; existing B/capability
    permission is not substituted.
- obligation_id: dimension:structure
  status: pass
  evidence: OMAC validate_proposal returned []; full candidate/invariant comparison
    and typed artifact lint passed. Operations are exactly one add and one aggregate
    update, with no done-node, ownership-transfer, literal or acceptance-migration
    operation. Structural validity does not resolve the independently reported regression-completeness
    blocker.
- obligation_id: dimension:execution
  status: pass
  evidence: Both current-task verification/integration commands returned exit 0. All
    seven future-owner shell/Python commands parse and include named run/pass/no-skip
    and coverage checks. No future producer or aggregate product execution was required
    by this amendment contract or claimed.
- obligation_id: dimension:ownership
  status: pass
  evidence: Fresh completed producer scopes place Workflow.Validate in convergence-owned
    aggregate.go, not capability-owned plan.go. The compensating successor owns aggregate.go/aggregate_test.go
    after that merged chain; aggregate retains its two test-only paths and release
    packaging identity. General TypedReference, frozen Kernel and other producers
    are outside the new owner scope.
- obligation_id: dimension:evidence
  status: pass
  evidence: Deliverable refresh and pinned/report/ledger/patch/Kernel hashes matched.
    Six fresh producer context reads and GH merge observations support lineage. Missing
    historical physical outputs are explicitly not certified and remain a consumption
    precondition; no synthetic passing evidence or historical seal is introduced.
- obligation_id: dimension:regression
  status: fail
  evidence: 'FAIL: the submitted reason itself labels D1-D4 unresolved and prohibits
    applying this candidate until resolution. Independent carrier/source comparison
    confirms that the new owner cannot repair schema.go requiredness, select the source-revision/configuration
    mapping, supply a general Decision cause mapping, or resolve the historical Plan
    fixture. Keeping the original aggregate obligations while leaving these legal
    execution paths undecided does not provide the requested sufficient source-bound
    recovery.'
- obligation_id: acceptance:Done/merged facts and unaffected node runtime state remain
    immutable
  status: pass
  evidence: In-memory candidate retains every one of the 64 done full objects, every
    other existing node object except the aggregate definition, and complete meta/baselines.
    Derived successor recovery is explicitly bounded to contracts-extension/direct-deployment;
    no runtime field is in any operation.
- obligation_id: acceptance:The amendment is schema-valid and changes only the minimum
    required nodes
  status: pass
  evidence: 'Static/schema criterion passes for the reported input-kind compensation:
    exactly one new narrow production owner and one existing consumer update, 178->179
    nodes. No unrelated definition or responsibility changes. This is not acceptance
    of semantic sufficiency for complete restoration; see failed dimension:regression.'
- obligation_id: acceptance:The output states why each changed node resumes at review,
    authoring, or merging
  status: pass
  evidence: 'Reason and OMAC independent minimal-rerun agree: authoring for new owner/aggregate,
    derived authoring for two started successors, no review/merging. Aggregate needs
    a fresh rebased submission after actual upstream merge; an unsealed failed delivery
    is not reused.'
- obligation_id: integration:running-dag-amendment
  status: pass
  evidence: The exact gate command omac dag show .omac/open-agent-cluster.yaml --output
    json completed/parsed, and in-memory full proposal/diff validation reproduced
    a reviewable minimal manifest diff without writing the live manifest. This is
    a control-plane/static gate, not product conformance.
- obligation_id: acceptance-responsibility:amendment-matrix
  status: pass
  evidence: 'Independently regenerated and exactly matched both formal 61-flow matrices:
    495/495 business Actions contributed, unchanged unique full/contribution owners,
    no gaps or unreachable owners, one added dependency per closure and two trace
    additions only. No historical correction audit entry exists.'
blockers:
- root_cause_key: source-bound-pinned-carrier-resolution-incomplete
  obligation_id: dimension:regression
  classification: new
  owner: hermes-orchestrator
  severity: high
  summary: The amendment knowingly leaves four prerequisite carrier/owner resolutions
    open, so the input-only compensating node is not a sufficient executable aggregate-restoration
    proposal.
  impact: After the input admission node merges, the test-only aggregate still lacks
    an approved legal path to preserve all required original predicates. It may stop
    again or substitute non-equivalent assertions. Conversely, a passed amendment
    could be mistaken for authority to resume despite its own do-not-apply caveat.
    Neither historical producer pass nor coverage discharges the original complete
    semantic-restoration obligation.
  evidence: 'The submitted reason D1-D4 explicitly says this candidate is NOT sufficient
    authority to resume the complete aggregate suite and requires a revised proposal
    if more production work is needed. Independent checks: (D1) pinned resource_test.go:168-201
    requires missing source revision/configuration/reference values to reject; current
    schema.go:168-177 uses uint64 ProjectRevision plus project-owned bindings/digests,
    while dirty resource_test.go:343-348 positively accepts zero. Neither the preserved
    aggregate contract nor the new aggregate.go-only owner settles this mapping. (D2)
    owning artifacts-release-and-deployment.md:18 requires schema; schema.go:412,442-446
    permits nil Schema. Current Artifact Producer is likewise optional and author
    lineage/component/provenance inputs are separate carriers; absence and malformed-present
    cases are not interchangeable. Neither operation supplies a schema.go compensating
    owner or an approved equivalent evidence mapping. (D3) pinned resource_conformance_test.go:1249-1259
    checks closed typed Decision causation; decision.go:21,85-87 carries only a nonempty
    string, and convergence.go:613-625 resolves only Answer causes against Question
    records. The dirty Answer-only unrelated-observation check does not establish
    general cause-category closure. No approved general owner-evidence mapping is
    specified. (D4) pinned resource_conformance_test.go:716-748 allows an executed
    retained nonobsolete WorkUnit whose node is removed from the active Plan; plan.go:718-727
    requires active membership and PlanTransition:821-886 removes only with never-executed
    Obsolete evidence, consistent with detailed03:469-477. The proposal leaves the
    precise retained-history mapping versus reviewed Plan change undecided. These
    are separate predicate decisions under one incomplete source-bound recovery root;
    they are not permission to weaken tests or automatically reopen done producers.'
  required_fix: Obtain and bind specific human decisions for the exact genuinely incompatible
    carrier/predicate choices, with an original-to-current scenario mapping that preserves
    expected failure causes rather than labels. Resolve the schema-requiredness discrepancy
    through its legal compensating production owner (or an explicitly approved authoritative
    contract resolution), and settle the source-revision/configuration, Decision-causation
    and historical Plan mappings against current immutable owners. If production compensation
    is necessary, submit a revised minimal amendment naming actual narrow owners,
    review/test commands, unique artifacts, upstream ordering and aggregate consumes/dependencies;
    preserve all 64 done full objects, histories, original four commands, baseline
    authority and test-only aggregate scope. If no production change is needed for
    a case, supply the concrete approved entry-point/fixture/predicate mapping and
    evidence, not another deferred decision. Independently review the complete revised
    proposal before apply; do not apply or resume the current partial candidate. The
    future aggregate must still independently restore and prove every original case/helper,
    including remaining same-carrier omissions such as JSON unmarshal failure, and
    discharge BLK-30432e7dcdee only after fresh exact-head full verification.


## Full rejection ledger

schema: omac.review-ledger/v2
cycles:
- round: 1
  subject_digest: cc48140ca0457097f9d68f599d2115388dbd2708d0bf6afca5bddf7e35e1a12a
  report_digest: e0f647941dc0f59647e16e812f08da3d0e72c49fee3ecd1fb7c1f65eb924f5a5
  verdict: reject
  obligation_results:
    dimension:authority: pass
    dimension:structure: pass
    dimension:execution: pass
    dimension:ownership: pass
    dimension:evidence: pass
    dimension:regression: fail
    acceptance:Done/merged facts and unaffected node runtime state remain immutable: pass
    acceptance:The amendment is schema-valid and changes only the minimum required nodes: pass
    acceptance:The output states why each changed node resumes at review, authoring, or merging: pass
    integration:running-dag-amendment: pass
    acceptance-responsibility:amendment-matrix: pass
  new_count: 1
  fixed_count: 0
  regressed_count: 0
  unchanged_count: 0
  open_count: 1
  prior_open_blocker_ids: []
  open_blocker_ids: &id001
  - BLK-8b075c79846f
  reported_blocker_ids: *id001
  blocker_facts_schema: omac.review-cycle-blocker-facts/v1
  blocker_facts:
  - blocker_id: BLK-8b075c79846f
    root_cause_key: source-bound-pinned-carrier-resolution-incomplete
    obligation_id: dimension:regression
    summary: The amendment knowingly leaves four prerequisite carrier/owner resolutions
      open, so the input-only compensating node is not a sufficient executable aggregate-restoration
      proposal.
    evidence: 'The submitted reason D1-D4 explicitly says this candidate is NOT sufficient
      authority to resume the complete aggregate suite and requires a revised proposal
      if more production work is needed. Independent checks: (D1) pinned resource_test.go:168-201
      requires missing source revision/configuration/reference values to reject; current
      schema.go:168-177 uses uint64 ProjectRevision plus project-owned bindings/digests,
      while dirty resource_test.go:343-348 positively accepts zero. Neither the preserved
      aggregate contract nor the new aggregate.go-only owner settles this mapping.
      (D2) owning artifacts-release-and-deployment.md:18 requires schema; schema.go:412,442-446
      permits nil Schema. Current Artifact Producer is likewise optional and author
      lineage/component/provenance inputs are separate carriers; absence and malformed-present
      cases are not interchangeable. Neither operation supplies a schema.go compensating
      owner or an approved equivalent evidence mapping. (D3) pinned resource_conformance_test.go:1249-1259
      checks closed typed Decision causation; decision.go:21,85-87 carries only a
      nonempty string, and convergence.go:613-625 resolves only Answer causes against
      Question records. The dirty Answer-only unrelated-observation check does not
      establish general cause-category closure. No approved general owner-evidence
      mapping is specified. (D4) pinned resource_conformance_test.go:716-748 allows
      an executed retained nonobsolete WorkUnit whose node is removed from the active
      Plan; plan.go:718-727 requires active membership and PlanTransition:821-886
      removes only with never-executed Obsolete evidence, consistent with detailed03:469-477.
      The proposal leaves the precise retained-history mapping versus reviewed Plan
      change undecided. These are separate predicate decisions under one incomplete
      source-bound recovery root; they are not permission to weaken tests or automatically
      reopen done producers.'
    required_fix: Obtain and bind specific human decisions for the exact genuinely
      incompatible carrier/predicate choices, with an original-to-current scenario
      mapping that preserves expected failure causes rather than labels. Resolve the
      schema-requiredness discrepancy through its legal compensating production owner
      (or an explicitly approved authoritative contract resolution), and settle the
      source-revision/configuration, Decision-causation and historical Plan mappings
      against current immutable owners. If production compensation is necessary, submit
      a revised minimal amendment naming actual narrow owners, review/test commands,
      unique artifacts, upstream ordering and aggregate consumes/dependencies; preserve
      all 64 done full objects, histories, original four commands, baseline authority
      and test-only aggregate scope. If no production change is needed for a case,
      supply the concrete approved entry-point/fixture/predicate mapping and evidence,
      not another deferred decision. Independently review the complete revised proposal
      before apply; do not apply or resume the current partial candidate. The future
      aggregate must still independently restore and prove every original case/helper,
      including remaining same-carrier omissions such as JSON unmarshal failure, and
      discharge BLK-30432e7dcdee only after fresh exact-head full verification.
    status: open
    classification: new
    owner: hermes-orchestrator
blockers:
- blocker_id: BLK-8b075c79846f
  root_cause_key: source-bound-pinned-carrier-resolution-incomplete
  obligation_id: dimension:regression
  summary: The amendment knowingly leaves four prerequisite carrier/owner resolutions
    open, so the input-only compensating node is not a sufficient executable aggregate-restoration
    proposal.
  evidence: 'The submitted reason D1-D4 explicitly says this candidate is NOT sufficient
    authority to resume the complete aggregate suite and requires a revised proposal
    if more production work is needed. Independent checks: (D1) pinned resource_test.go:168-201
    requires missing source revision/configuration/reference values to reject; current
    schema.go:168-177 uses uint64 ProjectRevision plus project-owned bindings/digests,
    while dirty resource_test.go:343-348 positively accepts zero. Neither the preserved
    aggregate contract nor the new aggregate.go-only owner settles this mapping. (D2)
    owning artifacts-release-and-deployment.md:18 requires schema; schema.go:412,442-446
    permits nil Schema. Current Artifact Producer is likewise optional and author
    lineage/component/provenance inputs are separate carriers; absence and malformed-present
    cases are not interchangeable. Neither operation supplies a schema.go compensating
    owner or an approved equivalent evidence mapping. (D3) pinned resource_conformance_test.go:1249-1259
    checks closed typed Decision causation; decision.go:21,85-87 carries only a nonempty
    string, and convergence.go:613-625 resolves only Answer causes against Question
    records. The dirty Answer-only unrelated-observation check does not establish
    general cause-category closure. No approved general owner-evidence mapping is
    specified. (D4) pinned resource_conformance_test.go:716-748 allows an executed
    retained nonobsolete WorkUnit whose node is removed from the active Plan; plan.go:718-727
    requires active membership and PlanTransition:821-886 removes only with never-executed
    Obsolete evidence, consistent with detailed03:469-477. The proposal leaves the
    precise retained-history mapping versus reviewed Plan change undecided. These
    are separate predicate decisions under one incomplete source-bound recovery root;
    they are not permission to weaken tests or automatically reopen done producers.'
  required_fix: Obtain and bind specific human decisions for the exact genuinely incompatible
    carrier/predicate choices, with an original-to-current scenario mapping that preserves
    expected failure causes rather than labels. Resolve the schema-requiredness discrepancy
    through its legal compensating production owner (or an explicitly approved authoritative
    contract resolution), and settle the source-revision/configuration, Decision-causation
    and historical Plan mappings against current immutable owners. If production compensation
    is necessary, submit a revised minimal amendment naming actual narrow owners,
    review/test commands, unique artifacts, upstream ordering and aggregate consumes/dependencies;
    preserve all 64 done full objects, histories, original four commands, baseline
    authority and test-only aggregate scope. If no production change is needed for
    a case, supply the concrete approved entry-point/fixture/predicate mapping and
    evidence, not another deferred decision. Independently review the complete revised
    proposal before apply; do not apply or resume the current partial candidate. The
    future aggregate must still independently restore and prove every original case/helper,
    including remaining same-carrier omissions such as JSON unmarshal failure, and
    discharge BLK-30432e7dcdee only after fresh exact-head full verification.
  status: open
  classification: new
  owner: hermes-orchestrator
  first_seen_round: 1
  last_seen_round: 1
  seen_count: 1


## Terminal rework report



独立评审已拒绝上一版，阻塞项为 `BLK-8b075c79846f`：输入校验责任划分正确，但不足以恢复完整回归套件。当前 issue 历史中没有以下决策的人工批准，因此不能重提同一方案或继续应用。

请明确选择：

1. **Project 快照**：采用当前类型化字段，并在对应输入边界区分“字段缺失”和合法 `revision=0`；还是恢复旧版字段与必填规则？
2. **Artifact**：是否批准新增 schema 责任节点，使缺失 `Schema` 必须拒绝？旧版必需的 Producer 证据，是继续要求独立字段，还是允许由当前来源与作者链证据提供等价证明？
3. **Decision 因果**：保留当前 `CausedBy` 字符串，通过完整的类型化来源记录验证类别、身份和摘要；还是恢复类型化 cause 字段？
4. **历史 Plan**：采用当前“已执行节点保留在新 Plan 中，完整保留历史”的模型调整旧 fixture；还是要求支持“已执行且非 Obsolete 的节点脱离活动 Plan”？

这些选择会影响 API、校验规则或原测试预期，不能代替你批准。确认后仍需形成完整的新提案并重新独立评审；本轮未修改产品代码、未应用 DAG，也未恢复聚合执行。

## Historical original source-bound request (prior individual-human-choice requirements/statuses below are superseded by the latest delegated authority/current runtime above; original regression/proof/budget constraints remain)

# Source-bound Platform Workflow input owner request

Produce a concrete executable responsibility/contract/dependency amendment and fresh independent review for the actual terminal v2 report below. This is a different conflict from the already merged capability-admission producer. Do not repeat that applied amendment, reopen completed producers, use plan/generic assessment/unchanged resume, or assume the Worker claim is a product verdict.

Current aggregate contracts-platform-resource / issue1b8e6ca8-4372-4974-a909-8994d0b05990: latest Developer01a1010c-b9d9-7145-b529-55dd2796cd9e completed09:43:36 after work block accepted exit20/terminal stop09:42:51. Native170 messages and fresh Store are preserved. PR8 remains OPEN60440b198d0ed5eda2f1d66371b9504a4ec2f68b; actual local HEAD8b146f789986d20bbab4de1a3e475f2f73de1271/tree2683fbe9808702418e38bd65ae56f6873f959a7c includes Worker rebase, both dirty aggregate test files and full binary patch remain unsubmitted. Coordinator did not edit or rerun OAC tests.

The native focused command exited1 with non-artifact Workflow input was accepted; full package failure is also recorded in full messages. The restored fixed assertion supplies a structurally valid Kind=decision reference to WorkflowSpec.InputArtifactIDs. Read current owning overview, detailed03, exact workflow reference, original pinned66efa tests, entire current source, all producer artifacts/owner contracts and original full reject before judging whether a missing owner implementation, valid API adaptation or new product choice exists. Public reference identifies creation-selected immutable input Artifact identities; independently reconcile that text and concrete typed carrier semantics, do not turn this coordinator observation into a technical decision. Choose and justify actual legal owner/scope/ordering or exact missing decision; no leaf production edits by aggregate's current two-test scope. Existing capability approval is not authority to change InputArtifactIDs or waive a pinned assertion.

Preserve current178 nodes/all64 done full objects and original histories. Original aggregate full report00483ca42e8d2d98741e4fa578967ce16ea8fedd6b480b10e2e0bd5f5c49567d/23836 and ledger4d943d149b4489939b3b70bea0de0f268ec9b9c9b54fd458e2fc61c17f29357c/18413, BLK-30432e7dcdee, all original29 Tests/14 helpers/every positive-negative scenario and failure cause, exact4 commands/package90/deterministic ownership and trace-only integration remain required. Check the complete pinned suite for any further genuine unresolved carrier/scope mismatch now, so a proposal is sufficient and concrete rather than hiding remaining cases. Do not weaken unrelated expectations, add speculative capability, alter frozen Kernel or invent passing evidence. Any compensating production owner must independently implement, review and really merge exact artifacts before aggregate resumes its complete original obligations.

Budget absolute20/12/0 and approved manifest applied baseline20/12/0 stay unchanged; keep all other baselines, SDK hold latestRun01a100a6/verificationa171 and originalc5fa+dddd, Kernel20/20/20 six roots, SDK23/raw85/wholeSDK90/Host90, H/S/d969/history unknown/security/pinnedbytes/all64 done and Workspace deferred live permission. No refunds by clearing or moving baselines. Reviewed proposal must state exact operations, stage/CAS/current snapshots/minimal restoration and actual counter effects; any genuine API/quality/security/product behavior change requires specific human approval of the exact fresh independently reviewed choice before apply. Existing B coordination permission authorizes proposal/review, not this new product decision.

Bound transport /tmp/oac-platform-input-owner-bound-inputs-20261003 on Mac/Oracle contains current full manifest/config/acceptance/all required contracts, full actual worker resource/kernel/project source, untouched dirty patch/pinned tests, latest full native messages/Store/report and old authority history. It is an input snapshot, not current apply authority; use current Store/read ports and exact producer verification/artifacts yourself. SDK OMAC code deployment is separate and will finish before this proposal controller starts; never start a parallel controller or touch SDK. Target .omac/platform-input-artifact-owner-reviewed-20261003.yaml.

## Verbatim current accepted decision

```json
{
  "schema": "omac.decision-required/v1",
  "reason_code": "worker-decision-required",
  "kind": "develop",
  "phase": "authoring",
  "gate": "worker",
  "resume_issue_id": "1b8e6ca8-4372-4974-a909-8994d0b05990",
  "review_context_binding": {
    "generation": "authoring-e77b8b7e3b10680fc478f0fc",
    "contract_sha256": "cafb52cf63058793e7da4e486b77181ce73e09e38147883a186d02e4e7c496be"
  },
  "blocker": {
    "schema": "omac.worker-blocker/v2",
    "reason_code": "owner-decision-required",
    "issue_id": "1b8e6ca8-4372-4974-a909-8994d0b05990",
    "review_context_binding": {
      "generation": "authoring-e77b8b7e3b10680fc478f0fc",
      "contract_sha256": "cafb52cf63058793e7da4e486b77181ce73e09e38147883a186d02e4e7c496be"
    },
    "handoff_generation": "handoff-0ac7bf4a2ff06809",
    "worker": "codex-macmini-newapi",
    "run_id": "01a1010c-b9d9-7145-b529-55dd2796cd9e",
    "summary": "The pinned Workflow input identity regression requires rejecting non-artifact references, but the current Workflow validator accepts them and its production file is outside this aggregate node's write scope.",
    "decision_needed": "Decide whether WorkflowSpec.InputArtifactIDs is artifact-only under the current API. If so, route an authorized aggregate validator change to its owner; if not, explicitly amend the pinned expectation. Do not remove or weaken the retained regression assertion in this test-only node.",
    "contract_ref": "scope_paths",
    "evidence": [
      {
        "ref": "contracts/workflow/resource/resource_conformance_test.go:1179-1182",
        "observation": "TestAuthoritativeProjectionRegressionGuards/immutable_identity_collections_are_closed assigns a structurally valid Kind=decision reference to InputArtifactIDs and requires Workflow.Validate to reject it. The focused command `go test ./contracts/workflow/resource/... -run '^TestAuthoritativeProjectionRegressionGuards/immutable_identity_collections_are_closed$' -count=1` exited 1 with `non-artifact Workflow input was accepted`."
      },
      {
        "ref": "contracts/workflow/resource/aggregate.go:129-137",
        "observation": "Workflow.Validate currently validates each TypedReference and enforces uniqueness by kind and identity, but does not require Kind=artifact. This file is outside this node's two aggregate test-file write paths."
      }
    ]
  },
  "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> contracts-platform-resource"
}
```
