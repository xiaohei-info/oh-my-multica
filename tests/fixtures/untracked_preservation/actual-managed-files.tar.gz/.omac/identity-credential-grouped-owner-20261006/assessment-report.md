# Source-bound grouped Identity/Credential amendment assessment

Root is OAC advancement owner under the latest direct human instruction and Root9512. This report authorizes assessment only, not product verdict, operation approval or budget grant.

Current main is 0dae29d869278750a051cf91272f577639c59b4b. The 102 relevant main files are Git-byte-identical to the immutable 1450 Source packet. The original 163 Identity and 102 Credential packet files have all been physically read and hash-verified; old counts/main labels are historical.

Candidate group: identity-local and credential-store. Verify from complete owning design and current Source whether their canonical RequestContext/evaluated audit evidence and conditional-expiry issues admit one minimal coherent proposal. Grouping is a candidate, never a technical owner verdict. All current DONE producers, including contracts-credential/authz/audit/AgentRun, remain immutable. Do not invent an auth policy, Provider, expiry, proof or second audit store. Do not waive security or contract compatibility.

The present request authorizes only the two held existing nodes. Every actual changed/derived/recovered node must be bound. If the minimal lawful solution needs another existing semantic owner, a new node, published owning-contract alignment or a product boundary decision, stop with its exact Source rationale and proposed necessary bounds; do not fabricate an operation outside bounds or omit derived nodes to fit this request. Root will decide and prepare the next concrete scope.

Use explicit budget_policy: preserve; retain approved authority, absolute and relative consumption/remaining/limits, CAS, all failures and original independent review cycles, full current DONE/meta and consumed264698-step8. No grant, reset, refund, ScopeTransfer, DONE reopening, general assessment, unchanged resume, fake evidence or private write path. One complete Source-coherent proposal and one fresh independent Reviewer must cover every original root, command and ledger; actual apply remains Root-owned after all gates. Root does not author OAC code/design/contracts/tests. The OMAC platform fixer has no OAC planning role.

Read the full overview, detailed09 and10, security-and-enterprise references, authoritative acceptance, source-ownership baseline, owning production Source and original Worker/publication histories. Genuine local fixes claimed by Worker are not independent closure. No Actor/recovery/comment or production modification in this assessment.


## Full original identity-local omac-review-report-2027651b5ad1.yaml
SHA256 2027651b5ad18ad04b65a2fe37c6118e75390919914e363950070359c7a91b9c; bytes 17541

```yaml
{
  "review_protocol": "omac.review/v2",
  "review_goals": [
    "Independently review the full identity lifecycle and Principal-owned locale implementation against current authoritative sources and non-goals.",
    "Reproduce every declared command, integration gate, coverage threshold and packaged-source lineage.",
    "Disposition both prior blockers and inspect the complete source/test/evidence changes for regressions and remaining canonical audit defects."
  ],
  "diff_reviewed": true,
  "tests_rerun": true,
  "integration_tests_rerun": true,
  "coverage_checked": true,
  "full_review_completed": true,
  "reviewed_pr": "https://github.com/xiaohei-info/open-agent-cluster/pull/101",
  "reviewed_head_sha": "ce2e24013d151c41c9d058cb2262f64d8374281a",
  "pr_base": "main",
  "coverage": 90.6,
  "summary": "Reject: both prior blockers are fixed and all six declared commands pass with 90.6% aggregate coverage. Two statically established canonical-audit blockers remain: external request IDs are used as persisted context references, and one-time proof audits manufacture policy/grant provenance. Packaged source reproduces byte-for-byte.",
  "obligation_results": [
    {
      "obligation_id": "dimension:authority",
      "status": "pass",
      "evidence": "Current work-show facts, contract, reviewer/evidence guides and bounded comment threads were checked. Approved locale document hash matches exactly. Cited design/acceptance sections and required security-and-enterprise reference were read, along with upstream identity, SDK, authorization and audit contracts. UJ-IDENTITY-001 is trace-only; no full browser/live acceptance or downstream input was imposed. Source conflicts are explicitly reported under structure and ownership."
    },
    {
      "obligation_id": "dimension:structure",
      "status": "fail",
      "evidence": "Inspected the complete 18-file PR source/test/artifact change set and revised source diff. Lifecycle operations, atomic ports, CAS/idempotency and HTTP routes are implemented. Persisted RequestContext linkage required for canonical audit is absent and replaced by the external RequestID; see identity-audit-context-reference-is-external-request-id."
    },
    {
      "obligation_id": "dimension:execution",
      "status": "pass",
      "evidence": "All six exact contract commands exited 0 independently in the pinned checkout. Fresh package execution used GOFLAGS=-count=1 to exclude cache; identity 89.3%, HTTP 98.4%, aggregate 90.6%. Declared suites exercise transactional rollback, one-time token behavior, operational failure/cancellation versus denial, session revocation/fencing, replay password equivalence and locale authorization/CAS. Focused locale selector has no matching HTTP-package tests; the full package suite covers the HTTP adapter. Passing execution does not resolve the statically identified audit contract defects."
    },
    {
      "obligation_id": "dimension:ownership",
      "status": "fail",
      "evidence": "Principal locale has one query and CAS writer, only PrincipalID/Locale/Revision, no non-Principal or anonymous persisted locale; packaging ownership passed and upstream dependencies are reused. However proofAuditEvent fabricates a parallel AuthorizationPolicy/grant family for proof checks instead of preserving actual canonical evaluated-control provenance; see identity-one-time-proof-audit-fabricates-authorization-policy-provenance."
    },
    {
      "obligation_id": "dimension:evidence",
      "status": "pass",
      "evidence": "PR #101 is open/non-draft against main, references AITEAM-1058 and has the pinned head. Current verification attachment is c6f4b9851daa79d214480300891efc2135334b82fcb3fba77b691030e35df717. All committed manifest source-file SHA-256 hashes match current files. Independently regenerated bundle is byte-identical to committed f7ea40f84c65438263ca708632e1d91cae6a0ce196a88b0eeb5b93b66ee54ec3. Manifest revision 9e2acf9798a558ea9a9301bfedb9354916813ece differs from the PR head only by artifact/verification refresh files. Required artifacts exist and are nonempty. This obligation assesses release-evidence lineage, not the broken runtime context provenance reported under structure."
    },
    {
      "obligation_id": "dimension:regression",
      "status": "pass",
      "evidence": "Both prior blockers are independently dispositioned fixed. Installer error wrapping now preserves operational/cancellation errors, while explicit denial and invalid proof remain closed. Concurrent break-glass replay emits a link only on the branch that committed the challenge. Deterministic tests for both fixes were inspected and executed inside the full declared suite. Complete source and supporting evidence review also identified both new audit roots; historical verdicts were not reused."
    },
    {
      "obligation_id": "integration:identity-local-gate",
      "status": "pass",
      "evidence": "Every declared gate command, metric, artifact and exact source/delivery-goal mapping was reproduced. Coverage is 90.6% and locale tests reject revision conflicts, including the forced CAS-loss branch, with zero accepted conflicts. This pass covers the declared executable gate only; functional delivery is rejected for the two canonical audit findings in structure/ownership."
    }
  ],
  "prior_blocker_results": [
    {
      "blocker_id": "BLK-8646e42ba221",
      "status": "fixed",
      "evidence": "service.go:93-97 and recovery.go:122-130 map only errors.Is(ErrForbidden) to denial, wrap all other installer errors and reject missing proof. The independently executed TestBootstrapInstallerAndPersistenceFailureMatrix and TestRecoveryAuthorizationScopeAndBreakGlassReplayFailures include operational error and cancellation cases and distinguish them from actual denial. Existing credential/governance error propagation and intentional post-commit fallbacks remain intact."
    },
    {
      "blocker_id": "BLK-9a7d286279b9",
      "status": "fixed",
      "evidence": "recovery.go:154-193 resets a created flag for each transaction callback, sets it only after challenge/audit/idempotency persistence succeeds, and attaches the token URL only for created=true. Concurrent replay returns the persisted token-free summary. TestConcurrentBreakGlassReplayOnlyReturnsPersistedToken at failure_paths_test.go:959-1025 uses a deterministic ID barrier, asserts one persisted challenge, one matching emitted link, one audit and a token-free subsequent replay; it passed in the uncached full declared suite."
    }
  ],
  "acceptance_mapping": [
    {
      "acceptance": "UJ-IDENTITY-001",
      "status": "pass",
      "scope": "trace-only module behavior; not full-flow or live acceptance",
      "evidence": "TestUJIdentity001BootstrapInvitationLocaleRecoveryAndSessionLifecycle executed in the declared package suite and establishes module-level bootstrap, invitation, saved locale, recovery session invalidation, relogin, logout and plaintext redaction. No full-flow claims or business-Action contributions exist in this contract. Functional approval is withheld for the two static audit defects."
    }
  ],
  "acceptance_notes": "acceptance_refs are trace-only; no full-flow or business-Action acceptance was invented. Database/installer/browser wiring downstream is not a prerequisite for this component review.",
  "integration_gate_mapping": [
    {
      "gate": "identity-local-gate",
      "status": "pass",
      "functional_delivery_status": "fail",
      "source_of_truth": [
        "docs/design/detailed/09-governance-and-security-detailed-design.md:L100-L213",
        "docs/design/detailed/10-web-api-cli-detailed-design.md:L170-L354",
        "docs/delivery/acceptance-and-validation.md:L129-L150",
        "account-locale-ownership-decision.md"
      ],
      "delivery_goal": "Deliver first-admin, invitation, recovery and browser-session behavior plus one Principal-owned saved locale preference restricted to zh-CN|en-US, updated by Authorization and expected_revision CAS, audited without storing locale on Scope, Project, Workflow or Solution.",
      "commands": [
        {
          "cmd": "python3 -c \"from pathlib import Path; import hashlib; p=Path('account-locale-ownership-decision.md'); assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()=='2ee85c6551db299f14f4903e5b0086e678208b38c6a3cba276c8a32a5f1a5be6'\"",
          "exit_code": 0,
          "summary": "Passed (no stdout)."
        },
        {
          "cmd": "mkdir -p artifacts/identity-local && go test -covermode=atomic -coverprofile=artifacts/identity-local/coverage.out ./internal/identity/... ./api/auth/local/...",
          "exit_code": 0,
          "summary": "Fresh uncached run with GOFLAGS=-count=1: identity package passed at 89.3% statement coverage; local HTTP API passed at 98.4%; aggregate 90.6%."
        },
        {
          "cmd": "go test ./internal/identity/... ./api/auth/local/... -run \"Test.*LocalePreference.*(Create|Read|CAS|Conflict|Authorization|Audit|Session|Fallback)\" -count=1",
          "exit_code": 0,
          "summary": "ok  \tgithub.com/xiaohei-info/open-agent-cluster/internal/identity\t0.019s\nok  \tgithub.com/xiaohei-info/open-agent-cluster/api/auth/local\t0.019s [no tests to run]"
        },
        {
          "cmd": "go test ./internal/identity/... -run \"Test.*LocalePreference.*Rejects(Scope|Project|Workflow|Solution|UnsupportedLocale|AnonymousWrite)\" -count=1",
          "exit_code": 0,
          "summary": "ok  \tgithub.com/xiaohei-info/open-agent-cluster/internal/identity\t0.008s"
        },
        {
          "cmd": "python3 -c \"from pathlib import Path; import re,subprocess; p=Path('artifacts/identity-local/coverage.out'); assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True); m=re.search(r'^total:\\s+\\(statements\\)\\s+([0-9.]+)%$',out,re.M); assert m and float(m.group(1)) >= 90\"",
          "exit_code": 0,
          "summary": "Passed (no stdout)."
        },
        {
          "cmd": "python3 scripts/release/package_component.py --component identity-local --kind platform-core-dependency-source --input internal/identity --input api/auth/local --bundle artifacts/identity-local/source-bundle.tar.zst --component-manifest artifacts/identity-local/component-manifest.json --digest-output artifacts/identity-local/bundle-digest.txt --ownership-baseline contracts/release/source-ownership-baseline.yaml --owner identity-local --require-all-owner-sources-accounted",
          "exit_code": 0,
          "summary": "bundle=artifacts/identity-local/source-bundle.tar.zst\nmanifest=artifacts/identity-local/component-manifest.json"
        }
      ],
      "metrics": {
        "statement_coverage_percent": 90.6,
        "locale_preference_conflict_accept_count": 0
      },
      "artifacts": [
        "artifacts/identity-local/coverage.out",
        "artifacts/identity-local/source-bundle.tar.zst",
        "artifacts/identity-local/bundle-digest.txt",
        "artifacts/identity-local/component-manifest.json"
      ],
      "evidence": "All executable checks and artifact requirements passed independently. Locale behavior tests assert stale revisions and forced CAS loss are rejected without successful conflicting mutation; the static canonical-audit findings are outside the assertions of this otherwise passing suite. No live/browser E2E approval is claimed."
    }
  ],
  "blockers": [
    {
      "root_cause_key": "identity-audit-context-reference-is-external-request-id",
      "obligation_id": "dimension:structure",
      "classification": "new",
      "owner": "identity-local",
      "severity": "medium",
      "summary": "Identity audit events use the external request ID as a persisted RequestContext reference without a context persistence/binding boundary.",
      "impact": "Canonical audit cannot reliably restore the authenticated context, authentication provenance and policy context for identity/locale writes or denials. External request correlation is conflated with the authoritative persisted context identity, so event shape validation and matching request headers do not establish audit traceability.",
      "evidence": "Static evidence on reviewed head: internal/identity/audit.go:14-19 drops the authenticated RequestContext down to three correlation fields; audit.go:83-99 unconditionally sets AuditEvent.RequestContextID to metadata.RequestID. RequestMetadata at types.go:192-197 has no persisted context reference; Tx at types.go:113-134 exposes only AppendAudit(AuditEvent), with no operation receiving/binding the trusted context. ResolveBrowserSession at service.go:444-464 constructs and returns the transient context, without issuing a persisted reference. The HTTP request ID may originate from a caller header (api/auth/local/handler.go:310-321). This conflicts with required security-and-enterprise.md:305-306,317 and contracts/governance/audit/contract.go:1075-1083, which explicitly distinguish the persisted RequestContextID from the external RequestID. Test store AppendAudit at identity_test.go:408-416 only validates/appends the event; locale audit tests count events/denials, not persisted context bindings. All declared tests pass; no additional negative experiment was constructed.",
      "required_fix": "Provide an explicit canonical audit/context persistence boundary in the owned identity port that receives the trusted context and supplies a server-issued persisted reference. Set AuditEvent.RequestContextID to that reference and retain external RequestID in the context record/summary, preserving correlation and causation. Apply this to successful writes, denials and the explicitly supported pre-authentication/installer evidence paths without inventing anonymous administrator contexts. Extend the existing declared tests to prove the event resolves to the correct persisted context and that external RequestID is not substituted for its identity. This is a module port/binding requirement, not a demand for an undeclared downstream live database."
    },
    {
      "root_cause_key": "identity-one-time-proof-audit-fabricates-authorization-policy-provenance",
      "obligation_id": "dimension:ownership",
      "classification": "new",
      "owner": "identity-local",
      "severity": "medium",
      "summary": "One-time proof audits manufacture AuthorizationPolicy and matched-grant provenance instead of recording the controls actually evaluated.",
      "impact": "Bootstrap, invitation acceptance, recovery completion and installer recovery are recorded as Allow decisions under nonexistent policy/grant identities. Audit consumers cannot replay or resolve the reported policy provenance; a token/proof digest is mislabeled as a policy digest. The operations do validate their proofs, but that does not justify synthetic Authorization evidence.",
      "evidence": "Static evidence: internal/identity/audit.go:22-43 constructs a fresh authz.AuthorizationDecision with an identity.one-time.<proof-kind> policy ID, revision 1, the proof digest as PolicyDigest and a hard-coded one-time/valid-<proof-kind> matched grant. It never obtains an AuthorizationDecision from Authorizer or a persisted policy from Governance. authorizationControl at audit.go:59-80 presents those fields as ControlAuthorization provenance. Callers are service.go:220, invitation.go:366 and recovery.go:175,277. Required security-and-enterprise.md:184-201,247-259 requires the single engine/current Scope policy and real immutable policy provenance; docs/design/detailed/10-web-api-cli-detailed-design.md:304 states one Scope has one current policy. The helper creates a parallel fictional policy family solely to satisfy audit validation. AuditEvent.Validate (contracts/governance/audit/contract.go:373-390) requires evaluated controls but does not establish that their policy/grant references exist. No exploit, network probe or new negative test was performed.",
      "required_fix": "Remove the synthesized AuthorizationDecision/policy/grant family. Record truthful evaluated-control evidence from the actual installer authority, bootstrap/current governance policy, invitation authorization and/or authentication receipt as appropriate to each entry point, keeping pre-authentication proof checks distinct from a Scope AuthorizationEngine decision. Do not relabel a token digest as a policy digest or invent a Provider release. If the upstream canonical audit schema cannot represent the required proof control, expose that precise contract-boundary conflict rather than fabricating provenance. Add existing-suite assertions that policy/control identities, revisions, digests and grants resolve to the real evaluated source."
    }
  ],
  "nits": [],
  "environment_notes": [
    "Isolated task checkout pinned to reviewed head; Go 1.26.0 linux/arm64, Python 3.14.3 and zstd 1.5.7 available; no external service required.",
    "Initial path-dependent invocation failed outside the checkout; all exact contract commands subsequently ran successfully with the explicit absolute checkout workdir. Package execution was repeated uncached.",
    "Only contract-declared local verification was executed. New findings are static inspection, not additional exploit/negative-test experiments. No worker source, upstream contract or platform state was changed by the reviewer. Reproduction rewrote the local component manifest to the reviewed-head revision; committed source bundle bytes remain identical."
  ]
}

```


## Full original identity-local omac-review-ledger-b116b01b1675.yaml
SHA256 b116b01b16757abbe0b4afabe9e6a287319ab60a62f41a0b733fea38a41318dc; bytes 45330

```yaml
schema: omac.review-ledger/v2
cycles:
- round: 1
  subject_digest: 8fb4b93a41bc8d44629f81d919199e67e206ef206ede979664e34fdcce60bd83
  report_digest: 66ea718b189247163324e9c7071af21f45781be63babfd45212aa51010d29cbb
  verdict: reject
  obligation_results:
    dimension:authority: pass
    dimension:structure: fail
    dimension:execution: fail
    dimension:ownership: pass
    dimension:evidence: fail
    dimension:regression: pass
    integration:identity-local-gate: pass
  new_count: 4
  fixed_count: 0
  regressed_count: 0
  unchanged_count: 0
  open_count: 4
  prior_open_blocker_ids: []
  open_blocker_ids: &id001
  - BLK-62858e200019
  - BLK-7e002b74f69c
  - BLK-8646e42ba221
  - BLK-8c9128c2b72c
  reported_blocker_ids: *id001
  blocker_facts_schema: omac.review-cycle-blocker-facts/v1
  blocker_facts:
  - blocker_id: BLK-62858e200019
    root_cause_key: identity-recovery-session-issuance-not-serialized
    obligation_id: dimension:structure
    summary: Session issuance is not fenced against concurrent password recovery.
    evidence: 'Static control-flow evidence: internal/identity/service.go:362-370
      authenticates outside the session-write transaction; createSession at service.go:294-355
      resolves identity and access before a transaction containing only CreateSession
      and AppendAudit. internal/identity/recovery.go:247-255 replaces the credential
      and revokes currently stored sessions in a separate transaction. SessionRecord/Tx
      at types.go:81-86,125-127 carry no credential generation or conditional issuance
      fence. TestRecoveryIssueCompletionRevokesSessionsAndIsIdempotent and TestUJIdentity001BootstrapInvitationLocaleRecoveryAndSessionLifecycle
      exercise already-persisted sessions sequentially; they do not cover in-flight
      authentication. This finding is based on code inspection, not an additional
      security experiment.'
    required_fix: Serialize local credential validation/session issuance with recovery,
      or bind the verified authentication to a credential/session generation checked
      atomically at session creation and session resolution. Apply the same boundary
      to login and bootstrap/invitation auto-login. Add a deterministic local regression
      proving recovery invalidates pre-recovery authentication even when session persistence
      completes later, without retaining plaintext credentials.
    status: open
    classification: new
    owner: identity-local
  - blocker_id: BLK-7e002b74f69c
    root_cause_key: identity-concurrent-idempotency-omits-password-equivalence
    obligation_id: dimension:structure
    summary: Concurrent replay branches skip the password-equivalence checks used
      for ordinary idempotent retries.
    evidence: 'Static evidence: recovery.go:195 hashes only the token digest; completedRecoveryReplay
      at 271-311 verifies password equivalence, but the transaction replay branch
      at 228-232 directly unmarshals the saved result. service.go:128-130 omits password
      from the bootstrap digest and 177-183 skips bootstrapReplay verification when
      the record appears between the initial lookup and transaction. invitation.go:308
      similarly omits password and 326-330 skips acceptedInvitationReplay verification.
      Existing concurrent tests use different idempotency keys; ordinary replay tests
      validate sequential changed-input rejection, not this race. No additional negative-test
      input was constructed.'
    required_fix: Make password-equivalence validation part of every idempotency replay
      decision, including the atomic transaction branch, using the same protected
      comparison semantics as the ordinary replay path. Do not store plaintext or
      an unkeyed low-entropy request-password digest. Add deterministic concurrent
      same-key tests for identical input and changed input across bootstrap, invitation
      acceptance, and recovery; changed input must return a conflict rather than success.
    status: open
    classification: new
    owner: identity-local
  - blocker_id: BLK-8646e42ba221
    root_cause_key: identity-dependency-errors-mapped-to-user-denials
    obligation_id: dimension:execution
    summary: Authentication and governance dependency failures are flattened into
      credential or permission errors.
    evidence: service.go:366-368 turns every LocalAuthenticator.Authenticate error
      into ErrInvalidCredentials; service.go:435-437 and invitation.go:467-469 turn
      Policy lookup errors into ErrForbidden; recovery.go:217-219 turns LocalScopeID
      errors into ErrNotFound. bootstrapReplay service.go:268-270, acceptedInvitationReplay
      invitation.go:415-417, and completedRecoveryReplay recovery.go:308-310 also
      flatten VerifyPassword operational errors into idempotency conflicts. The independently
      executed declared suite includes TestSessionAndAuthorizationFailureMatrix (failure_paths_test.go:194-275),
      which injects an operational driver failure at identity_test.go:485-487 and
      currently asserts ErrInvalidCredentials at failure_paths_test.go:248-251. handler.go:337-353
      already supports sanitized 500 responses, and its handler-only internal-error
      test does not exercise this Service path.
    required_fix: Distinguish known invalid-credential/authorization/not-found outcomes
      from operational errors through typed port/SDK errors. Preserve or wrap operational
      errors at the service boundary and return sanitized 5xx responses at HTTP boundaries.
      Update the declared failure tests to assert propagation for outages/cancellation
      and user-facing denial only for genuine credential or permission failures. Retain
      the intentionally designed post-commit login and notification fallbacks.
    status: open
    classification: new
    owner: identity-local
  - blocker_id: BLK-8c9128c2b72c
    root_cause_key: identity-request-metadata-regenerated-within-http-request
    obligation_id: dimension:evidence
    summary: Protected HTTP mutations regenerate request identity instead of propagating
      the resolved request metadata.
    evidence: handler.go:267 obtains requestMetadata for ResolveBrowserSession and
      273 exposes that RequestID; protected route callbacks invoke requestMetadata(r)
      again (e.g. 204 and 252). requestMetadata at 292-303 generates a new random
      RequestID each call and does not attach it to the request. locale.go:54-56 and
      recovery.go:40-42 overwrite the RequestContext IDs with the second metadata.
      The shared governance reference security-and-enterprise.md:13-15 requires request
      identity propagation and causal tracing. Handler tests use testApplication,
      returning a fixed context at handler_test.go:119-124, and do not assert identity
      equality between resolution, authorization, audit, and response. Static code
      inspection establishes this discrepancy; no new request experiment was run.
    required_fix: Normalize metadata exactly once at the HTTP entry and pass the same
      immutable metadata through session resolution and the application call. Preserve
      the resolved RequestContext request/causation/correlation IDs instead of overwriting
      them with independently generated ones. Add handler-to-service regression assertions
      for absent and supplied request IDs across locale, recovery, invitation, and
      logout paths.
    status: open
    classification: new
    owner: identity-local
- round: 2
  subject_digest: 208b06850fad83b3aad1386432bec49e9d219562b7f2030cb4dc6f1058027944
  report_digest: 1d3baab9c1ca027c3fa775d840f944d6db615dc5c5a5ce2e6c4498e0e9bc1ce6
  verdict: reject
  obligation_results:
    dimension:authority: pass
    dimension:structure: fail
    dimension:execution: fail
    dimension:ownership: pass
    dimension:evidence: pass
    dimension:regression: pass
    integration:identity-local-gate: pass
  new_count: 1
  fixed_count: 3
  regressed_count: 0
  unchanged_count: 0
  open_count: 2
  prior_open_blocker_ids:
  - BLK-62858e200019
  - BLK-7e002b74f69c
  - BLK-8646e42ba221
  - BLK-8c9128c2b72c
  open_blocker_ids: &id002
  - BLK-8646e42ba221
  - BLK-9a7d286279b9
  reported_blocker_ids: *id002
  blocker_facts_schema: omac.review-cycle-blocker-facts/v1
  blocker_facts:
  - blocker_id: BLK-62858e200019
    root_cause_key: identity-recovery-session-issuance-not-serialized
    obligation_id: dimension:structure
    summary: Session issuance is not fenced against concurrent password recovery.
    evidence: 'Static control-flow evidence: internal/identity/service.go:362-370
      authenticates outside the session-write transaction; createSession at service.go:294-355
      resolves identity and access before a transaction containing only CreateSession
      and AppendAudit. internal/identity/recovery.go:247-255 replaces the credential
      and revokes currently stored sessions in a separate transaction. SessionRecord/Tx
      at types.go:81-86,125-127 carry no credential generation or conditional issuance
      fence. TestRecoveryIssueCompletionRevokesSessionsAndIsIdempotent and TestUJIdentity001BootstrapInvitationLocaleRecoveryAndSessionLifecycle
      exercise already-persisted sessions sequentially; they do not cover in-flight
      authentication. This finding is based on code inspection, not an additional
      security experiment.'
    required_fix: Serialize local credential validation/session issuance with recovery,
      or bind the verified authentication to a credential/session generation checked
      atomically at session creation and session resolution. Apply the same boundary
      to login and bootstrap/invitation auto-login. Add a deterministic local regression
      proving recovery invalidates pre-recovery authentication even when session persistence
      completes later, without retaining plaintext credentials.
    status: fixed
    classification: fixed
    last_evidence: internal/identity/service.go:338-353 revalidates the current password
      inside the session-write transaction; recovery.go:253-260 replaces the credential
      and revokes sessions in the same Store transaction boundary. Login, bootstrap
      auto-login (service.go:271), and invitation auto-login (invitation.go:420) share
      createSession. Independently rerun full declared suite includes TestRecoveryFencesAuthenticationBeforeSessionIssue
      (identity_test.go:1134-1179), which deterministically pauses authenticated login,
      completes recovery, and asserts no late session is created. No undeclared experiment
      was run.
    owner: identity-local
  - blocker_id: BLK-7e002b74f69c
    root_cause_key: identity-concurrent-idempotency-omits-password-equivalence
    obligation_id: dimension:structure
    summary: Concurrent replay branches skip the password-equivalence checks used
      for ordinary idempotent retries.
    evidence: 'Static evidence: recovery.go:195 hashes only the token digest; completedRecoveryReplay
      at 271-311 verifies password equivalence, but the transaction replay branch
      at 228-232 directly unmarshals the saved result. service.go:128-130 omits password
      from the bootstrap digest and 177-183 skips bootstrapReplay verification when
      the record appears between the initial lookup and transaction. invitation.go:308
      similarly omits password and 326-330 skips acceptedInvitationReplay verification.
      Existing concurrent tests use different idempotency keys; ordinary replay tests
      validate sequential changed-input rejection, not this race. No additional negative-test
      input was constructed.'
    required_fix: Make password-equivalence validation part of every idempotency replay
      decision, including the atomic transaction branch, using the same protected
      comparison semantics as the ordinary replay path. Do not store plaintext or
      an unkeyed low-entropy request-password digest. Add deterministic concurrent
      same-key tests for identical input and changed input across bootstrap, invitation
      acceptance, and recovery; changed input must return a conflict rather than success.
    status: fixed
    classification: fixed
    last_evidence: Transaction replay branches at service.go:178-184, invitation.go:326-332,
      recovery.go:231-237 all invoke verifyReplayPassword (service.go:572-583), as
      do ordinary replay paths. This reads the protected credential hash and compares
      through the authenticator, with no persisted plaintext or added password request
      digest. Declared full suite independently passed TestConcurrentBootstrapIdempotencyChecksPasswordEquivalence,
      TestConcurrentInvitationIdempotencyChecksPasswordEquivalence, and TestConcurrentRecoveryIdempotencyChecksPasswordEquivalence;
      deterministic hashing barriers exercise same-input success and changed-input
      conflict.
    owner: identity-local
  - blocker_id: BLK-8646e42ba221
    root_cause_key: identity-dependency-errors-mapped-to-user-denials
    obligation_id: dimension:execution
    summary: Installer-authority outages and cancellation are still converted into
      permission denials.
    evidence: 'Static control-flow evidence at internal/identity/service.go:93-95
      and internal/identity/recovery.go:121-123: any InstallerAuthority error is replaced
      with ErrForbidden. The port at types.go:163-166 returns a general error, with
      no denial-only restriction. fakeInstaller at identity_test.go:713-732 returns
      only business denials; TestBootstrapInstallerAndPersistenceFailureMatrix and
      TestRecoveryIssueAndBreakGlassFailureMatrix therefore do not exercise these
      operational failure paths. All existing declared commands passed; no additional
      negative test was constructed.'
    required_fix: Preserve or wrap operational/cancellation errors from both InstallerAuthority
      calls; map only an explicitly typed/sentinel authorization denial to ErrForbidden.
      Keep missing/invalid proof fail-closed and retain the intentional post-commit
      session and notification fallbacks. Add coverage in the existing declared suite
      for actual denial versus operational failure and cancellation for both installer
      entry points.
    status: open
    classification: deeper
    owner: identity-local
    last_evidence: 'Previously cited authentication, replay-verification, Policy and
      LocalScopeID errors are now preserved at service.go:365-367,572-601,434-439;
      invitation.go:457-462; recovery.go:217-219. TestSessionAndAuthorizationFailureMatrix
      and TestIdempotencyReplayPreservesPasswordVerifierFailures passed independently.
      However the same error-flattening defect remains at installer-authority dependencies:
      service.go:93-95 maps every error to ErrForbidden and recovery.go:121-123 does
      likewise. The error-returning InstallerAuthority port (types.go:163-166) provides
      no guarantee that only business denials can be returned. Current installer tests
      cover denial/missing proof, not operational errors or cancellation. See the
      retained root-cause blocker.'
  - blocker_id: BLK-8c9128c2b72c
    root_cause_key: identity-request-metadata-regenerated-within-http-request
    obligation_id: dimension:evidence
    summary: Protected HTTP mutations regenerate request identity instead of propagating
      the resolved request metadata.
    evidence: handler.go:267 obtains requestMetadata for ResolveBrowserSession and
      273 exposes that RequestID; protected route callbacks invoke requestMetadata(r)
      again (e.g. 204 and 252). requestMetadata at 292-303 generates a new random
      RequestID each call and does not attach it to the request. locale.go:54-56 and
      recovery.go:40-42 overwrite the RequestContext IDs with the second metadata.
      The shared governance reference security-and-enterprise.md:13-15 requires request
      identity propagation and causal tracing. Handler tests use testApplication,
      returning a fixed context at handler_test.go:119-124, and do not assert identity
      equality between resolution, authorization, audit, and response. Static code
      inspection establishes this discrepancy; no new request experiment was run.
    required_fix: Normalize metadata exactly once at the HTTP entry and pass the same
      immutable metadata through session resolution and the application call. Preserve
      the resolved RequestContext request/causation/correlation IDs instead of overwriting
      them with independently generated ones. Add handler-to-service regression assertions
      for absent and supplied request IDs across locale, recovery, invitation, and
      logout paths.
    status: fixed
    classification: fixed
    last_evidence: api/auth/local/handler.go:63,294-321 resolves request metadata
      once in the outer middleware and caches it in the request context. Session resolution
      and protected callbacks receive the same metadata; RequestContext IDs are carried
      to authorization and canonical audit in internal/identity/locale.go:50-57,99
      and recovery.go:40-43,94. The independently rerun TestProtectedMutationsPropagateOneRequestMetadataValue
      checks generated and supplied IDs, correlation/causation, application RequestContext,
      and response headers for locale, recovery, invitation create/reissue/revoke,
      and logout.
    owner: identity-local
  - blocker_id: BLK-9a7d286279b9
    root_cause_key: identity-breakglass-concurrent-replay-returns-unpersisted-token
    obligation_id: dimension:structure
    summary: Concurrent break-glass recovery replay can return a successful response
      with a recovery link that was never persisted.
    evidence: 'Static evidence: internal/identity/recovery.go:134-145 performs an
      initial replay read, then allocates a fresh challenge identity and token. If
      another identical request commits before this call enters Transact, lines 148-151
      load the prior result and return from the callback without storing this call''s
      challenge/token digest. After that successful transaction, line 178 unconditionally
      attaches this call''s fresh token to the replayed result. Ordinary recovery
      issue at recovery.go:102-104, invitation create at invitation.go:112-114, and
      reissue at invitation.go:205-207 already guard this exact branch by comparing
      the committed result identity. TestRecoveryAuthorizationScopeAndBreakGlassReplayFailures
      at failure_paths_test.go:910-917 only checks sequential replay, so the declared
      passing suite does not rule this out. This finding is based solely on code inspection,
      not a new security experiment.'
    required_fix: Track whether this call actually committed the newly generated break-glass
      challenge and only expose its one-time link on that branch. Return the persisted
      token-free result on concurrent replay, consistently with ordinary recovery/invitation
      issuance, without storing plaintext tokens. Add a deterministic concurrent same-key
      regression to the existing declared suite proving that every emitted link corresponds
      to a committed challenge, only one challenge/audit is created, and replay emits
      no new link.
    status: open
    classification: new
    owner: identity-local
- round: 3
  subject_digest: 235a8e4f0b3b413af689babf309f65d66f51db88d0b0b4d38042697e2cbd43ed
  report_digest: 7dc767b988f3a6a5e0c8ca6606fc4cb15bb184d61998098011e4233195bcc244
  verdict: reject
  obligation_results:
    dimension:authority: pass
    dimension:structure: fail
    dimension:execution: pass
    dimension:ownership: fail
    dimension:evidence: pass
    dimension:regression: pass
    integration:identity-local-gate: pass
  new_count: 2
  fixed_count: 2
  regressed_count: 0
  unchanged_count: 0
  open_count: 2
  prior_open_blocker_ids:
  - BLK-8646e42ba221
  - BLK-9a7d286279b9
  open_blocker_ids: &id003
  - BLK-36b4b6bd212e
  - BLK-6edcc5450e8d
  reported_blocker_ids: *id003
  blocker_facts_schema: omac.review-cycle-blocker-facts/v1
  blocker_facts:
  - blocker_id: BLK-36b4b6bd212e
    root_cause_key: identity-one-time-proof-audit-fabricates-authorization-policy-provenance
    obligation_id: dimension:ownership
    summary: One-time proof audits manufacture AuthorizationPolicy and matched-grant
      provenance instead of recording the controls actually evaluated.
    evidence: 'Static evidence: internal/identity/audit.go:22-43 constructs a fresh
      authz.AuthorizationDecision with an identity.one-time.<proof-kind> policy ID,
      revision 1, the proof digest as PolicyDigest and a hard-coded one-time/valid-<proof-kind>
      matched grant. It never obtains an AuthorizationDecision from Authorizer or
      a persisted policy from Governance. authorizationControl at audit.go:59-80 presents
      those fields as ControlAuthorization provenance. Callers are service.go:220,
      invitation.go:366 and recovery.go:175,277. Required security-and-enterprise.md:184-201,247-259
      requires the single engine/current Scope policy and real immutable policy provenance;
      docs/design/detailed/10-web-api-cli-detailed-design.md:304 states one Scope
      has one current policy. The helper creates a parallel fictional policy family
      solely to satisfy audit validation. AuditEvent.Validate (contracts/governance/audit/contract.go:373-390)
      requires evaluated controls but does not establish that their policy/grant references
      exist. No exploit, network probe or new negative test was performed.'
    required_fix: Remove the synthesized AuthorizationDecision/policy/grant family.
      Record truthful evaluated-control evidence from the actual installer authority,
      bootstrap/current governance policy, invitation authorization and/or authentication
      receipt as appropriate to each entry point, keeping pre-authentication proof
      checks distinct from a Scope AuthorizationEngine decision. Do not relabel a
      token digest as a policy digest or invent a Provider release. If the upstream
      canonical audit schema cannot represent the required proof control, expose that
      precise contract-boundary conflict rather than fabricating provenance. Add existing-suite
      assertions that policy/control identities, revisions, digests and grants resolve
      to the real evaluated source.
    status: open
    classification: new
    owner: identity-local
  - blocker_id: BLK-6edcc5450e8d
    root_cause_key: identity-audit-context-reference-is-external-request-id
    obligation_id: dimension:structure
    summary: Identity audit events use the external request ID as a persisted RequestContext
      reference without a context persistence/binding boundary.
    evidence: 'Static evidence on reviewed head: internal/identity/audit.go:14-19
      drops the authenticated RequestContext down to three correlation fields; audit.go:83-99
      unconditionally sets AuditEvent.RequestContextID to metadata.RequestID. RequestMetadata
      at types.go:192-197 has no persisted context reference; Tx at types.go:113-134
      exposes only AppendAudit(AuditEvent), with no operation receiving/binding the
      trusted context. ResolveBrowserSession at service.go:444-464 constructs and
      returns the transient context, without issuing a persisted reference. The HTTP
      request ID may originate from a caller header (api/auth/local/handler.go:310-321).
      This conflicts with required security-and-enterprise.md:305-306,317 and contracts/governance/audit/contract.go:1075-1083,
      which explicitly distinguish the persisted RequestContextID from the external
      RequestID. Test store AppendAudit at identity_test.go:408-416 only validates/appends
      the event; locale audit tests count events/denials, not persisted context bindings.
      All declared tests pass; no additional negative experiment was constructed.'
    required_fix: Provide an explicit canonical audit/context persistence boundary
      in the owned identity port that receives the trusted context and supplies a
      server-issued persisted reference. Set AuditEvent.RequestContextID to that reference
      and retain external RequestID in the context record/summary, preserving correlation
      and causation. Apply this to successful writes, denials and the explicitly supported
      pre-authentication/installer evidence paths without inventing anonymous administrator
      contexts. Extend the existing declared tests to prove the event resolves to
      the correct persisted context and that external RequestID is not substituted
      for its identity. This is a module port/binding requirement, not a demand for
      an undeclared downstream live database.
    status: open
    classification: new
    owner: identity-local
  - blocker_id: BLK-8646e42ba221
    root_cause_key: identity-dependency-errors-mapped-to-user-denials
    obligation_id: dimension:execution
    summary: Installer-authority outages and cancellation are still converted into
      permission denials.
    evidence: 'Static control-flow evidence at internal/identity/service.go:93-95
      and internal/identity/recovery.go:121-123: any InstallerAuthority error is replaced
      with ErrForbidden. The port at types.go:163-166 returns a general error, with
      no denial-only restriction. fakeInstaller at identity_test.go:713-732 returns
      only business denials; TestBootstrapInstallerAndPersistenceFailureMatrix and
      TestRecoveryIssueAndBreakGlassFailureMatrix therefore do not exercise these
      operational failure paths. All existing declared commands passed; no additional
      negative test was constructed.'
    required_fix: Preserve or wrap operational/cancellation errors from both InstallerAuthority
      calls; map only an explicitly typed/sentinel authorization denial to ErrForbidden.
      Keep missing/invalid proof fail-closed and retain the intentional post-commit
      session and notification fallbacks. Add coverage in the existing declared suite
      for actual denial versus operational failure and cancellation for both installer
      entry points.
    status: fixed
    classification: fixed
    last_evidence: service.go:93-97 and recovery.go:122-130 map only errors.Is(ErrForbidden)
      to denial, wrap all other installer errors and reject missing proof. The independently
      executed TestBootstrapInstallerAndPersistenceFailureMatrix and TestRecoveryAuthorizationScopeAndBreakGlassReplayFailures
      include operational error and cancellation cases and distinguish them from actual
      denial. Existing credential/governance error propagation and intentional post-commit
      fallbacks remain intact.
    owner: identity-local
  - blocker_id: BLK-9a7d286279b9
    root_cause_key: identity-breakglass-concurrent-replay-returns-unpersisted-token
    obligation_id: dimension:structure
    summary: Concurrent break-glass recovery replay can return a successful response
      with a recovery link that was never persisted.
    evidence: 'Static evidence: internal/identity/recovery.go:134-145 performs an
      initial replay read, then allocates a fresh challenge identity and token. If
      another identical request commits before this call enters Transact, lines 148-151
      load the prior result and return from the callback without storing this call''s
      challenge/token digest. After that successful transaction, line 178 unconditionally
      attaches this call''s fresh token to the replayed result. Ordinary recovery
      issue at recovery.go:102-104, invitation create at invitation.go:112-114, and
      reissue at invitation.go:205-207 already guard this exact branch by comparing
      the committed result identity. TestRecoveryAuthorizationScopeAndBreakGlassReplayFailures
      at failure_paths_test.go:910-917 only checks sequential replay, so the declared
      passing suite does not rule this out. This finding is based solely on code inspection,
      not a new security experiment.'
    required_fix: Track whether this call actually committed the newly generated break-glass
      challenge and only expose its one-time link on that branch. Return the persisted
      token-free result on concurrent replay, consistently with ordinary recovery/invitation
      issuance, without storing plaintext tokens. Add a deterministic concurrent same-key
      regression to the existing declared suite proving that every emitted link corresponds
      to a committed challenge, only one challenge/audit is created, and replay emits
      no new link.
    status: fixed
    classification: fixed
    last_evidence: recovery.go:154-193 resets a created flag for each transaction
      callback, sets it only after challenge/audit/idempotency persistence succeeds,
      and attaches the token URL only for created=true. Concurrent replay returns
      the persisted token-free summary. TestConcurrentBreakGlassReplayOnlyReturnsPersistedToken
      at failure_paths_test.go:959-1025 uses a deterministic ID barrier, asserts one
      persisted challenge, one matching emitted link, one audit and a token-free subsequent
      replay; it passed in the uncached full declared suite.
    owner: identity-local
blockers:
- blocker_id: BLK-36b4b6bd212e
  root_cause_key: identity-one-time-proof-audit-fabricates-authorization-policy-provenance
  obligation_id: dimension:ownership
  summary: One-time proof audits manufacture AuthorizationPolicy and matched-grant
    provenance instead of recording the controls actually evaluated.
  evidence: 'Static evidence: internal/identity/audit.go:22-43 constructs a fresh
    authz.AuthorizationDecision with an identity.one-time.<proof-kind> policy ID,
    revision 1, the proof digest as PolicyDigest and a hard-coded one-time/valid-<proof-kind>
    matched grant. It never obtains an AuthorizationDecision from Authorizer or a
    persisted policy from Governance. authorizationControl at audit.go:59-80 presents
    those fields as ControlAuthorization provenance. Callers are service.go:220, invitation.go:366
    and recovery.go:175,277. Required security-and-enterprise.md:184-201,247-259 requires
    the single engine/current Scope policy and real immutable policy provenance; docs/design/detailed/10-web-api-cli-detailed-design.md:304
    states one Scope has one current policy. The helper creates a parallel fictional
    policy family solely to satisfy audit validation. AuditEvent.Validate (contracts/governance/audit/contract.go:373-390)
    requires evaluated controls but does not establish that their policy/grant references
    exist. No exploit, network probe or new negative test was performed.'
  required_fix: Remove the synthesized AuthorizationDecision/policy/grant family.
    Record truthful evaluated-control evidence from the actual installer authority,
    bootstrap/current governance policy, invitation authorization and/or authentication
    receipt as appropriate to each entry point, keeping pre-authentication proof checks
    distinct from a Scope AuthorizationEngine decision. Do not relabel a token digest
    as a policy digest or invent a Provider release. If the upstream canonical audit
    schema cannot represent the required proof control, expose that precise contract-boundary
    conflict rather than fabricating provenance. Add existing-suite assertions that
    policy/control identities, revisions, digests and grants resolve to the real evaluated
    source.
  status: open
  classification: new
  owner: identity-local
  first_seen_round: 3
  last_seen_round: 3
  seen_count: 1
- blocker_id: BLK-62858e200019
  root_cause_key: identity-recovery-session-issuance-not-serialized
  obligation_id: dimension:structure
  summary: Session issuance is not fenced against concurrent password recovery.
  evidence: 'Static control-flow evidence: internal/identity/service.go:362-370 authenticates
    outside the session-write transaction; createSession at service.go:294-355 resolves
    identity and access before a transaction containing only CreateSession and AppendAudit.
    internal/identity/recovery.go:247-255 replaces the credential and revokes currently
    stored sessions in a separate transaction. SessionRecord/Tx at types.go:81-86,125-127
    carry no credential generation or conditional issuance fence. TestRecoveryIssueCompletionRevokesSessionsAndIsIdempotent
    and TestUJIdentity001BootstrapInvitationLocaleRecoveryAndSessionLifecycle exercise
    already-persisted sessions sequentially; they do not cover in-flight authentication.
    This finding is based on code inspection, not an additional security experiment.'
  required_fix: Serialize local credential validation/session issuance with recovery,
    or bind the verified authentication to a credential/session generation checked
    atomically at session creation and session resolution. Apply the same boundary
    to login and bootstrap/invitation auto-login. Add a deterministic local regression
    proving recovery invalidates pre-recovery authentication even when session persistence
    completes later, without retaining plaintext credentials.
  status: fixed
  classification: fixed
  owner: identity-local
  first_seen_round: 1
  last_seen_round: 2
  seen_count: 1
  last_evidence: internal/identity/service.go:338-353 revalidates the current password
    inside the session-write transaction; recovery.go:253-260 replaces the credential
    and revokes sessions in the same Store transaction boundary. Login, bootstrap
    auto-login (service.go:271), and invitation auto-login (invitation.go:420) share
    createSession. Independently rerun full declared suite includes TestRecoveryFencesAuthenticationBeforeSessionIssue
    (identity_test.go:1134-1179), which deterministically pauses authenticated login,
    completes recovery, and asserts no late session is created. No undeclared experiment
    was run.
- blocker_id: BLK-6edcc5450e8d
  root_cause_key: identity-audit-context-reference-is-external-request-id
  obligation_id: dimension:structure
  summary: Identity audit events use the external request ID as a persisted RequestContext
    reference without a context persistence/binding boundary.
  evidence: 'Static evidence on reviewed head: internal/identity/audit.go:14-19 drops
    the authenticated RequestContext down to three correlation fields; audit.go:83-99
    unconditionally sets AuditEvent.RequestContextID to metadata.RequestID. RequestMetadata
    at types.go:192-197 has no persisted context reference; Tx at types.go:113-134
    exposes only AppendAudit(AuditEvent), with no operation receiving/binding the
    trusted context. ResolveBrowserSession at service.go:444-464 constructs and returns
    the transient context, without issuing a persisted reference. The HTTP request
    ID may originate from a caller header (api/auth/local/handler.go:310-321). This
    conflicts with required security-and-enterprise.md:305-306,317 and contracts/governance/audit/contract.go:1075-1083,
    which explicitly distinguish the persisted RequestContextID from the external
    RequestID. Test store AppendAudit at identity_test.go:408-416 only validates/appends
    the event; locale audit tests count events/denials, not persisted context bindings.
    All declared tests pass; no additional negative experiment was constructed.'
  required_fix: Provide an explicit canonical audit/context persistence boundary in
    the owned identity port that receives the trusted context and supplies a server-issued
    persisted reference. Set AuditEvent.RequestContextID to that reference and retain
    external RequestID in the context record/summary, preserving correlation and causation.
    Apply this to successful writes, denials and the explicitly supported pre-authentication/installer
    evidence paths without inventing anonymous administrator contexts. Extend the
    existing declared tests to prove the event resolves to the correct persisted context
    and that external RequestID is not substituted for its identity. This is a module
    port/binding requirement, not a demand for an undeclared downstream live database.
  status: open
  classification: new
  owner: identity-local
  first_seen_round: 3
  last_seen_round: 3
  seen_count: 1
- blocker_id: BLK-7e002b74f69c
  root_cause_key: identity-concurrent-idempotency-omits-password-equivalence
  obligation_id: dimension:structure
  summary: Concurrent replay branches skip the password-equivalence checks used for
    ordinary idempotent retries.
  evidence: 'Static evidence: recovery.go:195 hashes only the token digest; completedRecoveryReplay
    at 271-311 verifies password equivalence, but the transaction replay branch at
    228-232 directly unmarshals the saved result. service.go:128-130 omits password
    from the bootstrap digest and 177-183 skips bootstrapReplay verification when
    the record appears between the initial lookup and transaction. invitation.go:308
    similarly omits password and 326-330 skips acceptedInvitationReplay verification.
    Existing concurrent tests use different idempotency keys; ordinary replay tests
    validate sequential changed-input rejection, not this race. No additional negative-test
    input was constructed.'
  required_fix: Make password-equivalence validation part of every idempotency replay
    decision, including the atomic transaction branch, using the same protected comparison
    semantics as the ordinary replay path. Do not store plaintext or an unkeyed low-entropy
    request-password digest. Add deterministic concurrent same-key tests for identical
    input and changed input across bootstrap, invitation acceptance, and recovery;
    changed input must return a conflict rather than success.
  status: fixed
  classification: fixed
  owner: identity-local
  first_seen_round: 1
  last_seen_round: 2
  seen_count: 1
  last_evidence: Transaction replay branches at service.go:178-184, invitation.go:326-332,
    recovery.go:231-237 all invoke verifyReplayPassword (service.go:572-583), as do
    ordinary replay paths. This reads the protected credential hash and compares through
    the authenticator, with no persisted plaintext or added password request digest.
    Declared full suite independently passed TestConcurrentBootstrapIdempotencyChecksPasswordEquivalence,
    TestConcurrentInvitationIdempotencyChecksPasswordEquivalence, and TestConcurrentRecoveryIdempotencyChecksPasswordEquivalence;
    deterministic hashing barriers exercise same-input success and changed-input conflict.
- blocker_id: BLK-8646e42ba221
  root_cause_key: identity-dependency-errors-mapped-to-user-denials
  obligation_id: dimension:execution
  summary: Installer-authority outages and cancellation are still converted into permission
    denials.
  evidence: 'Static control-flow evidence at internal/identity/service.go:93-95 and
    internal/identity/recovery.go:121-123: any InstallerAuthority error is replaced
    with ErrForbidden. The port at types.go:163-166 returns a general error, with
    no denial-only restriction. fakeInstaller at identity_test.go:713-732 returns
    only business denials; TestBootstrapInstallerAndPersistenceFailureMatrix and TestRecoveryIssueAndBreakGlassFailureMatrix
    therefore do not exercise these operational failure paths. All existing declared
    commands passed; no additional negative test was constructed.'
  required_fix: Preserve or wrap operational/cancellation errors from both InstallerAuthority
    calls; map only an explicitly typed/sentinel authorization denial to ErrForbidden.
    Keep missing/invalid proof fail-closed and retain the intentional post-commit
    session and notification fallbacks. Add coverage in the existing declared suite
    for actual denial versus operational failure and cancellation for both installer
    entry points.
  status: fixed
  classification: fixed
  owner: identity-local
  first_seen_round: 1
  last_seen_round: 3
  seen_count: 2
  last_evidence: service.go:93-97 and recovery.go:122-130 map only errors.Is(ErrForbidden)
    to denial, wrap all other installer errors and reject missing proof. The independently
    executed TestBootstrapInstallerAndPersistenceFailureMatrix and TestRecoveryAuthorizationScopeAndBreakGlassReplayFailures
    include operational error and cancellation cases and distinguish them from actual
    denial. Existing credential/governance error propagation and intentional post-commit
    fallbacks remain intact.
- blocker_id: BLK-8c9128c2b72c
  root_cause_key: identity-request-metadata-regenerated-within-http-request
  obligation_id: dimension:evidence
  summary: Protected HTTP mutations regenerate request identity instead of propagating
    the resolved request metadata.
  evidence: handler.go:267 obtains requestMetadata for ResolveBrowserSession and 273
    exposes that RequestID; protected route callbacks invoke requestMetadata(r) again
    (e.g. 204 and 252). requestMetadata at 292-303 generates a new random RequestID
    each call and does not attach it to the request. locale.go:54-56 and recovery.go:40-42
    overwrite the RequestContext IDs with the second metadata. The shared governance
    reference security-and-enterprise.md:13-15 requires request identity propagation
    and causal tracing. Handler tests use testApplication, returning a fixed context
    at handler_test.go:119-124, and do not assert identity equality between resolution,
    authorization, audit, and response. Static code inspection establishes this discrepancy;
    no new request experiment was run.
  required_fix: Normalize metadata exactly once at the HTTP entry and pass the same
    immutable metadata through session resolution and the application call. Preserve
    the resolved RequestContext request/causation/correlation IDs instead of overwriting
    them with independently generated ones. Add handler-to-service regression assertions
    for absent and supplied request IDs across locale, recovery, invitation, and logout
    paths.
  status: fixed
  classification: fixed
  owner: identity-local
  first_seen_round: 1
  last_seen_round: 2
  seen_count: 1
  last_evidence: api/auth/local/handler.go:63,294-321 resolves request metadata once
    in the outer middleware and caches it in the request context. Session resolution
    and protected callbacks receive the same metadata; RequestContext IDs are carried
    to authorization and canonical audit in internal/identity/locale.go:50-57,99 and
    recovery.go:40-43,94. The independently rerun TestProtectedMutationsPropagateOneRequestMetadataValue
    checks generated and supplied IDs, correlation/causation, application RequestContext,
    and response headers for locale, recovery, invitation create/reissue/revoke, and
    logout.
- blocker_id: BLK-9a7d286279b9
  root_cause_key: identity-breakglass-concurrent-replay-returns-unpersisted-token
  obligation_id: dimension:structure
  summary: Concurrent break-glass recovery replay can return a successful response
    with a recovery link that was never persisted.
  evidence: 'Static evidence: internal/identity/recovery.go:134-145 performs an initial
    replay read, then allocates a fresh challenge identity and token. If another identical
    request commits before this call enters Transact, lines 148-151 load the prior
    result and return from the callback without storing this call''s challenge/token
    digest. After that successful transaction, line 178 unconditionally attaches this
    call''s fresh token to the replayed result. Ordinary recovery issue at recovery.go:102-104,
    invitation create at invitation.go:112-114, and reissue at invitation.go:205-207
    already guard this exact branch by comparing the committed result identity. TestRecoveryAuthorizationScopeAndBreakGlassReplayFailures
    at failure_paths_test.go:910-917 only checks sequential replay, so the declared
    passing suite does not rule this out. This finding is based solely on code inspection,
    not a new security experiment.'
  required_fix: Track whether this call actually committed the newly generated break-glass
    challenge and only expose its one-time link on that branch. Return the persisted
    token-free result on concurrent replay, consistently with ordinary recovery/invitation
    issuance, without storing plaintext tokens. Add a deterministic concurrent same-key
    regression to the existing declared suite proving that every emitted link corresponds
    to a committed challenge, only one challenge/audit is created, and replay emits
    no new link.
  status: fixed
  classification: fixed
  owner: identity-local
  first_seen_round: 2
  last_seen_round: 3
  seen_count: 1
  last_evidence: recovery.go:154-193 resets a created flag for each transaction callback,
    sets it only after challenge/audit/idempotency persistence succeeds, and attaches
    the token URL only for created=true. Concurrent replay returns the persisted token-free
    summary. TestConcurrentBreakGlassReplayOnlyReturnsPersistedToken at failure_paths_test.go:959-1025
    uses a deterministic ID barrier, asserts one persisted challenge, one matching
    emitted link, one audit and a token-free subsequent replay; it passed in the uncached
    full declared suite.

```


## Full original credential-store omac-review-report-d4b44c80ad70.yaml
SHA256 d4b44c80ad70cb6d63231afb8af079316bccbaf55a5f9cf9ab0d00fc3bf0e321; bytes 21914

```yaml
{
  "review_protocol": "omac.review/v2",
  "review_goals": [
    "Independently reproduce the exact credential-store gate at the sealed PR head.",
    "Inspect the complete implementation and tests against Governance authority, the narrow wire input and owner-only proof boundaries.",
    "Disposition every prior blocker and review the full changed scope without claiming trace-only UJ acceptance."
  ],
  "diff_reviewed": true,
  "tests_rerun": true,
  "integration_tests_rerun": true,
  "coverage_checked": true,
  "full_review_completed": true,
  "pr_url": "https://github.com/xiaohei-info/open-agent-cluster/pull/102",
  "reviewed_head_sha": "6c626bf573e6038634658890e8d7de205913ae02",
  "pr_base": "main",
  "coverage": 90.1,
  "summary": "Reject PR #102 at 6c626bf573e6038634658890e8d7de205913ae02. All five declared commands pass; coverage is 90.1% and source bundle digest reproduces exactly. Creation type safety is fixed. The prior audit and stale-use roots are only partially repaired; runtime GitHub App materialization and conditional-expiry rotation remain incomplete/conflicting. Findings below are static inspection plus declared verification, not additional attack experiments.",
  "env_setup": [
    "Independent clone checked out detached at the sealed PR head; no worker/shared worktree changed.",
    "Downloaded/selected Go 1.26.5 linux/arm64 through GOTOOLCHAIN; OAC_REAL_GO points to that binary.",
    "Created the env_setup-authorized coverage-output shim in ignored artifacts/credential-store/go-shim: only converts tab separators to spaces for go tool cover -func output and preserves its exit code; all tests execute the real Go binary.",
    "Source paths were already tracked in the sealed head, so no source staging/change was necessary for packaging."
  ],
  "obligation_results": [
    {
      "obligation_id": "dimension:authority",
      "status": "fail",
      "evidence": "Verified the exact structural-decomposition blob hash bee2866be23e0d5fe6f77a245f7f3177522308d5bd3ebbd14fb2baf0d9e37f19 and the declared detailed/reference/acceptance anchors. The consumed wire and owner impose mandatory rotation expiry contrary to the supported App-key lifecycle; see credential-rotation-conditional-expiry-conflicts-with-wire."
    },
    {
      "obligation_id": "dimension:structure",
      "status": "fail",
      "evidence": "Read all five added source/test files and the credential wire. Supported-type creation validates API-key/PAT/App metadata and provider scope, but accepted App Bindings have no runtime token-issuance handler; see credential-github-app-materialization-missing-type-handler."
    },
    {
      "obligation_id": "dimension:execution",
      "status": "fail",
      "evidence": "All declared commands pass independently; 90.1% statements. Store-read expiry checks and bounded Pending tests pass, but the separate durable delivery-start commit still precedes an unguarded consumer call; see credential-materialization-stale-use-window."
    },
    {
      "obligation_id": "dimension:ownership",
      "status": "pass",
      "evidence": "PR diff against main touches only internal/credentials/durable.go, owner.go and three owning-package test files. Reservation/finalization helpers, HMAC keys, secretStore and transaction paths are owner-private. Reconciliation loads durable authenticated records and compares exact lineage rather than trusting caller-shaped results. Existing canonical authz/audit/credential contracts are imported, not redefined; no adjacent module or manifest edits."
    },
    {
      "obligation_id": "dimension:evidence",
      "status": "fail",
      "evidence": "Manifest source_revision equals the sealed PR head and independently reproduced bundle SHA-256 f6c79a83f4061f9430e5f15994cea44a73efdb7ee99c1b9c6be88c7b3da2b73e matches worker evidence. Use/outcome handoffs now persist with replay deduplication, but some authorized failures still omit audit or attempted lineage; see credential-use-and-failure-audit-gap."
    },
    {
      "obligation_id": "dimension:regression",
      "status": "pass",
      "evidence": "Completed the whole new-head review, including original added files and rework changes. Dispositioned all three prior IDs explicitly below: creation fixed, audit deeper, stale-use deeper. Reviewed new type handlers/metadata, handoffs, delivery markers and supporting tests; no review-scope omission or assumption that prior passes carried forward."
    },
    {
      "obligation_id": "integration:credential-store-gate",
      "status": "pass",
      "evidence": "Reran every exact gate command with env_setup; each exits 0. Coverage assertion passes at 90.1%; all five exact named owner boundary tests pass; ownership-aware packaging creates every required artifact at the sealed source revision. These finite gate results do not prove absent profile/last-boundary behavior."
    }
  ],
  "prior_blocker_results": [
    {
      "blocker_id": "BLK-74de0bf0a781",
      "status": "deeper",
      "evidence": "internal/credentials/owner.go:465-488 validates the rotation authorization, then returns replay conflicts or a stale-CAS error without recordCredentialFailure/failRotation; rotationReplay at 523-537 is read-only. The existing stale-CAS case at owner_test.go:501-504 asserts only the returned error. Resolve at owner.go:815-825 sends authorized target/usage/subject failures through recordCredentialFailure; that helper at 1425-1435 persists Purpose=action and an empty boundary rather than the attempted request. In contrast, success/use witnesses and terminal replay deduplication are now implemented at 1142-1183 and independently passing owner_test.go:275-365. security-and-enterprise.md:491 requires audit for every resolution/use/failure/rotation/revocation. This is a static branch/lineage finding; no additional negative experiment was constructed."
    },
    {
      "blocker_id": "BLK-8bf407e188ad",
      "status": "deeper",
      "evidence": "internal/credentials/owner.go:1046 performs the last materializationEligible check; 1057-1066 marks delivery started. withState then validates state and performs the fsync/rename/directory-sync commit at durable.go:315-325,350-386 before returning. owner.go:1068-1076 invokes consume based solely on acquired, without a post-commit eligibility or terminal-state check. pendingMaterializationActive at 1128-1139 stops guarding lifecycle changes when the lease or two-minute delivery window expires; UpdateStatus at 373-393 can then terminalize Unknown and change status even though this original call has not reached consume. New tests at owner_review_test.go:343-475 cover expiry before acquisition and during Store read, not the commit-to-consumer interval. detailed design:418,505 requires current eligibility and fail-closed expiry. This is a static control-flow finding, not an added interleaving/security experiment."
    },
    {
      "blocker_id": "BLK-9e9b43e03248",
      "status": "fixed",
      "evidence": "owner.go:1533-1616 rejects unsupported types, checks context/subject, enforces PAT expiry/permissions/repository metadata, and requires a controlled App CreationValidator with provider-derived subject scope and permissions. API-key stays target-Probe based. Creation failure paths wipe copied secret bytes, do not persist an Active Binding and persist redacted failures. Independently passing owner_review_test.go:32-341 covers these creation branches; residual runtime/rotation findings are separately identified new roots, not re-labelled creation defects."
    }
  ],
  "acceptance_mapping": [
    {
      "mapping_kind": "responsibility-note",
      "acceptance_refs": [
        "UJ-CRED-001"
      ],
      "claim_status": "not-claimed",
      "evidence": "Trace-only responsibility: the current contract has no full-flow claims or Action contributions. This entry records that no UJ-CRED-001 end-to-end result is claimed; only the node-local gate and source-alignment review are reported."
    }
  ],
  "acceptance_notes": "UJ-CRED-001 is trace-only. Current contract has no acceptance_claims or acceptance_contributions; no UI/full-journey or downstream/live acceptance PASS is asserted.",
  "integration_gate_mapping": [
    {
      "gate": "credential-store-gate",
      "status": "pass",
      "source_of_truth": [
        "git:e1e48af331c0d568257e0eb2cbb88c1f19c97cb0:b-class-structural-decomposition-decisions.md#sha256=bee2866be23e0d5fe6f77a245f7f3177522308d5bd3ebbd14fb2baf0d9e37f19",
        "docs/design/detailed/09-governance-and-security-detailed-design.md:L408-L524",
        "docs/references/governance/security-and-enterprise.md:L402-L567",
        "docs/delivery/acceptance-and-validation.md:L314-L332"
      ],
      "delivery_goal": "Implement the Governance-owned current Binding CAS reservation, durable rotation finalization/audit witness, authenticated terminal materialization replay, redacted panic cleanup, and atomic broker/store reconciliation behind the narrow credential wire contract.",
      "commands": [
        {
          "cmd": "mkdir -p artifacts/credential-store && go test -covermode=atomic -coverprofile=artifacts/credential-store/coverage.out ./internal/credentials/...",
          "exit_code": 0,
          "summary": "ok  \tgithub.com/xiaohei-info/open-agent-cluster/internal/credentials\t(cached)\tcoverage: 90.1% of statements"
        },
        {
          "cmd": "python3 -c \"from pathlib import Path; import re,subprocess; p=Path('artifacts/credential-store/coverage.out'); assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True); m=re.search(r'^total:[ ]+[(]statements[)][ ]+([0-9.]+)%$',out,re.M); assert m and float(m.group(1)) >= 90\"",
          "exit_code": 0,
          "summary": ""
        },
        {
          "cmd": "mkdir -p artifacts/credential-store && go test -json ./internal/credentials/... -run '^(TestCredentialBindingReservationRequiresAuthoritativeCurrentCAS|TestCredentialRotationFinalizationRequiresDurableOwnerWitness|TestCredentialMaterializationTerminalReplayRequiresOwnerRecord|TestCredentialMaterializationPanicPersistsRedactedUnknown|TestCredentialReconciliationRejectsCallerAuthoredResult)$' -count=1 > artifacts/credential-store/owner-boundary-tests.json",
          "exit_code": 0,
          "summary": ""
        },
        {
          "cmd": "python3 -c \"import json; required={'TestCredentialBindingReservationRequiresAuthoritativeCurrentCAS', 'TestCredentialRotationFinalizationRequiresDurableOwnerWitness', 'TestCredentialMaterializationTerminalReplayRequiresOwnerRecord', 'TestCredentialMaterializationPanicPersistsRedactedUnknown', 'TestCredentialReconciliationRejectsCallerAuthoredResult'}; rows=[json.loads(x) for x in open('artifacts/credential-store/owner-boundary-tests.json') if x.strip()]; passed={x.get('Test') for x in rows if x.get('Action')=='pass' and x.get('Test') in required}; assert passed==required, f'missing required passing tests: {sorted(required-passed)}'\"",
          "exit_code": 0,
          "summary": ""
        },
        {
          "cmd": "python3 scripts/release/package_component.py --component credential-store --kind platform-core-dependency-source --input internal/credentials --bundle artifacts/credential-store/source-bundle.tar.zst --component-manifest artifacts/credential-store/component-manifest.json --digest-output artifacts/credential-store/bundle-digest.txt --ownership-baseline contracts/release/source-ownership-baseline.yaml --owner credential-store --require-all-owner-sources-accounted",
          "exit_code": 0,
          "summary": "bundle=artifacts/credential-store/source-bundle.tar.zst\nmanifest=artifacts/credential-store/component-manifest.json"
        }
      ],
      "metrics": {
        "statement_coverage_percent": 90.1,
        "required_owner_boundary_test_count": 5,
        "caller_minted_reservation_accept_count": 0,
        "caller_minted_finalization_accept_count": 0,
        "unsealed_terminal_result_accept_count": 0,
        "raw_panic_escape_count": 0
      },
      "artifacts": [
        "artifacts/credential-store/coverage.out",
        "artifacts/credential-store/owner-boundary-tests.json",
        "artifacts/credential-store/source-bundle.tar.zst",
        "artifacts/credential-store/bundle-digest.txt",
        "artifacts/credential-store/component-manifest.json"
      ],
      "evidence": "The numerical rejection/panic metrics describe the declared negative cases and owner-private interfaces inspected, not a universal claim over untested interleavings. All required artifacts are present/nonempty; manifest accounts for the exact five indexed owner sources and source bundle hashes match the verification handoff."
    }
  ],
  "blockers": [
    {
      "root_cause_key": "credential-use-and-failure-audit-gap",
      "obligation_id": "dimension:evidence",
      "classification": "deeper",
      "owner": "credential-store",
      "severity": "high",
      "summary": "Durable use/outcome handoffs were added, but authorized rotation failures still bypass audit and some resolution failures lose purpose/target lineage.",
      "impact": "Canonical audit ingestion cannot account for every authorized failed credential operation or reconstruct the attempted purpose and selected boundary. Passing use/panic tests do not close the all-failure-path requirement.",
      "evidence": "internal/credentials/owner.go:465-488 validates the rotation authorization, then returns replay conflicts or a stale-CAS error without recordCredentialFailure/failRotation; rotationReplay at 523-537 is read-only. The existing stale-CAS case at owner_test.go:501-504 asserts only the returned error. Resolve at owner.go:815-825 sends authorized target/usage/subject failures through recordCredentialFailure; that helper at 1425-1435 persists Purpose=action and an empty boundary rather than the attempted request. In contrast, success/use witnesses and terminal replay deduplication are now implemented at 1142-1183 and independently passing owner_test.go:275-365. security-and-enterprise.md:491 requires audit for every resolution/use/failure/rotation/revocation. This is a static branch/lineage finding; no additional negative experiment was constructed.",
      "required_fix": "Route all post-authorization rotation failure exits, including stale CAS and conflicting replay, through the durable redacted failure handoff. Preserve attempted resolve Usage, Subject and selected MaterializationBoundary in authorized failure lineage instead of replacing them with the action name and an empty boundary. Keep successful terminal replay audit deduplication. Add owning-package audit assertions for these existing rejection paths."
    },
    {
      "root_cause_key": "credential-materialization-stale-use-window",
      "obligation_id": "dimension:execution",
      "classification": "deeper",
      "owner": "credential-store",
      "severity": "high",
      "summary": "Eligibility is rechecked around Store read, but not after persisting the delivery marker and before invoking the consumer.",
      "impact": "A slow durable commit or scheduling delay can outlive the lease or bounded Pending authority; secret bytes already acquired can still be handed to the consumer after expiry or after a lifecycle change terminalizes that Pending record.",
      "evidence": "internal/credentials/owner.go:1046 performs the last materializationEligible check; 1057-1066 marks delivery started. withState then validates state and performs the fsync/rename/directory-sync commit at durable.go:315-325,350-386 before returning. owner.go:1068-1076 invokes consume based solely on acquired, without a post-commit eligibility or terminal-state check. pendingMaterializationActive at 1128-1139 stops guarding lifecycle changes when the lease or two-minute delivery window expires; UpdateStatus at 373-393 can then terminalize Unknown and change status even though this original call has not reached consume. New tests at owner_review_test.go:343-475 cover expiry before acquisition and during Store read, not the commit-to-consumer interval. detailed design:418,505 requires current eligibility and fail-closed expiry. This is a static control-flow finding, not an added interleaving/security experiment.",
      "required_fix": "Coordinate the durable delivery-start commit, final eligibility/terminal-state check, and actual consumer admission as one owner-controlled handoff. A marker that expires or becomes terminal while persistence/scheduling completes must not authorize subsequent byte delivery. Define lifecycle coordination at that final boundary without extending the lease; wipe acquired material and retain the authenticated redacted Unknown/audit outcome when admission is lost. Add a deterministic slow-commit/expired-marker regression test while preserving valid pre-rotation leases and immutable replay."
    },
    {
      "root_cause_key": "credential-github-app-materialization-missing-type-handler",
      "obligation_id": "dimension:structure",
      "classification": "new",
      "owner": "credential-store",
      "severity": "high",
      "summary": "The newly supported GitHub App profile materializes the stored private key, not an on-demand installation token.",
      "impact": "A Binding can become Active after provider-scope validation, but the advertised Repository/Skill consumer receives long-lived App key material rather than the provider-scoped short-lived credential required by the owning design. The supplied Validator cannot fill this missing runtime responsibility.",
      "evidence": "CreateBinding persists the uploaded material at internal/credentials/owner.go:282-298 and accepts github-app at 1568-1613. Resolve constructs a generic lease at 867-895, with no type-specific materialization descriptor. Materialize directly decrypts the stored handle at 1036 and sends those same bytes to consume at 1076. The production secretStore at durable.go:221-224,249-261 only encrypts/decrypts; Validator/CreationValidator at owner.go:47-65 provide validation, not token issuance. No production profile-dispatch or JWT/installation-token exchange path appears in the complete five-file PR diff. detailed design:482,487,498 and security reference:497 require Broker-owned JWT-to-installation-token issuance and provider-returned expires_at. Passing creation tests at owner_review_test.go:32-153 prove validation/scope retention, not this runtime behavior.",
      "required_fix": "Implement a controlled GitHub App type handler inside the Governance credential Store/Broker boundary that uses retained type metadata to obtain a purpose/subject-scoped installation token and bounds use by the provider expiry. Keep App private keys internal to that handler and materialize only the resulting short-lived credential to the selected consumer. Fail closed if the handler is absent or issuance fails; never delegate token minting to the arbitrary materializer callback. Add owning-package runtime profile/expiry/failure tests using controlled local fixtures, without requiring an undeclared live environment."
    },
    {
      "root_cause_key": "credential-rotation-conditional-expiry-conflicts-with-wire",
      "obligation_id": "dimension:authority",
      "classification": "new",
      "owner": "credential-store",
      "severity": "medium",
      "summary": "Supported non-expiring credentials cannot rotate without inventing an expiry, and the consumed wire also requires one.",
      "impact": "GitHub App creation explicitly requires no expiry, but the required add-key/test/switch/revoke lifecycle cannot be represented as a faithful rotation. Supplying an arbitrary future date changes non-expiring key semantics instead of resolving the published design/contract conflict.",
      "evidence": "internal/credentials/owner.go:1568-1570 accepts github-app only with zero ExpiresAt. Rotate at 460-462 and finalizeRotation at 659 reject zero expiry for every type; owner.go:683-688 copies that mandatory expiry into the record and 704-710 into Binding metadata. The allowlisted credential wire at contracts/governance/credential/wire.go:341-343 also rejects a rotation record with zero ExpiresAt. In contrast detailed design:427 says rotation expiry is optional, 489 explicitly states App private keys do not expire and requires rotation, and security reference:424,444 makes expiry type-dependent. All existing successful rotation fixtures at owner_test.go:122-126 supply an arbitrary future date for API-key credentials, so the passing gate does not exercise this conflict.",
      "required_fix": "Obtain explicit alignment of the consumed rotation wire with the authoritative conditional-expiry design, then enforce the resolved type-specific expiry rule in the owner and its durable witnesses. Do not fabricate App-key expiry merely to satisfy wire validation or silently edit upstream contracts in this implementation. Add a non-expiring-key rotation case and an expiring-PAT case against the aligned wire. Retain the existing CAS, idempotency and audit gates."
    }
  ],
  "nits": [],
  "security_evidence_boundary": "Only contract/env_setup verification was run. No live provider/network probing or new bypass/panic/interleaving experiment was constructed. Report omits secret fixtures, panic payloads and raw sensitive logs.",
  "submission_format_notes": "Original submit returned terminal ValidationError exit 5: acceptance_mapping must be non-empty. The original report is retained. Installed validate_review_evidence requires a non-empty list even when evidence_targets(contract) is empty, but only checks status/acceptance coverage for declared evidence targets. This revision adds an explicit non-claim responsibility note, not a fabricated acceptance ID or flow PASS; the technical verdict and all verification/findings are unchanged."
}
```


## Full original credential-store omac-review-ledger-df637f534989.yaml
SHA256 df637f5349894ccd92cea533d21dad5678e3d0383c2db267b5fdaed6a517550b; bytes 30595

```yaml
schema: omac.review-ledger/v2
cycles:
- round: 1
  subject_digest: 58fcadbd505dd89c518939ad866bab1427f02bb395a76ee8fe29162b851c6a6d
  report_digest: 6e5ea9f54fe95acbf8b5ee8e67f458d3b83979215c70bf1adc88bfa6eda3c236
  verdict: reject
  obligation_results:
    dimension:authority: pass
    dimension:structure: fail
    dimension:execution: fail
    dimension:ownership: pass
    dimension:evidence: fail
    dimension:regression: pass
    integration:credential-store-gate: pass
  new_count: 3
  fixed_count: 0
  regressed_count: 0
  unchanged_count: 0
  open_count: 3
  prior_open_blocker_ids: []
  open_blocker_ids: &id001
  - BLK-74de0bf0a781
  - BLK-8bf407e188ad
  - BLK-9e9b43e03248
  reported_blocker_ids: *id001
  blocker_facts_schema: omac.review-cycle-blocker-facts/v1
  blocker_facts:
  - blocker_id: BLK-74de0bf0a781
    root_cause_key: credential-use-and-failure-audit-gap
    obligation_id: dimension:evidence
    summary: Materialization outcomes and credential failure paths produce no durable
      AuditEvent.
    evidence: All production AuditEvents insertions are success-only creation/status/rotation/resolve
      writes at internal/credentials/owner.go:196,290,532,651. Materialize/finishMaterialization
      (664-803) update only Materializations and idempotency indexes; consumer failure,
      Store failure and panic cleanup never create an audit event. materializationEvidence
      (internal/credentials/durable.go:133-162) carries no audit witness. Rotate validation
      failures at owner.go:349-353 only release the reservation; Resolve rejection
      branches at 570-604 persist no failure audit. security-and-enterprise.md:491
      explicitly requires audit for every resolution, use, failure, rotation and revocation,
      and detailed design:464-471 includes cleanup plus AuditEvent. Passing panic
      tests prove durable redacted Unknown, not auditable failure.
    required_fix: Persist redacted credential-use/outcome and authorized failure AuditEvents
      with exact Binding, lease/materialization, request and purpose lineage in the
      owner transaction, and provide the canonical audit handoff rather than relying
      only on the private success-event map. Preserve idempotent replay so it does
      not emit duplicate events; keep Secret bytes, provider responses and panic payloads
      out of audit data. Add assertions for successful use, failure, panic/cleanup
      and terminal replay audit behavior.
    status: open
    classification: new
    owner: credential-store
  - blocker_id: BLK-8bf407e188ad
    root_cause_key: credential-materialization-stale-use-window
    obligation_id: dimension:execution
    summary: Materialization can deliver material after the Binding is disabled or
      the lease expires between its two owner transactions.
    evidence: internal/credentials/owner.go:697-748 checks active Binding and lease
      expiry only while committing Pending (726-727), then releases the owner lock.
      The separate Store-read transaction at 753-764 verifies sealed lineage but never
      reloads/checks current Binding status, lease expiry, or that the materialization
      is still Pending. consume runs at 770. UpdateStatus can commit Disabled in the
      gap (248-293); Disabled retains encrypted material. Likewise expiry can occur
      while the second transaction waits. TestCredentialResolveBindsBoundaryAndFailsClosedOnStatusChange
      only tests disable before Materialize starts (owner_test.go:457-463), not this
      gap. This is a static control-flow finding; no additional security experiment
      was constructed.
    required_fix: Make the authoritative eligibility check and material acquisition
      one guarded owner operation at the last safe boundary, verifying current Binding
      status, lease state/expiry and Pending ownership before delivering bytes. Define
      coordination with concurrent lifecycle changes so an already-issued Pending
      marker is not treated as indefinite authority. Preserve legitimate pre-rotation
      lease lineage and immutable terminal replay. Add deterministic interleaving/expiry
      regression tests in the owning package.
    status: open
    classification: new
    owner: credential-store
  - blocker_id: BLK-9e9b43e03248
    root_cause_key: credential-creation-skips-type-safety
    obligation_id: dimension:structure
    summary: CreateBinding marks arbitrary credential types Active without applying
      any type-specific creation rules.
    evidence: internal/credentials/owner.go:63-77 has no TypeMetadata or typed creation
      evidence. CreateBinding at 119-200 checks generic metadata, derives usage/subject,
      encrypts material and writes Active; it never invokes the configured Validator.
      CredentialBindingMetadata.Validate at contracts/governance/credential/wire.go:212-240
      requires only a nonempty CredentialType, and a zero ExpiresAt is accepted by
      CreateBinding at 126. validateMaterial is reached only from Rotate (349). The
      owning design requires type-fixed safety rules (detailed design:439), conditional
      PAT expiry (489), and controlled GitHub App validation/provider-derived scope
      before final creation (487; security reference:512). Generic API-key target
      Probe is expressly different and must not be converted into a universal credential
      test.
    required_fix: Add an explicit supported-type creation path that carries and validates
      required non-sensitive type metadata, enforces conditional expiry, and requires
      controlled type-specific validation/scope evidence where the design requires
      it before committing Active. Reject unsupported types instead of treating arbitrary
      nonempty strings as implemented. Keep generic API-key/MCP validity testing at
      the selected target Probe boundary and retain failure cleanup. This repair belongs
      to credential-store; no downstream evidence or new external artifact is requested.
    status: open
    classification: new
    owner: credential-store
- round: 2
  subject_digest: dc3a78442552735f609d2bb105ee3a30e6e300f5e94bd73563b84f2f969b6d94
  report_digest: 74cababdf31de3be267a7e54c3d648575d1272fc0f587815f0b2aed82661aa9f
  verdict: reject
  obligation_results:
    dimension:authority: fail
    dimension:structure: fail
    dimension:execution: fail
    dimension:ownership: pass
    dimension:evidence: fail
    dimension:regression: pass
    integration:credential-store-gate: pass
  new_count: 2
  fixed_count: 1
  regressed_count: 0
  unchanged_count: 0
  open_count: 4
  prior_open_blocker_ids:
  - BLK-74de0bf0a781
  - BLK-8bf407e188ad
  - BLK-9e9b43e03248
  open_blocker_ids: &id002
  - BLK-74de0bf0a781
  - BLK-8bf407e188ad
  - BLK-a9b452c2b67e
  - BLK-c3a9a7b897fb
  reported_blocker_ids: *id002
  blocker_facts_schema: omac.review-cycle-blocker-facts/v1
  blocker_facts:
  - blocker_id: BLK-74de0bf0a781
    root_cause_key: credential-use-and-failure-audit-gap
    obligation_id: dimension:evidence
    summary: Durable use/outcome handoffs were added, but authorized rotation failures
      still bypass audit and some resolution failures lose purpose/target lineage.
    evidence: internal/credentials/owner.go:465-488 validates the rotation authorization,
      then returns replay conflicts or a stale-CAS error without recordCredentialFailure/failRotation;
      rotationReplay at 523-537 is read-only. The existing stale-CAS case at owner_test.go:501-504
      asserts only the returned error. Resolve at owner.go:815-825 sends authorized
      target/usage/subject failures through recordCredentialFailure; that helper at
      1425-1435 persists Purpose=action and an empty boundary rather than the attempted
      request. In contrast, success/use witnesses and terminal replay deduplication
      are now implemented at 1142-1183 and independently passing owner_test.go:275-365.
      security-and-enterprise.md:491 requires audit for every resolution/use/failure/rotation/revocation.
      This is a static branch/lineage finding; no additional negative experiment was
      constructed.
    required_fix: Route all post-authorization rotation failure exits, including stale
      CAS and conflicting replay, through the durable redacted failure handoff. Preserve
      attempted resolve Usage, Subject and selected MaterializationBoundary in authorized
      failure lineage instead of replacing them with the action name and an empty
      boundary. Keep successful terminal replay audit deduplication. Add owning-package
      audit assertions for these existing rejection paths.
    status: open
    classification: deeper
    owner: credential-store
    last_evidence: internal/credentials/owner.go:465-488 validates the rotation authorization,
      then returns replay conflicts or a stale-CAS error without recordCredentialFailure/failRotation;
      rotationReplay at 523-537 is read-only. The existing stale-CAS case at owner_test.go:501-504
      asserts only the returned error. Resolve at owner.go:815-825 sends authorized
      target/usage/subject failures through recordCredentialFailure; that helper at
      1425-1435 persists Purpose=action and an empty boundary rather than the attempted
      request. In contrast, success/use witnesses and terminal replay deduplication
      are now implemented at 1142-1183 and independently passing owner_test.go:275-365.
      security-and-enterprise.md:491 requires audit for every resolution/use/failure/rotation/revocation.
      This is a static branch/lineage finding; no additional negative experiment was
      constructed.
  - blocker_id: BLK-8bf407e188ad
    root_cause_key: credential-materialization-stale-use-window
    obligation_id: dimension:execution
    summary: Eligibility is rechecked around Store read, but not after persisting
      the delivery marker and before invoking the consumer.
    evidence: internal/credentials/owner.go:1046 performs the last materializationEligible
      check; 1057-1066 marks delivery started. withState then validates state and
      performs the fsync/rename/directory-sync commit at durable.go:315-325,350-386
      before returning. owner.go:1068-1076 invokes consume based solely on acquired,
      without a post-commit eligibility or terminal-state check. pendingMaterializationActive
      at 1128-1139 stops guarding lifecycle changes when the lease or two-minute delivery
      window expires; UpdateStatus at 373-393 can then terminalize Unknown and change
      status even though this original call has not reached consume. New tests at
      owner_review_test.go:343-475 cover expiry before acquisition and during Store
      read, not the commit-to-consumer interval. detailed design:418,505 requires
      current eligibility and fail-closed expiry. This is a static control-flow finding,
      not an added interleaving/security experiment.
    required_fix: Coordinate the durable delivery-start commit, final eligibility/terminal-state
      check, and actual consumer admission as one owner-controlled handoff. A marker
      that expires or becomes terminal while persistence/scheduling completes must
      not authorize subsequent byte delivery. Define lifecycle coordination at that
      final boundary without extending the lease; wipe acquired material and retain
      the authenticated redacted Unknown/audit outcome when admission is lost. Add
      a deterministic slow-commit/expired-marker regression test while preserving
      valid pre-rotation leases and immutable replay.
    status: open
    classification: deeper
    owner: credential-store
    last_evidence: internal/credentials/owner.go:1046 performs the last materializationEligible
      check; 1057-1066 marks delivery started. withState then validates state and
      performs the fsync/rename/directory-sync commit at durable.go:315-325,350-386
      before returning. owner.go:1068-1076 invokes consume based solely on acquired,
      without a post-commit eligibility or terminal-state check. pendingMaterializationActive
      at 1128-1139 stops guarding lifecycle changes when the lease or two-minute delivery
      window expires; UpdateStatus at 373-393 can then terminalize Unknown and change
      status even though this original call has not reached consume. New tests at
      owner_review_test.go:343-475 cover expiry before acquisition and during Store
      read, not the commit-to-consumer interval. detailed design:418,505 requires
      current eligibility and fail-closed expiry. This is a static control-flow finding,
      not an added interleaving/security experiment.
  - blocker_id: BLK-9e9b43e03248
    root_cause_key: credential-creation-skips-type-safety
    obligation_id: dimension:structure
    summary: CreateBinding marks arbitrary credential types Active without applying
      any type-specific creation rules.
    evidence: internal/credentials/owner.go:63-77 has no TypeMetadata or typed creation
      evidence. CreateBinding at 119-200 checks generic metadata, derives usage/subject,
      encrypts material and writes Active; it never invokes the configured Validator.
      CredentialBindingMetadata.Validate at contracts/governance/credential/wire.go:212-240
      requires only a nonempty CredentialType, and a zero ExpiresAt is accepted by
      CreateBinding at 126. validateMaterial is reached only from Rotate (349). The
      owning design requires type-fixed safety rules (detailed design:439), conditional
      PAT expiry (489), and controlled GitHub App validation/provider-derived scope
      before final creation (487; security reference:512). Generic API-key target
      Probe is expressly different and must not be converted into a universal credential
      test.
    required_fix: Add an explicit supported-type creation path that carries and validates
      required non-sensitive type metadata, enforces conditional expiry, and requires
      controlled type-specific validation/scope evidence where the design requires
      it before committing Active. Reject unsupported types instead of treating arbitrary
      nonempty strings as implemented. Keep generic API-key/MCP validity testing at
      the selected target Probe boundary and retain failure cleanup. This repair belongs
      to credential-store; no downstream evidence or new external artifact is requested.
    status: fixed
    classification: fixed
    last_evidence: owner.go:1533-1616 rejects unsupported types, checks context/subject,
      enforces PAT expiry/permissions/repository metadata, and requires a controlled
      App CreationValidator with provider-derived subject scope and permissions. API-key
      stays target-Probe based. Creation failure paths wipe copied secret bytes, do
      not persist an Active Binding and persist redacted failures. Independently passing
      owner_review_test.go:32-341 covers these creation branches; residual runtime/rotation
      findings are separately identified new roots, not re-labelled creation defects.
    owner: credential-store
  - blocker_id: BLK-a9b452c2b67e
    root_cause_key: credential-github-app-materialization-missing-type-handler
    obligation_id: dimension:structure
    summary: The newly supported GitHub App profile materializes the stored private
      key, not an on-demand installation token.
    evidence: CreateBinding persists the uploaded material at internal/credentials/owner.go:282-298
      and accepts github-app at 1568-1613. Resolve constructs a generic lease at 867-895,
      with no type-specific materialization descriptor. Materialize directly decrypts
      the stored handle at 1036 and sends those same bytes to consume at 1076. The
      production secretStore at durable.go:221-224,249-261 only encrypts/decrypts;
      Validator/CreationValidator at owner.go:47-65 provide validation, not token
      issuance. No production profile-dispatch or JWT/installation-token exchange
      path appears in the complete five-file PR diff. detailed design:482,487,498
      and security reference:497 require Broker-owned JWT-to-installation-token issuance
      and provider-returned expires_at. Passing creation tests at owner_review_test.go:32-153
      prove validation/scope retention, not this runtime behavior.
    required_fix: Implement a controlled GitHub App type handler inside the Governance
      credential Store/Broker boundary that uses retained type metadata to obtain
      a purpose/subject-scoped installation token and bounds use by the provider expiry.
      Keep App private keys internal to that handler and materialize only the resulting
      short-lived credential to the selected consumer. Fail closed if the handler
      is absent or issuance fails; never delegate token minting to the arbitrary materializer
      callback. Add owning-package runtime profile/expiry/failure tests using controlled
      local fixtures, without requiring an undeclared live environment.
    status: open
    classification: new
    owner: credential-store
  - blocker_id: BLK-c3a9a7b897fb
    root_cause_key: credential-rotation-conditional-expiry-conflicts-with-wire
    obligation_id: dimension:authority
    summary: Supported non-expiring credentials cannot rotate without inventing an
      expiry, and the consumed wire also requires one.
    evidence: internal/credentials/owner.go:1568-1570 accepts github-app only with
      zero ExpiresAt. Rotate at 460-462 and finalizeRotation at 659 reject zero expiry
      for every type; owner.go:683-688 copies that mandatory expiry into the record
      and 704-710 into Binding metadata. The allowlisted credential wire at contracts/governance/credential/wire.go:341-343
      also rejects a rotation record with zero ExpiresAt. In contrast detailed design:427
      says rotation expiry is optional, 489 explicitly states App private keys do
      not expire and requires rotation, and security reference:424,444 makes expiry
      type-dependent. All existing successful rotation fixtures at owner_test.go:122-126
      supply an arbitrary future date for API-key credentials, so the passing gate
      does not exercise this conflict.
    required_fix: Obtain explicit alignment of the consumed rotation wire with the
      authoritative conditional-expiry design, then enforce the resolved type-specific
      expiry rule in the owner and its durable witnesses. Do not fabricate App-key
      expiry merely to satisfy wire validation or silently edit upstream contracts
      in this implementation. Add a non-expiring-key rotation case and an expiring-PAT
      case against the aligned wire. Retain the existing CAS, idempotency and audit
      gates.
    status: open
    classification: new
    owner: credential-store
blockers:
- blocker_id: BLK-74de0bf0a781
  root_cause_key: credential-use-and-failure-audit-gap
  obligation_id: dimension:evidence
  summary: Durable use/outcome handoffs were added, but authorized rotation failures
    still bypass audit and some resolution failures lose purpose/target lineage.
  evidence: internal/credentials/owner.go:465-488 validates the rotation authorization,
    then returns replay conflicts or a stale-CAS error without recordCredentialFailure/failRotation;
    rotationReplay at 523-537 is read-only. The existing stale-CAS case at owner_test.go:501-504
    asserts only the returned error. Resolve at owner.go:815-825 sends authorized
    target/usage/subject failures through recordCredentialFailure; that helper at
    1425-1435 persists Purpose=action and an empty boundary rather than the attempted
    request. In contrast, success/use witnesses and terminal replay deduplication
    are now implemented at 1142-1183 and independently passing owner_test.go:275-365.
    security-and-enterprise.md:491 requires audit for every resolution/use/failure/rotation/revocation.
    This is a static branch/lineage finding; no additional negative experiment was
    constructed.
  required_fix: Route all post-authorization rotation failure exits, including stale
    CAS and conflicting replay, through the durable redacted failure handoff. Preserve
    attempted resolve Usage, Subject and selected MaterializationBoundary in authorized
    failure lineage instead of replacing them with the action name and an empty boundary.
    Keep successful terminal replay audit deduplication. Add owning-package audit
    assertions for these existing rejection paths.
  status: open
  classification: deeper
  owner: credential-store
  first_seen_round: 1
  last_seen_round: 2
  seen_count: 2
  last_evidence: internal/credentials/owner.go:465-488 validates the rotation authorization,
    then returns replay conflicts or a stale-CAS error without recordCredentialFailure/failRotation;
    rotationReplay at 523-537 is read-only. The existing stale-CAS case at owner_test.go:501-504
    asserts only the returned error. Resolve at owner.go:815-825 sends authorized
    target/usage/subject failures through recordCredentialFailure; that helper at
    1425-1435 persists Purpose=action and an empty boundary rather than the attempted
    request. In contrast, success/use witnesses and terminal replay deduplication
    are now implemented at 1142-1183 and independently passing owner_test.go:275-365.
    security-and-enterprise.md:491 requires audit for every resolution/use/failure/rotation/revocation.
    This is a static branch/lineage finding; no additional negative experiment was
    constructed.
- blocker_id: BLK-8bf407e188ad
  root_cause_key: credential-materialization-stale-use-window
  obligation_id: dimension:execution
  summary: Eligibility is rechecked around Store read, but not after persisting the
    delivery marker and before invoking the consumer.
  evidence: internal/credentials/owner.go:1046 performs the last materializationEligible
    check; 1057-1066 marks delivery started. withState then validates state and performs
    the fsync/rename/directory-sync commit at durable.go:315-325,350-386 before returning.
    owner.go:1068-1076 invokes consume based solely on acquired, without a post-commit
    eligibility or terminal-state check. pendingMaterializationActive at 1128-1139
    stops guarding lifecycle changes when the lease or two-minute delivery window
    expires; UpdateStatus at 373-393 can then terminalize Unknown and change status
    even though this original call has not reached consume. New tests at owner_review_test.go:343-475
    cover expiry before acquisition and during Store read, not the commit-to-consumer
    interval. detailed design:418,505 requires current eligibility and fail-closed
    expiry. This is a static control-flow finding, not an added interleaving/security
    experiment.
  required_fix: Coordinate the durable delivery-start commit, final eligibility/terminal-state
    check, and actual consumer admission as one owner-controlled handoff. A marker
    that expires or becomes terminal while persistence/scheduling completes must not
    authorize subsequent byte delivery. Define lifecycle coordination at that final
    boundary without extending the lease; wipe acquired material and retain the authenticated
    redacted Unknown/audit outcome when admission is lost. Add a deterministic slow-commit/expired-marker
    regression test while preserving valid pre-rotation leases and immutable replay.
  status: open
  classification: deeper
  owner: credential-store
  first_seen_round: 1
  last_seen_round: 2
  seen_count: 2
  last_evidence: internal/credentials/owner.go:1046 performs the last materializationEligible
    check; 1057-1066 marks delivery started. withState then validates state and performs
    the fsync/rename/directory-sync commit at durable.go:315-325,350-386 before returning.
    owner.go:1068-1076 invokes consume based solely on acquired, without a post-commit
    eligibility or terminal-state check. pendingMaterializationActive at 1128-1139
    stops guarding lifecycle changes when the lease or two-minute delivery window
    expires; UpdateStatus at 373-393 can then terminalize Unknown and change status
    even though this original call has not reached consume. New tests at owner_review_test.go:343-475
    cover expiry before acquisition and during Store read, not the commit-to-consumer
    interval. detailed design:418,505 requires current eligibility and fail-closed
    expiry. This is a static control-flow finding, not an added interleaving/security
    experiment.
- blocker_id: BLK-9e9b43e03248
  root_cause_key: credential-creation-skips-type-safety
  obligation_id: dimension:structure
  summary: CreateBinding marks arbitrary credential types Active without applying
    any type-specific creation rules.
  evidence: internal/credentials/owner.go:63-77 has no TypeMetadata or typed creation
    evidence. CreateBinding at 119-200 checks generic metadata, derives usage/subject,
    encrypts material and writes Active; it never invokes the configured Validator.
    CredentialBindingMetadata.Validate at contracts/governance/credential/wire.go:212-240
    requires only a nonempty CredentialType, and a zero ExpiresAt is accepted by CreateBinding
    at 126. validateMaterial is reached only from Rotate (349). The owning design
    requires type-fixed safety rules (detailed design:439), conditional PAT expiry
    (489), and controlled GitHub App validation/provider-derived scope before final
    creation (487; security reference:512). Generic API-key target Probe is expressly
    different and must not be converted into a universal credential test.
  required_fix: Add an explicit supported-type creation path that carries and validates
    required non-sensitive type metadata, enforces conditional expiry, and requires
    controlled type-specific validation/scope evidence where the design requires it
    before committing Active. Reject unsupported types instead of treating arbitrary
    nonempty strings as implemented. Keep generic API-key/MCP validity testing at
    the selected target Probe boundary and retain failure cleanup. This repair belongs
    to credential-store; no downstream evidence or new external artifact is requested.
  status: fixed
  classification: fixed
  owner: credential-store
  first_seen_round: 1
  last_seen_round: 2
  seen_count: 1
  last_evidence: owner.go:1533-1616 rejects unsupported types, checks context/subject,
    enforces PAT expiry/permissions/repository metadata, and requires a controlled
    App CreationValidator with provider-derived subject scope and permissions. API-key
    stays target-Probe based. Creation failure paths wipe copied secret bytes, do
    not persist an Active Binding and persist redacted failures. Independently passing
    owner_review_test.go:32-341 covers these creation branches; residual runtime/rotation
    findings are separately identified new roots, not re-labelled creation defects.
- blocker_id: BLK-a9b452c2b67e
  root_cause_key: credential-github-app-materialization-missing-type-handler
  obligation_id: dimension:structure
  summary: The newly supported GitHub App profile materializes the stored private
    key, not an on-demand installation token.
  evidence: CreateBinding persists the uploaded material at internal/credentials/owner.go:282-298
    and accepts github-app at 1568-1613. Resolve constructs a generic lease at 867-895,
    with no type-specific materialization descriptor. Materialize directly decrypts
    the stored handle at 1036 and sends those same bytes to consume at 1076. The production
    secretStore at durable.go:221-224,249-261 only encrypts/decrypts; Validator/CreationValidator
    at owner.go:47-65 provide validation, not token issuance. No production profile-dispatch
    or JWT/installation-token exchange path appears in the complete five-file PR diff.
    detailed design:482,487,498 and security reference:497 require Broker-owned JWT-to-installation-token
    issuance and provider-returned expires_at. Passing creation tests at owner_review_test.go:32-153
    prove validation/scope retention, not this runtime behavior.
  required_fix: Implement a controlled GitHub App type handler inside the Governance
    credential Store/Broker boundary that uses retained type metadata to obtain a
    purpose/subject-scoped installation token and bounds use by the provider expiry.
    Keep App private keys internal to that handler and materialize only the resulting
    short-lived credential to the selected consumer. Fail closed if the handler is
    absent or issuance fails; never delegate token minting to the arbitrary materializer
    callback. Add owning-package runtime profile/expiry/failure tests using controlled
    local fixtures, without requiring an undeclared live environment.
  status: open
  classification: new
  owner: credential-store
  first_seen_round: 2
  last_seen_round: 2
  seen_count: 1
- blocker_id: BLK-c3a9a7b897fb
  root_cause_key: credential-rotation-conditional-expiry-conflicts-with-wire
  obligation_id: dimension:authority
  summary: Supported non-expiring credentials cannot rotate without inventing an expiry,
    and the consumed wire also requires one.
  evidence: internal/credentials/owner.go:1568-1570 accepts github-app only with zero
    ExpiresAt. Rotate at 460-462 and finalizeRotation at 659 reject zero expiry for
    every type; owner.go:683-688 copies that mandatory expiry into the record and
    704-710 into Binding metadata. The allowlisted credential wire at contracts/governance/credential/wire.go:341-343
    also rejects a rotation record with zero ExpiresAt. In contrast detailed design:427
    says rotation expiry is optional, 489 explicitly states App private keys do not
    expire and requires rotation, and security reference:424,444 makes expiry type-dependent.
    All existing successful rotation fixtures at owner_test.go:122-126 supply an arbitrary
    future date for API-key credentials, so the passing gate does not exercise this
    conflict.
  required_fix: Obtain explicit alignment of the consumed rotation wire with the authoritative
    conditional-expiry design, then enforce the resolved type-specific expiry rule
    in the owner and its durable witnesses. Do not fabricate App-key expiry merely
    to satisfy wire validation or silently edit upstream contracts in this implementation.
    Add a non-expiring-key rotation case and an expiring-PAT case against the aligned
    wire. Retain the existing CAS, idempotency and audit gates.
  status: open
  classification: new
  owner: credential-store
  first_seen_round: 2
  last_seen_round: 2
  seen_count: 1

```


## Full original queued Source requests (historical labels)

# Current identity-local owner responsibility request

Queued factual coordination request under Root9512, not admission, a proposal, implementation or product verdict. The actual terminal Worker v2 and full independent reject report/ledger are bound in /tmp/oac-identity-local-canonical-audit-proof-owner-bound-0855-20261004. Planner must inspect full current owning overview/detailed/exact references/acceptance/deploy boundaries and current physical source, rather than treating Worker owner-gap claims as a technical verdict. Current sampled main is 86624dab82924df9ba2a74107c45084ccaa5e7f2; source bytes here are immutable source captures, not retrieval of historical declared production Artifacts.

Node identity-local, issue 01a10382-ee40-74ef-8809-109e5d50bbe7, reviewed head ce2e24013d151c41c9d058cb2262f64d8374281a remains uncompleted. Its actual blocker binding, generation including actual None, full contract, original failures, all review cycles and absolute/effective approved budgets remain authoritative. Do not reopen or amend any current DONE producer, including AgentDefinition/AgentTemplate/AgentModelPolicy/Authorization/Audit contracts and every one of the current 71 done FULLobjects. All 18 retained approved budget records remain exact.

Derive a smallest genuine current-uncompleted or necessary compensating owner/scope/dependency/typed immutable proof repair from the actual owning design and source. Verify whether each reported absence is real and which semantic owner can lawfully supply it. Keep canonical RequestContext, evaluated control provenance, immutable audit/write boundaries, northbound adapters and inward dependencies intact. Do not fabricate policy/provider provenance, create a parallel audit schema/store, import adapter DTOs inward, label test applications as production, waive the original rejection, or invent an API/contract on Root's behalf. No generic assessment, empty operations, unchanged resume, plan route, fake evidence/ROOTs, direct merge or product PASS.

Any necessary affected/derived recoveries must explicitly use budget_policy: preserve: original absolute/relative consumed and remaining budgets, approved authority, limits, baseline/CAS identity and complete history; no implicit refund, reset or historical fixture as live admission. A genuinely new proposal requires a fresh independent Reviewer and full report/ledger, terminal controller, current minimal operation/stage/source/Store/CAS/related-terminal/all-current-done/budget guards before Root acceptable apply. The ordinary Runner is the sole control writer; no parallel B controller. Healthy related execution is preserved and old terminal observations are not current admission proof.

This request queues inputs only. Before formal admission refresh all current source/main/Store/native/CAS/done/budget bindings. Preserve original reports and Worker source unchanged. Workspace external resources remain deferred; no Root OAC code/test/contract design, live operation, or OMAC fixer product implementation. Target .omac/identity-local-canonical-audit-proof-owner-reviewed-20261004.yaml.

# Credential conditional-expiry owner responsibility request

Queued source-bound coordination request under Root9512. This is not admission, implementation, an amendment proposal, a technical verdict or a Worker retry. The actual terminal v2 owner decision and full independent REJECT report/ledger remain preserved in /tmp/oac-credential-conditional-expiry-owner-bound-0913-20261004.

Credential issue01a10384-778a-7d81-aacf-09c8da085586 remains blocked AUTHORING. Developer01a105d1-aab6-7377-b49b-6d5230973bf6 submitted one genuine terminal work block at08:56:55.690642 UTC, then stopped. Binding generationauthoring-6e52e8a37eebf435b3e10373, contract839d8002ba6367b0e903dc42c19a908b50c54f07f6de26a81992bab788cfe3bc, handoff3dbcc3022199506c and abs0/2/0 are protected. Clean physical Worker head83ccdab0d8f72492c30adaa5ebf3e4b296947b23/PR102 is author source only; the previous sealed delivery and full4-open-root independent REJECT on6c626 remain immutable history. No independent closure of the new rework is claimed.

Planner must verify the reported conditional-expiry conflict against complete current overview/detailed09/security-and-enterprise exact references, acceptance, immutable consumed wire, published contract compatibility rules and actual source. Preserve the owning approved type-dependent expiry/lifecycle requirements; do not make up an App-key expiry or narrow credential rotation to fit an implementation. Root does not define replacement wire fields, schema, API or implementation. Determine the smallest lawful current-uncompleted or necessary compensating owner and dependency/consumer/immutable publication repair, with precise scope and verification. contracts-credential is already DONE and must not be reopened or rewritten as a DAG producer; any necessary published-contract change requires the owning reviewed compatibility/change mechanism and fresh source-bound independent amendment review, not silently reinterpreting stored records.

All original failures, two review cycles/five historical roots/four open roots, fullreportd4b44c80ad70/21914, fullledgerdf637f534989/30595, old delivery/seal/verification, current Worker source, auth/audit/materialization/type-safety gates and effective absolute/relative consumed+remaining budgets remain. Preserve all current72 done FULLobjects and whole18 retained approved budget records. Any affected/derived recoveries must explicitly use budget_policy: preserve, with no implicit refund/reset/limit grant/history clear. Original audit/stale-materialization/GitHub-App-handler findings need fresh independent disposition after eventual repair; Worker claims and passing local commands are not product PASS.

No generic assessment, empty operations, unchanged resume, plan route, synthetic reports/seals/metrics/artifacts, second truth store, secret publication, done-producer reopen, Root source/test/contract design, direct merge or OMAC fixer product implementation. A new actual proposal requires fresh current main/source/Store/native/related-terminal/CAS/done/budget binding, Planner plus fresh independent Reviewer fullreport/ledger, terminal controller and actual minimal operations/stages/guards before Root acceptable apply. The ordinary Runner is the sole control writer; no parallel B controller or healthy Actor comment/cancel/unassign. Healthy Installer/Audit/API execution continues. Workspace external resources remain deferred. Target .omac/credential-conditional-expiry-owner-reviewed-20261004.yaml.
