# Source-bound Platform Workflow input owner request

Produce a concrete executable responsibility/contract/dependency amendment and fresh independent review for the actual terminal v2 report below. This is a different conflict from the already merged capability-admission producer. Do not repeat that applied amendment, reopen completed producers, use plan/generic assessment/unchanged resume, or assume the Worker claim is a product verdict.

Current aggregate contracts-platform-resource / issue1b8e6ca8-4372-4974-a909-8994d0b05990: latest Developer01a1010c-b9d9-7145-b529-55dd2796cd9e completed09:43:36 after work block accepted exit20/terminal stop09:42:51. Native170 messages and fresh Store are preserved. PR8 remains OPEN60440b198d0ed5eda2f1d66371b9504a4ec2f68b; actual local HEAD8b146f789986d20bbab4de1a3e475f2f73de1271/tree2683fbe9808702418e38bd65ae56f6873f959a7c includes Worker rebase, both dirty aggregate test files and full binary patch remain unsubmitted. Coordinator did not edit or rerun OAC tests.

The native focused command exited1 with non-artifact Workflow input was accepted; full package failure is also recorded in full messages. The restored fixed assertion supplies a structurally valid Kind=decision reference to WorkflowSpec.InputArtifactIDs. Read current owning overview, detailed03, exact workflow reference, original pinned66efa tests, entire current source, all producer artifacts/owner contracts and original full reject before judging whether a missing owner implementation, valid API adaptation or new product choice exists. Public reference identifies creation-selected immutable input Artifact identities; independently reconcile that text and concrete typed carrier semantics, do not turn this coordinator observation into a technical decision. Choose and justify actual legal owner/scope/ordering or exact missing decision; no leaf production edits by aggregate's current two-test scope. Existing capability approval is not authority to change InputArtifactIDs or waive a pinned assertion.

Preserve current178 nodes/all64 done full objects and original histories. Original aggregate full report00483ca42e8d2d98741e4fa578967ce16ea8fedd6b480b10e2e0bd5f5c49567d/23836 and ledger4d943d149b4489939b3b70bea0de0f268ec9b9c9b54fd458e2fc61c17f29357c/18413, BLK-30432e7dcdee, all original29 Tests/14 helpers/every positive-negative scenario and failure cause, exact4 commands/package90/deterministic ownership and trace-only integration remain required. Check the complete pinned suite for any further genuine unresolved carrier/scope mismatch now, so a proposal is sufficient and concrete rather than hiding remaining cases. Do not weaken unrelated expectations, add speculative capability, alter frozen Kernel or invent passing evidence. Any compensating production owner must independently implement, review and really merge exact artifacts before aggregate resumes its complete original obligations.

Budget absolute20/12/0 and approved manifest applied baseline20/12/0 stay unchanged; keep all other baselines, SDK hold latestRun01a100a6/verificationa171 and originalc5fa+dddd, Kernel20/20/20 six roots, SDK23/raw85/wholeSDK90/Host90, H/S/d969/history unknown/security/pinnedbytes/all64 done and Workspace deferred live permission. No refunds by clearing or moving baselines. Reviewed proposal must state exact operations, stage/CAS/current snapshots/minimal restoration and actual counter effects; any genuine API/quality/security/product behavior change requires specific human approval of the exact fresh independently reviewed choice before apply. Existing B coordination permission authorizes proposal/review, not this new product decision.

Bound transport /tmp/oac-platform-input-owner-bound-inputs-20261003 on Mac/Oracle contains current full manifest/config/acceptance/all required contracts, full actual worker resource/kernel/project source, untouched dirty patch/pinned tests, latest full native messages/Store/report and old authority history. It is an input snapshot, not current apply authority; use current Store/read ports and exact producer verification/artifacts yourself. SDK OMAC code deployment is separate and will finish before this proposal controller starts; never start a parallel controller or touch SDK. Target .omac/platform-input-artifact-owner-reviewed-20261003.yaml.

## Verbatim current accepted decision

```json
{
  "schema": "omac.decision-required/v1",
  "reason_code": "worker-decision-required",
  "kind": "develop",
  "phase": "authoring",
  "gate": "worker",
  "resume_issue_id": "1b8e6ca8-4372-4974-a909-8994d0b05990",
  "review_context_binding": {
    "generation": "authoring-e77b8b7e3b10680fc478f0fc",
    "contract_sha256": "cafb52cf63058793e7da4e486b77181ce73e09e38147883a186d02e4e7c496be"
  },
  "blocker": {
    "schema": "omac.worker-blocker/v2",
    "reason_code": "owner-decision-required",
    "issue_id": "1b8e6ca8-4372-4974-a909-8994d0b05990",
    "review_context_binding": {
      "generation": "authoring-e77b8b7e3b10680fc478f0fc",
      "contract_sha256": "cafb52cf63058793e7da4e486b77181ce73e09e38147883a186d02e4e7c496be"
    },
    "handoff_generation": "handoff-0ac7bf4a2ff06809",
    "worker": "codex-macmini-newapi",
    "run_id": "01a1010c-b9d9-7145-b529-55dd2796cd9e",
    "summary": "The pinned Workflow input identity regression requires rejecting non-artifact references, but the current Workflow validator accepts them and its production file is outside this aggregate node's write scope.",
    "decision_needed": "Decide whether WorkflowSpec.InputArtifactIDs is artifact-only under the current API. If so, route an authorized aggregate validator change to its owner; if not, explicitly amend the pinned expectation. Do not remove or weaken the retained regression assertion in this test-only node.",
    "contract_ref": "scope_paths",
    "evidence": [
      {
        "ref": "contracts/workflow/resource/resource_conformance_test.go:1179-1182",
        "observation": "TestAuthoritativeProjectionRegressionGuards/immutable_identity_collections_are_closed assigns a structurally valid Kind=decision reference to InputArtifactIDs and requires Workflow.Validate to reject it. The focused command `go test ./contracts/workflow/resource/... -run '^TestAuthoritativeProjectionRegressionGuards/immutable_identity_collections_are_closed$' -count=1` exited 1 with `non-artifact Workflow input was accepted`."
      },
      {
        "ref": "contracts/workflow/resource/aggregate.go:129-137",
        "observation": "Workflow.Validate currently validates each TypedReference and enforces uniqueness by kind and identity, but does not require Kind=artifact. This file is outside this node's two aggregate test-file write paths."
      }
    ]
  },
  "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> contracts-platform-resource"
}
```
