# Authorized request: concrete Harness redesign amendment proposal

The user explicitly requested starting `omac dag amend propose` to produce a concrete reviewable amendment, not another assessment-only plan. Authorization is to PROPOSE and independently REVIEW a specific design/contract/dependency change. Do not apply it, implement product code, confirm the separate plan, or restart developers. The coordinator will present the exact reviewed changes for user approval before accept.

Required deliverable:
- A valid non-empty omac.dag-amendment/v1 proposal with genuine necessary operations and complete affected contract replacements where required, not a cosmetic description change or unsupported resume to pass schema.
- Explain the concrete before/after design, why it addresses the observed blocker, owning design/reference updates required, public API/compatibility implications, SDK/Host authority and responsibility effects, dependency/typed artifact/acceptance effects, and exact minimal recovery set.
- Specify implementable Worker acceptance/verification requirements and the evidence needed to substantiate feasibility. Do not claim a proposed design is already verified.
- Independent Reviewer must explicitly assess whether the changes are sufficiently concrete to execute after user approval, not merely whether this report is cautious or well formed. A generic investigation checklist or another unchanged authoring loop does not meet the requested outcome.
- If no defensible concrete proposal can be formed, identify the exact missing product/design decision, bounded alternatives and consequences. Do not invent operations or claim completion. Do not ask again whether assessment is authorized.

Constraints: keep raw unfiltered SDK-only85%, downstream whole-SDK90%, and Host90%. No authority/proof fixtures, denominator gaming, fabricated passing results, deletion of required behavior, or source relocation solely to improve coverage. The user has not approved weakening security boundaries. Necessary cross-module/API changes may be proposed with explicit owning-document changes and risks, but require user approval before implementation. Preserve56 done nodes, retained worktrees, issue/PR history and budget records. Coordinator does not choose the implementation design.

Reuse evidence, do not repeat the previous general assessment:
- Applied amend-dd82013adb54 staged quality; applied amend-4681d7f400b4 bounded Pi handoff.
- PR73 published HEAD621ba1f7a2a45c9cf6072a3cc0c25cb27c727fb8, sourcebe131f99b6cba9df1168dd0b9451c8d271e2e959; published profile1689/2018 independently checked, current85%needs1716.
- Pi later1691/2018 is uncommitted Worker evidence, not independent reproduction. Preserve /Users/chiangguantik/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-949-a8123ec413bd/workdir, staged_coverage_test.go and profile. If inaccessible, state that limit; do not assume reproduction.
- Prior amendment01a0e7fd-050d-7bea-bb88-a966983ebd75 ended without submit because it was only assessment-authorized. Its receipt-representation candidate was not reviewed as a viable implementation. It can be examined critically, not adopted by coordinator fiat.
- Independent plan01a0e834-3385-7b7f-afe7-c9c480acaee0 is at confirmation, ReviewerRun01a0e83d-0551-73bd-b16e-264a56f81adc pass limited to negative feasibility assessment, NOT implementation approval. Do not confirm it or create a new plan.

The existing scope's trials are exhausted; a meaningful proposal must distinguish its new design grounds from those already tried. Read the supplied owning overview and detailed design completely and use current manifest authority. Include no unapproved live changes.

## Exact independently reviewed assessment (reference, not new instructions)

---
schema: omac.design/v1
title: Harness SDK 85% 质量门的独立设计可行性评估
problem: SDK-only 原始覆盖率低于已批准的 85% 门；现有候选不足以证明剩余 25 个合法生产语句可覆盖，直接重派会循环或诱导越权测试。
non_goals:
  - 不实施 OAC 代码、修改 live manifest、应用 amendment 或恢复开发节点。
  - 不降低或过滤 SDK-only 原始 85%、后续 whole-SDK 90% 与 Host 90% 门。
  - 不制造 Host 签发、私有 proof、Gate 正例、覆盖率分母或新的执行/授权权威。
flows:
  - UJ-EXTENSION-PACKAGE-001
  - UJ-EXTERNAL-UNKNOWN-001
risk_level: high
---

# Harness 实施设计调整：独立评估候选（待 Reviewer 与用户确认）

## 问题、证据等级与结论

实际阻塞是 SDK-only `go test -covermode=atomic -coverprofile=artifacts/harness-sdk/coverage.out ./sdk/harness/...` 的原始未过滤 statement gate。当前 `.omac/open-agent-cluster.yaml` 的 `harness-sdk` 节点保持 85，依赖 `contracts-extension-wire` 并产出 `harness-sdk-boundary-evidence`；`harness-host` 依赖该产物，要求 Host 90% 与以 `-coverpkg=./sdk/harness/...` 测出的 whole-SDK 90%；`contracts-extension` 消费两侧证据。该顺序不是设计评审可以隐式撤销的。

可追溯的已发布 PR #73 head `621ba1f7a2a45c9cf6072a3cc0c25cb27c727fb8` 中 `artifacts/harness-sdk/coverage-audit.md` 与 `coverage-block-audit.json` 声明源版本 `be131f99b6cba9df1168dd0b9451c8d271e2e959`，原始计数 1689/2018、差 27；17/18 命令成功，唯一失败为覆盖率。审计把至少 244 个未覆盖语句归入 Host/proof 限制，87.9088% 只是把全部其他块当作可覆盖的乐观上界；其 ordinary-conformance 分类还含大量“某个本应拒绝的输入被接受才会执行”的失败断言，不能视为合法产能。独立读取了上述已提交审计及 manifest/设计；未重新执行该历史 Mac 环境的 18 命令，也未验证此前审计对每个 block 的动态可达性。

两次后续 Worker 报告分别声称 1690/2018 与 1691/2018，后者比 1716 尚缺 25；其 `staged_coverage_test.go` 和 profile 未提交，**不是本评估复现结果**。报告指出 malformed typed-request 与普通 Description schema-number 已耗尽，binding-release 和非 executor `agent.invoke` 受前置校验支配。另有原 amendment issue `01a0e7fd-050d-7bea-bb88-a966983ebd75` 的当前 OMAC work show 为 blocked/authoring；Planner Run `01a0e7fd-d2d2-7a10-a6bf-bc2a30234b6f` 的源文档没有经本次 work show/read 取得，不能当作独立通过的评审或批准。原始报告与已提交基线互相区分，不替代 source-bound 新证据。

**判定：目前不能证明现有分工和质量门下存在达到 85% 的安全实施路径。** 不推荐把静态可覆盖上界、损坏 invariant 的 fixture、纯 helper 测试、在 SDK 内创建 Host issuer 或改变分母作为交付路径；也不建议重复同一两增量交接。下面是一条带明确停止条件的候选设计评估路径，而不是通过门槛的保证或实施授权。

## 候选路径、阶段与停止条件

1. **源绑定复核（只读可行性前置）。** 由独立 Reviewer/获授权技术人员从可访问的提交或只读归档取得 PR73 精确源、审计原始 profile 和两次未提交增量的精确 diff/profile/命令结果；记录 commit、文件 SHA-256、运行环境与工具、完整原始分子/分母及候选 block 对应生产调用链。不得覆盖 Pi 保留的工作树或以其 dirty bytes 充当可复现提交。若后续增量无法取得，只能以 PR73 的 1689/2018 为可检验基线，不得引用 1691 为已验证进度。采用相同源码/工具重新执行 SDK-only 命令，确认原始 profile 的 statement universe 与证据摘要一致；证据不一致先停止。
2. **按语义分桶，明确真正的新依据。** 对未覆盖 block 从公开入口追溯到 Core/生产共享 validator，给出合法非 Host 输入、可观察断言、代码路径和原始权重；把 Host-only/service/Gate proof、receipt lineage、支配不可达、只有破坏断言才走到的分支排除在合法额度外。已试 `typed_execution_receipt.go:276` 与 Description schema-number 不重复计入；`harness.go:1257` binding-release、非 executor permission 不作为待实施候选；`service.go:18-46` 和 `extension_points.go:342-362` 只有发现**不同于已审计 data-only 路径**的真实生产输入及断言时才有新意。`schema.go` 与 `conformance.go` 普通错误返回只能在共享生产语义且不会奖励无效 conformance 的条件下纳入。先提交可独立复核的 block 清单，要求合法增量至少足以弥补同一个未过滤 profile 的缺口（后续报告称 25），而不是把旧审计的 85 个非 proof 语句相加。清单不足则立即停在用户决策门，不写覆盖率测试。
3. **若清单通过独立评审且获实施授权，才考虑最小 SDK 修复。** `sdk/harness/**` 只添加通过现有生产入口的公开、非权威 ordinary-operation/Describe/typed response 负例与正例；需要时只整理纯数据校验以复用同一生产 validator，保留权限/身份校验顺序和全套固定 selector。每项断言应测量拒绝、零实现调用/绑定/权威 receipt 或成功与业务错误分离，并逐项证明生产 block 新增覆盖。不得导出 proof/issuer、使用同包测试桥、让伪造 handoff 成功、搬移代码以改变覆盖率分母或在 Gate/service 行声称 Host 正例。没有足额新合法 block，就不启动这一步。
4. **完整交付门（绝不由本 plan 执行）。** 对同一源码版本运行 manifest `harness-sdk` 的全部 18 条命令，SDK-only raw 未过滤 >=85%、50 必需测试/13 行真实语义证据均通过，Host 正例仍记 `not-run`；生成同源快照、审计、component/bundle 和复核摘要，交给独立 Reviewer。随后 Host 由 `internal/hosts/harness/**` 消费 SDK 产物，生产 Host 从安装/治理来源签发并验证真实服务与 Gate 交接，产出 `harness-host-gate-evidence`、Host 原始 >=90% 和相同 SDK 文件集合的 whole-SDK 集成 >=90%，最后 `contracts-extension` 联合验收。任一门失败不声称交付，不恢复节点；`work submit` 本次只提交设计供审阅。

## 业务流、数据及模块责任

`UJ-EXTENSION-PACKAGE-001`：开发者选择 `harness.oac.dev/v1` 并用 SDK 固定同源 conformance 检查 Extension 的 Describe、Guide/Sensor/Executor/Trigger/EventHandler；管理员安装时 Component Governance 对 Package release、digest、Trust 与 SDK 检查负责，Harness Host 只能解析 LockedComponentSet 的精确实现。SDK ordinary runner 可用确定性非权威请求证明类型化输入/输出和失败策略，但其记录不得产生 RequestScope、Host service/Gate handoff、权威 receipt 或 Gate 接受。安装失败不得进入 Active；内置与第三方同路径。

`UJ-EXTERNAL-UNKNOWN-001`：WorkUnit 的唯一 `execution=executor|child-workflow` 不变；有副作用的 ComponentRun 带精确 package/entrypoint、binding、operation、owner、subject、scope、request 与 service payload digest、component/run、policy revision、external operation/idempotency 及 outcome-known。Harness Host 提交 ComponentRun 专用报告，Platform Core 先持久化 Artifact/Observation/report，且独自物理写 Workflow CR；Controller/Kernel 从事实与 Gate 判定后续。Unknown、丢失响应或 Cancel Accepted 均不等于 Failed/Cancelled；原 Run 上 observe，只有已证实副作用未发生或幂等安全才允许新 Retry Run。Optional 的未知副作用不能跳过。SDK 不拥有 Host credential、治理判定、Gate 注册表、持久化、第二主执行或新的状态机。

写路径：Extension 仅返回类型化结果；SDK 校验并分类但不写产品状态；Host 按安装与认证上下文调用受控实现；Platform Core 持久化当前 ComponentRun/不可变事实；Kernel 消费显式事实。读路径：Host 从 LockedComponentSet、ComponentInstall、RequestContext 与记录读取可信选择；SDK 只接收必要类型化 DTO/opaque 已验证能力。缺失/陈旧/不匹配的身份、schema、证据或权限 fail closed，无降级/latest/隐式 fallback。重复调用用稳定幂等身份及 CAS；重启后必须读取持久事实并 observe，不能依赖测试进程内标记。接口详情仍由 `docs/references/extension/plugin-contracts.md` 与 `component-governance.md` 持有，不在本设计创建新外部字段或版本。

## 所属文档、依赖与验收影响

- `docs/design/open-agent-cluster-overview-design.md` 的 Harness 与唯一主执行、Platform Core/Kernel/Host、控制状态边界保持不变；`docs/design/detailed/08-component-and-extension-detailed-design.md` 的 SDK conformance、Harness Host、权限交集和 Unknown 恢复保持不变。目前**不提议编辑产品设计**；若复核揭示不可避免的责任转移，先由用户选择，再在归属的 overview + 08 与受影响详细设计中同步成文。
- 若改动 SDK 的确切 DTO/schema/行为，`docs/references/extension/plugin-contracts.md` 与 `component-governance.md` 和同源安装检查须同步；若 Host 治理/隔离身份发生变化，需先核对 `docs/design/detailed/09-governance-and-security-detailed-design.md` 及相关 exact contract。新材料不能藏在 AGENTS.md。当前 contract 的 `harness-sdk → harness-host → contracts-extension`、`harness-sdk-boundary-evidence` 与 Host 产物方向不变；不得逆向把 Host 作为 SDK 的运行依赖或对已完成节点改历史。
- `docs/delivery/acceptance-and-validation.md:170-185` 的 `UJ-EXTENSION-PACKAGE-001` 必须证明开发端/安装端固定同源 SDK 检查、失败不能 Active、Builtin 无旁路；`:852-866` 的 `UJ-EXTERNAL-UNKNOWN-001` 必须证明 Unknown→同 Run Observe→仅安全时新 Retry 与取消后观察。若以后变更用户可见行为才在该文档的拥有位置调整；本提案不增设新验收流。
- Wave 0 已有 `contracts-extension-wire` 和发布制品工具链为精确输入。证据基线是 PR73 的已提交源/审计而非新接口 shell。任何 Host 合作实验需隔离且不可充作 SDK85 的替代：该门必须仍用 SDK-only 的未过滤原始 profile；联测 whole-SDK90、Host90 和真实 Gate/service 正例另做。构建用现有 source ownership baseline/组件 manifest，不能使用 synthetic production fallback。

## 风险、兼容性与待用户批准决策

1. **已有授权内的窄路径并非已证可行。** 后续 25 条合法语句的输入/调用链尚未提供，历史审计把可能的失败断言误分类为可测语句的风险高。独立 Reviewer 应否决“理论上界即达标”的论证，要求 source-bound 可重复 profile 与逐块可达证据。若证据不成立，停止，不改门槛。
2. **可能需要明确的人类产品/质量决定，而非普通 amendment resume。** 若真实 SDK-only 85 在现有 ownership 和生产契约下不可达，用户需明确选择：保持三个门与现有 SDK→Host 顺序、让任务保持阻塞；或授权一次单独的跨模块 SDK/Host 责任及交付顺序再设计（指定哪些实际产品责任变化、拥有文档、source ownership、证据移交与兼容性，且仍保留 SDK-only raw85、whole-SDK90、Host90 原值），先由独立 Reviewer 核定其可实现性和无测量套利，再单独决定是否实施。不能在本 plan 自行把 Host code 移入 SDK、从 SDK 删除难测必要行为、改计算集合，或把 SDK85 延迟/替换为集成90。若三个门在任何候选结构下不能同时满足，需用户另作明确质量策略决定；本评估**没有提出降低门槛的默认选项**。
3. **DAG 表达风险。** 当前 `harness-host` 消费已验收 SDK 产物，单纯 `resume`/contract replacement 不能安全表达“未通过 SDK85 却需 Host 的真实生产签发来补 SDK-only 证据”，而且 SDK-only 命令不会执行 Host 包。不要制造循环依赖、覆写 done/merged、搬运 acceptance claims 或用旧 amendment schema 伪装为开发恢复；等上述具体边界决策形成且经 review/confirmation 后，由授权的编排者评估是否可由最小合法 amendment 表达，否则维持阻塞并请求用户批准新的交付分期。
4. **兼容性/回退。** 保留公开 `harness.oac.dev/v1` 的 Describe 与 typed operation/result/error/Unknown 语义、Package release/digest 与老 Workflow LockedComponentSet；任何公开接口/数据形状的改变需明确版本/迁移决定。失败时维持 PR73 与现有 DAG，不发布不完整制品、不擦除 Pi 的未提交增量、不把已知 Unknown 降为失败。

本 plan 只给 Reviewer 评估设计可行性与证据限制；即便 Reviewer 通过，也仍停在 confirmation，**不执行 plan confirm、amendment 应用或 developer resume**。Reviewer 的通过不是用户对安全、owner 或质量边界变化的授权。

## 验收映射与可执行核验入口

- `UJ-EXTENSION-PACKAGE-001` → 现有 `docs/delivery/acceptance-and-validation.md:170-185`；复核固定 SDK selector、50 测试/13 测量行、SDK-only raw >=85 与真实安装端同源 suite；缺失/伪造 Host 来源时零 binding、零权威 receipt、零 implementation/evaluator 调用，Host 正例在 SDK 证据中 `not-run`，交给 Host 后才运行真实正例。失败为 raw 低于 85、fixture 自授权、可选测试或版本/digest 不匹配仍 Active。
- `UJ-EXTERNAL-UNKNOWN-001` → `docs/delivery/acceptance-and-validation.md:852-866`；SDK 负例测 typed execute/observe/cancel、Optional Unknown 不跳过，Host/集成测持久观察、重启、取消、幂等与真正安全 Retry。失败为盲重试、未知变失败、旧 ComponentRun 被覆盖或缺审计/归属。
- 本次**只读计划**的完成标准：两份文件可按 OMAC 提交，Reviewer 可以从 manifest、已提交审计与设计定位每项边界，证据缺口和用户选择明确；不把任何未运行的质量/验收命令写为通过。


## Exact retained Worker reports

Run 01a0e756-208b-7138-a882-a8123ec413bd

**Blocked; PR #73 was not updated or submitted.**

The existing PR head is `621ba1f7a2a45c9cf6072a3cc0c25cb27c727fb8`. I added a focused malformed-request assertion in `sdk/harness/staged_coverage_test.go`; the broad SDK test passed and exercised one previously uncovered production validation block. Raw coverage is now **1690/2018 (83.7463%)**, still **26 statements short** of the 1716 required for 85%. The updated local profile is `artifacts/harness-sdk/coverage.out`; the partial test and profile are preserved in the worktree.

The other named candidates are not safe coverage targets: the binding-release rejection is dominated by earlier binding/description validation, and the non-executor `agent.invoke` rejection is dominated by `Extension.Validate`. Reaching Host-gated paths or forcing private proof state is prohibited. The audit’s 87.9088% ceiling is only optimistic; I could not establish another specific, legal production path for the remaining coverage, so I stopped rather than add speculative fixtures or run unchanged retries.

I did not use `omac work block`: its supported schema is limited to an unreadable upstream `work-show`/`work-read` with exit code 5, which does not describe this blocker. A human/OMAC decision is needed on an allowed contract or scope path for further legitimate coverage. Current OMAC state remains `in_progress` / `authoring`.

Run 01a0e76a-6c9c-7e41-81eb-38d06a481804

**Still blocked on the 85% coverage gate; PR #73 was not changed.** No new owner decision or contract change appeared in the comment scan.

The two focused data-only tests now cover the malformed typed-request rejection and an ordinary `ValidateDescription` schema-number rejection. The SDK suite passes, but fresh raw coverage is **1691/2018 (83.7958%)**; the gate requires **1716**, leaving **25 statements uncovered**. The raw profile is in `artifacts/harness-sdk/coverage.out`; the local test changes are in `sdk/harness/staged_coverage_test.go`. Neither was committed or pushed, and the semantic evidence was not regenerated.

The remaining named binding-release and non-executor permission branches are dominated by earlier validation; Host-only paths remain out of scope. I stopped after the allowed two focused increments. The current OMAC state remains `in_progress` / `authoring`. I did not fabricate an upstream-read blocker report: the available `omac work block` protocol only accepts that specific blocker type. Further work needs an approved path to cover at least 25 more statements without weakening the authority boundary.

