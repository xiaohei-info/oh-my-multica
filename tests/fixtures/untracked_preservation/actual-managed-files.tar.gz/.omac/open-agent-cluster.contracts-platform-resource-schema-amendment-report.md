# contracts-platform-resource-schema amendment audit report

## Current persisted facts

- Manifest: `.omac/open-agent-cluster.yaml`
- Blocked node: `contracts-platform-resource-schema`
- Existing work item: `54df9c3e-4748-4874-a28d-d00e2a1b889e` (`AITEAM-849`)
- Existing implementation: OAC PR #33, branch `agent/codex-ubuntu-newapi/178d3f78`
- Existing PR commits and evidence must be preserved.
- OMAC decision: `review-convergence-ledger-unverifiable`
- Convergence mode: `unverifiable-legacy-ledger`
- Semantic review cycles: 3
- Review ledger: `omac.review-ledger/v1`, SHA-256
  `044163497abd9f500a60b1b8efde13cb43dcbb2ef3b5f12fa616a264b9be8ca3`
- Persisted issue state: `blocked`, phase `review`, recommended action `dag-amendment`
- Historical Agent Runs: 21, active Runs: 0; the recovery Runner created no new
  Worker or Reviewer Run.

## Why the current node must be amended

The current node combines several independently testable contract responsibilities
inside one delivery and review boundary. Three review cycles leave six independent
open roots across authority, structure, ownership, execution, evidence, and the
integration gate. Dispatching another Worker revision against the same oversized
boundary is not an acceptable recovery.

The durable review ledger remains the exact authority for blocker evidence and
required fixes. The six open roots are:

1. `kernel-v1-compatibility-artifact-not-consumed`
2. `kernel-v1-wire-validation-not-implemented`
3. `kernel-v1-evidence-relations-redefined-lossily`
4. `platform-resource-values-are-incomplete-parallel-contracts`
5. `workflow-enums-and-decision-wire-contradict-authority`
6. `tests-assert-implementation-coverage-not-contract-compatibility`

## Required amendment outcome

Replace only the oversized `contracts-platform-resource-schema` delivery boundary
with the smallest independently PR-able, testable, and reviewable semantic nodes.
The Orchestrator must derive the exact split from the supplied authoritative `docs/`
corpus, the current manifest, AITEAM-849's ledger, and PR #33.

The amendment must:

- preserve AITEAM-849, PR #33, all correct implementation, commits, verification,
  ledger history, and existing evidence;
- assign each of the six open roots exactly once to an independently reviewable leaf
  or a final conformance node;
- separate strict Kernel v1 raw-wire admission and digest identity, compatibility
  artifact consumption, authoritative immutable resource values, Decision and
  evidence-reference semantics, and independent compatibility fixtures where those
  are genuinely separate responsibilities;
- retain a final schema conformance boundary that depends on every required leaf and
  proves the cross-contract invariants before downstream nodes are unblocked;
- rewire downstream dependencies only to the complete conformance boundary, never to
  a partial contract;
- make source ownership non-overlapping or explicitly ordered where the existing Go
  package surface cannot be edited safely in parallel;
- preserve all authoritative APIs, package boundaries, acceptance refs, coverage
  thresholds, integration gates, security boundaries, and fail-closed behavior;
- use the minimum recovery set and leave done/merged and unrelated nodes unchanged;
- resume the existing implementation and review evidence at the correct stages rather
  than creating replacement product history.

Multica and OMAC are recovery and orchestration mechanisms only. Do not add their
concepts, issue metadata, approval mechanics, or runtime terminology to OAC product
design documents or product contracts. This amendment may change only the DAG
definition needed to recover the current OAC delivery boundary.

## Reviewer confirmation requirements

Reviewer must verify that the proposed amendment:

1. preserves AITEAM-849, PR #33, existing implementation, and evidence;
2. gives every new or amended node one clear semantic responsibility;
3. owns all six durable blocker roots exactly once without relaxing any requirement;
4. prevents partial schemas from unblocking downstream consumers;
5. avoids unsafe overlapping parallel edits or supplies explicit ordering;
6. keeps a final cross-contract conformance gate;
7. introduces no OMAC/Multica concept into OAC product design or product contracts;
8. requests only the minimum safe recovery set.
