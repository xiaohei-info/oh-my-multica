# Source-bound Platform capability validator owner request

The current aggregate owner completed a real v2 owner-decision report, not a proposed waiver. Produce a concrete executable amendment with independent review using current DAG responsibility and actual CAS/stage preconditions. Do not use a plan, generic assessment, unchanged resume, coordinator implementation or automatic admission of the Worker claim.

Affected existing node: contracts-platform-resource, issue 1b8e6ca8-4372-4974-a909-8994d0b05990. Worker Run 01a0fbea-bc8e-736f-a5d5-e321da1b91c8 completed 2026-10-02T10:22:31Z. PR8 remains OPEN at 60440b198d0ed5eda2f1d66371b9504a4ec2f68b; restored local tests are unsubmitted and must be retained. Worker HEAD: 60440b198d0ed5eda2f1d66371b9504a4ec2f68b

The exact focused command reported failing is `go test ./contracts/workflow/resource/... -run '^TestWorkflowGraphHumanAndProjectionIntegrity/input_and_capability_keys_are_canonical$' -count=1`, with blank or duplicate executor capability accepted. The report points to the current ExecutorRequirement.Validate production method outside the aggregate node's two-test-file scope. Independently inspect the full pinned test 66efa82f66bdd763e25355d7bef9da95841b5bb1, actual restored test/source, owning exact contracts and current owner catalog before deciding whether this is a missing owner implementation, legitimate API adaptation or a new actual product decision. Do not assume the requested repair or scope expansion is correct.

Original independent reject remains open: pinned-regression-semantics-not-preserved, full report SHA00483ca42e8d2d98741e4fa578967ce16ea8fedd6b480b10e2e0bd5f5c49567d/23836B; ledger4d943d149b4489939b3b70bea0de0f268ec9b9c9b54fd458e2fc61c17f29357c/18413B. Preserve all original positive/negative scenarios, expected failure reasons, names/selectors/29tests/14helpers, four exact commands/full package90%, deterministic ownership packaging and trace-only acceptance semantics. Do not weaken tests or modify leaf production within aggregate ownership. Any required owner repair must follow current responsibility with independent implementation review and real merged artifact dependency before this aggregate recovery. Do not reopen completed producer nodes.

Preserve original 177 nodes/62 done snapshots, all budgets (Platform absolute worker20/review12/merge0 and retained baselines/history; other nodes exact), original reject context and workspace. Healthy Kernel Pi Run01a0fbd9-8bc8-760e-93d3-f95cd04bab2d is unrelated and must remain running/unaffected. Preview PR91 evidence resubmission completed10:23:53; its normal collect/review must remain preserved and outside recovery unless exact typed dependence is proved. SDK23/full uncached gates/85/wholeSDK90/Host90/H/S/d969/security/pinnedbyte/historical-cause-unknown and downstream DAG dependencies stay unchanged. No live Workspace authorization.

Transport evidence at /tmp/oac-platform-capability-owner-bound-inputs-20261002 on Mac/Oracle: current manifest/config/acceptance and owning docs/required contracts are under current/; retained Worker full two test files, actual Kernel source, binary patch/native report are under worker/. This is a transport snapshot, not substitute control authority. Use fresh current Store/DAG and immutable producer evidence to bind proposal and exact recovery/budget/CAS. Output target .omac/platform-capability-validator-owner-reviewed-20261002.yaml. A concrete new API/security/quality/behavior decision requires explicit user review of the exact independently reviewed choice; existing B routing authority does not waive it.

## Verbatim accepted decision

```json
{
  "schema": "omac.decision-required/v1",
  "reason_code": "worker-decision-required",
  "kind": "develop",
  "phase": "authoring",
  "gate": "worker",
  "resume_issue_id": "1b8e6ca8-4372-4974-a909-8994d0b05990",
  "review_context_binding": {
    "generation": "authoring-278d35663d65a6ebe49af54d",
    "contract_sha256": "98f85d677b208a625cdd980f6ffc7a38630b2638033b6ea1e4011e48f0501951"
  },
  "blocker": {
    "schema": "omac.worker-blocker/v2",
    "reason_code": "owner-decision-required",
    "issue_id": "1b8e6ca8-4372-4974-a909-8994d0b05990",
    "review_context_binding": {
      "generation": "authoring-278d35663d65a6ebe49af54d",
      "contract_sha256": "98f85d677b208a625cdd980f6ffc7a38630b2638033b6ea1e4011e48f0501951"
    },
    "handoff_generation": "handoff-e8486c6eda948988",
    "worker": "codex-macmini-newapi",
    "run_id": "01a0fbea-bc8e-736f-a5d5-e321da1b91c8",
    "summary": "A pinned capability-canonicalization regression fails against the reviewed kernel API, and its production validator is outside this node's write scope.",
    "decision_needed": "The kernel contract owner must authorize and implement rejection of blank and duplicate ExecutorRequirement.CapabilityRequirements, or provide an approved reviewed API change that preserves the pinned regression expectation. Then rebase this aggregate test work and rerun its contract gates.",
    "contract_ref": "scope_paths",
    "evidence": [
      {
        "ref": "contracts/workflow/resource/resource_conformance_test.go:840-853",
        "observation": "The pinned input-and-capability canonicalization subtest fails at the assertion that expects blank and duplicate executor capabilities to be rejected. The exact focused go test command exited 1 with \"blank or duplicate executor capability was accepted\"."
      },
      {
        "ref": "contracts/kernel/validation.go:213-230",
        "observation": "ExecutorRequirement.Validate only requires a non-empty capability list; it does not validate individual entries for blank or duplicate values. Fixing that production method is outside this node's two test-file scope."
      }
    ]
  },
  "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> contracts-platform-resource"
}
```
