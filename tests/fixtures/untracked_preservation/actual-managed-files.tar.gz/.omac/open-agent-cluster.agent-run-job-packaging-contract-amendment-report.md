# agent-run-job packaging verification contract mismatch

## Trigger

- Manifest: `.omac/open-agent-cluster.yaml`
- Blocked node: `agent-run-job`
- Work item: `33999d9a-0535-4e13-8926-111e57ce5fe5` (AITEAM-835)
- Existing implementation PR: OAC PR #25, current head `e393f280ce4b529dd16192dd255e05f435d9cfab`
- Current implementation scope is limited to:
  - `cmd/agentrun-job/main.go`
  - `internal/agentrun/runner.go`
  - `internal/agentrun/runner_test.go`

## Completed work that must be preserved

The Worker implemented the AgentRun Job event and result pipeline and achieved the node's scoped coverage threshold. The existing PR is open, clean, mergeable, and contains only the three paths owned by this node. Do not discard, redo, move, or broaden this implementation.

The node's Go tests and coverage verification are not the blocker. The blocker is the packaging verification command embedded in the manifest.

## Confirmed contract defect

The current node contract invokes `scripts/release/link_go_component.py` using the superseded one-step source-bundle interface:

```text
--component-manifest ...
--entrypoint-input ...
--bundle ...
--digest-output ...
--require-all-input-digests ...
--ownership-baseline ...
--owner ...
--require-all-owner-sources-accounted
```

The checked-in authoritative script no longer supports that interface. Its current exact contract is:

```text
link_go_component.py
  --component-manifest <component-manifest>
  --go-binaries-manifest <go-binaries-manifest>
  --output <immutable-link>
```

The binary manifest is produced separately by `scripts/release/build_go_binaries.py`, which binds one or more real binary payloads to the exact component manifest. The link script then binds that binary manifest to the same exact component manifest.

Therefore the manifest simultaneously requires the Worker to call a CLI interface that no longer exists and forbids the Worker from changing release-tooling files outside this node's scope. The Worker cannot satisfy this honestly by inventing flags, fabricating an upstream binary manifest, or modifying the shared release tooling.

## Required amendment outcome

Amend only `agent-run-job` unless the complete authority corpus proves that a directly necessary dependency correction is required. Preserve DAG topology, work item, PR history, objective, non-goals, acceptance responsibility, scope paths, Go tests, coverage threshold, and the existing implementation.

1. Replace the obsolete packaging verification command in both `verification_commands` and the matching integration gate with the current authoritative release-tooling flow.
2. State explicitly which node owns each required packaging input and output:
   - AgentRun Job component manifest;
   - actual AgentRun Job binary payload;
   - Go binaries manifest;
   - immutable component link.
3. If the current node can deterministically produce all required inputs from its owned source and build output, define exact commands and declare the resulting artifacts in this node.
4. If a required input is owned by an upstream node and is not yet available, add only the authority-backed dependency or typed `consumes` relationship needed to make the command executable. Do not fabricate the input and do not create a hidden second packaging path.
5. Do not restore the superseded one-step source-bundle interface merely to preserve the old manifest text.
6. Keep verification fail-closed for missing, mismatched, mutable, or unbound manifests and binaries.
7. Request the minimum recovery set, preferably only `authoring=[agent-run-job]`.

## Reviewer requirements

Reviewer must independently verify that:

1. every amended CLI flag exists in the checked-in release tooling;
2. the amended commands are executable from a clean checkout with only declared dependencies and owned build outputs;
3. component manifest, binary manifest, binary payload, and immutable link are digest-bound without a second packaging truth path;
4. no upstream or downstream artifact is fabricated or silently assumed;
5. PR #25 and the current AgentRun Job implementation are preserved;
6. no unrelated node, topology, acceptance responsibility, or runtime state changes;
7. only the minimum authoring recovery set is requested.

Derive the amendment from the complete supplied `docs/` corpus, the current manifest, the checked-in release tooling, AITEAM-835 history, and OAC PR #25. If the authority corpus does not determine which node owns the missing binary/component packaging input, stop for a product decision instead of guessing.
