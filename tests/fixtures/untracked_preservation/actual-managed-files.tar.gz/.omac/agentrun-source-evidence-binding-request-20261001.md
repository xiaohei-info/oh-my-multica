# Source-bound evidence delivery conflict: exact owner decision request

Use the existing OAC DAG and current approved H/S contract. Do not create a plan or generic assessment. Inspect the complete current contract, retained independent rejects, actual delivered source and evidence. The coordinator does not adopt the Worker impossibility claim or choose a solution.

Determine whether the existing contract and supported immutable artifact/verification delivery already provide a legal, non-self-referential final-HEAD evidence path. If so provide the precise executable authoring handoff and justified supported recovery, without manufacturing empty operations or an unnecessary contract change. If a real contract/ownership/evidence obligation change is necessary, deliver the smallest concrete amendment and independent review with exact before/after obligations and provenance. Do not simply resume unchanged authoring. Do not waive HEAD/tree binding, causal proof, release checks, historical records, or counters. If scope, quality, safety, accepted evidence authority or evidence obligations materially change, identify the exact user decision; prior H/S approval is not approval of new tradeoffs.

Original historical AITEAM-820 cause remains unknown under approved H. Final-source prospective cause/remedy and PID/start identity/PPID/state/owning Wait records remain mandatory. Full approved S held-original-Wait proof across unchanged 5/10/20/30 second boundaries, one diagnostic, no premature Job return/terminal/Complete, sibling paths and bounded single-owner teardown remains mandatory. Preserve 90%, ten-second assertion, pinned shipped-byte release, security, absolute budgets, all 61 done IDs and existing dependencies; Host wholeSDK90 and Host90 remain. Only amend a proven necessary boundary, not the architecture or DAG wholesale.

No new source code, tests, or technical implementation may be written by this coordinator. Planner/Reviewer must independently decide feasibility and necessary contract changes; no OMAC-infrastructure delegate.

Current manifest SHA256: ef2ea8dfd24eb7dbfc45ceba80a59e5ea1f295274947daa9374c262fc30fac5b
Current PR88 OPEN HEAD1e2d4073b3e90f9c9676bef53a0690ddb4a22109; no merge. All product Runs terminal, Runner5704 exited19:05:19UTC; no concurrent writer. Original workdir retained.

## Exact worker report
Automatic review rejected PR #88 because its committed evidence named `b957aee`, while the reviewed PR head was `48881db`. I reran the full gates at `48881db`, refreshed and committed the verification and evidence package, and pushed the update. That evidence-only commit advanced the PR head to `1e2d407`, leaving the same revision-binding conflict.

OMAC recorded a terminal owner-decision blocker. It needs a decision on whether release evidence should bind to the code-source commit while OMAC records the later delivery commit, or use a different non-self-referential attestation. The gates passed at `48881db`; AITEAM-1031 is blocked pending that decision.

## Exact persisted blocker
```json
"{\"schema\": \"omac.decision-required/v1\", \"reason_code\": \"worker-decision-required\", \"kind\": \"develop\", \"phase\": \"authoring\", \"gate\": \"worker\", \"resume_issue_id\": \"01a0f396-a507-7db4-b0f2-39dc38aa6dce\", \"review_context_binding\": {\"generation\": \"amendment-9aa4a86b5ba8b81678952de8\", \"contract_sha256\": \"392778e5ceee381f3bd6b1ea4d240048897bfdded99df6d0b59e02b403b82b00\"}, \"blocker\": {\"schema\": \"omac.worker-blocker/v2\", \"reason_code\": \"owner-decision-required\", \"issue_id\": \"01a0f396-a507-7db4-b0f2-39dc38aa6dce\", \"review_context_binding\": {\"generation\": \"amendment-9aa4a86b5ba8b81678952de8\", \"contract_sha256\": \"392778e5ceee381f3bd6b1ea4d240048897bfdded99df6d0b59e02b403b82b00\"}, \"handoff_generation\": \"handoff-737009e0617c5dad\", \"worker\": \"codex-ubuntu-newapi\", \"run_id\": \"01a0f8c6-ef68-7b7a-96b3-30e4ae265f18\", \"summary\": \"Review requires committed evidence to bind to the final PR HEAD.\", \"decision_needed\": \"Approve binding the release to the code-source commit and OMAC delivery identity to the later evidence commit, or define an external non-self-referential attestation.\", \"contract_ref\": \"integration_gates\", \"evidence\": [{\"ref\": \"Review report 01a0f8c6-328d-763c-8bc3-728d16997624, SHA-256 3fe4c303792c51dbd87938b8a9f1ae6d55b079345855ca17564fbdd9c9323658\", \"observation\": \"Round 5 requires diagnosis, index, release package, manifests, and verification to name the actual PR HEAD.\"}, {\"ref\": \"PR\", \"observation\": \"All gates passed at 48881db and its indexed package was committed; that evidence-only commit advanced HEAD to 1e2d407. Repeating the build and commit advances HEAD again.\"}]}, \"next_action\": \"Resolve the reported decision, then explicitly run omac node retry <manifest> agentrun-cancellation-prerequisite\"}"
```

## Full retained independent review (immutable report SHA3fe4c303792c51dbd87938b8a9f1ae6d55b079345855ca17564fbdd9c9323658; ledgerSHAf060a5259edaa30493dc5eda13d19df62f0143f439dfbda334f3b77b9a659d7f)
```yaml
review_protocol: omac.review/v2
review_goals:
- Independently verify the source-bound cancellation/Wait cause-and-remedy evidence
  at the actual PR HEAD.
- Independently verify the approved S owning-Wait, deadline, diagnostic, teardown,
  protocol, and release obligations.
- Check final evidence lineage, scope, source alignment, coverage, and shipped-package
  verification.
diff_reviewed: true
tests_rerun: true
integration_tests_rerun: true
coverage_checked: true
full_review_completed: true
obligation_results:
- obligation_id: dimension:authority
  status: fail
  evidence: The checked-out PR HEAD is 48881db8e1223ef1f105d3f3f237d50f948a511d, while
    diagnosis.md, evidence-index.json, and runtime-driver-release-manifest.json identify
    b957aee75921e3a4751f439de39c3bf0e395c31f as the final tested/delivered source.
- obligation_id: dimension:structure
  status: pass
  evidence: The indexed evidence files exist, parse successfully, and their committed
    bytes and SHA-256 digests match evidence-index.json entries.
- obligation_id: dimension:execution
  status: pass
  evidence: Independent uncached scoped go test, go vet, go build, cancellation regression,
    protocol-hardening tests, pinned linux/arm64 builder check, release build, and
    shipped-pair verification all exited 0 in this review.
- obligation_id: dimension:ownership
  status: pass
  evidence: The reviewed source keeps Runtime Wait with the vendor adapter and adapter
    Wait with the Job childReaper; published-source fixture-hook scanning passed and
    the diff remains within the declared implementation/documentation scope.
- obligation_id: dimension:evidence
  status: fail
  evidence: 'The final evidence package is not retrievable as evidence for the actual
    PR HEAD: its delivery.head is b957aee75921e3a4751f439de39c3bf0e395c31f and delivery.tree
    is a0374df07a3430053832ad71823cd8d0434a7158, not the actual 48881db8e1223ef1f105d3f3f237d50f948a511d
    and tree 372375831167326f3c80ffbb32f2f970a2d25bea.'
- obligation_id: dimension:regression
  status: fail
  evidence: The committed before/after production-chain records are present and independently
    reproducible, but the after evidence and shipped package are not rebound to the
    actual final PR HEAD; the required verification.yaml reference is also absent.
- obligation_id: integration:agentrun-cancellation-cause-and-remedy-gate
  status: fail
  evidence: The declared production-chain regression and held-Wait tests pass independently,
    but the cause/remedy evidence index and diagnosis bind those claims to b957aee75921e3a4751f439de39c3bf0e395c31f
    rather than the delivered PR HEAD 48881db8e1223ef1f105d3f3f237d50f948a511d.
- obligation_id: integration:agentrun-cancellation-preserved-release-gate
  status: fail
  evidence: The exact pinned release build and shipped-pair verification pass when
    run from the current HEAD, but the committed release manifest/package evidence
    was built from b957aee75921e3a4751f439de39c3bf0e395c31f; the delivered package
    therefore does not prove the actual PR HEAD.
prior_blocker_results:
- blocker_id: BLK-319b7b41c362
  status: deeper
  evidence: The index and before/after records are now present, but the causal/remedy
    package remains bound to the prior b957aee75921e3a4751f439de39c3bf0e395c31f revision
    instead of the actual delivered HEAD.
- blocker_id: BLK-6327a0789617
  status: fixed
  evidence: The committed built-chain-production-before.json, pre-fix process evidence,
    and final process evidence exist and match the evidence-index.json byte/hash entries.
- blocker_id: BLK-684309bfa033
  status: deeper
  evidence: The evidence index and referenced process records now exist and hash-check,
    but diagnosis.md still cites the absent verification.yaml and all final lineage
    remains bound to the prior source revision.
- blocker_id: BLK-82098a16894b
  status: fixed
  evidence: artifacts/agentrun-cancellation-prerequisite/evidence-index.json is present,
    non-empty, parseable, and its listed committed artifacts all exist with matching
    bytes and SHA-256 digests.
- blocker_id: BLK-cb12ce227d78
  status: unchanged
  evidence: 'The same final-release-source-revision-mismatch remains: committed release
    evidence records b957aee75921e3a4751f439de39c3bf0e395c31f, while git rev-parse
    HEAD returns 48881db8e1223ef1f105d3f3f237d50f948a511d.'
acceptance_mapping:
- acceptance: ACT-UJ-RUN-001-06
  status: fail
  evidence: The cancellation/Wait contribution tests pass, but the required evidence
    and package lineage is not bound to the actual delivered PR HEAD; the full UJ-RUN-001
    journey is not claimed by this fixture node.
integration_gate_mapping:
- gate: agentrun-cancellation-cause-and-remedy-gate
  name: agentrun-cancellation-cause-and-remedy-gate
  layer: L1
  status: pass
  source_of_truth:
  - docs/design/open-agent-cluster-overview-design.md#55-execution-host-与执行边界
  - docs/design/detailed/06-agent-runtime-detailed-design.md#8-runtime-sdk-调用与实时事件流
  - docs/design/detailed/06-agent-runtime-detailed-design.md#83-usage-采集主链
  - docs/design/detailed/06-agent-runtime-detailed-design.md#10-runtime-sdk-与-agent-job-接口检查
  - docs/design/detailed/09-governance-and-security-detailed-design.md#7-execution-security
  - docs/design/detailed/09-governance-and-security-detailed-design.md#91-权威来源与写入边界
  - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/main_test.go#L179-L219
  - https://github.com/xiaohei-info/open-agent-cluster/blob/7fa6e08311f1680967ff20273b56421b698b0219/cmd/agentrun-job/adapters_test.go#L609-L649
  - AITEAM-820 reject report attachment 01a0f325-c5a2-7bd0-ae43-624c6d61e485 SHA256
    e15cd8e27bbf52e970b31e16453e885f99178b4576adc1f23f66f5c49040fd39; ledger 01a0f325-c91c-7abf-b69f-346fe0f95b39
    SHA256 35afd7e34ac1d0c0ed9af931fd2584e628d0d82ab4dea9f5b9957dd1b9620c4c; root
    required-agentrun-cancellation-verification-intermittent-failure
  - .omac/open-agent-cluster.yaml:agent-run-job and runtime-sdk-mcp-launch-compatibility
    (completed source-owner contracts)
  - .omac/open-agent-cluster.acceptance.yaml:UJ-RUN-001
  - docs/references/execution/agent-runtime.md#7-runtime-sdk
  - AITEAM-1031 approved S comment 01a0f592-f317-7d9f-a49b-43af3fac6b1d; applied amendment
    amend-82e0c1a4d969 (policy authority only)
  - AITEAM-1031 latest reject report attachment 01a0f621-0cc8-7205-9ad6-4d89e8ef1a77
    SHA256 efdf0fb6dba9e24d537c425b498630c036db087b1efba585cbcede55a347d2df; ledger
    attachment 01a0f621-1005-71b1-baf6-933faad00165 SHA256 90fdbf47f5adabd91b73a54cdd71ea5e1a6276f3656da9af12b70760019364fc
  - AITEAM-820 Reviewer Run 01a0f309-c400-7722-95e9-d0d1fd842aac tool-result seq 83
    retained full output SHA256 14840a218f6da62d98ddf3f3268028855b3978d8c4811096b1ff7d2050042976
    (numeric PID and failing assertion only; no historical identity/state/Wait proof)
  - docs/references/execution/agent-runtime.md#9-oac-agent-job-与-agentrunevent
  delivery_goal: 'Under explicit H approval, independent Reviewer must verify a source-bound
    prospective cause and reproducible remedy for the cancellation/Wait failure class,
    not reconstruction of the original AITEAM-820 ten-second failure. Retain that
    original failed test and historical root as cause unknown with H approval reference,
    not historically fixed. Independently reproduce a permanent failing-before/passing-after
    regression through the actual built Job -> linked stream-json driver -> adapter
    -> configured Runtime chain; pin immutable before and final source SHA/tree, exact
    build/test commands, environment/Go/OS/architecture/reaper conditions, command
    exit codes and redacted evidence hashes. Bind observations in the new reproduction
    to PID plus start identity, PPID, state, the single original Wait owner and Wait
    outcome/order. Demonstrate the causal mechanism and why the minimal remedy prevents
    that reproduced failure; no green retry, observer-only result, changed deadline
    or policy approval counts. The known 072c3b5be69d7461c381d699b01df4e291748ff9
    ordering regression and final 0a267c37c22b5cdc38a13e7751d5375e4ccaf425 result
    are reproducible baselines, not new-HEAD verification and not proof of the historical
    ten-second process state. The replacement does NOT require making that unknowable
    historical state known or stretching the existing 100ms regression into proof
    of ten-second historical persistence. If claiming an environment-only remedy instead,
    independently demonstrate causal before/after process evidence and commit the
    bounded setup/cleanup recipe without privilege, host policy or new deployment
    requirements; absence of a source diagnosis cannot itself establish an environment
    cause. Diagnose any newly observed failure and retain its evidence; block rather
    than reinterpret a failing ten-second assertion. diagnosis.md and evidence-index.json
    must map each assertion, test/subtest, source revision, command/exit code, raw
    evidence digest/size and retrievable immutable evidence location to its precise
    limited claim; existence alone is not proof. The user-approved S boundary must
    also be verified: independently distinguish a post-exit pipe/channel stall from
    a still-pending owning Wait; prove bounded cancellation/pipe cleanup without killing
    the adapter that still owns Runtime Wait; include startup/no-acceptance, malformed-stream,
    append-failure and timeout sibling paths. With a deterministic held-Wait test
    seam outside production, observe across the existing deadlines that no Job return/terminal/Complete
    occurs and the redacted pending-cleanup diagnostic appears, then release and reap
    every fixture process in bounded test teardown. This controlled hold proves the
    safety rule, not an actually unkillable OS process or a finite OS completion guarantee.
    Once Wait is proven, permanently non-closing Events/Result must not prevent the
    existing bounded unknown/no-completion exit. Preserve the ten-second disappearance
    assertion and live-child/zombie/PID-reuse/probe-error controls; rerun the actual
    built production-chain failing-before/passing-after regression and all inherited
    final-HEAD quality and shipped-byte gates. Reviewer must explicitly reject undocumented
    infinite software waits, premature outer-owner killing, fake reaping or treating
    user policy approval as evidence of historical-cause closure. The independent
    held-original-Wait proof must traverse the existing ownership chain, not merely
    substitute a fake driver or delay invoking Wait. Cover startup/no-acceptance,
    malformed-stream, persistent-append and timeout siblings; observe the unchanged
    five-second escalation, ten-second observation, twenty-second SDK cancellation
    deadline and thirty-second runner drain boundary where applicable. While the original
    Wait is held, adapter/Job stay alive, no SDK terminal/result or Complete is published,
    cancellation and owned-pipe cleanup proceed, and exactly one bounded redacted
    diagnostic appears. Then release the hold and prove single-owner reaping and bounded
    teardown for all fixtures. A controlled test hold is not evidence of an actually
    unkillable kernel process. Confirm bounded unknown/no-completion after proven
    Wait with nonclosing driver channels, and align only the named owning documentation
    to that already-approved exception. The Developer chooses the minimal test seam/remedy,
    confined to non-release test code for instrumentation; the Planner prescribes
    evidence and ownership, not implementation.'
  commands:
  - cmd: GOTOOLCHAIN=go1.26.0 go version
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
      go test -count=1 -json ./cmd/agentrun-job -run '^TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure$'
      > artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: python3 -c "import json; rows=[json.loads(x) for x in open('artifacts/agentrun-cancellation-prerequisite/cancellation-test.json')
      if x.strip()]; name='TestBuiltEntrypointCancelsVendorOnPersistentAppendFailure';
      assert any(x.get('Test')==name and x.get('Action')=='run' for x in rows); assert
      any(x.get('Test')==name and x.get('Action')=='pass' for x in rows); assert not
      any(x.get('Action') in ('fail','skip') for x in rows)"
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: GOTOOLCHAIN=go1.26.0 go test -count=1 ./runtime-sdk/... ./internal/agentrun/...
      ./cmd/agentrun-job/...
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: GOTOOLCHAIN=go1.26.0 go vet ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: GOTOOLCHAIN=go1.26.0 go build ./cmd/agentrun-job/...
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: test -s artifacts/agentrun-cancellation-prerequisite/diagnosis.md
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: mkdir -p artifacts/agentrun-cancellation-prerequisite && GOTOOLCHAIN=go1.26.0
      go test -count=1 -json ./runtime-sdk/... ./internal/agentrun/... ./cmd/agentrun-job/...
      > artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: test -s artifacts/agentrun-cancellation-prerequisite/evidence-index.json
    exit_code: 0
    summary: 'independently rerun: passed'
  metrics: {}
  artifacts:
  - artifacts/agentrun-cancellation-prerequisite/diagnosis.md
  - artifacts/agentrun-cancellation-prerequisite/cancellation-test.json
  - artifacts/agentrun-cancellation-prerequisite/evidence-index.json
  - artifacts/agentrun-cancellation-prerequisite/uncached-scope-tests.json
- gate: agentrun-cancellation-preserved-release-gate
  name: agentrun-cancellation-preserved-release-gate
  layer: L1
  status: pass
  source_of_truth:
  - docs/design/detailed/06-agent-runtime-detailed-design.md:L38-L175
  - docs/design/detailed/06-agent-runtime-detailed-design.md:L305-L451
  - docs/references/execution/agent-runtime.md
  - docs/references/software-delivery/artifacts-release-and-deployment.md:L138-L209
  - five-nodes-recovery-decisions.md
  delivery_goal: Preserve all completed AgentRun Job quality, security, protocol and
    exact-byte release guarantees on the separately delivered cancellation remedy;
    no historical package evidence substitution.
  commands:
  - cmd: mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -covermode=atomic
      -coverprofile=artifacts/agent-run-job/coverage.out ./internal/agentrun/... ./cmd/agentrun-job/...
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: python3 -c "from pathlib import Path; import re,subprocess; p=Path('artifacts/agent-run-job/coverage.out');
      assert p.is_file() and p.stat().st_size>0; out=subprocess.check_output(['go','tool','cover','-func='+str(p)],text=True);
      m=re.search(r'^total:\s+\(statements\)\s+([0-9.]+)%$',out,re.M); assert m and
      float(m.group(1)) >= 90"
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: mkdir -p artifacts/agent-run-job && GOTOOLCHAIN=go1.26.0 go test -json ./cmd/agentrun-job/...
      -run '^(TestProductionStreamJSONAdapterLaunchesConfiguredCommand|TestPublishedRuntimeAdapterContainsNoFixtureHooks|TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData|TestStreamJSONCleansUpAcceptanceKindMismatch|TestStreamJSONRejectsForeignSessionEvents)$'
      -count=1 > artifacts/agent-run-job/stream-json-hardening.json
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: 'python3 -c "import json; required={''TestStreamJSONRejectsDuplicateAcceptanceAndPostTerminalData'',
      ''TestPublishedRuntimeAdapterContainsNoFixtureHooks'', ''TestStreamJSONRejectsForeignSessionEvents'',
      ''TestStreamJSONCleansUpAcceptanceKindMismatch'', ''TestProductionStreamJSONAdapterLaunchesConfiguredCommand''};
      rows=[json.loads(x) for x in open(''artifacts/agent-run-job/stream-json-hardening.json'')
      if x.strip()]; passed={x.get(''Test'') for x in rows if x.get(''Action'')==''pass''
      and x.get(''Test'') in required}; assert passed==required, f''missing required
      passing stream-json tests: {sorted(required-passed)}''"'
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: 'python3 -c "from pathlib import Path; roots=[Path(''cmd/agentrun-job/vendor''),Path(''cmd/agentrun-job/driver.go'')];
      files=[]; [files.extend(p for p in ([r] if r.is_file() else r.rglob(''*''))
      if p.is_file() and ''testdata'' not in p.parts and not p.name.endswith(''_test.go''))
      for r in roots]; forbidden=(''AGENTRUN_FIXTURE_MODE'',''AGENTRUN_FIXTURE_MARKER'',''AGENTRUN_FIXTURE_PID_FILE'',''blockForever'');
      hits=[f''{p}:{token}'' for p in files for token in forbidden if token in p.read_text(errors=''ignore'')];
      assert not hits, f''published fixture hooks: {hits}''"'
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: test "$(docker run --rm --platform linux/arm64 golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
      go version)" = "go version go1.26.0 linux/arm64"
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: python3 cmd/agentrun-job/build_release.py --source-revision HEAD --target
      linux/arm64 --build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
      --vendor-package ./cmd/agentrun-job/vendor --driver-identity cmd/agentrun-job/driver_identity.json
      --output artifacts/agent-run-job --network-policy module-download-only
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: python3 -c "from pathlib import Path; import json; d=json.loads(Path('artifacts/agent-run-job/runtime-driver-release-manifest.json').read_text());
      assert d['build']=={'image':'golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7','go_version':'1.26.0','goos':'linux','goarch':'arm64'};
      assert set(d['binaries'])=={'agentrun-job','agentrun-vendor'}; assert d['vendor_source']=='cmd/agentrun-job/vendor'
      and d['vendor_role']=='stream-json-protocol-adapter' and d['bundled_third_party_runtime_count']==0"
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: python3 cmd/agentrun-job/verify_package.py --package-root artifacts/agent-run-job
      --component-manifest artifacts/agent-run-job/component-manifest.json --binaries-manifest
      artifacts/agent-run-job/go-binaries-manifest.json --component-link artifacts/agent-run-job/immutable-component-link.json
      --release-manifest artifacts/agent-run-job/runtime-driver-release-manifest.json
      --driver-identity cmd/agentrun-job/driver_identity.json --expected-target linux/arm64
      --expected-build-image golang@sha256:1ee99c345f8179002a0de40728e0eaa8865b81257b3924ef150ee65b3f1d3fc7
      --execute-shipped-pair --forbid-build --forbid-fixture-staging --report artifacts/agent-run-job/package-verification.json
    exit_code: 0
    summary: 'independently rerun: passed'
  - cmd: python3 -c "from pathlib import Path; import json; r=json.loads(Path('artifacts/agent-run-job/package-verification.json').read_text());
      assert r['schema']=='oac.agentrun-package-verification/v1' and r['build_attempted']
      is False and r['fixture_staging_attempted'] is False and r['shipped_pair_executed']
      is True and r['process_tests_passed'] is True and r['published_fixture_hook_count']==0
      and r['external_stream_json_command_executed'] is True and r['native_event_provenance_verified']
      is True"
    exit_code: 0
    summary: 'independently rerun: passed'
  metrics:
    statement_coverage_percent: 90.1
    declared_artifact_count: 11
    published_fixture_hook_count: 0
    bundled_third_party_runtime_count: 0
    required_stream_json_hardening_test_count: 5
    shipped_pair_execution_count: 1
    external_stream_json_command_execution_count: 1
    native_event_provenance_failure_count: 0
  artifacts:
  - artifacts/agent-run-job/coverage.out
  - artifacts/agent-run-job/stream-json-hardening.json
  - artifacts/agent-run-job/source-bundle.tar.zst
  - artifacts/agent-run-job/component-manifest.json
  - artifacts/agent-run-job/agentrun-job
  - artifacts/agent-run-job/agentrun-vendor
  - artifacts/agent-run-job/go-binaries-manifest.json
  - artifacts/agent-run-job/immutable-component-link.json
  - artifacts/agent-run-job/runtime-driver-release-manifest.json
  - artifacts/agent-run-job/release-package.tar
  - artifacts/agent-run-job/package-verification.json
blockers:
- root_cause_key: final-release-source-revision-mismatch
  obligation_id: dimension:authority
  classification: unchanged
  summary: The committed final evidence and shipped release manifest identify b957aee75921e3a4751f439de39c3bf0e395c31f,
    but the actual PR HEAD is 48881db8e1223ef1f105d3f3f237d50f948a511d.
  evidence: git rev-parse HEAD=48881db8e1223ef1f105d3f3f237d50f948a511d; git rev-parse
    HEAD^{tree}=372375831167326f3c80ffbb32f2f970a2d25bea; committed artifacts/agentrun-cancellation-prerequisite/evidence-index.json
    delivery.head=b957aee75921e3a4751f439de39c3bf0e395c31f and runtime-driver-release-manifest.json
    source_revision=b957aee75921e3a4751f439de39c3bf0e395c31f.
  required_fix: Regenerate the complete diagnosis, evidence index, release package,
    manifests, and verification records from the actual final PR HEAD; update every
    digest and source/tree binding, then rerun the full declared release gate.
- root_cause_key: cancellation-cause-and-remedy-evidence-open
  obligation_id: integration:agentrun-cancellation-cause-and-remedy-gate
  classification: deeper
  summary: The prospective cause/remedy evidence is not independently attributable
    to the delivered PR HEAD.
  evidence: The evidence index and diagnosis bind the before/after claim to b957aee75921e3a4751f439de39c3bf0e395c31f,
    not 48881db8e1223ef1f105d3f3f237d50f948a511d.
  required_fix: Re-run or rebind the production-chain before/after and held-Wait evidence
    at the final HEAD, with exact source/tree, command, exit-code, artifact digest,
    and retrievable location mappings.
- root_cause_key: cancellation-final-head-regression-unbound
  obligation_id: dimension:regression
  classification: deeper
  summary: The required before/after regression evidence is not bound to the actual
    final PR HEAD.
  evidence: The committed after process evidence and diagnosis identify b957aee75921e3a4751f439de39c3bf0e395c31f,
    while the reviewed PR HEAD is 48881db8e1223ef1f105d3f3f237d50f948a511d.
  required_fix: Regenerate the before/after regression records at the final PR HEAD
    and update the evidence index with the final source/tree and exact artifact digests.
- root_cause_key: cancellation-evidence-index-and-lineage-missing
  obligation_id: dimension:evidence
  classification: deeper
  summary: The evidence package contains a broken verification.yaml reference and
    does not provide final-HEAD lineage.
  evidence: diagnosis.md:19 cites artifacts/agentrun-cancellation-prerequisite/verification.yaml,
    but that file is absent; evidence-index.json delivery remains bound to b957aee75921e3a4751f439de39c3bf0e395c31f.
  required_fix: Either commit the referenced verification artifact and index its exact
    bytes/digest or remove the stale reference, then rebind and hash all final evidence
    to the actual PR HEAD.
- root_cause_key: preserved-release-evidence-stale
  obligation_id: integration:agentrun-cancellation-preserved-release-gate
  classification: deeper
  summary: The committed release package and manifest were built from a prior source
    revision rather than the actual final PR HEAD.
  evidence: Committed runtime-driver-release-manifest.json records source_revision
    b957aee75921e3a4751f439de39c3bf0e395c31f; git rev-parse HEAD returns 48881db8e1223ef1f105d3f3f237d50f948a511d.
  required_fix: Rebuild and verify the pinned linux/arm64 shipped pair from the actual
    final PR HEAD, then commit the resulting package and all updated manifest/digest
    records.
nits:
- The independent native verification runs reached 90.1% scoped statement coverage
  and passed the declared protocol and shipped-pair checks; these results are non-delivery
  evidence until committed against the final HEAD.
integration_gates:
- name: agentrun-cancellation-cause-and-remedy-gate
  status: fail
- name: agentrun-cancellation-preserved-release-gate
  status: fail

```

## Transport and admission
The exact current 38 required inputs (manifest, acceptance, configuration, authority documents and required contract sources) are copied under /tmp/oac-source-binding-bound-inputs-20261001 on Mac and Oracle. Read .omac/open-agent-cluster.yaml and its dependent paths from that directory; do not substitute any old 172-node or pre-H snapshot. The initial archive was SHA7b58d40ba14bc5482cedbe461298e65d07ccd584717f7c378435e072bdb246c6, all 38 SHA/bytes independently verified remotely. This request is updated only to append these transport paths before the new attempt. Normal node retry completed solely for amendment admission; no Runner or Developer dispatched. The initial propose returned identity conflict without creating an issue; this new attempt follows the exact CLI next_action supersedes original AITEAM811 6fa7495c-7d54-4876-8e22-07d61a0078d9.
