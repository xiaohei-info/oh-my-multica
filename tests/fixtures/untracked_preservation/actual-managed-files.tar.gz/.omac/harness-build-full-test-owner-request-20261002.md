# Harness build repair: source-bound full-test owner/environment resolution

Produce the smallest executable OMAC DAG owner/dependency or supported environment correction for the actual full-test failures reported by the repair Worker. Independently verify the retained exact source and failure evidence; do not presume owner attribution or technical impossibility. No generic assessment, plan bypass, gate waiver, test weakening, unchanged retry, coordinator code, reopening completed nodes, or unapproved scope/API/security/quality tradeoff.

Current 176 nodes / 62 done must remain. Repair issue 01a0fb38-0558-7ae0-a2b1-23b00e56190a; completed formal Run 01a0fb38-a98b-7418-a208-f7cfdac73b8c; PR90 open e8b8dfb, one-line SDK repair only, no independently accepted implementation. All 23 exact commands remain mandatory. Worker claims 1-22 pass /1933 of2262=85.4553%; command23 full uncached test fails in Preview acceptance fixtures authorization outcome pass and workspace filesystem identity-atomic mutation unsupported. Determine genuine owning producer or exact supported non-live environment recipe. Workspace live cluster/namespace/fault injection authorization remains deferred; this is not permission for live operations. Do not preselect changed gate/environment or silently waive missing tests.

Retain SDK85, wholeSDK90/Host90, all original20 SDK commands/tests/cases/artifact integrity and three added build/test commands. Audit still waits this independently reviewed and merged repair, original e15cd8 report/35afd7 ledger, retained clean unpushed59c51 rebase and full freshHEAD uncached gates remain. All H/S/d969 approved rules, historicalcauseunknown, budgets/baselines and accepted done history remain. Platform real reject pinned-regression-semantics-not-preserved and Kernel current submission are independent normal A work; do not affect or cancel healthy Runs. Changes must be concrete typed owner/dependency/environment routing via amendment with actual stage/CAS/minimal recovery checked independently. New substantive choices require precise user decision before applying.

## Exact terminal output
- Replaced the test-only helper with the same `ExternalOperation` value; the one-line repair is in [PR #90](https://github.com/xiaohei-info/open-agent-cluster/pull/90) to `main`.
- The SDK gate and both production builds pass. Coverage is 1,933/2,262 (85.4553%); all 50 required tests, 13 semantic rows, 7 amendment rows, 15 service cases, and 4 receipt-tree regressions pass.
- `go test -count=1 ./...` fails in untouched Preview and workspace filesystem packages. OMAC recorded an owner-decision blocker; the full gate remains unresolved.

## Actual structured decision
```json
{
  "schema": "omac.decision-required/v1",
  "reason_code": "worker-decision-required",
  "kind": "develop",
  "phase": "authoring",
  "gate": "worker",
  "resume_issue_id": "01a0fb38-0558-7ae0-a2b1-23b00e56190a",
  "review_context_binding": {
    "generation": null,
    "contract_sha256": "a4fca9486a485c5df7ff6fdf8b2ee1266ab7db1678dd31caf2b486c65efbff8c"
  },
  "blocker": {
    "schema": "omac.worker-blocker/v2",
    "reason_code": "owner-decision-required",
    "issue_id": "01a0fb38-0558-7ae0-a2b1-23b00e56190a",
    "review_context_binding": {
      "generation": null,
      "contract_sha256": "a4fca9486a485c5df7ff6fdf8b2ee1266ab7db1678dd31caf2b486c65efbff8c"
    },
    "handoff_generation": "handoff-68800c0131347766",
    "worker": "codex-macmini-newapi",
    "run_id": "01a0fb38-a98b-7418-a208-f7cfdac73b8c",
    "summary": "Repair commit e8b8dfb is in PR #90 to main. SDK gates and builds pass; the required full test command fails in two untouched packages outside scope.",
    "decision_needed": "Have the owning components fix the failures or provide a supported environment where the exact full test gate passes, then resume this task. No gate waiver or out-of-scope SDK repair is requested.",
    "contract_ref": "integration_gates",
    "evidence": [
      {
        "ref": "https://github.com/xiaohei-info/open-agent-cluster/pull/90",
        "observation": "Open, non-draft; base main; head e8b8dfb; one-line SDK diff."
      },
      {
        "ref": "open-agent-cluster/artifacts/harness-sdk-build-repair-evidence/verification-results.json",
        "observation": "23 exact commands; 1-22 exit 0, full test command 23 exit 1; SDK coverage 1933/2262."
      },
      {
        "ref": "open-agent-cluster/artifacts/harness-sdk-build-repair-evidence/failed-full-tests.log",
        "observation": "Untouched preview tests reject authorization outcome \"pass\"; workspace filesystem test reports identity-atomic mutation unsupported."
      },
      {
        "ref": "open-agent-cluster/artifacts/harness-sdk-build-repair-evidence/evidence-manifest.json",
        "observation": "SHA-256 inventory for the fresh source-bound repair evidence set."
      }
    ]
  },
  "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> harness-sdk-production-build-repair"
}
```

Original worktree: /Users/chiangguantik/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-1040-f7cfdac73b8c/workdir/open-agent-cluster

## Bound retained input transport
Mac and Oracle /tmp/oac-harness-full-test-bound-inputs-20261002 contains 176 files: current full manifest/config/acceptance/owning designs/required contracts, exact retained SDK+Preview+filesystem source and all repair evidence. Archive /tmp/oac-harness-full-test-bound-inputs-20261002.tar.gz SHA255caaa44739ef2875403f3dca13df428a53ac9341e7beb360920466b94651ea /1412496B, every per-file SHA/bytes independently checked on Oracle. Transport snapshot is evidence, not replacement control authority; use current proposal-bound manifest/Store for CAS and current recovery/counters.
