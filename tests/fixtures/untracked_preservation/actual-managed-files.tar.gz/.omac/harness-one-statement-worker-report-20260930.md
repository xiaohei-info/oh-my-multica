## Source-bound raw coverage result

- Source revision: `d630e39959c7064f2437e5231a371aedd30cdb94`
- SDK source snapshot SHA-256: `bd1da0f899aa6233e35eb2d6be2d7255cfa39f83a73f3f2bb19f36914015abfe`
- Raw profile SHA-256: `29d2b674ab5b634d1682c09446de61c7a58c9d05b50406a14aa1aa998458ffb7`
- Raw coverage: 1,909 / 2,246 statements (84.9955476%). The exact 85% check requires at least 1,910 statements.
- The unfiltered profile has 273 zero-hit blocks containing 337 statements. Their statement counts by source file are: `conformance.go` 55, `execution_receipt.go` 77, `extension_points.go` 81, `harness.go` 70, `schema.go` 1, `service.go` 35, and `typed_execution_receipt.go` 18.

The exact broad coverage command exited 0 and generated `coverage.out`. The contract's following raw coverage assertion exited 1 with `(1909, 2246, 'required raw SDK-only coverage >=85%')`. No profile filters, denominator changes, or synthetic Host evidence were used.

## Reachability and ownership diagnosis

The recursive SDK measurement refactor is committed in `d630e399`; it reuses the complete validated measurement-tree projection for both typed and Executor attachment. The four receipt-tree regressions, vet, race, all fixed conformance selectors, semantic evidence checks, and packaging checks passed after that commit. A terminal-Cancel regression also confirms `CancelResponse.Validate` rejects a terminal status before the later conformance assertion can observe it; that case did not add coverage.

The current remaining candidates do not provide an authorized statement to exercise. `schema.go:58` reaches `Schema.Validate` only after bounded schema compilation and bounded valid-JSON payload validation; the SDK rejects schema references before this call. The Unknown recovery assertion at `conformance.go:1187` follows a successful `ExecuteResponse.Validate` and `RecoveryFor`, which maps a valid `StatusUnknown` response to Observe. Receipt, scope, service, and Gate proof paths require Host-owned authority or opaque handoffs; the contract assigns their positive paths to `harness-host` and forbids SDK-owned Host fixtures. The final semantic artifact keeps those Host obligations `not-run` and reports `evidence_scope=sdk-boundary`.

The fixed selectors already exercise the contract's production-used non-authoritative operation and failure paths. No further in-contract path was identified that can cover another statement without manufacturing Host authority, forcing an internal invariant failure, filtering/padding coverage, or changing required behavior. The current 85% `coverage_gate` therefore conflicts with the authorized SDK-only test boundary at this source revision.
