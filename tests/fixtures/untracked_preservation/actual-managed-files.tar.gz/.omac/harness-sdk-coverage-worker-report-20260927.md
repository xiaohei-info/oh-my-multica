# Worker-reported OAC coverage / authority-boundary blocker

This is a coordination request, not a coordinator technical verdict. Independently verify the Worker claims against the current approved contract and owning designs. Determine whether in-scope implementation or test changes resolve the issue. Do not assume coverage must be lowered; do not manufacture Host authority, bypass production verification or mark unrun checks passed. If a real contract correction is necessary, propose only the minimal design-consistent change and retain independent review and exact acceptance ownership. Do not change unrelated/done nodes. Preserve existing uncommitted work. The prior amendment amend-d96005866702 is already applied; do not replay it.

Source: completed Worker Run 01a0e25a-067b-791b-86c5-e10c0298b131 / issue01a03bd2-6ef8-7b75-a86c-466f6aaabc1e, completion 2026-09-27T11:33:15Z. Working tree: /Users/chiangguantik/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-949-e10c0298b131/workdir.

## Verbatim Worker report

## Blocked by the coverage gate

I restored the handoff changes on the existing PR #73 branch and added the negative-only ingress test and measured evidence fields. The fixed test selectors, semantic evidence checks, `go vet`, race test, and package/digest checks pass. Package coverage is **76.5% (1,555/2,034 statements)**; the required 90% assertion fails.

The contract requires 90% coverage while forbidding SDK tests from constructing Host proofs and assigning genuine Host service and Gate paths to downstream `harness-host`. At least 226 uncovered statements sit behind those Host-only proofs or handoffs, leaving a maximum of about **88.9%** even if every other statement were covered.

I reported the conflict with `omac work block`, but OMAC rejected it: that command accepts only `upstream-unreadable` blockers for failed upstream reads. The task rules prohibit direct Issue comments and status changes, so the Issue remains `in_progress`. PR #73 remains open at `b2a45b425`; these changes are uncommitted and were not submitted.

This needs a contract decision: provide an approved Host-owned verification path for this node, or revise the coverage gate or its measured scope.
