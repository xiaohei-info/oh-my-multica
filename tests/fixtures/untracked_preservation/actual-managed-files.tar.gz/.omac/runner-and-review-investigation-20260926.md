# Runner and review investigation — 2026-09-26

## Runner termination

Old runner PID 57900 is absent. Its last log is an attachment-download retry at 11:09:09 UTC. No normal result, OmacError, KeyboardInterrupt message, traceback, or exit status was retained. The original command was owned by the interactive exec session (85226), which is now unavailable. Desktop logs place the end of conversation activity near 11:09:21 UTC, but do not identify a process-kill event. External/session termination is a hypothesis, not a proven cause. Attachment timeouts alone do not establish why the runner disappeared.

The OMAC CLI main handler writes known errors and KeyboardInterrupt. Its bounded read retry is operational. A fresh direct download of the same Solution review-ledger attachment succeeded in 3.47 seconds; this rules out a permanently missing artifact, not intermittent networking.

Recovery: started one detached supervisor (PID 66183, observed parent PID 1), running OMAC PID 66184. No automatic restart loop. Supervisor records child exit status/signals under `/tmp/oac-runner-supervised-20260926/lifecycle.jsonl`; log is `runner.log` in that directory. `/tmp/oac-a-runner-current.json` identifies the current process. Historical unknown termination cannot be reconstructed from new instrumentation.

## Solution publishing: seven open reviewer blockers

1. Exact component catalog records can be overwritten.
2. Semantic fixtures validate standalone sample payloads rather than the selected release behavior.
3. Fixture evidence does not identify the actual release objects asserted.
4. Recommended AgentTemplate and Skill dependencies lack authoritative typed closure.
5. SDK/source proof success is locally synthesized rather than consumed from verified records.
6. Integration gate misses the authoritative catalog/content lifecycle.
7. Solution root authority is synthesized from the caller package.

Source: OMAC work show context.prior_open_blockers, `/tmp/oac-solution-progress.json`. These are reviewer findings, not independently reproduced code fixes in this investigation.

## Kernel evidence: four open reviewer blockers

1. Decision-backed action admission accepts missing persisted Decision facts.
2. Different-executor admission compares a Run ID instead of ExecutorKey.
3. Nested action parameter field types are absent from recursive spec parity checks.
4. Integration gate must cover the above and regenerate seven exact-head artifacts.

Source: OMAC work show context.prior_open_blockers, `/tmp/oac-kernel-progress.json`. OMAC will route current rejected reviews through its normal rework process; no manual acceptance or fabricated evidence.
