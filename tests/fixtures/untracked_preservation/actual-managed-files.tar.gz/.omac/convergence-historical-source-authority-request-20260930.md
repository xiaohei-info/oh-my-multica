# Convergence historical source boundary — approval requested

This authorizes an additional historical evidence source only. It is not product reviewpass, permission to handwrite identity, budget reset, new Worker, contract amendment, or application of untested recovery code. Existing Executor raw-session authorization is not reused.

Exact source: /Users/chiangguantik/Documents/Codex/2026-09-26/omac-recovery-fixes/outputs/stale-review-handoff-20260930/issue.json
Exact whole-file SHA256: 615c93bf75992d22bcde4ef51d3baf4225443de1b86d6fe68d749bb52eb87499
Origin: saved real platform issue-read response before the faulty 2026-09-30 tick retired delivery_identity. Use only its original metadata.delivery_identity record, unchanged. It has 14 original fields, including handoff-604dd7170b2ee743; it does not contain the original full WorkerHandoffIntent or baseline. Do not invent those missing facts.

Exact target: contracts-platform-resource-convergence / issue01a0e28c-0705-7851-940d-c12b4eebad50.
Original formal accepted WorkerRun: 01a0efde-f2b1-77eb-b77b-94fcde62a44f; Workerpi-ubuntu-newapi / Agent4c7d9069-108e-400b-8469-16994c468e21.
Exact PR85 HEAD:6b118c17628a8198a3d624b75acde8398a8f516c; must freshly remain the same, OPEN, non-draft.
Verification: attachment01a0efe1-7f8e-72e0-b651-20ca948026a6, comment01a0efe1-8001-7c17-81ac-5cc006a04f40, SHAfd355413920f40fbd37186d1a46fe4f32742c9bd7909ccd1384ca24bd92ab587; exact agent uploader/task/bytes independently fresh verified.
Original immutable reject report52f30f5781457e6d757a0671c6680d0ec812f794fde37b9ec11d277c062f7838 and ledger822068d79c6d6cf76fd277414b2956593705a67e7d81bd2c1f4ea011ea10dff3 bind round2 subjectc3fb8a9c0d2bc76c4e22811534e2f8c35eb4723193d3984b3b78bfc017ef78bb. Independent completed Reviewer provenance stays mandatory.
Existing context authoring-ae14dac0bbc3d7bc6e3b620e / fullcontractSHA51e529f79d6f1258c445e66faaa909b83347cb1e0203f22e78102e26a2422f40.

Observed current failure state: IN_REVIEW/REVIEW/reject; sourceidentity empty, handoff empty, all Runs terminal; absolute worker20/review1/merge0 and accepted baseline20/1/0 retained. The defective tick cleared identity before its new intent was durably persisted; metadata persistence was rejected by aggregate PostgreSQL JSONB8KB constraint. Fresh native submission receipt proves real successful submission but omits original generation/baseline. A captured prior sealed record is therefore an additional historical witness, not automatic current authority.

Offline source authentication passed: the unmodified record in an in-memory clone reproduces the exact trusted immutable reject subject above against fresh verification attribution/PRHEAD/formalRun; changing generation makes the subject mismatch. This does not establish original baseline and does not itself grant live restore.

If authorized, require the smallest supported OMAC recovery capability plus full tests and deployment verification before any live operation. Prepare is read-only; exact target/current empty-state/source bytes/ref/digest/provenance/contract/gen/HEAD/counters/phase/all formal Runs and reject obligations are CAS-bound and independently verified. Preserve the complete historical record and source file; no field fabrication, no subject inversion, no alias to Executor recovery and no global reject/Run/metadata limit relaxation. Any missing/mismatched/stale/unknown fact fails closed.

A supported operation may restore only this previously accepted source fact through validated normal control materialization; it must not pretend that the missing original fullintent/baseline exists. If safe restoration still cannot be proven without those facts, authorization does not waive that requirement and the operation must refuse. Consume approval once, preserve original reject and counter/history, journal recovery and read back actual effects; crash/unknown/retry and aggregate payload tests must be complete. Coordinator alone performs serial production recovery after reviewing exact CLI request; dedicated OMAC thread only fixes/tests/deploys infrastructure and gives handoff. Formal OAC rework/review remains unchanged and required afterward.

If not authorized, preserve fail-closed current state. General metadata and durable-before-retire repair may finish independently but must not introduce this historical source as active authority.
