# Dispatch model-stream interruption investigation

Date: 2026-09-26
Status: High-confidence diagnosis from existing logs/configuration/source;
no production reload was triggered and no gateway configuration was changed.

## Finding

The three dispatch failures align with the hourly subscription refresh in
Oracle's `codex-rotate-yufly1459-worker-1`. Its configured
`subscription_refresh_minutes` is 60. The deployed-image revision label/tag
references f426589; that revision and the inspected local checkout have the
same `RefreshProviders`/`Reload` implementation.

The periodic callback downloads providers, regenerates the configuration and
unconditionally calls Mihomo `PUT /configs?force=true`. The incident timestamps
strongly implicate this full-reload boundary interrupting active model streams.
This is separate from the previously diagnosed OMAC Run-list TLS-read failure.

## Correlated evidence

All timestamps below are UTC; add eight hours for the user's local time.

| Dispatch attempt | Pi error timestamp | Proxy unexpected EOF | Proxy refresh completion |
| --- | --- | --- | --- |
| 1: `01a0dbc6-0909-7329-bfe8-05ad6f46672e` | 04:05:49.568 | 04:05:49.028 / .031 | 04:05:49.074 |
| 2: `01a0dbe4-1128-71d5-95fb-a47310e4cc3f` | 06:05:49.362 | 06:05:48.962 / .964 | 06:05:48.973 |
| 3: `01a0dc51-f6c5-7285-9304-19642a276b07` | 07:05:49.259 | 07:05:49.020 | 07:05:49.084 |

- In the proxy log window 00:00–07:10 UTC, all seven `unexpected EOF` records
  occurred within one second of subscription refresh completion; their actual
  offsets were 0.009–0.144 seconds before completion. Eight refreshes were logged.
- New API's matching last request began at 07:05:44 and ended at 07:05:49 with
  `stream ended: reason=eof` and no upstream usage. Its channel was 77, whose
  read-only database routing metadata points to `http://cli-proxy-api:8317`.
- The proxy logged `unexpected EOF` from `/backend-api/codex/responses`, then
  egress rotation after the stream error. Rotation is observed as a reaction;
  it is not evidence that a successful model response had completed.
- The first interruption also affected the Oracle Workspace task at the same
  second, despite that task using another machine/runtime from dispatch.
- New API, CLI Proxy and the rotation worker showed no container restarts at
  the incident times. The dispatch daemon invocation recorded task timeout=0
  and idle_watchdog=0. The request did not fail because dispatch had a fixed
  total runtime limit.
- Pi persisted `api=openai-responses`, `provider=newapi`, `model=gpt-6-luna`
  and the exact stream error on all three attempts. It had received partial
  response content before failure; no complete terminal result was available.

The precise socket teardown inside the reload was not packet-captured or
actively reproduced against production. The repeated cross-layer timestamps,
the configured timer, and the unconditional reload code provide strong causal
evidence; do not describe this investigation as a controlled production test.

## Source inspected

- Local `ccodex-rotate/cmd/ccodex-rotate/main.go:348`: configured minute ticker
  calls `RefreshProviders` and logs refresh completion afterward.
- Local `ccodex-rotate/internal/mihomo/manager.go:558`: regenerate configuration
  and call `Reload` even without an explicit equality check.
- Local `ccodex-rotate/internal/mihomo/manager.go:581`: `PUT /configs?force=true`.
- Local `ccodex-rotate/internal/proxy/server.go:650`: log stream-copy error and
  rotate egress for subsequent requests; do not replay a partially delivered
  response as though it had not started.
- [Mihomo v1.19.31 configuration route](https://raw.githubusercontent.com/MetaCubeX/mihomo/v1.19.31/hub/route/configs.go)
  forwards the force flag to ApplyConfig.
- [Mihomo v1.19.31 executor](https://raw.githubusercontent.com/MetaCubeX/mihomo/v1.19.31/hub/executor/executor.go)
  applies the full configuration, including proxy/provider and listener updates.

## Work preservation and separate observation

All three attempts reused session
`/Users/chiangguantik/.multica/pi-sessions/20260831T022524.939141000.jsonl`
and checkout
`/Users/chiangguantik/multica_workspaces/410ade5e-8ae0-4402-b975-813dea2ff3e1/01a055a2/workdir/open-agent-cluster`.
The current PR head remains `5004311a706b37bf9d862426611cdb3c4d2dbc35`.
Uncommitted dispatch source/tests, staged run.go changes and helper files remain
present. Binary staged/unstaged patches, helper files and verification YAML were
backed up with hashes under `/tmp/oac-dispatch-preserved-20260926-155401`.
No checkout reset, cleanup or resubmission was performed.

There was also an independent context-window error at 06:41:09, followed by a
Pi compaction event. It does not explain the three hourly stream breaks.

## Remediation direction

Avoid unconditional periodic full reload while long-lived responses are active.
An operational mitigation is to disable scheduled full refresh until a safe
refresh/reload policy is deployed; apply it deliberately because the timer is
created at process startup. A code fix should preserve active streams, avoid
no-change reloads and validate any provider-only refresh approach. Do not assume
changing `force=true` to false alone removes the whole ApplyConfig path.

Preserve the existing dispatch work and resume through OMAC only after its own
fixes and the upstream stream-stability issue are addressed. Do not substitute
more retry attempts for either fix.
