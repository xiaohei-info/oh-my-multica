# Minimal Runtime MCP purpose literal correction

User authorizes independently reviewed acceptable B amendments. No plan pipeline or new architecture. Existing node runtime-sdk-mcp-launch-compatibility / issue01a0f017-0014-7e9b-846e-ed9f33477036 was created by reviewed Audit scope amendment. Worker Run01a0f017-7fd7 completed without coding with a genuine concrete contract contradiction: task prose specifies mcp-http-header while SDK/shared AgentRun/MCP types and owning security docs use mcp-http-auth. Coordinator freshly read all named lines: runtime-sdk/sdk.go230/360, contracts/agentrun/agentrun.go418, internal/mcp/types.go46; docs/security448/reference438/451/runtime198 consistently define mcp-http-auth.

Request Planner/independentReviewer to correct only erroneous credential purpose literal(s) and clarify handoff against current owning authority. Preserve actual transport-specific credential checks and secret boundaries, primary SDK ownership and narrow supporting launch fixture scope, complete gates/90%/package evidence, deps and174nodes/57done. Do not add an alias, change public types/security docs to suit erroneous task prose, widen scope or redesign runtime. Verify exact current full contract differences; the default request is replacing mistaken mcp-http-header with canonical mcp-http-auth, not authorizing any new purpose. All normal verification still required. Preserve healthy developers/reviews and old audit history; no manual baseline/counter edits. Keep previous blocker report as history, use normal admitted amendment and its minimumauthoringrecovery. If admission needs operatorretry do not Workerdispatch until correctionapplied.

Original blocker/results:
{
  "status": "WorkItemStatus.BLOCKED",
  "phase": "TaskPhase.AUTHORING",
  "verdict": null,
  "decision": {
    "schema": "omac.decision-required/v1",
    "reason_code": "worker-decision-required",
    "kind": "develop",
    "phase": "authoring",
    "gate": "worker",
    "resume_issue_id": "01a0f017-0014-7e9b-846e-ed9f33477036",
    "review_context_binding": {
      "generation": null,
      "contract_sha256": "1d98bbafa3e05614e7782b11c3f9575ef757b1d17a2187beea249f4cc76e2fc4"
    },
    "blocker": {
      "schema": "omac.worker-blocker/v2",
      "reason_code": "owner-decision-required",
      "issue_id": "01a0f017-0014-7e9b-846e-ed9f33477036",
      "review_context_binding": {
        "generation": null,
        "contract_sha256": "1d98bbafa3e05614e7782b11c3f9575ef757b1d17a2187beea249f4cc76e2fc4"
      },
      "handoff_generation": "handoff-59c4205f95329e2b",
      "worker": "codex-ubuntu-newapi",
      "run_id": "01a0f017-7fd7-7dca-b4cb-25acf4f72d57",
      "summary": "The task contract names the HTTP credential purpose mcp-http-header, while the shared contract, MCP catalog, validators, and owning security design use mcp-http-auth.",
      "decision_needed": "Confirm that mcp-http-auth is the canonical HTTP-header purpose for this scoped repair, or authorize updating the shared contract and owning documentation to mcp-http-header.",
      "contract_ref": "non_goals",
      "evidence": [
        {
          "ref": "runtime-sdk/sdk.go:230,360; contracts/agentrun/agentrun.go:418; internal/mcp/types.go:46",
          "observation": "The SDK, AgentRun launch contract, and MCP catalog all define and validate the HTTP-header purpose as mcp-http-auth; no mcp-http-header token exists in the checked source."
        },
        {
          "ref": "docs/design/detailed/09-governance-and-security-detailed-design.md:448; docs/references/governance/security-and-enterprise.md:438,451; docs/references/execution/agent-runtime.md:198",
          "observation": "The owning security and runtime references also specify mcp-http-auth. The task limits supporting edits to existing consumer fixtures/tests and forbids changing contracts or runtime launch validation, so switching only the SDK would create divergent purpose validation."
        }
      ]
    },
    "next_action": "Resolve the reported decision, then explicitly run omac node retry <manifest> runtime-sdk-mcp-launch-compatibility"
  },
  "latest": [
    {
      "id": "01a0f017-7fd7-7dca-b4cb-25acf4f72d57",
      "status": "completed",
      "error": null,
      "result": {
        "output": "OMAC accepted a structured blocker and stopped the task. I made no code changes.\n\nThe task contract specifies `mcp-http-header`, while the shared types and security docs specify `mcp-http-auth`. The scope forbids changing those shared contracts. Please confirm which purpose is canonical, or authorize expanding the scope to update the shared contracts and docs.",
        "pr_url": "",
        "session_id": "01a0f017-a452-7aa0-a277-cdcc278bde7e",
        "work_dir": "/home/ubuntu/multica_workspaces/guantik-ait-813dea2ff3e1/aiteam-1023-25acf4f72d57/workdir"
      }
    }
  ]
}
